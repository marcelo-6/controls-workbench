'''***************************************************************************************************
	Procedure:          WM_API.WebApp
	Create Date:       	13Nov24
	Author:             Marcelo Amorim
	Description:        See documentation for more info on this script.
	Used By:			PAT objects
	****************************************************************************************************
	SUMMARY OF CHANGES
	Version		Date(ddMMMyy)	Author		Comments
	----------------------------------------------------------------------------------------------------
	1.0			13Nov24			MA			Created
	***************************************************************************************************'''
########################################################################################################
##### Single httpClient object instance for connection to API
##### Global variables
########################################################################################################
client = system.net.httpClient(version="HTTP_1_1", timeout=10000) # uvicorn doesnt use HTTP2?
api_root = "/api/"
## Dynamically select ip based on system
try:
	ip = "10.37.102.30"
	if 'DEV' in system.tag.readBlocking(tagPaths=["[System]Gateway/SystemName"])[0].value:
		pass
	else:
		ip = "10.37.100.25"
except:
	pass
port = "8000"
base_url = ip + ":" + port
import json
import base64
import urllib2
import os
import io
import itertools
import mimetools
import mimetypes
from StringIO import StringIO
import  java.lang.Exception

def get_ip():
	return ip

def heartbeat():
	"""
	Checks the health of the API.
	
	Returns
	-------
	bool
	    True if the web app is running/healthy, False otherwise.
	"""
	try:
		url = 'http://{0}{1}{2}'.format(base_url,api_root,"health/")
		response = client.get(url)
		
		if response.statusCode == 200 and response:
			return True
		else:
			return False
	except Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Arguments:\n{1!r}"
		message = template.format(base_url, type(e).__name__, e.args)
		print(message)
		return False
	except java.lang.Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Exception:\n{2}"
		message = template.format(base_url, type(e).__name__, str(e))
		print(message)
		return False
		
def predict(input_data, ml_model_name, ml_model_version):
	"""
	Sends a prediction request to the /model/predict endpoint.
	
	Parameters
	----------
	input_data : str
	    Input data for the prediction.
	ml_model_name : str
	    Name of the ML model to use.
	ml_model_version : int
	    Version of the ML model to use.
	
	Returns
	-------
	response : str
	    Response from the prediction API.
	"""
	try:
		headers = {"Content-Type":"application/json"}
		payload = {
					"input_data":input_data,
					"ml_model_name":ml_model_name,
					"ml_model_version":ml_model_version
		}
		url = 'http://{0}{1}{2}'.format(base_url,api_root,"model/predict")
		
		response = client.post(url,headers=headers,data=payload)
		
		return response
	except Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Arguments:\n{1!r}"
		message = template.format(base_url, type(e).__name__, e.args)
		print(message)
		raise e
		return None
	except java.lang.Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Exception:\n{2}"
		message = template.format(base_url, type(e).__name__, str(e))
		print(message)
		raise e
		return None
		
def get_results(task_id):
	"""
	Retrieves the result of a prediction by task ID.
	
	Parameters
	----------
	task_id : str
	    The ID of the task to retrieve results for.
	
	Returns
	-------
	response : str
	    Response from the result API.
	"""
	try:
		url = 'http://{0}{1}{2}{3}'.format(base_url,api_root,"model/result/",task_id)
		
		response = client.get(url)
		
		return response
	except Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Arguments:\n{1!r}"
		message = template.format(base_url, type(e).__name__, e.args)
		print(message)
		raise e
		return None
	except java.lang.Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Exception:\n{2}"
		message = template.format(base_url, type(e).__name__, str(e))
		print(message)
		raise e
		return None

def get_models(model_filter = None, order_by = None):
	"""
	Retrieves the latest models from the /model/models/latest endpoint.

	Parameters
	----------
	model_filter : str
	    filter string, can be "name LIKE 'test%'" or "tags.stage = 'production'"
	order_by : str
		Use order_by to sort results by fields such as 'name ASC' for alphabetical order.

	Returns
	-------
	response : str
	    Response from the models API.
	"""
	try:
		url = 'http://{0}{1}{2}'.format(base_url,api_root,"model/models/latest")
		payload = {
			"filter_string":model_filter,
			"order_by":order_by
			}
		
		response = client.get(url, params=payload)
		
		return response
	except Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Arguments:\n{1!r}"
		message = template.format(base_url, type(e).__name__, e.args)
		print(message)
		raise e
		return None
	except java.lang.Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Exception:\n{2}"
		message = template.format(base_url, type(e).__name__, str(e))
		print(message)
		raise e
		return None



def post_register_model(model_metadata, model_bytes):
    """
    Registers a model by sending a POST request to the /api/model/register endpoint with metadata and the model file in bytes.

    Parameters
    ----------
    model_metadata : dict
        A dictionary containing model metadata, including `ml_model_name`, `ml_model_description`, and `ml_model_tags`.

    model_bytes : bytes
        The model file content in bytes.

    Returns
    -------
    response : str
        The response from the model registration API.
    """
    import mimetools
    import json
    import urllib2
    from StringIO import StringIO

    # Logger for debugging
    logging = system.util.getLogger("PAT.registry")

    try:
    	# Create the form
    	form = MultiPartForm()
    	
    	# Add metadata as a field
    	model_metadata = {
            "ml_model_name": model_metadata.get("ml_model_name"),
            "ml_model_description": model_metadata.get("ml_model_description", ""),
            "ml_model_change_description": model_metadata.get("ml_model_change_description", ""),
            "ml_model_tags": model_metadata.get("ml_model_tags", {})
    	}
    	form.add_field('ml_model_metadata', json.dumps(model_metadata))
    	
    	# Add the pickle file
    	form.add_file('file', "model.pkl", model_bytes)
    	
    	# Build the request 
    	url = "http://{0}{1}{2}".format(base_url, api_root, "model/register")
    	request = urllib2.Request(url)
    	request.add_header('User-Agent', 'FileUploader/1.0')
    	body = str(form)
    	request.add_header('Content-Type', form.get_content_type())
    	request.add_header('Content-Length', str(len(body)))
    	request.add_data(body)

        # Send the request
        response = urllib2.urlopen(request, timeout=10)

        # Return the response content
        return response

    except Exception as e:
        # Log and handle general exceptions
        message = "Exception occurred: {}".format(str(e))
        logging.error(message)
        return message

    except java.lang.Exception as e:
        # Log and handle Java exceptions
        message = "Java Exception occurred: {}".format(str(e))
        logging.error(message)
        return message

def put_archive_model(model_name, model_metadata):
	"""
	Archives the given model. 
	Update the metadata for the specified model using the PUT /api/model/{model_name}/update-metadata endpoint.
	
	Parameters
	----------
	model_name : str
	    The name of the model to update.
	metadata : dict
	    A dictionary containing the updated metadata for the model.
	    
	Returns
	-------
	response : dict
	    The response from the API, parsed as a dictionary.
	"""

	try:
		# Prepare the URL with model_name
		url = 'http://{0}{1}model/{2}/update-metadata'.format(base_url, api_root, model_name)
		
	    # Prepare the metadata payload (JSON string)
		change_type = model_metadata.get("latest_version", False)
		model_change_description = model_metadata.get("description", "")
		model_tags = model_metadata.get("tags", {})
		
		payload = {
			"latest_version": change_type,
		    "description": model_change_description,
		    "tags": model_tags
		}
		# Prepare the HTTP headers
		headers = {
		    'Content-Type': 'application/json',
		    'Accept': 'application/json'
		}
		
		# with PUT method make request
		response = client.put(url,headers=headers,data=payload)
		
		# Return the parsed response as a dictionary
		return response

	except Exception as e:
		message = "Exception trying {0}, An exception of type {1} occurred. Arguments:\n{1!r}".format(base_url, type(e).__name__, e.args)
		print(message)
		raise e
	except java.lang.Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Exception:\n{2}"
		message = template.format(base_url, type(e).__name__, str(e))
		print(message)
		raise e


def download_model_from_registry(model_name, model_version):
	"""
	Downloads a model (.pkl) file from the FastAPI MLflow registry endpoint.

	Parameters
	----------
	base_url : str
	    Base URL of the FastAPI server (e.g., 'localhost:8000')
	api_root : str
	    Base API path prefix (e.g., '/api/')
	model_name : str
	    Name of the registered MLflow model.
	model_version : str
	    Version of the model to download.
	save_path : str
	    Full path on the local filesystem to save the .pkl file.

	Returns
	-------
	str or None
	    The path where the model was saved, or None if failed.
	"""
	try:
		logging = system.util.getLogger("PAT.registry")
		url = "http://{0}{1}model/models/{2}/versions/{3}/download".format(
			base_url, api_root, model_name, model_version
		)
		
		headers = {"Accept": "application/octet-stream"}

		client = system.net.httpClient()
		response = client.get(url, headers)
		status_code = response.getStatusCode()
		
		if status_code == 200:
			
			# Trigger browser download in Perspective
			system.perspective.download("{}-v{}.pkl".format(model_name,model_version), response.body)
		else:
			system.perspective.print("Download failed with status: " + str(response))

		return response

	except Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Arguments:\n{2!r}"
		message = template.format(url, type(e).__name__, e.args)
		system.perspective.print(message)
		raise e
		return None

	except java.lang.Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Exception:\n{2}"
		message = template.format(url, type(e).__name__, str(e))
		system.perspective.print(message)
		raise e
		return None
		
def get_all_models(model_filter = None, max_results = 100, order_by = None):
	try:
		url = 'http://{0}{1}{2}'.format(base_url,api_root,"model/models")
		system.perspective.print(url)
		payload = {
			"filter_string": model_filter,
			"max_result": max_results,
			"order_by": order_by
			}
		system.perspective.print(123)
		response = client.get(url, params=payload)
#		system.perspective.print(123)
		
		return response
	except Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Arguments:\n{1!r}"
		message = template.format(base_url, type(e).__name__, e.args)
		print(message)
		raise e
		return None
	except java.lang.Exception as e:
		template = "Exception trying {0}, An exception of type {1} occurred. Exception:\n{2}"
		message = template.format(base_url, type(e).__name__, str(e))
		print(message)
		raise e
		return None

class MultiPartForm(object):
    """Accumulate the data to be used when posting a form."""
    #  (the built-in Ignition's httpclient doesnt support multi-form post requests so we implement our own)
    # from https://gist.github.com/zhenyi2697/5252801#file-urllib2_upload-py-L11

    def __init__(self):
        self.form_fields = []
        self.files = []
        self.boundary = mimetools.choose_boundary()
    
    def get_content_type(self):
        return 'multipart/form-data; boundary=%s' % self.boundary

    def add_field(self, name, value):
        """Add a simple field to the form data."""
        self.form_fields.append((name, value))
    
    def add_file(self, fieldname, filename, filedata, mimetype=None):
        """Add a file to be uploaded."""
        body = filedata
        if mimetype is None:
            mimetype = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
        # --- NEW: make sure body is a *str* (unicode) but with 1‑to‑1 bytes ---
#	    if isinstance(filedata, (bytearray, bytes)):
#	        # bytes(..) -> CPython, but in Jython convert explicitly
#	        body = filedata.decode('iso-8859-1')   # ← key line
#	    else:
#	        # already a str coming from open('rb') in Jython – keep as‑is
#	        body = filedata
        self.files.append((fieldname, filename, mimetype, body))
    
    def __str__(self):
        """Return a string representing the form data, including attached files."""
        parts = []
        part_boundary = '--' + self.boundary
        
        # Add the form fields
        parts.extend(
            [part_boundary,
             'Content-Disposition: form-data; name="%s"' % name,
             '',
             value]
            for name, value in self.form_fields
        )
        
        # Add the files to upload
        parts.extend(
            [part_boundary,
             'Content-Disposition: file; name="%s"; filename="%s"' % (field_name, filename),
             'Content-Type: %s' % content_type,
             '',
             body]
            for field_name, filename, content_type, body in self.files
        )
        
        # Flatten the list and add closing boundary marker
        flattened = list(itertools.chain(*parts))
        flattened.append('--' + self.boundary + '--')
        flattened.append('')
        return '\r\n'.join(flattened)

def toPredictionEndpoint(result, model_name, model_version):
	formatted_data = '\n'.join(['{},{}'.format(key, value) for key, value in result["combinedData"].items()])
	response = WM_API.WebApp.predict(input_data=formatted_data, ml_model_name=model_name, ml_model_version=model_version)
	# send results back to the GUI
	def sendBack(response = response):
		task_id = response.json['data']['task_id']
		request_status = response.statusCode
		tagPaths=["[default]RBP/IO/Marqmetrix01/Val_TaskID"]
		system.tag.writeBlocking(tagPaths, values=[task_id])
	system.util.invokeLater(sendBack)