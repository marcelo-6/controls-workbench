"""
Heartbeat / watchdog checks for PAT instruments.

State (caches + latches) is stored in system.util.globals so it survives
script reloads while the gateway is running.

Supports two modes per instrument family:
    - Small systems: browse UDT instances by typeId under TAG_BROWSE_ROOT.
    - Big systems:  hard-code UDT instance paths in STATIC_*_INSTANCES 
                    (use only if you need to keep a short heartbeat and a broad browse takes > ~5sec)

All HTTP work runs in background threads via system.util.invokeAsynchronous,
and each instance has its own AtomicBoolean latch so at most one 60s
heartbeat per device is ever in-flight at a time.

Enable debug level for PAT.Heartbeat logger to debug any issues

"""

from java.util.concurrent.atomic import AtomicBoolean

logger = system.util.getLogger("PAT.Heartbeat")
logger.debug("PAT.heartbeat module loaded / reloaded")

# ---------------------------------------------------------------------------
# CONFIG – tweak for your system
# ---------------------------------------------------------------------------

TAG_BROWSE_ROOT = "[default]PAT/IO"

# UDT typeIds (to obtain it right click on an instance and "edit raw", 
# but should be the full path of the UDT definition (e.g. PAT/WM_Irubis_UDT)
UDT_TYPE_RAMAN   = "PAT/WM_RAMAN_MarqMetrix_UDT"
UDT_TYPE_MIR     = "PAT/WM_Irubis_UDT"
UDT_TYPE_NIR     = "PAT/WM_PAT_NIR_Avantes_UDT"
UDT_TYPE_WEBAPP  = "PAT/WM_PAT_Diagnostics_UDT"

# Per-family mode toggles:
# - True  → use browse + STATIC_*_INSTANCES
# - False → use STATIC_*_INSTANCES only (no browse, good for big systems)
USE_BROWSE_FOR_RAMAN  = True
USE_BROWSE_FOR_MIR    = True
USE_BROWSE_FOR_NIR    = True
USE_BROWSE_FOR_WEBAPP = True

# Static instance paths (for big systems, or to pin specific instances)
STATIC_RAMAN_INSTANCES = [
    # "[default]PAT/IO/MarqMetrix_01",
]
STATIC_MIR_INSTANCES = [
    # "[default]PAT/IO/Irubis",
]
STATIC_NIR_INSTANCES = [
    # "[default]PAT/IO/Avantes_01",
]
STATIC_WEBAPP_INSTANCES = [
    # "[default]PAT/IO/WebApp_01",
]

# Common relative paths inside UDT instances
TAG_HEARTBEAT_REL        = "/CM/Sts_Available"
TAG_HEARTBEAT_REL_WEBAPP = "/WebApp/Sts_Available"
TAG_INTERLOCK_REL        = "/CM/Sts_InterlocksMet"

IP_REL     = "/Parameters/EP/0/Val_String"
PORT_REL   = "/Parameters/EP/1/Val_String"
APIKEY_REL = "/CM/Val_APIKey"   # used by Marq


# Refresh browsed instances every N seconds
DISCOVERY_PERIOD_SEC = 300

# Key under system.util.globals where we store state
STATE_KEY = "PAT_HEARTBEAT_STATE"


# ---------------------------------------------------------------------------
# GLOBAL STATE via system.util.globals
# ---------------------------------------------------------------------------

def _get_state():
    """
    Get or initialize the heartbeat state dict stored in system.util.globals.

    Structure:
        {
          'raman_dynamic': [...],
          'mir_dynamic':   [...],
          'nir_dynamic':   [...],
          'webapp_dynamic': [...],
          'last_discovery': <java.util.Date or None>,
          'raman_flags':  {path: AtomicBoolean},
          'mir_flags':    {path: AtomicBoolean},
          'nir_flags':    {path: AtomicBoolean}
        }
    """
    g = system.util.globals
    state = g.get(STATE_KEY)
    if state is None:
        logger.debug("Initializing PAT heartbeat state at globals['%s']" % STATE_KEY)
        state = {
            'raman_dynamic': [],
            'mir_dynamic':   [],
            'nir_dynamic':   [],
            'webapp_dynamic': [],
            'last_discovery': None,
            'raman_flags':  {},
            'mir_flags':    {},
            'nir_flags':    {},
            'webapp_flags': {},
        }
        g[STATE_KEY] = state
    else:
        logger.debug(
            "Retrieved existing PAT heartbeat state from globals['%s']; keys=%s"
            % (STATE_KEY, list(state.keys()))
        )
    return state


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _stable_union(static_list, dynamic_list):
    """Static first, then dynamic elements not in static_list."""
    logger.debug(
        "stable_union: static_count=%d dynamic_count=%d"
        % (len(static_list), len(dynamic_list))
    )
    seen = set(static_list)
    out = list(static_list)
    for p in dynamic_list:
        if p not in seen:
            out.append(p)
            seen.add(p)
    logger.debug("stable_union: result_count=%d" % len(out))
    return out


def _get_flag(flag_dict, path):
    """Get or create AtomicBoolean latch for a given path."""
    flag = flag_dict.get(path)
    if flag is None:
        logger.debug("Creating new AtomicBoolean latch for path: %s" % path)
        flag = AtomicBoolean(False)
        flag_dict[path] = flag
    return flag


# ---------------------------------------------------------------------------
# Instance discovery
# ---------------------------------------------------------------------------

def _browse_udt_instances(type_id):
    """
    Return list of full tag paths for UDT instances of typeId under TAG_BROWSE_ROOT.
    Ignition 8+ only (system.tag.browse).
    """
    logger.debug(
        "Browsing for UDT instances: root=%s typeId=%s"
        % (TAG_BROWSE_ROOT, type_id)
    )
    results = system.tag.browse(
        TAG_BROWSE_ROOT,
        {"tagType": "UdtInstance", "typeId": type_id, "recursive": True}
    )
    paths = []
    for r in results.getResults():
        fp = str(r["fullPath"])
        paths.append(fp)
        logger.debug("  Found UDT instance: %s" % fp)
    logger.debug(
        "Browse complete for typeId=%s; found=%d" % (type_id, len(paths))
    )
    return paths


def refreshInstances():
    """
    Force a re-browse of UDT instances (for families where browse is enabled).
    Stores dynamic instance lists in system.util.globals state.
    """
    logger.info("PAT Heartbeat: refreshInstances() invoked")
    state = _get_state()

    if USE_BROWSE_FOR_RAMAN:
        logger.debug("  Browsing RAMAN instances (typeId=%s)" % UDT_TYPE_RAMAN)
        state['raman_dynamic'] = _browse_udt_instances(UDT_TYPE_RAMAN)
    else:
        logger.debug("  Skipping RAMAN browse (USE_BROWSE_FOR_RAMAN=False)")
        state['raman_dynamic'] = []

    if USE_BROWSE_FOR_MIR:
        logger.debug("  Browsing MIR instances (typeId=%s)" % UDT_TYPE_MIR)
        state['mir_dynamic'] = _browse_udt_instances(UDT_TYPE_MIR)
    else:
        logger.debug("  Skipping MIR browse (USE_BROWSE_FOR_MIR=False)")
        state['mir_dynamic'] = []

    if USE_BROWSE_FOR_NIR:
        logger.debug("  Browsing NIR instances (typeId=%s)" % UDT_TYPE_NIR)
        state['nir_dynamic'] = _browse_udt_instances(UDT_TYPE_NIR)
    else:
        logger.debug("  Skipping NIR browse (USE_BROWSE_FOR_NIR=False)")
        state['nir_dynamic'] = []

    if USE_BROWSE_FOR_WEBAPP:
        logger.debug("  Browsing WebApp instances (typeId=%s)" % UDT_TYPE_WEBAPP)
        state['webapp_dynamic'] = _browse_udt_instances(UDT_TYPE_WEBAPP)
    else:
        logger.debug("  Skipping WebApp browse (USE_BROWSE_FOR_WEBAPP=False)")
        state['webapp_dynamic'] = []

    state['last_discovery'] = system.date.now()

    logger.info(
        "Heartbeat discovery (dynamic only): Raman=%d, MIR=%d, NIR=%d, WebApp=%d"
        % (
            len(state['raman_dynamic']),
            len(state['mir_dynamic']),
            len(state['nir_dynamic']),
            len(state['webapp_dynamic']),
        )
    )


def _ensureInstances():
    """Refresh dynamic instance lists periodically, not every heartbeat tick."""
    state = _get_state()
    last = state['last_discovery']
    now = system.date.now()
    if last is None:
        logger.debug("No previous discovery; calling refreshInstances() now")
        refreshInstances()
        return
    age_sec = system.date.secondsBetween(last, now)
    logger.debug(
        "Last discovery age: %ds (threshold=%ds)"
        % (age_sec, DISCOVERY_PERIOD_SEC)
    )
    if age_sec >= DISCOVERY_PERIOD_SEC:
        logger.debug("Discovery threshold reached; refreshing instances")
        refreshInstances()
    else:
        logger.debug("Discovery still fresh; reusing existing instance lists")


# Public getters: static + dynamic per family

def getRamanInstances():
    s = _get_state()
    paths = _stable_union(STATIC_RAMAN_INSTANCES, s['raman_dynamic'])
    logger.debug("Raman instance list: %s" % paths)
    return paths


def getMIRInstances():
    s = _get_state()
    paths = _stable_union(STATIC_MIR_INSTANCES, s['mir_dynamic'])
    logger.debug("MIR instance list: %s" % paths)
    return paths


def getNIRInstances():
    s = _get_state()
    paths = _stable_union(STATIC_NIR_INSTANCES, s['nir_dynamic'])
    logger.debug("NIR instance list: %s" % paths)
    return paths


def getWebAppInstances():
    s = _get_state()
    paths = _stable_union(STATIC_WEBAPP_INSTANCES, s['webapp_dynamic'])
    logger.debug("WebApp instance list: %s" % paths)
    return paths


# ---------------------------------------------------------------------------
# WebApp heartbeat
# ---------------------------------------------------------------------------

def _check_webapp_udt_for_instance(base_path):
    try:
        import WM_API.WebApp
        logger.debug(
            "WebApp UDT heartbeat: base_path=%s; calling WM_API.WebApp.heartbeat()"
            % base_path
        )
        status = WM_API.WebApp.heartbeat()
        path = base_path + TAG_HEARTBEAT_REL_WEBAPP
        logger.debug(
            "WebApp UDT heartbeat: writing status=%r to tag %s"
            % (status, path)
        )
        system.tag.writeBlocking([path], [status])
    except Exception, exc:
        logger.error("WebApp UDT heartbeat failed for %s: %r" % (base_path, exc))
    finally:
        state = _get_state()
        _get_flag(state['webapp_flags'], base_path).set(False)


def scheduleWebAppUDTs():
    state = _get_state()
    instances = getWebAppInstances()
    logger.debug("Scheduling WebApp UDT heartbeats for instances: %s" % instances)
    for base_path in instances:
        flag = _get_flag(state['webapp_flags'], base_path)
        if not flag.compareAndSet(False, True):
            logger.debug(
                "Skipping WebApp heartbeat for %s; previous call still in-flight"
                % base_path
            )
            continue

        logger.debug("Scheduling WebApp heartbeat (async) for %s" % base_path)

        def _runner(path=base_path):
            start = system.date.now()
            try:
                _check_webapp_udt_for_instance(path)
            finally:
                dur_ms = system.date.millisBetween(start, system.date.now())
                logger.debug(
                    "WebApp UDT heartbeat for %s completed in %.3fs"
                    % (path, dur_ms / 1000.0)
                )

        system.util.invokeAsynchronous(_runner)


# ---------------------------------------------------------------------------
# Raman (MarqMetrix)
# ---------------------------------------------------------------------------

def _check_raman_for_instance(base_path):
    import WM_API.Marqmetrix
    state = _get_state()
    start = system.date.now()
    try:
        paths = [
            base_path + IP_REL,
            base_path + PORT_REL,
            base_path + APIKEY_REL,
        ]
        logger.debug(
            "Raman heartbeat: reading IP/Port/APIKey tags for %s -> %s"
            % (base_path, paths)
        )
        qvs = system.tag.readBlocking(paths)
        ip      = qvs[0].value
        port    = qvs[1].value
        api_key = qvs[2].value

        logger.debug(
            "Raman heartbeat: base_path=%s ip=%r port=%r (api_key length=%s)"
            % (base_path, ip, port,
               (len(api_key) if api_key is not None else "None"))
        )

        logger.debug("Raman heartbeat: calling dev_get_heartbeat()")
        hb = WM_API.Marqmetrix.dev_get_heartbeat(ip, port, api_key)

        logger.debug("Raman heartbeat: calling instrument_get_instrument_interlcoks()")
        interlocks = WM_API.Marqmetrix.instrument_get_instrument_interlcoks(
            ip, port, api_key
        )

        write_paths = [
            base_path + TAG_HEARTBEAT_REL,
            base_path + TAG_INTERLOCK_REL,
        ]
        logger.debug(
            "Raman heartbeat: writing hb=%r interlocks=%r to %s"
            % (hb, interlocks, write_paths)
        )
        system.tag.writeBlocking(write_paths, [hb, interlocks])

    except Exception, exc:
        logger.error("Raman/MarqMetrix heartbeat failed for %s: %r" % (base_path, exc))
    finally:
        dur_ms = system.date.millisBetween(start, system.date.now())
        logger.debug(
            "Raman heartbeat for %s completed in %.3fs"
            % (base_path, dur_ms / 1000.0)
        )
        _get_flag(state['raman_flags'], base_path).set(False)


def scheduleRaman():
    state = _get_state()
    instances = getRamanInstances()
    logger.debug("Scheduling Raman heartbeats for instances: %s" % instances)
    for base_path in instances:
        flag = _get_flag(state['raman_flags'], base_path)
        if not flag.compareAndSet(False, True):
            logger.debug(
                "Skipping Raman heartbeat for %s; previous call still in-flight"
                % base_path
            )
            continue

        logger.debug("Scheduling Raman heartbeat (async) for %s" % base_path)

        def _runner(path=base_path):
            _check_raman_for_instance(path)

        system.util.invokeAsynchronous(_runner)


# ---------------------------------------------------------------------------
# MIR (Irubis)
# ---------------------------------------------------------------------------

def _check_mir_for_instance(base_path):
    import WM_API.Irubis
    state = _get_state()
    start = system.date.now()
    try:
        paths = [
            base_path + IP_REL,
            base_path + PORT_REL,
        ]
        logger.debug(
            "MIR heartbeat: reading IP/Port tags for %s -> %s"
            % (base_path, paths)
        )
        qvs = system.tag.readBlocking(paths)
        ip   = qvs[0].value
        port = qvs[1].value

        logger.debug(
            "MIR heartbeat: base_path=%s ip=%r port=%r"
            % (base_path, ip, port)
        )

        logger.debug("MIR heartbeat: calling WM_API.Irubis.heartbeat()")
        hb = WM_API.Irubis.heartbeat(ip, port)

        logger.debug("MIR heartbeat: calling WM_API.Irubis.get_alarms()")
        interlocks = WM_API.Irubis.get_alarms(ip, port)

        write_paths = [
            base_path + TAG_HEARTBEAT_REL,
            base_path + TAG_INTERLOCK_REL,
        ]
        logger.debug(
            "MIR heartbeat: writing hb=%r interlocks=%r to %s"
            % (hb, interlocks, write_paths)
        )
        system.tag.writeBlocking(write_paths, [hb, interlocks])

    except Exception, exc:
        logger.error("MIR/Irubis heartbeat failed for %s: %r" % (base_path, exc))
    finally:
        dur_ms = system.date.millisBetween(start, system.date.now())
        logger.debug(
            "MIR heartbeat for %s completed in %.3fs"
            % (base_path, dur_ms / 1000.0)
        )
        _get_flag(state['mir_flags'], base_path).set(False)


def scheduleMIR():
    state = _get_state()
    instances = getMIRInstances()
    logger.debug("Scheduling MIR heartbeats for instances: %s" % instances)
    for base_path in instances:
        flag = _get_flag(state['mir_flags'], base_path)
        if not flag.compareAndSet(False, True):
            logger.debug(
                "Skipping MIR heartbeat for %s; previous call still in-flight"
                % base_path
            )
            continue

        logger.debug("Scheduling MIR heartbeat (async) for %s" % base_path)

        def _runner(path=base_path):
            _check_mir_for_instance(path)

        system.util.invokeAsynchronous(_runner)


# ---------------------------------------------------------------------------
# NIR (skeleton – hook to your Avantes / NIR API when ready)
# ---------------------------------------------------------------------------

def _check_nir_for_instance(base_path):
    state = _get_state()
    start = system.date.now()
    try:
        from PAT.cm.nir import NirCM

        cm = NirCM(base_path)

        paths = [
            base_path + IP_REL,
            base_path + PORT_REL,
        ]
        logger.debug(
            "NIR heartbeat: reading IP/Port tags for %s -> %s"
            % (base_path, paths)
        )
        qvs = system.tag.readBlocking(paths)
        ip   = qvs[0].value
        port = qvs[1].value

        logger.debug(
            "NIR heartbeat: base_path=%s ip=%r port=%r"
            % (base_path, ip, port)
        )

        logger.debug("NIR heartbeat: calling PAT.cm.nir.NirCM.api_health()")
        hb = cm.api_health()

        write_paths = [
            base_path + TAG_HEARTBEAT_REL,
        ]
        logger.debug(
            "NIR heartbeat: writing hb=%r %s"
            % (hb, write_paths)
        )
        system.tag.writeBlocking(write_paths, [hb])

    except Exception, exc:
        logger.error("NIR heartbeat failed for %s: %r" % (base_path, exc))
    finally:
        dur_ms = system.date.millisBetween(start, system.date.now())
        logger.debug(
            "NIR heartbeat for %s completed in %.3fs"
            % (base_path, dur_ms / 1000.0)
        )
        _get_flag(state['nir_flags'], base_path).set(False)


def scheduleNIR():
    state = _get_state()
    instances = getNIRInstances()
    logger.debug("Scheduling NIR heartbeats for instances: %s" % instances)
    for base_path in instances:
        flag = _get_flag(state['nir_flags'], base_path)
        if not flag.compareAndSet(False, True):
            logger.debug(
                "Skipping NIR heartbeat for %s; previous call still in-flight"
                % base_path
            )
            continue

        logger.debug("Scheduling NIR heartbeat (async) for %s" % base_path)

        def _runner(path=base_path):
            _check_nir_for_instance(path)

        system.util.invokeAsynchronous(_runner)


# ---------------------------------------------------------------------------
# PUBLIC ENTRYPOINT
# ---------------------------------------------------------------------------

def run():
    """
    Entry point for Gateway Timer Script.

    - Refreshes browsed instance lists on a fixed period.
    - Schedules:
        * Legacy WebApp heartbeat
        * Optional WebApp UDT heartbeats
        * Raman, MIR, NIR heartbeats
    - Uses system.util.globals to store state + latches.
    """
#    return
    logger.debug("PAT Heartbeat: run() invoked")
    _ensureInstances()

    logger.debug("PAT Heartbeat: scheduling WebApp heartbeats")
    if USE_BROWSE_FOR_WEBAPP or STATIC_WEBAPP_INSTANCES:
        scheduleWebAppUDTs()

    logger.debug("PAT Heartbeat: scheduling instrument heartbeats")
    scheduleRaman()
    scheduleMIR()
    scheduleNIR()
    logger.debug("PAT Heartbeat: run() scheduling cycle complete")