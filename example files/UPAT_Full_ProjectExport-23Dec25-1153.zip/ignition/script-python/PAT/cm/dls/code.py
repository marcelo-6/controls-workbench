"""PAT.cm.dls
---------------------------------
Control‑Module wrapper for the **DLS** (Dynamic Light Scattering) instrument
using the new PAT framework.

*   **CM** purely talks to tags and *summarises* the current state; it
    never blocks or loops.
*   When a *Stop* is issued while the instrument is still *Measuring* it 
    will **finish the last measurement first**.
    The CM flags this via ``{"stopping": True}``.
*   Uses timestamps of the X/Y array tags to recognise fresh data even
    if the instrument restarts and re‑uses *SampleNumber 1*.

"""

# ────────────────────────────────────────────────────────────────────────────
# stdlib
import json, time
from collections import OrderedDict

# framework
from PAT.cm.base    import BaseCM, CMState
from PAT.em.base     import BaseEM, EMState
from PAT.em.sfc.base import BaseSFC
from PAT.infra       import tagio, log
import PAT.db

__all__ = ["DlsCM"]

# ---------------------------------------------------------------------------
# CM IMPLEMENTATION
# ---------------------------------------------------------------------------
class DlsCM(BaseCM):
	"""Concrete CM for a **DLS** UDT instance.
	
	Tag layout (relative to ``tag_root``)::
	
	    LM/Control/Command                        (Int: 0=Stop, 1=Start(OPC), 2=Start(ProjectFile))
	    LM/Control/Status                         (String: "WaitingForCommand", "Measuring", ...)
	    LM/Measurement/Results/SampleNumber       (Int - instrument’s own counter)  ← update path!
	    LM/Measurement/Results/PSD/Intensity_x    (Double[ ])
	    LM/Measurement/Results/PSD/Intensity_y    (Double[ ])
	    LM/Measurement/Results/Quality            (Int / Float ?)
	
	The framework keeps its *own* monotonically increasing ``self._sample_no``
	because the instrument counter resets after every restart.  Both values are
	shown in the CM/EM messages for traceability.
	"""
	
	# ------------- relative paths (str) -----------------
	TAG_COMMAND       = "/LM/Control/Command"
	TAG_STATUS        = "/LM/Control/Status"
	TAG_INST_SAMPLE   = "/LM/Measurement/Number"
	TAG_QUALITY       = "/LM/Measurement/Results/Quality"
	TAG_X             = "/LM/Measurement/Results/PSD/Intensity_x"
	TAG_Y             = "/LM/Measurement/Results/PSD/Intensity_y"
	TAG_SAMPLE_DATA   = "/LM/Val_SampleData"
	TAG_MEAS_STS_MSG  = "/LM/Measurement/Message"
	
	# Status strings
	STATUS_READY       = "WaitingForCommand"
	STATUS_MEASURING   = "Executing"# v1 of XsperGo used "Measuring"
	
	# Command values
	CMD_STOP            = 0
	CMD_START_OPC_PARAM = 1
	CMD_START_PROJECT   = 2
	
	
	# ----------------------------ctor-------------------------------- 
	def __init__(self, tag_root):
	    super(DlsCM, self).__init__(tag_root)
	    self.log             = log.get("PAT.CM.DLS")
	    self._stop_requested = False        # To handle stopping logic since this instrument is the continous measurement type
	    self._sample_no      = 1            # Our current run counter (can differ from intrument if instrument resets while we are in the same run)
	    self._last_sample    = None         # cache to detect new data
	    self._last_sample_ts = system.date.now()         # timestamp of last sample data
	
	# ----------------------------private helpers----------------------------- 
	#	@staticmethod
	def combine_xy(x_arr, y_arr):
		"""Combine X/Y arrays into the canonical JSON string (ordered)."""
		combined = OrderedDict((str(round(x, 4)), str(y)) for x, y in zip(x_arr, y_arr))
		return json.dumps(combined)
	
	# -----------------------------BaseCM API--------------------------- 
	def start(self, use_project=True):
		"""Issue a *Start* command.  Non‑blocking. use_project will use projecrt file settings instead of OPC parameters"""
		cmd_val = self.CMD_START_PROJECT if use_project else self.CMD_START_OPC_PARAM
		tagio.write_single(self.tag_root + self.TAG_COMMAND, cmd_val)
		self._stop_requested = False
		self.set_state(CMState.READY, "Start command sent")
	
	def stop(self):
		"""Issue a *Stop* command.  Instrument will finish the current sample first."""
		tagio.write_single(self.tag_root + self.TAG_COMMAND, self.CMD_STOP)
		self._stop_requested = True
		self.log.debug("Stop command written")
	#        self.set_state(CMState.STOPPED, "Stop command sent")
	
	# --------------------------public polling helper----------------------- 
	def status_poll(self):
		"""Read status + sample + data, detect fresh sample, handle stop‑in‑progress.
		
		Returns a dict with at least the following keys::
		
		    {
		        "state"        : "Measuring" | "WaitingForCommand" | …,
		        "instr_sample" : 17,            # as read from OPC
		        "new_sample"   : bool,
		        "stopping"     : bool,          # stop issued, still Measuring
		        "stopped"      : bool,          # stop issued & instrument idle
		        # when **new_sample** is True:
		        "data_json"    : "{…}",
		        "x_len"        : 2048,
		    }
		"""
	#		self.log.debug("Polling status out of DLS {}".format(self.tag_root))
		paths = [self.tag_root + p for p in (
		    self.TAG_STATUS,
		    self.TAG_INST_SAMPLE,
		    self.TAG_X,
		    self.TAG_Y,
		    self.TAG_COMMAND,
		    self.TAG_MEAS_STS_MSG,
		)]
		qvs = tagio.read_multi(paths, return_qv=True)  # QualifiedValues keep timestamps
		status           = qvs[0].value
		instr_sample_num = int(qvs[1].value)
		x_arr            = qvs[2].value
		y_arr            = qvs[3].value
		data_ts          = qvs[3].timestamp# max(qvs[2].timestamp, qvs[3].timestamp) # Get newest timestamp
		command          = qvs[4].value
		meas_sts_msg     = qvs[5].value
	#		self.log.debug("Polling status out of DLS - {}-{}-{}".format(status,instr_sample_num,data_ts))
	#		self.log.debug("1. Is {} equal to {}? {}".format(status,self.STATUS_MEASURING, status == self.STATUS_MEASURING))
		
		ret = {
		    "state":        status,
		    "instr_sample": instr_sample_num,
		    "new_sample":   False,
		    "stopping":     False,
		    "stopped":      False,
		    "command":      command,
		    "status_msg":   meas_sts_msg,
		}
	#		self.log.debug("2. Is {} equal to {}? {}".format(status,self.STATUS_MEASURING, status == self.STATUS_MEASURING))
		
		# --------------------stop / stopping flags----------------- 
		if self._stop_requested:
		    if status == self.STATUS_MEASURING:
		        ret["stopping"] = True           # finishing last sample
		    elif status == self.STATUS_READY:
		    	self.set_state(CMState.READY, "Measurement stopped")
		        ret["stopped"]  = True           # completely stopped
		        self._stop_requested = False      # reset latch
		        tagio.write_single(self.tag_root + self.TAG_INST_SAMPLE, 1) # they dont reset the sample number... lets do it
	#		self.log.debug("3.  Is {} equal to {}? {}".format(status,self.STATUS_MEASURING, status == self.STATUS_MEASURING))
		
		# -------------------new‑sample detection----------
	#		self.log.debug("4. Is {} equal to {}? {}".format(status,self.STATUS_MEASURING, status == self.STATUS_MEASURING))
		if status == self.STATUS_MEASURING:
			
			fresh = False
			if data_ts and system.date.isAfter(data_ts, self._last_sample_ts):
				self.log.debug("New sample detected timestamp diff previous={} new={}".format(self._last_sample_ts, data_ts))
				fresh = True                     # timestamp ticked forward
	#			self.log.debug("Polling status out of DLS - fresh data? {}-current data timestamp {} vs last {}".format(fresh,self._last_sample_ts,data_ts))
			if fresh:
				ret.update({
				    "new_sample": True,
				    "data_json" : json.dumps(OrderedDict((str(round(x, 4)), str(y)) for x, y in zip(x_arr, y_arr))),#json.dumps(OrderedDict((str(round(x, 4)), str(y)) for x, y in zip(x_arr, y_arr))), #combine_xy(x_arr, y_arr),
				    "x_len"     : len(x_arr),
				})
				self._last_sample_ts      = data_ts
				if instr_sample_num > 1:
					self.set_state(CMState.SAMPLING, "Sample {} complete".format(instr_sample_num + 1))
				else:
					self.set_state(CMState.SAMPLING, "Sample {} complete".format(instr_sample_num))
				tagio.write_single(self.tag_root + self.TAG_SAMPLE_DATA, ret["data_json"])
				self._last_sample =+ 1
				tagio.write_single(self.tag_root + self._T_SAMPLE_NO, instr_sample_num)
			# raw data not stored in OPC as of their v1 release, we will just keep track of sample numbers for now and read the raw data from files later

			else:
				# DLS only updates its sample number count when the sample completes, in the case of the first sample we need to check the timestamp of the tag
				# if the sample number has not changed and we already took the first sample we display sample number + 1 is in progress
				if instr_sample_num > 1: 
					self.set_state(CMState.SAMPLING, "Sample {} in progress".format(instr_sample_num + 1))
				else:
					self.set_state(CMState.SAMPLING, "Sample {} in progress".format(instr_sample_num))
		else:
			self.set_state(CMState.READY, "Instrument status {}".format(status))
		return ret
		
	def _device_interlocks_met(self):
		"""DLS specific logic that should be used to check after 
		CM + EM is acquired that instrument is ready for control
		
		1. device is online (Sts_Available)
		2. Instrument status message (TAG_STATUS) is WaitingForCommand AND
		
		"""
		if not self.is_online():
			reason = "Instrument is offline"
			self.set_state(CMState.ERROR, reason)
			return False, reason
		
		status_message = tagio.read_single(self.tag_root + self.TAG_STATUS)
		if  status_message == self.STATUS_READY:
			self.set_state(CMState.ACQUIRED, "Instrument is online and waiting for command")
			return True, ""
		else:
			reason = "Unable to command instrument. {} state".format(status_message)
			self.set_state(CMState.ERROR, reason)
			return False, reason
		