"""
PAT.cm.nir
----------
Control-Module wrapper for the Avantes NIR spectrometer via the NIR Integration API.

Relies on BaseCM for:
- state & message writes
- arbitration (Owned/ChartID)
- error serialization (post_error)
- device hooks (heartbeat, interlocks, cancel)

No blocking loops / sleep calls here; everything is one-shot.

Tag interface (relative to UDT root)
------------------------------------
Reads:
  /Parameters/EP/0/Val_String                     - NIR API host/IP
  /Parameters/EP/1/Val_String                     - NIR API port

  /LM/Instrument/SerialNumber                     - bound spectrometer serial number

  /LM/Measurement/Parameters/Mode                 - "single" | "fixed" | "continuous"
  /LM/Measurement/Parameters/NumberOfMeasurements - int (>=1 for fixed, -1 for continuous, 1 for single)
  /LM/Measurement/Parameters/StoreLocally         - bool

  /LM/Measurement/Parameters/IntegrationTimeMs    - float (ms)
  /LM/Measurement/Parameters/NumberOfAverages     - int
  /LM/Measurement/Parameters/SmoothingPixels      - int
  /LM/Measurement/Parameters/StartWavelengthNm    - float (nm)
  /LM/Measurement/Parameters/StopWavelengthNm     - float (nm)
  /LM/Measurement/Parameters/ScansStoredInRam     - int (must be 0; StoreToRam unsupported)
  /LM/Measurement/Parameters/SaturationDetection  - bool
  /LM/Measurement/Parameters/SensitivityMode      - "auto" | "low_noise" | "high_sensitivity"

Writes:
  /CM/Val_SampleNumber                            - incremental sample counter (BaseCM)
  /LM/Measurement/Status/State                    - string; "idle"|"running"|"stopped"|...
  /LM/Measurement/Status/MeasurementMode          - effective measurement mode for current run
  /LM/Measurement/Status/CurrentScan              - int
  /LM/Measurement/Status/TotalScans               - int
  /LM/Measurement/Status/RunId                    - int
  /LM/Measurement/Status/StoreLocally             - bool
  /LM/Measurement/Status/LastErrorCode            - string
  /LM/Measurement/Status/LastErrorMessage         - string

  /LM/Data/Raw                                    - latest raw measurement (JSON/dataset)
  /LM/Data/Dark                                   - dark measurement (captured by EM)
  /LM/Data/Ref                                    - reference measurement (captured by EM)
  /LM/Data/Absorbance                             - absorbance spectrum (to be computed from Raw/Dark/Ref)
"""

from collections import OrderedDict
import json

from PAT.infra import tagio, log

from PAT.cm.base import BaseCM, CMState

import math

class NirCM(BaseCM):
    """
    Concrete NIR Control Module using the NIR Integration FastAPI backend.

    Public surface (used by EM/SFC):
      - api_health()
      - api_list_devices()
      - api_get_device(sn=None)
      - api_activate(sn=None)
      - api_deactivate(sn=None)

      - configure_from_tags()       -> PUT /meas/{sn}
      - configure(config_dict)      -> PUT /meas/{sn}

      - start(params=None)          -> POST /meas/{sn}
      - start_from_tags()           -> POST /meas/{sn}
      - stop()                      -> DELETE /meas/{sn}

      - api_get_status(sn=None)     -> GET /meas/{sn}/status
      - api_get_latest_measurement(sn=None)
      - api_get_latest_run(sn=None)

      - status_poll()               -> one-shot snapshot for EM/SFC monitor steps

    All instrument-specific tag reads/writes live in the LM folder.
    """

    # ------------------------ tag constants ---------------------------

    # Connection parameter tags
    _P_IP   = "/Parameters/EP/0/Val_String"
    _P_PORT = "/Parameters/EP/1/Val_String"

    # BaseCM sample counter tag
    _T_SAMPLE_NO = "/CM/Val_SampleNumber"

    # LM instrument
    _T_LM_SN =    "/LM/Instrument/SerialNumber"
    _T_LM_TOKEN = "/LM/Instrument/Token"

    # LM measurement parameters
    _T_LM_MODE            = "/LM/Measurement/Parameters/Mode"
    _T_LM_NR_MEAS         = "/LM/Measurement/Parameters/NumberOfMeasurements"
    _T_LM_STORE_LOCAL     = "/LM/Measurement/Parameters/StoreLocally"
    _T_LM_INT_TIME_MS     = "/LM/Measurement/Parameters/IntegrationTimeMs"
    _T_LM_NR_AVG          = "/LM/Measurement/Parameters/NumberOfAverages"
    _T_LM_SMOOTH_PIX      = "/LM/Measurement/Parameters/SmoothingPixels"
    _T_LM_START_WL_NM     = "/LM/Measurement/Parameters/StartWavelengthNm"
    _T_LM_STOP_WL_NM      = "/LM/Measurement/Parameters/StopWavelengthNm"
    _T_LM_SCANS_IN_RAM    = "/LM/Measurement/Parameters/ScansStoredInRam"
    _T_LM_SAT_DETECT      = "/LM/Measurement/Parameters/SaturationDetection"
    _T_LM_SENS_MODE       = "/LM/Measurement/Parameters/SensitivityMode"

    # LM measurement status
    _T_LM_ST_STATE        = "/LM/Measurement/Status/State"
    _T_LM_ST_MODE         = "/LM/Measurement/Status/MeasurementMode"
    _T_LM_ST_CURR_SCAN    = "/LM/Measurement/Status/CurrentScan"
    _T_LM_ST_TOTAL_SCANS  = "/LM/Measurement/Status/TotalScans"
    _T_LM_ST_RUN_ID       = "/LM/Measurement/Status/RunId"
    _T_LM_ST_STORE_LOCAL  = "/LM/Measurement/Status/StoreLocally"

    # LM data tags
    _T_LM_DATA_RAW        = "/LM/Data/Raw"
    _T_LM_DATA_DARK       = "/LM/Data/Dark"
    _T_LM_DATA_REF        = "/LM/Data/Reference"
    _T_LM_DATA_ABS        = "/LM/Data/Absorbance"

    # ---------------------------- ctor --------------------------------

    def __init__(self, tag_root):
        """
        Parameters
        ----------
        tag_root : unicode
            Fully qualified UDT root for this instrument instance.
            Example: "[default]RBP/PAT/NIR-01"
        """
        super(NirCM, self).__init__(tag_root, logger_name="PAT.CM.NIR")
        self.log = log.get("PAT.CM.NIR")

        # Runtime latch for new-sample detection
        self._last_seen_scan_index = 0
        self.serial = None
        # --- Authentication for NIR API --------------------------------
        self._auth_client_id = "scada"
        self._auth_client_secret = "test123"
        self._auth_token = None  # Bearer token string (JWT)

    # ---------------------------- helpers -----------------------------

    def _tag(self, rel):
        """Return absolute tag path under this UDT root."""
        return self.tag_root + rel

    def _read_ip_port(self):
        ip   = tagio.read_single(self._tag(self._P_IP))
        port = tagio.read_single(self._tag(self._P_PORT))
        return ip, port

    def _base_url(self):
        ip, port = self._read_ip_port()
        return "http://%s:%s" % (ip, port)

    def _client(self, timeout_ms=6000):
        # Mirror MIR pattern: use shared PAT.net client
        return PAT.net.client_v1
    def _ensure_token(self):
        """
        Ensure we have a valid access token.

        Source of truth: LM/Instrument/Token tag.
        - If tag token exists and looks valid (JWT not expired), use it.
        - Otherwise, POST /token and persist new token into LM/Instrument/Token.

        Notes
        -----
        - "Validity" here means: token is a JWT-like string and (if it contains
        an 'exp' claim) it is not expired. If the server later rejects a token
        (revoked, etc.), _request()'s 401 handler will refresh it.
        """
        import base64
        import time

        def _read_token_tag():
            try:
                v = tagio.read_single(self._tag(self._T_LM_TOKEN))
                if v is None:
                    return None
                s = unicode(v).strip()
                return s or None
            except:
                return None

        def _write_token_tag(token_str):
            try:
                tagio.write_single(self._tag(self._T_LM_TOKEN), token_str)
            except Exception as exc:
                # Don't fail hard on tag write; but do log it.
                self.log.warn("Failed to write LM/Instrument/Token tag: %s" % exc)

        def _b64url_decode(seg):
            # Python2-safe base64url decode with padding
            seg = seg.replace("-", "+").replace("_", "/")
            pad = len(seg) % 4
            if pad:
                seg += "=" * (4 - pad)
            return base64.b64decode(seg)

        def _jwt_not_expired(token_str, skew_sec=30):
            """
            Return True if:
            - token looks like JWT (has 3 dot parts),
            - payload decodes as JSON,
            - if payload has 'exp', exp is in the future (with small skew).
            If payload has no 'exp', treat as usable.
            """
            try:
                parts = token_str.split(".")
                if len(parts) < 2:
                    return False

                payload_b64 = parts[1]
                payload_json = _b64url_decode(payload_b64)
                payload = json.loads(payload_json)

                exp = payload.get("exp")
                if exp is None:
                    return True

                now = int(time.time())
                return int(exp) > (now + int(skew_sec))
            except:
                return False

        # 1) Prefer tag token
        tag_token = _read_token_tag()
        if tag_token and _jwt_not_expired(tag_token):
            # keep runtime cache in sync
            self._auth_token = tag_token
            return

        # 2) Otherwise request a new token and persist it
        client = self._client(timeout_ms=5000)
        url = self._base_url() + "/token"

        body = "username=%s&password=%s" % (
            self._auth_client_id,
            self._auth_client_secret,
        )

        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        self.log.debug("Requesting NIR API token from %s" % url)

        resp = client.post(url, data=body, headers=headers)

        code = getattr(resp, "statusCode", None)
        if code is None:
            try:
                code = resp.getStatusCode()
            except:
                code = None

        if code is None or not (200 <= int(code) < 300):
            try:
                txt = resp.getText()
            except:
                txt = "<no body>"
            raise RuntimeError(
                "Token request failed (status %s). Body: %s" % (code, txt)
            )

        # Parse JSON body, extract access_token
        try:
            txt = resp.getText()
            data = json.loads(txt)
        except Exception:
            try:
                data = resp.json
            except Exception as exc:
                raise RuntimeError("Token response not JSON: %s" % exc)

        token = None
        if isinstance(data, dict):
            token = data.get("access_token")

        if not token:
            raise RuntimeError("Token response missing 'access_token': %s" % (data,))

        # Persist to tag + runtime cache
        self._auth_token = token
        _write_token_tag(token)

        self.log.debug("NIR API token acquired and stored to LM/Instrument/Token")

    def _get_auth_headers(self):
        """
        Return a dict with Authorization header.

        Ensures token is present; if missing, will call _ensure_token().
        """
        self._ensure_token()
        return {"Authorization": "Bearer %s" % self._auth_token}

    def _request(
        self,
        method,
        path,
        params=None,
        body=None,
        timeout_ms=6000,
        fast=False,
        auth=True,
        _retry=False,
    ):
        """
        Small wrapper around Ignition httpClient with minimal assumptions.

        - Adds Authorization: Bearer <token> header to every call (except /token).
        - If we receive HTTP 401 once, we clear token, re-acquire and retry once.

        Parameters
        ----------
        method : str
            "GET", "POST", "PUT", or "DELETE".
        path : str
            Path relative to NIR API base (e.g. "/meas/7421214SP").
        params : dict or None
            Optional query parameters.
        body : dict or None
            JSON-serializable body for POST/PUT.
        timeout_ms : int
            HTTP client timeout in milliseconds.
        fast : bool
            If True, use PAT.net.client_fast (if available).
        auth : bool
            If False, skip Authorization header (used internally for /token).
        _retry : bool
            Internal guard to avoid infinite loop when retrying on 401.

        Raises
        ------
        RuntimeError
            On HTTP errors (non-2xx) after any retry attempt.
        """
        if fast:
            client = PAT.net.client_v1_fast
        else:
            client = self._client(timeout_ms)

        url = self._base_url() + path

        # Build headers (Authorization + optional JSON Content-Type)
        headers = {}
        if auth:
            try:
                # /token calls should pass auth=False explicitly
                auth_headers = self._get_auth_headers()
                headers.update(auth_headers)
            except Exception as exc:
                # Allow token acquisition errors to propagate
                raise RuntimeError("Failed to obtain NIR API token: %s" % exc)

        # Prepare request based on HTTP method
        if method == "GET":
            resp = client.get(url, params=params or {}, headers=headers)
        elif method == "DELETE":
            resp = client.delete(url, params=params or {}, headers=headers)
        elif method in ("POST", "PUT"):
            if body is None:
                # No body: simple POST/PUT, only auth header
                resp = getattr(client, method.lower())(url, headers=headers)
            else:
                # JSON body
                h = dict(headers)  # copy
                h["Content-Type"] = "application/json"
                resp = getattr(client, method.lower())(
                    url,
                    data=json.dumps(body),
                    headers=h,
                )
        else:
            raise ValueError("Unsupported method %s" % method)

        # Normalize status code
        code = getattr(resp, "statusCode", None)
        if code is None:
            try:
                code = resp.getStatusCode()
            except:
                code = None

        self.log.debug("request url=%s" % getattr(resp, "url", url))
        self.log.debug("response code=%s" % code)

        # Handle auth failure once: clear token & retry
        if auth and code == 401 and not _retry:
            self.log.warn("NIR API returned 401; refreshing token and retrying once.")
            self._auth_token = None
            self._ensure_token()
            return self._request(
                method=method,
                path=path,
                params=params,
                body=body,
                timeout_ms=timeout_ms,
                fast=fast,
                auth=auth,
                _retry=True,
            )

        # Treat 2xx / 204 as success
        if code is not None and 200 <= int(code) < 300:
            # Try JSON first
            try:
                self.log.debug("response body=%s" % resp.json)
                return resp.json
            except:
                # Fallback to text
                try:
                    txt = resp.getText()
                    self.log.debug("response text=%s" % txt)
                    if txt and txt.strip().startswith(("{", "[")):
                        return json.loads(txt)
                    return txt
                except:
                    return None

        # Error branch (after any retries)
        try:
            body_txt = resp.getText()
        except:
            body_txt = "<no body>"

        raise RuntimeError(
            "HTTP %s %s failed (status %s). Body: %s"
            % (method, path, code, body_txt)
        )

    # --------------------- LM helper(s) -----------------------------

    def _read_serial(self):
    	if self.serial is None:
        	sn = tagio.read_single(self._tag(self._T_LM_SN))
	        if sn is None:
	            return None
	        sn = unicode(sn).strip()
	        self.serial = sn
        return self.serial or None

    def clear_data(self):
        """
        Clear LM data and status for a new logical run.

        This is typically called by EM at the start of a step.
        """
        paths = [
            self._tag(self._T_LM_DATA_RAW),
            self._tag(self._T_LM_DATA_DARK),
            self._tag(self._T_LM_DATA_REF),
            self._tag(self._T_LM_DATA_ABS),
        ]
        tagio.write_multi(paths, [None, None, None, None])

        # Reset status fields that are safe to clear
        paths = [
            self._tag(self._T_LM_ST_CURR_SCAN),
            self._tag(self._T_LM_ST_TOTAL_SCANS),
            self._tag(self._T_LM_ST_RUN_ID),
            self._tag(self._T_SAMPLE_NO),
        ]
        tagio.write_multi(paths, [0, 0, 0, 0])

        self._last_seen_scan_index = 0

    def capture_dark(self):
        """
        Snapshot the current LM/Data/Raw into LM/Data/Dark.

        Called by EM when the operator confirms the 'dark' prompt.
        Expects LM/Data/Raw to hold the latest measurement JSON
        (same structure as GET /meas/{sn} 'data' field).
        """
        try:
            raw_json = tagio.read_single(self._tag(self._T_LM_DATA_RAW))
            if not raw_json:
                raise RuntimeError("capture_dark: LM/Data/Raw is empty; no data to capture")

            # We store the full dict (metadata + wavelengths_nm + counts).
            tagio.write_single(self._tag(self._T_LM_DATA_DARK), system.util.jsonEncode(raw_json.toDict()))
            self.log.info("Captured dark spectrum from LM/Data/Raw into LM/Data/Dark")
        except Exception as exc:
            self.post_error(exc, context="NIR.capture_dark")

    def capture_ref(self):
        """
        Snapshot the current LM/Data/Raw into LM/Data/Ref.

        Called by EM when the operator confirms the 'reference' prompt.
        Expects LM/Data/Raw to hold the latest measurement JSON.
        """
        try:
            raw_json = tagio.read_single(self._tag(self._T_LM_DATA_RAW))
            if not raw_json:
                raise RuntimeError("capture_ref: LM/Data/Raw is empty; no data to capture")

            tagio.write_single(self._tag(self._T_LM_DATA_REF), system.util.jsonEncode(raw_json.toDict()))
            self.log.info("Captured reference spectrum from LM/Data/Raw into LM/Data/Ref")
        except Exception as exc:
            self.post_error(exc, context="NIR.capture_ref")

    def _coerce_float(self, v):
        """
        Coerce a value (int, float, str, java.math.BigDecimal, etc.) to float.

        This is needed because Ignition often returns java.math.BigDecimal
        for numeric values (especially from tags / Documents).
        """
        try:
            # Works for Python int/float and many simple cases
            return float(v)
        except Exception:
            # Try common Java numeric APIs (BigDecimal, Double, etc.)
            try:
                # BigDecimal / Double / Float usually have doubleValue()
                return float(v.doubleValue())
            except Exception:
                try:
                    # Some only have floatValue()
                    return float(v.floatValue())
                except Exception:
                    # Last resort: string round-trip
                    return float(str(v))

    def _compute_absorbance_dict(self, raw_dict, dark_dict, ref_dict):
        """
        Compute absorbance spectrum from raw/dark/ref measurement dicts.

        Each dict is expected to follow the GET /meas/{sn} 'data' structure:
          {
            "serial_number": "...",
            "run_id": 0,
            "scan_index": 0,
            "timestamp_utc": "...",
            "start_wavelength_nm": 0.0,
            "stop_wavelength_nm": 0.0,
            "wavelengths_nm": [...],
            "counts": [...],
            "saturated": true/false
          }

        We only use wavelengths_nm and counts for the calculation:
          A(x) = -log((sample(x) - dark(x)) / (ref(x) - dark(x)))

        The returned dict:
          - copies raw_dict,
          - replaces 'counts' with absorbance values,
          - keeps wavelengths_nm unchanged (up to the common length).
        """
        wl_raw = raw_dict.get("wavelengths_nm") or []
        s_raw  = raw_dict.get("counts") or []
        s_dark = dark_dict.get("counts") or []
        s_ref  = ref_dict.get("counts") or []

        # Ensure all arrays are the same length; use common minimum.
        n = min(len(wl_raw), len(s_raw), len(s_dark), len(s_ref))
        if n == 0:
            raise RuntimeError("Absorbance computation: one or more arrays are empty")

        wl = wl_raw[:n]
        sample = s_raw[:n]
        dark = s_dark[:n]
        ref = s_ref[:n]

        absorbance = []
        invalid_count = 0

        for i in range(n):
#            self.log.info(
#                "sample[i]: %d dark[i] %d  ref[i] %d" %
#                sample[i], dark[i], ref[i]
#            )
#            num = float(sample[i]) - float(dark[i])
#            den = float(ref[i]) - float(dark[i])
            s_val = self._coerce_float(sample[i])
            d_val = self._coerce_float(dark[i])
            r_val = self._coerce_float(ref[i])

            num = s_val - d_val
            den = r_val - d_val

            # Avoid log of zero/negative; clamp using a small epsilon.
            # This keeps the array numeric and JSON-serializable.
            if den <= 0.0 or num <= 0.0:
                invalid_count += 1
                # Use a very small positive value to avoid math domain errors.
                # This yields large positive absorbance, which is at least
                # a clear indicator of invalid points.
                num = 1e-9
                den = 1e-9

            ratio = num / den
            # Natural log by default; can be changed to log10 if desired.
            a = -math.log(ratio)
            absorbance.append(a)

        if invalid_count:
            self.log.debug(
                "Absorbance computation: %d points required epsilon clamping" %
                invalid_count
            )

        abs_dict = dict(raw_dict)  # shallow copy of metadata + fields
        abs_dict["wavelengths_nm"] = wl
        abs_dict["counts"] = absorbance
#        # Optional: mark this explicitly as absorbance
#        abs_dict["type"] = "absorbance"

        return abs_dict

    def _update_absorbance_from_raw(self, raw_dict):
        """
        If LM/Data/Dark and LM/Data/Ref are present, compute absorbance
        for the given raw_dict and write it to LM/Data/Absorbance.
        """
        try:
            dark_json = tagio.read_single(self._tag(self._T_LM_DATA_DARK))
            ref_json  = tagio.read_single(self._tag(self._T_LM_DATA_REF))

            if not dark_json or not ref_json:
                # EM hasn't captured dark/ref yet; nothing to do.
                return

            try:
                dark_dict = dark_json.toDict()#json.loads(dark_json)
                ref_dict  = ref_json.toDict()#json.loads(ref_json)
            except Exception as exc:
                self.log.warn("Absorbance: failed to decode Dark/Ref JSON: %s" % exc)
                return

            abs_dict = self._compute_absorbance_dict(raw_dict, dark_dict, ref_dict)
            abs_json = system.util.jsonEncode(abs_dict)

            tagio.write_single(self._tag(self._T_LM_DATA_ABS), abs_json)
            self.log.debug(
                "Absorbance updated for run_id=%s scan_index=%s" %
                (abs_dict.get("run_id"), abs_dict.get("scan_index"))
            )
        except Exception as exc:
            self.post_error(exc, context="NIR.update_absorbance_from_raw")

    # ==================================================================
    # Direct API helpers (cover all endpoints)
    # ==================================================================

    def api_health(self):
        """
        Check if the configured NIR device is online/activated.

        Semantics
        ---------
        - This is a *device* health check, not a generic API health check.
        - Reads LM/Instrument/SerialNumber.
        - Calls GET /comms/{sn}.
        - Returns True iff the backend reports `activated == True`
          for that serial number.

        Returns
        -------
        bool
            True if the device is activated and reachable, False otherwise.
        """
        sn = self._read_serial()
        if not sn:
            self.log.warn("api_health: LM/Instrument/SerialNumber is empty")
            return False

        try:
            resp = self.api_get_device(sn)
        except Exception as exc:
            self.log.warn("api_health: GET /comms/%s failed: %s" % (sn, exc))
            return False

        data = resp.get("data") if isinstance(resp, dict) else resp
        if not isinstance(data, dict):
            self.log.warn(
                "api_health: unexpected /comms/%s response shape: %r" % (sn, data)
            )
            return False

        activated = bool(data.get("activated"))
        status = data.get("status")

        if not activated:
            self.log.debug(
                "api_health: device %s is not activated (status=%r)" % (sn, status)
            )

        return activated

    def api_list_devices(self):
        """GET /comms -> list of devices (data array in BaseResponse)."""
        resp = self._request("GET", "/comms", timeout_ms=5000)
        if isinstance(resp, dict):
            return resp.get("data")
        return resp

    def api_get_device(self, sn=None):
        """GET /comms/{sn} -> device info + lazy activation."""
        if sn is None:
            sn = self._read_serial()
        if not sn:
            raise RuntimeError("api_get_device: SerialNumber is empty")
        return self._request("GET", "/comms/%s" % sn, timeout_ms=5000)

    def api_activate(self, sn=None):
        """PUT /comms/{sn} -> explicit activation."""
        if sn is None:
            sn = self._read_serial()
        if not sn:
            raise RuntimeError("api_activate: SerialNumber is empty")
        return self._request("PUT", "/comms/%s" % sn, timeout_ms=8000)

    def api_deactivate(self, sn=None):
        """DELETE /comms/{sn} -> explicit deactivation."""
        if sn is None:
            sn = self._read_serial()
        if not sn:
            raise RuntimeError("api_deactivate: SerialNumber is empty")
        return self._request("DELETE", "/comms/%s" % sn, timeout_ms=5000)

    def api_get_status(self, sn=None):
        """GET /meas/{sn}/status -> measurement_state + measurement_status."""
        if sn is None:
            sn = self._read_serial()
        if not sn:
            raise RuntimeError("api_get_status: SerialNumber is empty")
        return self._request("GET", "/meas/%s/status" % sn, timeout_ms=5000, fast=True)

    def api_get_latest_measurement(self, sn=None):
        """GET /meas/{sn} -> latest raw measurement."""
        if sn is None:
            sn = self._read_serial()
        if not sn:
            raise RuntimeError("api_get_latest_measurement: SerialNumber is empty")
        return self._request("GET", "/meas/%s" % sn, timeout_ms=8000)

    def api_get_latest_run(self, sn=None):
        """GET /meas/{sn}/run/latest -> latest run summary."""
        if sn is None:
            sn = self._read_serial()
        if not sn:
            raise RuntimeError("api_get_latest_run: SerialNumber is empty")
        return self._request("GET", "/meas/%s/run/latest" % sn, timeout_ms=8000)

    # ==================================================================
    # BaseCM device hooks
    # ==================================================================

    def _device_heartbeat(self):
        """
        BaseCM hook: device considered "alive" if /comms/{sn}
        says the configured device is activated.

        This is intentionally a *device* heartbeat, not a generic
        API process health check.
        """
        try:
            return bool(self.api_health())
        except Exception as exc:
            self.log.warn("Device heartbeat failed: %s" % exc)
            return False

    def _device_interlocks_met(self):
        """
        BaseCM: check high-level interlocks for safe operation.

        Conditions:
          1) LM/Instrument/SerialNumber must be set.
          2) Device must be activated in /comms.
          3) Measurement state must be idle/stopped in /meas/{sn}/status.
        """
        try:
            self.log.debug("Checking interlock conditions prior to start")
            sn = self._read_serial()
            self.log.debug("1) LM/Instrument/SerialNumber must be set.")
            if not sn:
                return (False, u"LM/Instrument/SerialNumber is empty")
            self.log.debug("1) Number: {}".format(sn))
            self.log.debug("2) Device must be online.")

            dev_resp = self.api_get_device(sn)
            data = dev_resp.get("data") if isinstance(dev_resp, dict) else dev_resp
            if not isinstance(data, dict):
                return (False, u"Unexpected /comms response shape")

            activated = bool(data.get("activated"))
            status = unicode(data.get("status", u"unknown"))
            if not activated:
                return (
                    False,
                    u"Device %s not activated in NIR API (status=%s)" % (sn, status),
                )
            self.log.debug("2) Device Online")
            self.log.debug("3) Device state must be idle/stopped")

            st_resp = self.api_get_status(sn)
            st_data = st_resp.get("data") if isinstance(st_resp, dict) else st_resp
            if not isinstance(st_data, dict):
                return (False, u"Unexpected /meas/{sn}/status response shape")

            meas_state = unicode(
                st_data.get("status", u"unknown")
            ).lower()

            if meas_state not in (u"idle", u"stopped"):
                return (
                    False,
                    u"Device %s measurement_state='%s' (need idle/stopped)"
                    % (sn, meas_state),
                )
            self.log.debug("3) Device state check passed")

            return (True, u"")

        except Exception as exc:
            msg = u"Interlocks check failed: %s" % exc
            self.log.warn(msg)
            return (False, msg)

    def _device_cancel(self):
        """BaseCM: best-effort stop of any active measurement."""
        try:
            sn = self._read_serial()
            if not sn:
                self.log.warn("Cancel requested but SerialNumber tag is empty")
                return
            self._request("DELETE", "/meas/%s" % sn, timeout_ms=3000)
        except Exception as exc:
            self.log.warn("NIR cancel failed: %s" % exc)

    # ==================================================================
    # Configuration helpers
    # ==================================================================

    def _read_measurement_params(self):
        """
        Read all known measurement parameters from LM tags into a dict
        matching MeasurementConfigRequest field names.
        """
        root = self.tag_root

        def _r(rel):
            return tagio.read_single(root + rel)

        params = {}

        mode = _r(self._T_LM_MODE)
        if mode:
            params["measurement_mode"] = unicode(mode).lower()

        nr_meas = _r(self._T_LM_NR_MEAS)
        if nr_meas is not None:
            try:
                params["number_of_measurements"] = int(nr_meas)
            except:
                pass

        it_ms = _r(self._T_LM_INT_TIME_MS)
        if it_ms is not None:
            try:
                params["integration_time_ms"] = float(it_ms)
            except:
                pass

        nr_avg = _r(self._T_LM_NR_AVG)
        if nr_avg is not None:
            try:
                params["number_of_averages"] = int(nr_avg)
            except:
                pass

        smooth = _r(self._T_LM_SMOOTH_PIX)
        if smooth is not None:
            try:
                params["smoothing_pixels"] = int(smooth)
            except:
                pass

        start_wl = _r(self._T_LM_START_WL_NM)
        if start_wl is not None:
            try:
                params["start_wavelength_nm"] = float(start_wl)
            except:
                pass

        stop_wl = _r(self._T_LM_STOP_WL_NM)
        if stop_wl is not None:
            try:
                params["stop_wavelength_nm"] = float(stop_wl)
            except:
                pass

        scans_ram = _r(self._T_LM_SCANS_IN_RAM)
        if scans_ram is not None:
            # Backend will reject non-zero; we can either:
            # - pass through (and let validation fail), or
            # - force 0 here. For now, clamp to 0 but log if non-zero.
            try:
                scans_ram = int(scans_ram)
            except:
                scans_ram = 0
            if scans_ram != 0:
                self.log.warn(
                    "ScansStoredInRam=%s but API requires 0; clamping to 0." % scans_ram
                )
                scans_ram = 0
            params["scans_stored_in_ram"] = scans_ram

        sat = _r(self._T_LM_SAT_DETECT)
        if sat is not None:
            params["saturation_detection"] = bool(sat)

        sens = _r(self._T_LM_SENS_MODE)
        if sens:
            params["sensitivity_mode"] = unicode(sens).lower()

        return params

    def configure(self, config_dict):
        """
        PUT /meas/{sn} with explicit config_dict (dict must already match
        MeasurementConfigRequest schema).
        """
        sn = self._read_serial()
        if not sn:
            raise RuntimeError("configure: SerialNumber is empty")
        self.log.debug("configure: PUT /meas/%s with %s" % (sn, config_dict))
        return self._request("PUT", "/meas/%s" % sn, body=config_dict, timeout_ms=8000)

    def configure_from_tags(self):
        """
        Convenience wrapper: read LM/Measurement/Parameters and apply them
        via PUT /meas/{sn}.

        EM typically calls this after writing parameter tags.
        """
        try:
            cfg = self._read_measurement_params()
            if not cfg:
                self.log.debug("configure_from_tags: nothing to send")
                return
            self.configure(cfg)
        except Exception as exc:
            self.post_error(exc, context="NIR.configure_from_tags")

    # ==================================================================
    # Public CM API used by EM/SFC
    # ==================================================================

    def start(self, params=None):
        """
        Non-blocking start of a measurement run.

        params: dict or None
            Matches StartMeasurementRequest fields:
              {
                "measurement_mode": "single"|"fixed"|"continuous" (optional),
                "number_of_measurements": int (required for fixed),
                "store_locally": bool,
              }
            If None, backend uses last configured mode and EM-provided
            parameters from previous configure() call.
        """
        try:
            sn = self._read_serial()
            if not sn:
                raise RuntimeError("Cannot start NIR run – SerialNumber is empty")

            body = params or {}
            self.log.debug("Starting NIR measurement for %s with params=%s" % (sn, body))
            self._request("POST", "/meas/%s" % sn, body=body, timeout_ms=8000)

            # reset sample tracking
            self._last_seen_scan_index = 0
            try:
                tagio.write_single(self._tag(self._T_SAMPLE_NO), 0)
            except:
                pass

            self.set_state(CMState.READY, "Start command sent")

        except Exception as exc:
            self.post_error(exc, context="NIR.start")

    def start_from_tags(self):
        """
        Build StartMeasurementRequest from LM parameters and start the run.

        Uses:
          - Mode from LM/Measurement/Parameters/Mode (if set)
          - NumberOfMeasurements from LM/Measurement/Parameters/NumberOfMeasurements
          - StoreLocally from LM/Measurement/Parameters/StoreLocally
        """
        try:
            root = self.tag_root
            mode = tagio.read_single(root + self._T_LM_MODE)
            nr_meas = tagio.read_single(root + self._T_LM_NR_MEAS)
            store = tagio.read_single(root + self._T_LM_STORE_LOCAL)

            body = {}
            if mode:
                body["measurement_mode"] = unicode(mode).lower()
            if nr_meas is not None:
                try:
                    body["number_of_measurements"] = int(nr_meas)
                except:
                    pass
            if store is not None:
                body["store_locally"] = bool(store)

            self.start(body)
        except Exception as exc:
            self.post_error(exc, context="NIR.start_from_tags")

    def stop(self):
        """Request backend to stop any active measurement."""
        try:
            sn = self._read_serial()
            if not sn:
                raise RuntimeError("Cannot stop NIR run – SerialNumber is empty")
            self.log.debug("Stopping NIR measurement for %s" % sn)
            self._request("DELETE", "/meas/%s" % sn, timeout_ms=4000)
            self.set_state(CMState.READY, "Stop command sent")
        except Exception as exc:
            self.post_error(exc, context="NIR.stop")

    def format_data_for_db(self,x,y):
        # Build mapping of x,y pairs where:
        # - key  = integer-rounded wavelength as string
        # - value = counts rounded to 6 decimal places as string
        combined = OrderedDict(
            (
                str(int(round(self._coerce_float(xv)))),
                "%.3f" % round(self._coerce_float(yv), 3),
            )
            for xv, yv in zip(x, y)
        )

        # x,y\n representation (string) and length
        xy_str = "\n".join(
            ["%s,%s" % (k, v) for k, v in combined.items()]
        )
        return combined, xy_str

    def status_poll(self):
        """
        One-shot snapshot used by EM/SFC monitor steps.

        Returns dict:
          {
            "state":         measurement_state string,
            "instr_sample":  current_scan,
            "new_sample":    bool,
            "data_json":     JSON for latest sample (if new_sample),
            "data_dict":     dict for latest sample (if new_sample),
            "stopping":      bool (reserved),
            "stopped":       bool (True when state is idle/stopped),
          }
        """
        ret = {
            "state": None,
            "instr_sample": 0,
            "new_sample": False,
            "data_json": None,
            "data_dict": None,
            "stopping": False,
            "stopped": False,
        }

        try:
            sn = self._read_serial()
            if not sn:
                self.log.warn("status_poll: SerialNumber is empty")
                ret["state"] = "unknown"
                return ret

            st_resp = self.api_get_status(sn)
            st_data = st_resp.get("data") if isinstance(st_resp, dict) else st_resp
            if not isinstance(st_data, dict):
                self.log.warn("status_poll: unexpected status shape=%r" % (st_data,))
                ret["state"] = "unknown"
                return ret
            self.log.debug("status_poll: =%r" % (st_data))

#            meas_state = st_resp.get("message", u"unknown")
            meas_state = st_data.get("status",u"unknown")

            current_scan = int(st_data.get("current_scan") or 0)
            total_scans = int(st_data.get("total_scans") or 0)
            run_id = st_data.get("run_id")
            store_locally = bool(st_data.get("store_locally", False))
            mode = st_data.get("measurement_mode")

            ret["state"] = meas_state
            ret["instr_sample"] = current_scan

            # Update LM status tags
            paths = [
                self._tag(self._T_LM_ST_STATE),
                self._tag(self._T_LM_ST_CURR_SCAN),
                self._tag(self._T_LM_ST_TOTAL_SCANS),
                self._tag(self._T_LM_ST_RUN_ID),
                self._tag(self._T_LM_ST_STORE_LOCAL),
                self._tag(self._T_LM_ST_MODE),
            ]
            tagio.write_multi(paths, [
            meas_state, current_scan, total_scans, run_id, store_locally,mode])

            # Only fetch data if we see a new scan index
            if current_scan > int(self._last_seen_scan_index):
                data_resp = self.api_get_latest_measurement(sn)
                data = data_resp.get("data") if isinstance(data_resp, dict) else data_resp

                if isinstance(data, dict):
                    scan_index = int(data.get("scan_index") or current_scan)
                    self._last_seen_scan_index = scan_index

                    data_dict = {
                        "serial_number": data.get("serial_number"),
                        "run_id": data.get("run_id"),
                        "scan_index": scan_index,
                        "timestamp_utc": data.get("timestamp_utc"),
                        "start_wavelength_nm": data.get("start_wavelength_nm"),
                        "stop_wavelength_nm": data.get("stop_wavelength_nm"),
                        "wavelengths_nm": data.get("wavelengths_nm") or [],
                        "counts": data.get("counts") or [],
                        "saturated": bool(data.get("saturated")),
                    }
                    data_json = json.dumps(data_dict)
                    
                    combined, xy_str = self.format_data_for_db(data.get("wavelengths_nm"), data.get("counts"))

                    ret["new_sample"] = True
                    ret["data_dict"] = data_dict
                    ret["data_json"] = data_json
                    ret["data_xy_str"] = xy_str
                    ret["data_xy_dict"] = combined

                    # Write LM/Data/Raw so EM/SFC can access it
                    tagio.write_single(self._tag(self._T_LM_DATA_RAW), data_json)
                    # update Absorbance if Dark & Ref exist
                    try:
                        self._update_absorbance_from_raw(data_dict)
                    except Exception as exc:
                        self.post_error(exc, context="NIR.status_poll.absorbance")
                    # Advance BaseCM sample counter
                    try:
                        current = int(
                            tagio.read_single(self._tag(self._T_SAMPLE_NO)) or 0
                        )
                        tagio.write_single(self._tag(self._T_SAMPLE_NO), current + 1)
                    except:
                        pass

            if meas_state in ("idle", "stopped"):
                ret["stopped"] = True

            # Map to CMState for operator visibility
            if meas_state == "running":
                if mode == "continuous":
                    self.set_state(
                        CMState.SAMPLING,
                        "Sample %s in progress" % current_scan,
                    )
                else:
                    self.set_state(
                        CMState.SAMPLING,
                        "Sample %s in progress (%s of %s)" % (current_scan,current_scan,total_scans),
                    )
            elif meas_state in ("idle", "stopped"):
                self.set_state(CMState.READY, "Instrument idle")
            else:
                self.log.debug("NIR measurement_state=%s" % meas_state)

            return ret

        except Exception as exc:
            self.post_error(exc, context="NIR.status_poll")
            return ret
            