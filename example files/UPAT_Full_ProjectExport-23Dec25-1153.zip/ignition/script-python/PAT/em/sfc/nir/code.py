"""
pat.em.sfc.nir
----------------
SFC orchestration layer for the Avantes NIR.

This coordinates:
- High level run / sample flow via BaseSFC hooks.
- Dark / reference prompt workflow for continuous runs.
- Interaction with NirCM (which owns all CM/ and LM/ tags and NIR API calls).

Responsibilities
---------------
- Measurement mode is read from LM/Measurement/Parameters/Mode as a simple
  string ("single", "fixed", "continuous").
- Dark/reference prompting is only used when:
    - mode == "continuous"
    - LM/Measurement/Parameters/UseDarkRefWorkflow is true
- When dark/ref workflow is enabled, NirCM.clear_data() is called once during
  initialization so LM/Data/Raw, LM/Data/Dark, LM/Data/Ref, LM/Data/Absorbance
  start empty.
- For continuous mode:
    - We start measurement once (cm.start_from_tags()) and then just monitor.
    - While prompts are active we keep acquiring raw spectra normally.
    - When the operator confirms:
        * For dark prompt -> cm.capture_dark()
        * For ref prompt  -> cm.capture_ref()
      and NirCM will compute Absorbance on subsequent samples.
- For non continuous modes ("single", "fixed"):
    - We just start and monitor the run and let it complete.
    - No dark/ref prompts are issued (even if UseDarkRefWorkflow is set).
    - SFC exits gracefully when CM indicates idle/stopped.

"""

import json
from collections import OrderedDict

from PAT.em.sfc.base import BaseSFC # type: ignore
from PAT.em.base     import EMState # type: ignore
from PAT.cm.nir      import NirCM # type: ignore
from PAT.infra       import tagio, log # type: ignore
import system  # type: ignore
import PAT.db as _db # type: ignore


class NirSFC(BaseSFC):
    """
    SFC implementation for NIR Integration API.

    Orchestrates:
    - Run initialisation and measurement start.
    - Continuous measurement flow.
    - Optional dark/reference workflow (continuous only).
    - Graceful stop for non continuous modes.

    The SFC does not perform input validation; it trusts the graphics/CM to
    write valid LM/Measurement/Parameters/ values.
    """

    # ---------------------------------------------------------------------
    # EM / LM parameter tags used by the SFC
    # ---------------------------------------------------------------------
    # These are offsets from cm.tag_root.
    _P_TAGS = OrderedDict([
        # EM setup parameters (mirroring MIR / MALS patterns)
        ("run_name",      "/Parameters/Setup/1/Val_String"),
        ("model_name",    "/Parameters/Setup/2/Val_String"),
        ("model_version", "/Parameters/Setup/3/Val_Integer"),
        ("batch_id",      "/Parameters/Setup/4/Val_String"),
        ("unit_op",       "/Parameters/Setup/5/Val_String"),
        ("use_model",     "/Parameters/Setup/0/Val_Boolean"),

        # NIR specific sequence parameter
        ("use_dark_ref", "/LM/Measurement/Parameters/UseDarkRefWorkflow"),
        ("measurement_mode",      "/LM/Measurement/Parameters/Mode"),
    ])

    def __init__(self, cm, em):
        if not isinstance(cm, NirCM):
            raise TypeError("NirSFC requires a NirCM instance.")
        super(NirSFC, self).__init__(cm, em)

        self.log = log.get("PAT.EM.SFC.NIR")

        # Run level state
        self.run_params = {}
        self.sample_no = 1

        # Latest data from CM.status_poll()
        self.latest_status =           None
        self.latest_sample_data =      None  # dict exactly as returned by /meas/{sn}
        self.latest_sample_data_json = None
        self.latest_raw_dict =         None
        self.latest_dark_dict =        None
        self.latest_ref_dict =         None
        self.latest_abs_dict =         None
   

        # Measurement mode and workflow flags
        self.meas_mode =       u"continuous"  # "single", "fixed", "continuous"
        self.use_dark_ref =    False
        self.dark_ref_stored = False
        self.has_dark =        False
        self.has_ref =         False

        # Prompt workflow state:
        #   None  -> no dark/ref workflow
        #   "dark" -> prompting for dark
        #   "ref"  -> prompting for ref
        #   "done" -> both captured
        self.prompt_phase = None
        self._prompt_confirm_in_progress = False

        self._stop_cmd_first_seen = None

    # ------------------------------------------------------------------
    # Helpers for LM data tags (Raw / Dark / Ref / Absorbance)
    # ------------------------------------------------------------------
    def _lm_tag(self, suffix):
        """
        Utility for building full LM tag paths based on NirCM constants.
        """
        return self.cm.tag_root + suffix

    def _has_dark(self):
        try:
            if self.has_dark:
                return True
            v = tagio.read_single(self._lm_tag(self.cm._T_LM_DATA_DARK))
            if v and v not in (None, "", u""):
                v = v.toDict()
                self.latest_dark_dict, _ = self.cm.format_data_for_db(v.get("wavelengths_nm"), v.get("counts"))
                self.has_dark = True
                return True
            return False
        except Exception as exc:
            self.em.post_error(exc, context="failed to read/parse LM/Data/Dark")
            return False
        
    def _has_ref(self):
        try:
            if self.has_ref:
                return True
            v = tagio.read_single(self._lm_tag(self.cm._T_LM_DATA_REF))
            if v and v not in (None, "", u""):
                v = v.toDict()
                self.latest_ref_dict, _ = self.cm.format_data_for_db(v.get("wavelengths_nm"), v.get("counts"))
                self.has_ref = True
                return True
            return False
        except Exception as exc:
            self.em.post_error(exc, context="failed to read/parse LM/Data/Ref")
            return False

    # ------------------------------------------------------------------
    # BaseSFC hooks
    # ------------------------------------------------------------------
    def _initialize_after_acquire(self):
        """
        Called once after CM acquire. Performs interlock checks, reads
        run parameters, determines measurement mode and sets up the
        dark/ref workflow if applicable.
        """
        self.log.info("initialize: starting after acquire")

        # Interlocks
        ok, reason = self.cm.interlocks_met()
        if not ok:
            self.em.set_state(EMState.ERROR, reason)
            # Returning False tells BaseSFC that initialization failed.
            return False

        # Read run parameters from EM/LM tags
        paths = [self.cm.tag_root + p for p in self._P_TAGS.values()]
        values = tagio.read_multi(paths)
        self.run_params = dict(zip(self._P_TAGS.keys(), values or []))

        # Ensure a non empty run_name (mirror MIR behavior)
        run_name = self.run_params.get("run_name")

        if _db.run_exists(run_name, self.em.udt_instance_name):
            import re
            pattern = re.compile(r'^(?P<prefix>.*)___\d{2}_\d{2}_\d{2}$')
            m = pattern.match(run_name)
            run_name = m.group('prefix') if m else run_name
            ts = system.date.format(system.date.now(), "___HH_mm_ss") # type: ignore
            run_name = "{}{}".format(run_name, ts)
            tagio.write_single(self.cm.tag_root + self._P_TAGS["run_name"], run_name)
            self.log.debug("Duplicate run name detected, renamed={}".format(run_name))
            self.run_params["run_name"] = run_name

        # Insert DB run & first sample rows
        self.db_run_insert_id = _db.run_insert(
            run_name       = run_name,
            equipment_name = self.em.udt_instance_name,
            unit_name      = self.run_params["unit_op"],
            batch_id       = self.run_params["batch_id"],
            model_class    = self.run_params["model_name"],
            model_version  = self.run_params["model_version"],
        )
        if self.db_run_insert_id == -1:
            raise RuntimeError("DB run_insert failed")

        self.db_sample_insert_id = _db.sample_insert(
            run_id        = self.db_run_insert_id,
            sample_number = self.sample_no,
            timestamp     = system.date.now(), # type: ignore
        )
        if self.db_sample_insert_id == -1:
            raise RuntimeError("DB sample_insert failed")

        self.meas_mode = self.run_params.get("measurement_mode")

        self.use_dark_ref = self.run_params.get("use_dark_ref")

        if self.meas_mode == "continuous" and self.use_dark_ref:
            self.prompt_phase = "dark"
            # Clear LM data tags so EM has a clean start.
            self.cm.clear_data()
            self.em.set_state(EMState.STARTING, "dark/ref workflow enabled, data cleared via cm.clear_data()",False)

        else:
            if self.use_dark_ref and self.meas_mode != "continuous":
                self.em.set_state(EMState.STARTING, "UseDarkRefWorkflow ignored for non continuous mode '%s'"
                    % self.meas_mode,False)
            self.use_dark_ref = False
            self.prompt_phase = None

        # 5) Reset run counters and last status
        self.sample_no = 1
        self.latest_status = None

        self.em.set_state(EMState.STARTING, "initialize: completed, ready to sample",False)
        return True

    def _sample_after_initialize(self):
        self.em.set_state(EMState.RUNNING, "Starting NIR measurement (mode=%s)" % self.meas_mode)
        self.cm.start_from_tags()
        return True

    def _monitor_sample(self):
        """
        Poll CM; advance on new sample; handle comm loss and stop/hold paths.

        Returns
        -------
        bool
            True  -> a new sample is available and should be stored.
            False -> no new sample; SFC can remain in monitor loop.
        """
            
        if not tagio.read_single(self.cm.tag_root + self.cm._T_AVAILABLE):
            self.em.set_state(EMState.HOLDING, "Device comm lost!")
            self.held_reason = "Device comm lost"
            return False
        
        status = self.cm.status_poll()
        self.latest_status = status

        # status dict shape:
        # {
        #   "state": string,
        #   "instr_sample": int,
        # }

        state = status.get("state") or "unknown"
        new_sample = bool(status.get("new_sample"))
        #   "new_sample": bool,
        #   "data_json": str or None,
        #   "data_dict": dict or None,
        #   "stopping": bool,
        #   "stopped": bool,
        data_dict = status.get("data_dict")
        current_scan = int(status.get("instr_sample") or 0)

        if state == "running":
            self._set_state_if_prompt(EMState.RUNNING, "Sample {} in progress".format(self.sample_no))
        elif state in ("idle", "stopped"):
            # Instrument is no longer measuring
            self.em.set_state(EMState.STOPPING, "NIR instrument is idle.")
        else:
            # Unknown / transient; keep previous EMState but still allow
            # new_sample detection below.
            pass

        if new_sample and isinstance(data_dict, dict):
            self.latest_sample_data = data_dict
            self.latest_sample_data_json = status.get("data_json")
            self.log.debug(
                "new sample %s for run '%s' (mode=%s)"
                % (self.sample_no, self.run_params.get("run_name"), self.meas_mode)
            )

            # Handle dark/ref workflow only in continuous mode
            if self.meas_mode == "continuous" and self.use_dark_ref and self.sample_no > 1:
                self._handle_dark_ref_workflow_on_new_sample()
            return True

        return False

    def _store_sample_data(self):
        """
            1) metadata      -> data_type = "metadata"
            2) raw spectra   -> data_type = "raw_spectra"
            3) absorbance    -> data_type = "raw_data" (if available)
        """
        self._set_state_if_prompt(EMState.RUNNING, "Storing sample data")

        udt_root = self.cm.tag_root.rsplit('/', 1)[0] + "/"

        # 1) Build metadata dict (no wavelengths / counts)
        meta_dict = dict(self.latest_sample_data)
        meta_dict.pop("wavelengths_nm", None)
        meta_dict.pop("counts", None)
        meta_dict.pop("data_xy_dict", None)
        meta_dict.pop("data_xy_str", None)

        # 3) Absorbance dict comes from LM/Data/Absorbance (if any)
        abs_json = None
        abs_dict = None
        abs_str  = None
        try:
            abs_json = tagio.read_single(self._lm_tag(self.cm._T_LM_DATA_ABS))
            if abs_json and abs_json not in (None, "", u""):
                abs_dict = abs_json.toDict()
                abs_dict, abs_str = self.cm.format_data_for_db(abs_dict.get("wavelengths_nm"), abs_dict.get("counts"))
        except Exception as exc:
            self.em.post_error(exc, context="failed to read/parse LM/Data/Absorbance")


        # 1) dark + ref
        if not self.dark_ref_stored and (self.has_dark and self.has_ref):
            db_params = {
                "data":                          self.latest_dark_dict,
                "step_counter":                  self.sample_no,
                "run_insert_id":                 self.db_run_insert_id,
                "sample_id":                     self.db_sample_insert_id,
                "data_type":                     "raw_dark",
                "pat_equipment_tag_path_prefix": udt_root,
                "pat_equipment_tag_name":        self.em.udt_instance_name,
                "run_name":                      self.run_params["run_name"],
                "model_name":                    "",
                "sample_number":                 self.sample_no,
            }
            db_chart = system.sfc.startChart(
                system.project.getProjectName(),
                "PAT/Common/Database",
                db_params,
            )
            self._set_state_if_prompt(EMState.RUNNING, "PAT/Common/Database chartId={}".format(db_chart), False)

            db_params = {
                "data":                          self.latest_ref_dict,
                "step_counter":                  self.sample_no,
                "run_insert_id":                 self.db_run_insert_id,
                "sample_id":                     self.db_sample_insert_id,
                "data_type":                     "raw_ref",
                "pat_equipment_tag_path_prefix": udt_root,
                "pat_equipment_tag_name":        self.em.udt_instance_name,
                "run_name":                      self.run_params["run_name"],
                "model_name":                    "",
                "sample_number":                 self.sample_no,
            }
            db_chart = system.sfc.startChart(
                system.project.getProjectName(),
                "PAT/Common/Database",
                db_params,
            )
            self._set_state_if_prompt(EMState.RUNNING, "PAT/Common/Database chartId={}".format(db_chart), False)

            self.dark_ref_stored = True

        # 1) metadata
            db_params = {
                "data":                          meta_dict,
                "step_counter":                  self.sample_no,
                "run_insert_id":                 self.db_run_insert_id,
                "sample_id":                     self.db_sample_insert_id,
                "data_type":                     "metadata",
                "pat_equipment_tag_path_prefix": udt_root,
                "pat_equipment_tag_name":        self.em.udt_instance_name,
                "run_name":                      self.run_params["run_name"],
                "model_name":                    "",
                "sample_number":                 self.sample_no,
            }
            db_chart = system.sfc.startChart(
                system.project.getProjectName(),
                "PAT/Common/Database",
                db_params,
            )
            self._set_state_if_prompt(EMState.RUNNING, "PAT/Common/Database chartId={}".format(db_chart), False)

        # 2) Raw spectra
        raw_spectra, _ = self.cm.format_data_for_db(self.latest_sample_data.get("wavelengths_nm"), self.latest_sample_data.get("counts"))
        db_params = {
            "data":                          raw_spectra,
            "step_counter":                  self.sample_no,
            "run_insert_id":                 self.db_run_insert_id,
            "sample_id":                     self.db_sample_insert_id,
            "data_type":                     "raw_spectra",
            "pat_equipment_tag_path_prefix": udt_root,
            "pat_equipment_tag_name":        self.em.udt_instance_name,
            "run_name":                      self.run_params["run_name"],
            "model_name":                    "",
            "sample_number":                 self.sample_no,
        }
        db_chart = system.sfc.startChart(
            system.project.getProjectName(),
            "PAT/Common/Database",
            db_params,
        )
        self._set_state_if_prompt(EMState.RUNNING, "PAT/Common/Database chartId={}".format(db_chart), False)


        # 3) Absorbance (if available)
        if abs_dict and abs_json not in (None, "", u""):

            db_params = {
                "data":                          json.dumps(abs_dict),
                "step_counter":                  self.sample_no,
                "run_insert_id":                 self.db_run_insert_id,
                "sample_id":                     self.db_sample_insert_id,
                "data_type":                     "raw",
                "pat_equipment_tag_path_prefix": udt_root,
                "pat_equipment_tag_name":        self.em.udt_instance_name,
                "run_name":                      self.run_params["run_name"],
                "model_name":                    "",
                "sample_number":                 self.sample_no,
            }
            db_chart = system.sfc.startChart(
                system.project.getProjectName(),
                "PAT/Common/Database",
                db_params,
            )
            self._set_state_if_prompt(EMState.RUNNING, "PAT/Common/Database chartId={}".format(db_chart), False)

            if self.run_params.get("use_model"):
                ml_params = {
                    "In_RunName":                 self.run_params["run_name"],
                    "In_EquipmentTagPathPrefix":  udt_root,
                    "In_EquipmentName":           self.em.udt_instance_name,
                    "In_ModelName":               self.run_params["model_name"],
                    "In_ModelVersion":            self.run_params["model_version"],
                    "In_RunId":                   self.db_run_insert_id,
                    "sample_id":                  self.db_sample_insert_id,
                    "In_SampleNumber":            self.sample_no,
                    "In_Data":                    abs_str,
                }
                ml_chart = system.sfc.startChart(
                    system.project.getProjectName(),
                    "PAT/Common/Sub-Model-Process",
                    ml_params,
                )
                self._set_state_if_prompt(EMState.RUNNING, "PAT/Common/Sub-Model-Process chartId={}".format(ml_chart), False)
            else:
                self._set_state_if_prompt(EMState.RUNNING, "Use analytics run param set to false, skipping model processing", False)
        # --- Operator commands while storing
        cmds = self.em.poll_commands()
        if cmds.get("hold"):
            self.em.ack_command("hold")
            self.em.set_state(EMState.HOLDING, "Operator hold received", False)
            self.held_reason = "Operator Hold"
            return True
        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.cm.stop()
            self.em.set_state(EMState.STOPPING, "Operator stop received", False)
            return False

        return True

    def _next_sample(self):
        """Prepare DB and EM for the *next* sample run."""
        self.sample_no += 1
        self._set_state_if_prompt(EMState.RUNNING, "Initializing next sample")

        self.db_sample_insert_id = _db.sample_insert(
            run_id        = self.db_run_insert_id,
            sample_number = self.sample_no,
            timestamp     = system.date.now(), # type: ignore
        )
        if self.db_sample_insert_id == -1:
            raise RuntimeError("DB sample_insert failed (next)")
        return True

    # ------------------------------------------------------------------
    # Prompt workflow helpers
    # ------------------------------------------------------------------
    def _ensure_dark_prompt(self):
        """
        Issue the dark prompt if not already active.
        """
        if self.prompt_phase != "dark":
            return

        if self._has_dark():
            # Dark already captured; move on.
            self.log.debug("dark already present, skipping dark prompt")
            self.prompt_phase = "ref"
            return

        # Enter prompt via EM
        self.em.enter_prompt("Confirm to take DARK measurement")
        self.log.debug("dark prompt issued")

    def _ensure_ref_prompt(self):
        """
        Issue the reference prompt if not already active.
        """
        if self.prompt_phase != "ref":
            return

        if self._has_ref():
            self.log.debug("reference already present, finishing workflow")
            self.prompt_phase = "done"
            return

        self.em.enter_prompt("Confirm to take REFERENCE measurement")
        self.log.debug("reference prompt issued")

    def _handle_dark_ref_workflow_on_new_sample(self):
        """
        Called whenever a new sample is detected in continuous mode
        and dark/ref workflow is enabled.

        It:
        - Ensures the appropriate prompt is shown.
        - On operator confirm, calls NirCM.capture_dark() / capture_ref().
        - Advances prompt_phase from 'dark' -> 'ref' -> 'done'.
        """
        if self.prompt_phase not in ("dark", "ref"):
            return

        # First, ensure the right prompt is on screen
        if self.prompt_phase == "dark":
            self._ensure_dark_prompt()
        elif self.prompt_phase == "ref":
            self._ensure_ref_prompt()

        # Avoid double capture if SFC runs faster than operator actions
        if self._prompt_confirm_in_progress:
            return

        try:
            if not self.em.is_prompt_confirmed():
                return
        except Exception:
            # If EM prompt support is not available, fail silently
            return

        self._prompt_confirm_in_progress = True
        try:
            if self.prompt_phase == "dark":
                self.log.debug("operator confirmed dark prompt, capturing dark")
                try:
                    self.cm.capture_dark()
                    # Change state to running since we are done with prompt
                    self.em.set_state(EMState.RUNNING, "Dark measurement captured", False)
                except Exception as exc:
                    self.em.post_error(exc, context="cm.capture_dark() failed")
                # After capturing dark, move to ref phase
                self.prompt_phase = "ref"
            elif self.prompt_phase == "ref":
                self.log.debug("operator confirmed reference prompt, capturing ref")
                try:
                    self.cm.capture_ref()
                    # Change state to running since we are done with prompt
                    self.em.set_state(EMState.RUNNING, "Reference measurement captured", False)
                except Exception as exc:
                    self.em.post_error(exc, context="cm.capture_ref() failed")
                # After capturing ref, workflow is done
                self.prompt_phase = "done"

        finally:
            self._prompt_confirm_in_progress = False
            
    def _set_state_if_prompt(self, state, msg, writeToMsgTag=True):
        """Called when prompt active but logic must proceed (while keeping prompt active."""
        if self.sample_no <= 1 or self.prompt_phase not in ("dark", "ref"):
            self.em.set_state(state, msg, writeToMsgTag)
        else:
            self.em.set_state(EMState.PROMPT, msg, False)

    def held_poll(self):
        """Called while HELD → look for restart/stop."""
        cmds = self.em.poll_commands()
        if cmds.get("restart"):
            self.em.ack_command("restart")
            # MIR workflow prefers RESUME of current measurement session.
            try:
                self.em.set_state(EMState.RUNNING, "Start command issued")
                self.cm.start_from_tags()
            except Exception as exc:
                # If resume fails, remain held and surface reason
                self.em.set_state(EMState.HOLDING, "Resume failed: {}".format(exc), False)

        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.cm.stop()
            self.em.set_state(EMState.STOPPING, "Operator stop received", False)

    def hold(self):
        """Pause the current measurement when transitioning into HOLD."""
        self.em.set_state(EMState.HOLDING, "Holding - {}".format(getattr(self, "held_reason", "")))
        try:
        	# Issue stop once unless already idle/stopped/stopping
            polled = self.cm.status_poll()
            st = polled.get("state")
            if not bool(polled.get("stopping") or polled.get("stopped") or st in ("idle", "stopped")):
                self.cm.stop()
        finally:
            polled = self.cm.status_poll()

            # Consider 'paused' OR 'stopped' as a safe held condition as long as we stored the data
            return (polled.get("state") == "idle" or polled.get("stopped"))
        
    def held(self):
        due_to = " - {}".format(self.held_reason) if getattr(self, "held_reason", "") else ""
        self.em.set_state(EMState.HELD, "Sequence held{}".format(due_to))

    def stop(self):
        """Issue STOP and keep polling until instrument acknowledges."""
        if not getattr(self, "skip_stop", False):
            # issue stop once, then rely on future invocations to check completion
            if self._stop_cmd_first_seen is None:
                self.cm.stop()
                self.em.set_state(EMState.STOPPING, "Stopping ...")
                self._stop_cmd_first_seen = system.date.now()

            polled = self.cm.status_poll()
            if polled.get("stopped") or polled.get("state") == "idle":
                self.em.set_state(EMState.STOPPED, "Sequence stopped")
                return True

            # Command-disagree/timeout handling (no sleep; based on elapsed wall-clock)
            elapsed_ms = system.date.millisBetween(self._stop_cmd_first_seen, system.date.now())
            if elapsed_ms >= self._stop_cmd_timeout_ms:
                self.em.set_state(EMState.STOPPING, "Stop timeout - proceeding to stopped")
                return True

            return False

        # If we decided to skip stopping (e.g., interlocks not met at init)
        self.em.set_state(EMState.STOPPING, "Stopping - {}".format(getattr(self, "skip_stop_reason", "skip")))
        return True
        