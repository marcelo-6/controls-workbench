global filePath
global dataHeaderRow
global recipeParamSheet
global deferalParamSheet
global parentRecipeClassLink
global saveList
global unitInstanceName

# add parameters to recipeObj 						WM_Template
def addParamsToRecipe(recipeObj):
	global filePath
	global dataHeaderRow
	global recipeParamSheet
	dataSet = WM_FIRE.dataset.excelToDataSet(filePath, dataHeaderRow, recipeParamSheet)
	
	for row in range(dataSet.getRowCount()):
		
		paramName = str(dataSet.getValueAt(row, 0))
		recordingType = str(dataSet.getValueAt(row, 1))
		valueSource = str(dataSet.getValueAt(row, 2))
		
		tagType = str(dataSet.getValueAt(row, 3))
		dataType = str(dataSet.getValueAt(row, 4))
		enumDefUUID = str(dataSet.getValueAt(row, 5))
		minValue = (dataSet.getValueAt(row, 6))
		maxValue = (dataSet.getValueAt(row, 7))
		defaultValue = (dataSet.getValueAt(row, 8))
		engUnits = str(dataSet.getValueAt(row, 9))
		
		# if parameter to be set during Recipe and Execution, define parameter
		if valueSource == 'Recipe and Execution':
		
			param = recipeObj.addParameter(paramName)
			param.setParamKindName('User Phase')
			param.setParamRecordingTypeName(recordingType)
			param.setParamValueSourceName(valueSource)
					
			if tagType != "NULL" and tagType != "n/a":
				param.setParamTagTypeName(tagType)
			
			param.setParamDataTypeName(dataType)
			
			if dataType == 'Enum':
				param.setParamEnumDefUUID(enumDefUUID)
			
			if dataType == 'Integer':
				defaultValue = int(float(defaultValue))
				param.setParamMaxValueAsString(str(int(float(maxValue))))
				param.setParamMinValueAsString(str(int(float(minValue))))
			
			if dataType == 'Byte' or dataType == 'Double' or dataType == 'Float' or dataType == 'Long' or dataType == 'Short':
				param.setParamMaxValueAsString(str(maxValue))
				param.setParamMinValueAsString(str(minValue))
			
			if defaultValue != "NULL":
				param.setParamValueAsString(str(defaultValue))
			
			param.setParamUnits(engUnits)

# set deferals to recipeObjj 						WM_Template
def setDeferals(recipeObj, step, unitInstanceName, instanceName):
	global filePath
	global dataHeaderRow
	global deferalParamSheet
	dataSet = WM_FIRE.dataset.excelToDataSet(filePath, dataHeaderRow, deferalParamSheet)

	for row in range(dataSet.getRowCount()):
		unitID = str(dataSet.getValueAt(row, 0))
		untiName = str(dataSet.getValueAt(row, 1))
		recipeObjName = str(dataSet.getValueAt(row, 2))
		phaseClassName = str(dataSet.getValueAt(row, 3))
		paramDesc = str(dataSet.getValueAt(row, 4))
		dataType = str(dataSet.getValueAt(row, 5))
		
		phaseParamName = str(dataSet.getValueAt(row, 6))
		deferPhaseParam = dataSet.getValueAt(row, 7)
		phaseCalcValue = dataSet.getValueAt(row, 8)
		phaseParamValue = (dataSet.getValueAt(row, 9))
		
		recipeParamName = (dataSet.getValueAt(row, 10))
		recipeParamValue = (dataSet.getValueAt(row, 11))
		
		# define parameters
		
		if dataType == 'Integer' and phaseParamValue != 'n/a':
			phaseParamValue = int(float(phaseParamValue))
		
		if untiName == unitInstanceName and recipeObjName == instanceName:
			#set phase params
			if deferPhaseParam == 1: #true
				step.setParameterCalculation(phaseParamName, phaseCalcValue)
			else:
				if phaseParamValue != 'n/a':
					step.setParameterValueAsString(phaseParamName, str(phaseParamValue))

# end recipeObject
def endRecipeObj(recipeObj):
	# add a terminator (within OP) and link with above step
	stepNum = recipeObj.getComplexPropertyCount('BatchMasterLogicSteps')
	recipeObj.addStep('End', stepNum, system.mes.batch.phase.getPhaseLink('Terminator'))
	recipeObj.addLink(stepNum-1,stepNum)

# create operation/phase
def createOperation(unitProcedure, priorStepNum, phaseName, instanceName, addTransition):
	global unitInstanceName

	# add step and links to step in UP
	stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
	priorStepName = 'PH'+str(stepNum-1)
	upStep = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink(phaseName))
	unitProcedure.addLink(priorStepNum,stepNum)
	
	# add links to transition in UP
	if addTransition == True:
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		priorStepNum = stepNum-1
		priorStepName = 'PH'+str(stepNum-1)
		transition = unitProcedure.addStep('T_PH'+str(stepNum-1), stepNum, system.mes.batch.phase.getBuiltInPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(priorStepNum)+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
	
	### add parameters and deferals to recipeObj and step
	setDeferals(unitProcedure, upStep, unitInstanceName, instanceName)

# create unit procedure
def createUnitProcedure(procedure, unitClassName, addTransition):
	
	# create unit procedure
	unitProcedure = procedure.createLogic('Unit Procedure')
	unitClassLink = system.mes.batch.unitclass.getLink(unitClassName)
	unitProcedure.setUnitClassRef(unitClassLink)
	saveList.add(unitProcedure)

	# add step links to step in Procedure
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	priorStepName = 'UP'+str(stepNum-1)
	pStep = procedure.addStep('UP'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Unit Procedure'))
	pStep.setLogicRefUUID(unitProcedure.getUUID())
	procedure.addLink(stepNum-1,stepNum)
	
	# add links to transition in UP
	if addTransition == True:
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		priorStepName = 'UP'+str(stepNum-1)
		transition = procedure.addStep('T_UP'+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',priorStepName+'.Complete')
		procedure.addLink(stepNum-1,stepNum)
	
	# add start block in UP
	unitProcedure.addStep('UP', 0, system.mes.batch.phase.getPhaseLink('Start'))
	
	return unitProcedure

# create procedure
def createProc(recipeClassName, recipeName):
	global parentRecipeClassLink
	
	# check if the recipe exists, and if yes, then delete it
	recipeClassLink = system.mes.batch.recipe.getRecipeClassLink(recipeClassName, None)
	try: 
		recipeLink = system.mes.batch.recipe.getRecipeLink(recipeName, recipeClassLink)
		system.mes.batch.recipe.removeRecipe(recipeLink)
	except:
		pass
	
	# create recipe object
	recipeCls = system.mes.batch.recipe.loadRecipeClass(recipeClassName, parentRecipeClassLink)
	recipe = system.mes.batch.recipe.createRecipe(recipeName, recipeCls.asLink())
	saveList.add(recipe)
	recipe.setRecipeState('')
	recipe.setRecipeScale(1.0)
	recipe.setUserVersion(1)
	
	# create procedure
	procedure = recipe.createLogic('Procedure')
	saveList.add(procedure)
	
	# add the start block
	procedure.addStep('Start', 0, system.mes.batch.phase.getBuiltInPhaseLink('Start'))
	
	### add custom parameters for Procedure
	addParamsToRecipe(procedure)
	
	return procedure

# create syncStep (procedure level)
def addSyncPhase(procedure, priorStepNum, syncGroup, addTransition):
	# add step and links to step in Procedure
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	step = procedure.addStep('UP'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Synchronize'))
	step.setParameterValue('Sync_Group', syncGroup)
	procedure.addLink(priorStepNum,stepNum)
	# add a transition
	if addTransition == True:
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		priorStepNum = stepNum-1
		priorStepName = 'UP'+str(priorStepNum)
		transition = procedure.addStep('T_UP'+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','UP'+str(priorStepNum)+'.Complete')
		procedure.addLink(stepNum-1,stepNum)

# create syncStep (unit procedure level)
def addSyncPhaseInUP(unitProcedure, priorStepNum, syncGroup, addTransition):
	# add step and links to step in Procedure
	stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
	step = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Synchronize'))
	step.setParameterValue('Sync_Group', syncGroup)
	unitProcedure.addLink(priorStepNum,stepNum)
	# add a transition
	if addTransition == True:
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		priorStepNum = stepNum-1
		priorStepName = 'PH'+str(priorStepNum)
		transition = unitProcedure.addStep('T_PH'+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(priorStepNum)+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)

# create noAction (procedure level)
def addNoActionPhase(procedure, priorStepNum, addTransition):
	# add a no action phase
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	procedure.addStep('UP'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('No Action'))
	procedure.addLink(priorStepNum,stepNum)
	# add a transition
	if addTransition == True:
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		priorStepNum = stepNum-1
		priorStepName = 'UP'+str(priorStepNum)
		transition = procedure.addStep('T_UP'+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',priorStepName+'.Complete')
		procedure.addLink(stepNum-1,stepNum)

### CREATE Main SOO RECIPE  						WM_Template
def drugProductRecipeBuilder_ver2():
	global parentRecipeClassLink
	global saveList
	global filePath
	global headerRow
	
	global unitInstanceName
	
	stageProgress = 0
	runningLog = ''
	myLogger = ''
	
	# import WM Sepasoft phase and recipe template file
	filePath='E:\WME\Book3.xlsx'
	headerRow = 7 # do not modify
	sheetNumber = 14 # recipe params sheet
	
	recipeName = 'DrugProduct_ver2 (with TFF mods)'
	recipeClassName = 'CP: Drug Product Recipes'
	
	parentRecipeClassLink = None
	
	saveList = system.mes.object.list.createList()
	procedure = createProc(recipeClassName, recipeName)
	
	# start of Logic // Init: setup
	if 1==1:
	
	# 'And Begin' transition
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		procedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		procedure.addLink(stepNum-1,stepNum)
		andBeginStepNum = stepNum
		andSteps = []
	
		# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartIVT', addTransition=True)
	
		# syncStep
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addSyncPhase(procedure, priorStepNum=(stepNum-1), syncGroup='EndInit', addTransition=False)
		
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Dataset created from Excel file', loggerObj=myLogger, fullLog=runningLog)	
		
	### UM01: IVT (vesselType01) and UM02: IVTP (vesselType01)
	if 1==1:
	
		# syncStep
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartIVT', addTransition=True)
	
	# IVT unit Proc
		unitInstanceName = 'ivt'
		unitClassName = 'UM01_IVT'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1', addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2', addTransition=True)
		
	# "And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Recirc', instanceName='RECIRC', addTransition=False)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Analytics', instanceName='ANALYTICS', addTransition=False)
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='SKID', instanceName='SKID', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('UP'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
	
		endRecipeObj(unitProcedure)
		
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Dataset created from Excel file', loggerObj=myLogger, fullLog=runningLog)	
	
	# IVTP Unit Proc
		unitInstanceName = 'ivtp'
		unitClassName = 'UM02_IVTP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
		
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='SETUP', addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndInit', addTransition=True)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Recirc', instanceName='RECIRC',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndInit', addTransition=True)
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndInit', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE1',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1',addTransition=True)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count < 2' + ' AND ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec = "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T'+str(stepNum-1),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count >= 2' + ' OR ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec != "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE2',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER2',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T_PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT4',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName = 'tff1'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC2',addTransition=True)
		unitInstanceName = 'ivtp'
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartTFF1', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartCHRP_mod', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndIVTP', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM07: CHRP (vesselType01)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartCHRP_mod', addTransition=True)
	
	# Unit Proc
		unitInstanceName = 'chrp'
		unitClassName = 'UM07_CHRP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Recirc', instanceName='RECIRC',addTransition=False)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRP_mod', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
	
	### UM03: TFF1 (vesselType02) and UM04: TF1P (vesselType02) MODIFIED
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartTFF1', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'tf1p'
		unitClassName = 'UM09_TF2P'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='Setup',addTransition=True)
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName='tff1'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='SKID', instanceName='SKID',addTransition=True)
		unitInstanceName='tf1p'
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRP_mod', addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndIVTP', addTransition=True)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Recirc', instanceName='RECIRC',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndIVTP', addTransition=True)
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndIVTP', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE1',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1',addTransition=True)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count < 2' + ' AND ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec = "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T'+str(stepNum-1),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count >= 2' + ' OR ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec != "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE2',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER2',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT4',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartCHRL', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
	
	### UM03: TFF1 (vesselType02) MODIFIED
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartTFF1_mod', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'tf1p'
		unitClassName = 'UM04_TF1P'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferOutTF1P', addTransition=True)
		
		# xfer-out operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-Out', instanceName='XFER-OUT',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInCHRL', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndTF1P', addTransition=True)
		
		# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM05: CHRL (vesselType03) MODIFIED
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartCHRL', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'chrl'
		unitClassName = 'UM05_CHRL'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='Setup',addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='StartTFF1_mod', addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='CHRL', addTransition=True)
		
		# temp operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Temp', instanceName='TEMP',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='XferOutTF1P', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInCHRL', addTransition=True)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndTF1P', addTransition=True)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='CHRL', addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName='chrm'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC',addTransition=True)
		unitInstanceName='chrl'
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT5',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartCHRM', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndCHRL', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM06: CHRM (vesselType01) and UM07: CHRP (vesselType01)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartCHRM', addTransition=True)
	
	# Unit Proc
		unitInstanceName = 'chrp'
		unitClassName = 'UM07_CHRP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
		
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='SETUP', addTransition=True)
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName='chrm'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='SKID', instanceName='SKID',addTransition=True)
		unitInstanceName='chrp'
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRL', addTransition=True)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Recirc', instanceName='RECIRC',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRL', addTransition=True)
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndCHRL', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE2',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER2',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T_PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT4',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		# AND PH##:PH.L_out_select = 1
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName = 'tff2'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC2',addTransition=True)
		unitInstanceName = 'chrp'
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartTFF2', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartLSPP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndCHRP', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM08: TFF2 (vesselType02) and UM09: TF2P (vesselType02)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartTFF2', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'tf2p'
		unitClassName = 'UM09_TF2P'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='Setup',addTransition=True)
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName='tff2'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='SKID', instanceName='SKID',addTransition=True)
		unitInstanceName='tf2p'
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRP', addTransition=True)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Recirc', instanceName='RECIRC',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRP', addTransition=True)
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndCHRP', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE1',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1',addTransition=True)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count < 2' + ' AND ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec = "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T'+str(stepNum-1),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count >= 2' + ' OR ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec != "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE2',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER2',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT4',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartDDSP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferOutTF2P', addTransition=True)
		
		# xfer-out operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-Out', instanceName='XFER-OUT',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInDDSP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndTF2P', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM10: DDSP (vesselType03)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartDDSP', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'ddsp'
		unitClassName = 'UM10_DDSP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='Setup',addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='XferOutTF2P', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInDDSP', addTransition=True)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndTF2P', addTransition=True)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName = 'lnp'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC',addTransition=True)
		unitInstanceName = 'ddsp'
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT5',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartLNP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndDDSP', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM11: LSPP (vesselType03)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartLSPP', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'lspp'
		unitClassName = 'UM11_LSPP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2',addTransition=True)
		
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='SETUP',addTransition=True)
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='LSPP', instanceName='LSPP',addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# temp operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Temp', instanceName='TEMP',addTransition=False)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Time', instanceName='TIMER',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartLSF', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferOutLSPP', addTransition=True)
		
		# xfer-out operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-Out', instanceName='XFER-OUT',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndLSPP', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM12: LSF (vesselType03)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartLSF', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'lsf'
		unitClassName = 'UM12_LSF'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='SETUP',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferOutLSPP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndLSPP', addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='syncLSF', addTransition=True)
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Prompt', instanceName='PROMPT1',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		upOrSteps = []
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upOrSteps.append(stepNum+1) # track for AndEnd step
		opTransitionConditions = str(stepNum) # track for AndEnd transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin1', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps1 = []
		
		# temp operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps1.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Temp', instanceName='TEMP',addTransition=False)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Time', instanceName='TIMER',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps1.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd1', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps1:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		upOrSteps.append(stepNum) # track for AndEnd step
		
	# 'Or End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrEnd', stepNum, system.mes.batch.phase.getPhaseLink('Or End'))
		orEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upOrSteps:
			unitProcedure.addLink(stepNum,orEndStepNum)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='syncLSF', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartLNP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndLSF', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM13: LNP (vesselType03)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartLNP', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'lnp'
		unitClassName = 'UM13_LNP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='SKID', instanceName='SKID',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndDDSP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndLSF', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName = 'tff3'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC',addTransition=True)
		unitInstanceName = 'lnp'
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartTFF3', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndLNP', addTransition=False)
		
	# transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM14: TFF3 (vesselType02) and UM15: TF3P (vesselType02)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartTFF3', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'tf3p'
		unitClassName = 'UM15_TF3P'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartFMDP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndLNP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartTFF3Skid', addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		unitInstanceName='tff3'
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='SKID', instanceName='SKID',addTransition=False)
		unitInstanceName='tf3p'
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='XferOutTF3P', addTransition=True)
		
		# xfer-out operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-Out', instanceName='XFER-OUT',addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInFMDP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndTF3P', addTransition=True)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM16: FMDP (vesselType03)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartFMDP', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'fmdp'
		unitClassName = 'UM16_FMDP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='Setup',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartTFF3Skid', addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferOutTF3P', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInFMDP', addTransition=True)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndTF3P', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT4',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count < 2' + ' AND ' + '(PH'+opTransitionConditionOnly+'.L_concentration_spec = "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE2',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count >= 2' + ' OR ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec != "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Time', instanceName='TIMER1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT5',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartBDP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferOutFMDP', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin1', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Calc', instanceName='CALC1',addTransition=True)
		
		# xfer-out operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-Out', instanceName='XFER-OUT',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInBDP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndFMDP', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd1', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM17: BDP (vesselType03)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartBDP', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'bdp'
		unitClassName = 'UM17_BDP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='Setup',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferOutFMDP', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInBDP', addTransition=True)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndFMDP', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE1',addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Prompt', instanceName='PROMPT5',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartFF', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
		# xfer-out operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-Out', instanceName='XFER-OUT',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT6',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndBDP', addTransition=True)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	# end of Logic
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartFF', addTransition=True)
		
	# syncStep
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = stepNum # track for AndEnd transition step
		addSyncPhase(procedure, priorStepNum=(stepNum-1), syncGroup='EndBDP', addTransition=False)
	
	# 'And End' transition
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		procedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in andSteps:
			procedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'UP'+str(stepNum)+'.Complete'
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = procedure.addStep('UP'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'UP'+str(transitionConditionOnly)+'.Complete')
		procedure.addLink(stepNum-1,stepNum)
	
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
	
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = procedure.addStep('T_UP'+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','UP'+str(transitionConditionOnly)+'.Complete')
		procedure.addLink(stepNum-1,stepNum)
	
	# saveProcedure
	if 1==1:
	# end Procedure
		endRecipeObj(procedure)
	# save Recipe
		logs = system.mes.batch.recipe.validateRecipe(saveList)
		system.mes.batch.recipe.saveRecipe(saveList)
		system.mes.invalidateCache()
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, logs, loggerObj=myLogger, fullLog=runningLog)

### CREATE Main SOO RECIPE  						WM_Template
def drugSubstanceRecipeBuilder_ver1():
	global parentRecipeClassLink
	global saveList
	global filePath
	global headerRow
	
	global unitInstanceName
	
	stageProgress = 0
	runningLog = ''
	myLogger = ''
		
	# import WM Sepasoft phase and recipe template file
	filePath='E:\WME\Book3.xlsx'
	headerRow = 7 # do not modify
	sheetNumber = 14 # recipe params sheet
	
	recipeName = 'DrugSubstance_ver1'
	recipeClassName = 'CP: Drug Substance Recipes'
	parentRecipeClassLink = None
	
	saveList = system.mes.object.list.createList()
	procedure = createProc(recipeClassName, recipeName)
	
	# start of Logic // Init: setup
	if 1==1:
	
	# 'And Begin' transition
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		procedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		procedure.addLink(stepNum-1,stepNum)
		andBeginStepNum = stepNum
		andSteps = []
	
		# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartIVT', addTransition=True)
	
		# syncStep
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addSyncPhase(procedure, priorStepNum=(stepNum-1), syncGroup='EndInit', addTransition=False)
	
	### UM01: IVT (vesselType01) and UM02: IVTP (vesselType01)
	if 1==1:
	
		# syncStep
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartIVT', addTransition=True)
	
	# IVT unit Proc
		unitInstanceName = 'ivt'
		unitClassName = 'UM01_IVT'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1', addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2', addTransition=True)
		
	# "And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Recirc', instanceName='RECIRC', addTransition=False)
		
		# recirc analytics
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Analytics', instanceName='ANALYTICS', addTransition=False)
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='SKID', instanceName='SKID', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('UP'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
	
		endRecipeObj(unitProcedure)
	
	# IVTP Unit Proc
		unitInstanceName = 'ivtp'
		unitClassName = 'UM02_IVTP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
		
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='SETUP', addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndInit', addTransition=True)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Recirc', instanceName='RECIRC',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndInit', addTransition=True)
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndInit', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE1',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1',addTransition=True)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count < 2' + ' AND ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec = "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T'+str(stepNum-1),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count >= 2' + ' OR ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec != "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE2',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER2',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T_PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT4',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName = 'tff1'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC2',addTransition=True)
		unitInstanceName = 'ivtp'
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartTFF1', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndIVTP', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM03: TFF1 (vesselType02) and UM04: TF1P (vesselType02)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartTFF1', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'tf1p'
		unitClassName = 'UM04_TF1P'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='Setup',addTransition=True)
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName='tff1'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='SKID', instanceName='SKID',addTransition=True)
		unitInstanceName='tf1p'
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndIVTP', addTransition=True)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Recirc', instanceName='RECIRC',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndIVTP', addTransition=True)
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndIVTP', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE1',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1',addTransition=True)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count < 2' + ' AND ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec = "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T'+str(stepNum-1),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count >= 2' + ' OR ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec != "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE2',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER2',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT4',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartCHRL', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferOutTF1P', addTransition=True)
		
		# xfer-out operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-Out', instanceName='XFER-OUT',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInCHRL', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndTF1P', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM05: CHRL (vesselType03)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartCHRL', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'chrl'
		unitClassName = 'UM05_CHRL'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='Setup',addTransition=True)
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='CHRL', addTransition=True)
		
		# temp operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Temp', instanceName='TEMP',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='XferOutTF1P', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='XferInCHRL', addTransition=True)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndTF1P', addTransition=True)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='CHRL', addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName='chrm'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC',addTransition=True)
		unitInstanceName='chrl'
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT5',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartCHRM', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndCHRL', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM06: CHRM (vesselType01) and UM07: CHRP (vesselType01)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartCHRM', addTransition=True)
	
	# Unit Proc
		unitInstanceName = 'chrp'
		unitClassName = 'UM07_CHRP'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
		
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='SETUP', addTransition=True)
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName='chrm'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='SKID', instanceName='SKID',addTransition=True)
		unitInstanceName='chrp'
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRL', addTransition=True)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Recirc', instanceName='RECIRC',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRL', addTransition=True)
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndCHRL', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE2',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER2',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T_PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT4',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		# AND PH##:PH.L_out_select = 1
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName = 'tff2'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC2',addTransition=True)
		unitInstanceName = 'chrp'
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='StartTFF2', addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		opTransitionConditionOnly = str(stepNum) # track for AndEnd transition step
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndCHRP', addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
		
	### UM08: TFF2 (vesselType02) and UM09: TF2P (vesselType02)
	if 1==1:
	
	# syncStep
		addSyncPhase(procedure, andBeginStepNum, syncGroup='StartTFF2', addTransition=True)
	
	# unit Proc
		unitInstanceName = 'tf2p'
		unitClassName = 'UM09_TF2P'
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
#		andSteps.append(stepNum) # track for AndEnd step
		transitionConditionOnly = str(stepNum) # track for AndEnd transition step
		unitProcedure = createUnitProcedure(procedure, unitClassName, addTransition=True)
	
		# setup operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Setup', instanceName='Setup',addTransition=True)
		
		# SKID operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitInstanceName='tff2'
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='SKID', instanceName='SKID',addTransition=True)
		unitInstanceName='tf2p'
		
	# 'And Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndBegin', stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
		unitProcedure.addLink(stepNum-1,stepNum)
		upAndBeginStepNum = stepNum
		upAndSteps = []
		
		# ag operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Ag', instanceName='AG',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRP', addTransition=True)
		
		# recirc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Recirc', instanceName='RECIRC',addTransition=False)
		
		# synStep
		addSyncPhaseInUP(unitProcedure, upAndBeginStepNum, syncGroup='EndCHRP', addTransition=True)
		
		# analytics operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Analytics', instanceName='ANALYTICS',addTransition=False)
		
		# xfer-in operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, upAndBeginStepNum, phaseName='Xfer-In', instanceName='XFER-IN',addTransition=True)
		
		# synStep
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addSyncPhaseInUP(unitProcedure, priorStepNum=(stepNum-1), syncGroup='EndCHRP', addTransition=True)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE1',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT1',addTransition=True)
		
		# dilute operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Dilute', instanceName='DILUTION',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count < 2' + ' AND ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec = "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T'+str(stepNum-1),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+str(opTransitionConditionOnly)+'.Execute_Count >= 2' + ' OR ' + 'PH'+opTransitionConditionOnly+'.L_concentration_spec != "above range"')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# sample operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionBack = stepNum # track for transition BACK step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Sample', instanceName='SAMPLE2',addTransition=True)
		
		# timer operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Time', instanceName='TIMER2',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT2',addTransition=True)
		
		# calc operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Calc', instanceName='CALC1',addTransition=True)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		opTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT3',addTransition=True)
		
	# 'Or Begin' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
		orBeginStepNum = stepNum
		unitProcedure.addLink(stepNum-1,stepNum)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'PH'+opTransitionConditionOnly+'.L_out_select = 2')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# prompt operation
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		operation = createOperation(unitProcedure, priorStepNum=(stepNum-1), phaseName='Prompt', instanceName='PROMPT4',addTransition=True)
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addLink('T_PH'+str(stepNum-2),'PH'+str(opTransitionBack))
		
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('T'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.L_out_select = 1')
		unitProcedure.addLink(orBeginStepNum,stepNum)
		
		# noAction
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		upAndSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(unitProcedure, priorStepNum=(stepNum-1), addTransition=False)
		
	# 'And End' transition
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		unitProcedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in upAndSteps:
			unitProcedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'PH'+str(stepNum)+'.Complete'
		stepNum = unitProcedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = unitProcedure.addStep('PH'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','PH'+opTransitionConditionOnly+'.Complete')
		unitProcedure.addLink(stepNum-1,stepNum)
		
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
		
		endRecipeObj(unitProcedure)
	
	# end of Logic
	if 1==1:
	# 'And End' transition
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		procedure.addStep('AndEnd', stepNum, system.mes.batch.phase.getPhaseLink('And End'))
		andEndStepNum = stepNum
		transitionExp = ''
		for stepNum in andSteps:
			procedure.addLink(stepNum,andEndStepNum)
			if len(transitionExp) != 0:
				transitionExp = transitionExp + ' AND '
			transitionExp = transitionExp + 'UP'+str(stepNum)+'.Complete'
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = procedure.addStep('UP'+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression', 'UP'+str(transitionConditionOnly)+'.Complete')
		procedure.addLink(stepNum-1,stepNum)
	
	# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addNoActionPhase(procedure, priorStepNum=(stepNum-1), addTransition=False)
	
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = procedure.addStep('T_UP'+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','UP'+str(transitionConditionOnly)+'.Complete')
		procedure.addLink(stepNum-1,stepNum)
	# saveProcedure
	if 1==1:
	
		# end Procedure
		endRecipeObj(procedure)
		# save Recipe
		logs = system.mes.batch.recipe.validateRecipe(saveList)
		system.mes.batch.recipe.saveRecipe(saveList)
		system.mes.invalidateCache()
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, logs, loggerObj=myLogger, fullLog=runningLog)




if 1==2:
	pass