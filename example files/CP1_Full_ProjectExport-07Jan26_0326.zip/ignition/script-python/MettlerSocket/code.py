import re
from time import sleep
from java.io import IOException
from java.net import Socket
from java.net import InetSocketAddress
from java.nio import ByteBuffer
from java.nio.channels import SocketChannel
from java.nio.charset import StandardCharsets
from java.lang import String

# Helper function to read from the channel and decode the response
def read_response(channel):
	# Create a buffer to read data from the socket
	buffer = ByteBuffer.allocate(1024)
	channel.read(buffer)  # Read the response from the channel

	# Flip the buffer to prepare for reading
	buffer.flip()
	
	# Decode the byte buffer into a string and strip unwanted spaces or newlines
	response = StandardCharsets.ISO_8859_1.decode(buffer).toString().strip()
	
	return response

# Helper function to send a command and receive a response
def send_command(channel, command):
	# Write the command to the channel
	channel.write(ByteBuffer.wrap(String(command).getBytes(StandardCharsets.ISO_8859_1)))
	
	# Wait a moment for the scale to process the command
	sleep(1)
	
	# Read the response using the read_response function
	response = read_response(channel)
	
	return response

# Simplified function to connect to the scale and interact
def test_scale_connection(command):
	ip = '10.118.92.129'
	port = 1701
	timeout = 100  # 100 milliseconds timeout
	
	for attempt in range(0,3):
		try:
			e = ""
			
			# Create socket channel and configure
			sa = InetSocketAddress(ip, port)
			channel = SocketChannel.open()
			channel.socket().setSoTimeout(timeout)  # Set socket read timeout
			channel.configureBlocking(True)
			channel.socket().setReuseAddress(True) # Set reuse address
			channel.connect(sa)
			# Send 'user admin' command and receive response
			response = send_command(channel, 'user admin\r')
			
			if command==0:
				# Send 'read wt0102' command to read the weight
				response = send_command(channel, 'read wt0102\r')
				# Regular expression to capture the value between ~ symbols
				match = re.search(r'~\s*(-?[\d\.]+)\s*~', str(response)).group(1)
				system.tag.writeAsync("[default]RBP/IO/MettlerScale01/Source_Weight", match)
			
			if command==1:
				# Send 'write wc0101=1' command to tare the scale
				response = send_command(channel, 'write wc0101=1\r')
			
			if command==2:
				# Send 'write wc0104=1' command to zero the scale
				response = send_command(channel, 'write wc0104=1\r')
			
			break
			
		except IOException as e:
			system.tag.writeAsync("[default]RBP/IO/MettlerScale01/Source_Weight", -9999)
		except Exception as e:
			system.tag.writeAsync("[default]RBP/IO/MettlerScale01/Source_Weight", -9999)
		finally:
			try:
				# Close the connection
				channel.close()
			except Exception as e:
				system.tag.writeAsync("[default]RBP/IO/MettlerScale01/Source_Weight", -9999)
	
	# if connection fails, write error value to weight
	if len(str(e)):
		system.tag.writeAsync("[default]RBP/IO/MettlerScale01/Source_Weight", -9999)

# Test the connection to the scale
# test_scale_connection(command=0)