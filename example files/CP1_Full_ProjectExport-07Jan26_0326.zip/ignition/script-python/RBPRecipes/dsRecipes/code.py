global filePath
global dataHeaderRow
global recipeParamSheet
global deferalParamSheet

global saveList
global unitInstanceName
	
def do(obj,searchString):
	members = dir(obj)
	for member in members:
		if searchString.upper() in member.upper():
			print (member)

################################################################################

# add parameters to recipeObj
def addParams(obj):
	global filePath
	global dataHeaderRow
	global recipeParamSheet
	dataSet = WM_FIRE.dataset.excelToDataSet(filePath, dataHeaderRow, recipeParamSheet)
	
	for row in range(dataSet.getRowCount()):
		
		paramName = str(dataSet.getValueAt(row, 0))
		recordingType = str(dataSet.getValueAt(row, 1))
		valueSource = str(dataSet.getValueAt(row, 2))
		tagType = str(dataSet.getValueAt(row, 3))
		dataType = str(dataSet.getValueAt(row, 4))
		enumDefUUID = str(dataSet.getValueAt(row, 5))
		minValue = (dataSet.getValueAt(row, 6))
		maxValue = (dataSet.getValueAt(row, 7))
		defaultValue = (dataSet.getValueAt(row, 8))
		engUnits = str(dataSet.getValueAt(row, 9))
		
		# if parameter to be set during Recipe and Execution, define parameter
		if valueSource == 'Recipe and Execution':
			param = obj.addParameter(paramName)
			param.setParamKindName('User Phase')
			param.setParamRecordingTypeName(recordingType)
			param.setParamValueSourceName(valueSource)		
			if tagType != "NULL" and tagType != "n/a":
				param.setParamTagTypeName(tagType)
			param.setParamDataTypeName(dataType)
			if dataType == 'Enum':
				param.setParamEnumDefUUID(enumDefUUID)
			if dataType == 'Integer':
				defaultValue = int(float(defaultValue))
				param.setParamMaxValueAsString(str(int(float(maxValue))))
				param.setParamMinValueAsString(str(int(float(minValue))))
			if dataType == 'Byte' or dataType == 'Double' or dataType == 'Float' or dataType == 'Long' or dataType == 'Short':
				param.setParamMaxValueAsString(str(maxValue))
				param.setParamMinValueAsString(str(minValue))
			if defaultValue != "NULL":
				param.setParamValueAsString(str(defaultValue))
			param.setParamUnits(engUnits)
# create procedure
def createProc(recipeClassName, recipeName, parentRecipeClassLink):
	
	# check if the recipe exists, and if yes, then delete it
	recipeClassLink = system.mes.batch.recipe.getRecipeClassLink(recipeClassName, None)
	try: 
		recipeLink = system.mes.batch.recipe.getRecipeLink(recipeName, recipeClassLink)
		system.mes.batch.recipe.removeRecipe(recipeLink)
	except:
		pass
	
	# create recipe object
	recipeCls = system.mes.batch.recipe.loadRecipeClass(recipeClassName, parentRecipeClassLink)
	recipe = system.mes.batch.recipe.createRecipe(recipeName, recipeCls.asLink())
	saveList.add(recipe)
	recipe.setRecipeState('')
	recipe.setRecipeScale(1.0)
	recipe.setUserVersion(1)
	
	# create procedure
	procedure = recipe.createLogic('Procedure')
	saveList.add(procedure)
	
	# add the start block
	procedure.addStep('Start', 0, system.mes.batch.phase.getBuiltInPhaseLink('Start'))
	
	# add recipe parameters
	addParams(procedure)
	
	return procedure

# create unit procedure
def createUP(obj, priorStepNum, addTransition, className, instanceName):
	
	# create unit procedure
	unitProcedure = obj.createLogic('Unit Procedure')
	unitClassLink = system.mes.batch.unitclass.getLink(className)
	unitProcedure.setUnitClassRef(unitClassLink)
	saveList.add(unitProcedure)

	# add step links to unit procedure in Procedure
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	pStep = obj.addStep(str(stepNum)+' - '+instanceName, stepNum, system.mes.batch.phase.getPhaseLink('Unit Procedure'))
	pStep.setLogicRefUUID(unitProcedure.getUUID())
	obj.addLink(priorStepNum,stepNum)
	
	# add links to transition in Procedure
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+instanceName, stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',str(stepNum-1)+' - '+instanceName+'.Complete')
		obj.addLink(stepNum-1,stepNum)
	
	# add start block in unit procedure
	unitProcedure.addStep('UP', 0, system.mes.batch.phase.getPhaseLink('Start'))
	
	return unitProcedure
# set deferals to recipeObj
def setDeferals(step, instanceName, phaseName):
	global filePath
	global dataHeaderRow
	global deferalParamSheet
	global unitInstanceName
	dataSet = WM_FIRE.dataset.excelToDataSet(filePath, dataHeaderRow, deferalParamSheet)

	for row in range(dataSet.getRowCount()):
		unitID = str(dataSet.getValueAt(row, 0))
		unitName = str(dataSet.getValueAt(row, 1))
		phaseClassName = str(dataSet.getValueAt(row, 2))
		phaseInstance = str(dataSet.getValueAt(row, 3))
		paramDesc = str(dataSet.getValueAt(row, 4))
		dataType = str(dataSet.getValueAt(row, 5))
		
		phaseParamName = str(dataSet.getValueAt(row, 6))
		phaseDeferParam = dataSet.getValueAt(row, 7)
		phaseCalcValue = dataSet.getValueAt(row, 8)
		phaseParamValue = dataSet.getValueAt(row, 9)
		recipeParamName = dataSet.getValueAt(row, 10)
		recipeParamValue = dataSet.getValueAt(row, 11)
		
		# define parameters
		if dataType == 'Integer' and phaseParamValue != 'n/a':
			phaseParamValue = int(float(phaseParamValue))
		#print unitName, instanceName, ' - ', phaseInstance, ' - ', phaseName
		if unitName == instanceName and phaseInstance == phaseName:
			#print untiName, unitInstanceName, ' - ', phaseInstanceName, instanceName, ' - ', phaseParamName
			#set params
			if phaseDeferParam == 1: #true
				#print phaseParamName, phaseCalcValue
				step.setParameterCalculation(phaseParamName, phaseCalcValue)
			else:
				if phaseParamValue != 'n/a':
					#print phaseName,phaseParamName,phaseParamValue
				
				
					step.setParameterValueAsString(str(phaseParamName), str(phaseParamValue))
# add step
def addStep(obj, priorStepNum, addTransition, instanceName, className, phaseName):

	# create step
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	step = obj.addStep(str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink(className))
	obj.addLink(priorStepNum,stepNum)
	
	# add links to step
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+str(stepNum-1), stepNum, system.mes.batch.phase.getBuiltInPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',str(stepNum-1)+'.Complete')
		obj.addLink(stepNum-1,stepNum)
	
	# add parameters and deferals
	setDeferals(step, instanceName, phaseName)

def addAndBegin(obj, priorStepNum):
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	obj.addStep(str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('And Begin'))
	obj.addLink(priorStepNum,stepNum)
def addAndEnd(obj, andSteps, transitionConditionOnly):
	# 'And End' transition
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	obj.addStep(str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('And End'))
	andEndStepNum = stepNum
	transitionExp = ''
	for stepNum in andSteps:
		obj.addLink(stepNum,andEndStepNum)
		if len(transitionExp) != 0:
			transitionExp = transitionExp + ' AND '
		transitionExp = transitionExp + str(stepNum)+'.Complete'
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = obj.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression',transitionConditionOnly+'.Complete')
	obj.addLink(stepNum-1,stepNum)

def addAndEndMultiCondition(obj, andSteps):		
# 'And End' transition
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	obj.addStep(str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('And End'))
	andEndStepNum = stepNum
	transitionExp = ''
	for stepNum in andSteps:
		obj.addLink(stepNum,andEndStepNum)
		if len(transitionExp) != 0:
			transitionExp = transitionExp + ' AND '
		transitionExp = transitionExp + str(stepNum)+'.Complete'
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = obj.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', transitionExp)
	obj.addLink(stepNum-1,stepNum)	
	
# add noAction
def addNoAction(obj, priorStepNum, addTransition):
	# add a no action phase
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	obj.addStep(str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('No Action'))
	obj.addLink(priorStepNum,stepNum)
	# add a transition
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',str(stepNum-1)+'.Complete')
		obj.addLink(stepNum-1,stepNum)

# end recipeObject
def endRecipeObj(recipeObj):
	# add a terminator (within OP) and link with above step
	stepNum = recipeObj.getComplexPropertyCount('BatchMasterLogicSteps')
	recipeObj.addStep('End', stepNum, system.mes.batch.phase.getPhaseLink('Terminator'))
	recipeObj.addLink(stepNum-1,stepNum)

################################################################################

# set syncParam
def setSyncParam(obj, priorStepNum, addTransition, paramName, paramValue):
	# add a no action phase
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	step = obj.addStep(str(stepNum)+' - '+str(paramName), stepNum, system.mes.batch.phase.getPhaseLink('Set Parameter'))
	step.setParameterValue('Parameter_Path','/{}.xsync_'+paramName)
	step.setParameterValue('Parameter_Value',paramValue)
	obj.addLink(priorStepNum,stepNum)
	# add a transition
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',str(stepNum-1)+' - '+str(paramName)+'.Complete')
		obj.addLink(stepNum-1,stepNum)
# monitor syncParam
def monSyncParam(obj, priorStepNum, addTransition, paramName):
	# add a no action phase
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	obj.addStep(str(stepNum)+' - '+str(paramName), stepNum, system.mes.batch.phase.getPhaseLink('No Action'))
	obj.addLink(priorStepNum,stepNum)
	# add a transition
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','/{}.xsync_'+str(paramName)+'=true')
		obj.addLink(stepNum-1,stepNum)

################################################################################
	
	### UM01: IVT
def createIVT(procedure, priorStepNum, unitID, unitName, upstreamName, downstreamName):

	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(procedure, priorStepNum=priorStepNum, addTransition=True, paramName='start'+unitName)

# Unit Proc
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	uP = createUP(procedure, priorStepNum=(stepNum-1), addTransition=True, className=(unitID+'_'+unitName), instanceName=unitName)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT1')
	
# 'And Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='RECIRC', phaseName='RECIRC')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='ANALYTICS', phaseName='ANALYTICS')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=upAndBeginStepNum, addTransition=True, paramName=('end'+upstreamName), paramValue=1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='SKID', phaseName='SKID')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE1')	
	
###
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='start'+downstreamName, paramValue=1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='end'+unitName)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=False)
	upAndSteps.append(stepNum) # track for AndEnd step
	
# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEnd(uP, andSteps=upAndSteps, transitionConditionOnly=str(stepNum-1))

	endRecipeObj(uP)
	return uP
	
	
	### UM02: IVTP
def createIVTP(procedure, priorStepNum, unitID, unitName, upstreamName, downstreamName):
	
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(procedure, priorStepNum=priorStepNum, addTransition=True, paramName='start'+unitName)
	
# Unit Proc
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	uP = createUP(procedure, priorStepNum=(stepNum-1), addTransition=True, className=(unitID+'_'+unitName), instanceName=unitName)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='SETUP', phaseName='SETUP')
	
# 'And Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum1 = stepNum
	upAndSteps = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum1, addTransition=False, instanceName=unitName, className='AG', phaseName='AG')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum1, addTransition=True, instanceName=unitName, className='XFER-IN', phaseName='XFER-IN')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName=('end'+upstreamName), paramValue=1)
	
	# 'And Begin' transition for SAMPLE and TIMER
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps_TimerSample1 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE1')
	upAndSteps_TimerSample1.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TIME', phaseName='TIMER1')
	upAndSteps_TimerSample1.append(stepNum) # track for AndEnd step
	
	# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEndMultiCondition(uP, andSteps=upAndSteps_TimerSample1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT1')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='DILUTE', phaseName='DILUTION')
	stepTransitionBack = stepNum # track for transition BACK step
	stepTransitionConditionOnly = str(stepNum) # track for OrBegin transition condition
	
# 'Or Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
	upOrSteps = []
	orBeginStepNum = stepNum
	uP.addLink(stepNum-1,stepNum)

	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression',str(stepTransitionConditionOnly)+'.Execute_Count < 2' + ' AND ' + stepTransitionConditionOnly+'.L_concentration_spec = "above range"')
	uP.addLink(orBeginStepNum,stepNum)
	
	
	
	# 'And Begin' transition for SAMPLE and TIMER
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps_TimerSample4 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE4')
	upAndSteps_TimerSample4.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TIME', phaseName='TIMER4')
	upAndSteps_TimerSample4.append(stepNum) # track for AndEnd step
	
	# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEndMultiCondition(uP, andSteps=upAndSteps_TimerSample4)


	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addLink('T - '+str(stepNum-1),str(stepTransitionBack))

	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression',str(stepTransitionConditionOnly)+'.Execute_Count >= 2' + ' AND ' + stepTransitionConditionOnly+'.L_concentration_spec = "above range"')
	uP.addLink(orBeginStepNum,stepNum)
	

	
	# 'And Begin' transition for SAMPLE and TIMER
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps_TimerSample2 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE2')
	upAndSteps_TimerSample2.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TIME', phaseName='TIMER2')
	upAndSteps_TimerSample2.append(stepNum) # track for AndEnd step
	
	# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEndMultiCondition(uP, andSteps=upAndSteps_TimerSample2)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=stepNum-1, addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT5')	
	upOrSteps.append(stepNum+1)	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_concentration_spec != "above range"')
	uP.addLink(orBeginStepNum,stepNum)
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=True)
	upOrSteps.append(stepNum+1)
	
# 'Or End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrEnd', stepNum, system.mes.batch.phase.getPhaseLink('Or End'))
	orEndStepNum = stepNum
	transitionExp = ''
	for stepNum in upOrSteps:
		uP.addLink(stepNum,orEndStepNum)
	
	
	
#  Set up loop back to prompt for overnight prompt
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='CALC', phaseName='CALC1')
	stepPrompt_back = stepNum
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT3')
	stepTransitionConditionOnly = str(stepNum) # track for OrBegin transition condition
	
# 'Or Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
	orBeginStepNum = stepNum
	uP.addLink(stepNum-1,stepNum)
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_out_select = 2')
	uP.addLink(orBeginStepNum,stepNum)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT4')
	stepNumContinue = stepNum
	
	
	# 'And Begin' transition for SAMPLE and TIMER
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps_TimerSample3 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE3')
	upAndSteps_TimerSample3.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TIME', phaseName='TIMER3')
	upAndSteps_TimerSample3.append(stepNum) # track for AndEnd step
	
	# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEndMultiCondition(uP, andSteps=upAndSteps_TimerSample3)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT2')
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addLink('T - '+str(stepNum-2),str(stepPrompt_back))
	
	
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_out_select = 1')
	uP.addLink(orBeginStepNum,stepNum)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	unitInstanceName = 'TFF1'
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='CALC', phaseName='CALC2')
	unitInstanceName = 'IVTP'
	
###
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='start'+downstreamName, paramValue=1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='end'+unitName)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=False)
	upAndSteps.append(stepNum) # track for AndEnd step
	stepNumEnd = stepNum
	
	
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=upAndBeginStepNum1, addTransition=True, paramName=('end'+upstreamName))
	

	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=False, instanceName=unitName, className='RECIRC', phaseName='RECIRC')
	stepNumRecirc = stepNum
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transitionRecirc = '('+str(stepNumEnd)+'.Complete AND '+stepTransitionConditionOnly+'.L_out_select = 1)'# + 'OR (' + str(stepTransitionConditionOnly)+'.L_out_select = 2 AND ' + str(stepTransitionConditionOnly) + '.State = "Running")'
#transition needs to be manually completed by entering commented section with appropriate phase labels e.g. 39.State = "Running"
	transition.setParameterValueAsString('Transition_Expression', transitionRecirc)
	uP.addLink(stepNum-1,stepNum)
	
	# 'Or Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrBegin3', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
	orBeginStepNum3 = stepNum
	uP.addLink(stepNum-1,stepNum)
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', str(stepNumEnd)+'.Complete')
	
	uP.addLink(orBeginStepNum3,stepNum)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=False)
#	upOrSteps.append(stepNum)
	upAndSteps.append(stepNum) # track for AndEnd step
	
#	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
#	uP.addLink(stepNum-1,stepNum)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_out_select = 2')
	uP.addLink(orBeginStepNum3,stepNum)
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=False)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', str(stepNumContinue)+'.Complete')
	
	uP.addLink(stepNum-1, stepNum)
	
#	uP.addLink(orBeginStepNum3,stepNum)
	
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addLink('T - '+str(stepNum-1),str(stepNumRecirc))
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=upAndBeginStepNum1, addTransition=True, paramName=('end'+upstreamName))
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=False, instanceName=unitName, className='ANALYTICS', phaseName='ANALYTICS')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	
	
# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEnd(uP, andSteps=upAndSteps, transitionConditionOnly=str(stepNumEnd))
	
	endRecipeObj(uP)
	return uP
	

	### UM04: TF1P
def createTF1P(procedure, priorStepNum, unitID, unitName, upstreamName, downstreamName):

	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(procedure, priorStepNum=priorStepNum, addTransition=True, paramName='start'+unitName)

# Unit Proc
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	uP = createUP(procedure, priorStepNum=(stepNum-1), addTransition=True, className=(unitID+'_'+unitName), instanceName=unitName)
	
###
	# 'And Begin' transition for SetSyncParam and AG and RECIRC
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='AG', phaseName='AG')
	upAndSteps.append(stepNum) # track for AndEnd step	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='RECIRC', phaseName='RECIRC')
	upAndSteps.append(stepNum) # track for AndEnd step

	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=upAndBeginStepNum, addTransition=True, paramName='end'+upstreamName, paramValue=1)

	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='start'+downstreamName, paramValue=1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName=('XferOut'+unitName))
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='XFER-OUT', phaseName='XFER-OUT',)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName=('XferIn'+downstreamName), paramValue=1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='end'+unitName)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=False)
	upAndSteps.append(stepNum) # track for AndEnd step
	
# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEnd(uP, andSteps=upAndSteps, transitionConditionOnly=str(stepNum-1))
	
	endRecipeObj(uP)
	return uP
	
	### UM05: CHRL
def createCHRL(procedure, priorStepNum, unitID, unitName, upstreamName, downstreamName):
	
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(procedure, priorStepNum=priorStepNum, addTransition=True, paramName='start'+unitName)

# Unit Proc
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	uP = createUP(procedure, priorStepNum=(stepNum-1), addTransition=True, className=(unitID+'_'+unitName), instanceName=unitName)

	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='SETUP', phaseName='SETUP')
	
# 'And Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='AG', phaseName='AG')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=upAndBeginStepNum, addTransition=True, paramName='XferOut'+upstreamName, paramValue=1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='XferIn'+unitName)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='XFER-IN', phaseName='XFER-IN',)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='end'+upstreamName, paramValue=1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='DILUTE', phaseName='DILUTION')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT1',)
	stepTransitionConditionOnly = str(stepNum) # track for OrBegin transition step
	
# 'Or Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
	orBeginStepNum = stepNum
	uP.addLink(stepNum-1,stepNum)
	upOrSteps = []
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_out_select = 1')
	uP.addLink(orBeginStepNum,stepNum)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=True)
	upOrSteps.append(stepNum+1) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_out_select = 2')
	uP.addLink(orBeginStepNum,stepNum)
	
# 'And Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps1 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TEMP', phaseName='TEMP')
	upAndSteps1.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=True, instanceName=unitName, className='TIME', phaseName='TIMER')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=False, instanceName=unitName, className='PROMPT', phaseName='PROMPT3')
	upAndSteps1.append(stepNum) # track for AndEnd step
	
# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEnd(uP, andSteps=upAndSteps1, transitionConditionOnly=str(stepNum-1))
	upOrSteps.append(stepNum+1) # track for AndEnd step
	
# 'Or End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrEnd', stepNum, system.mes.batch.phase.getPhaseLink('Or End'))
	orEndStepNum = stepNum
	transitionExp = ''
	for stepNum in upOrSteps:
		uP.addLink(stepNum,orEndStepNum)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	unitInstanceName='CHRM'
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='CALC', phaseName='CALC')
	unitInstanceName='CHRL'
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT5')
	
###
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='start'+downstreamName, paramValue=1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='end'+unitName)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=False)
	upAndSteps.append(stepNum) # track for AndEnd step
	
# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEnd(uP, andSteps=upAndSteps, transitionConditionOnly=str(stepNum-1))
	
	endRecipeObj(uP)
	return uP

	### UM06: CHRM and UM07: CHRP
def createCHRP(procedure, priorStepNum, unitID, unitName, upstreamName, downstreamName):
	
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(procedure, priorStepNum=priorStepNum, addTransition=True, paramName='start'+unitName)

# Unit Proc
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	uP = createUP(procedure, priorStepNum=(stepNum-1), addTransition=True, className=(unitID+'_'+unitName), instanceName=unitName)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='SETUP', phaseName='SETUP')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	unitInstanceName='CHRM'
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='SKID', phaseName='SKID')
	unitInstanceName='CHRP'
	
# 'And Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='AG', phaseName='AG')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=upAndBeginStepNum, addTransition=True, paramName=('end'+upstreamName))
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=False, instanceName=unitName, className='RECIRC', phaseName='RECIRC')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=upAndBeginStepNum, addTransition=True, paramName=('end'+upstreamName))
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=False, instanceName=unitName, className='ANALYTICS', phaseName='ANALYTICS')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=True, instanceName=unitName, className='XFER-IN', phaseName='XFER-IN')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName=('end'+upstreamName), paramValue=1)
	
#  Set up loop back to NA for later prompt 
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=True)
	stepNA_back = stepNum
	
	# 'And Begin' transition for SAMPLE and TIMER
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps_TimerSample2 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE2')
	upAndSteps_TimerSample2.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TIME', phaseName='TIMER2')
	upAndSteps_TimerSample2.append(stepNum) # track for AndEnd step
	
	# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEndMultiCondition(uP, andSteps=upAndSteps_TimerSample2)
			
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT2')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='CALC', phaseName='CALC1')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT3')
	stepTransitionConditionOnly = str(stepNum) # track for OrBegin transition condition
	
# 'Or Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
	orBeginStepNum = stepNum
	uP.addLink(stepNum-1,stepNum)
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_out_select = 2')
	uP.addLink(orBeginStepNum,stepNum)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT4')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addLink('T - '+str(stepNum-2),str(stepNA_back))
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_out_select = 1')
	uP.addLink(orBeginStepNum,stepNum)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	#unitInstanceName = 'TFF2'
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='CALC', phaseName='CALC2')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='CALC', phaseName='CALC3')
	#unitInstanceName = 'CHRP'
###
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='start'+downstreamName, paramValue=1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName='end'+unitName)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=False)
	upAndSteps.append(stepNum) # track for AndEnd step
	
# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEnd(uP, andSteps=upAndSteps, transitionConditionOnly=str(stepNum-1))
	
	endRecipeObj(uP)
	return uP
	
	### UM08: TFF2 and UM09: TF2P
def createTF2P(procedure, priorStepNum, unitID, unitName, upstreamName, downstreamName):
	
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(procedure, priorStepNum=priorStepNum, addTransition=True, paramName='start'+unitName)

# Unit Proc
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	uP = createUP(procedure, priorStepNum=(stepNum-1), addTransition=True, className=(unitID+'_'+unitName), instanceName=unitName)

	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='SETUP', phaseName='SETUP')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	unitInstanceName='TFF2'
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='SKID', phaseName='SKID')
	unitInstanceName='TF2P'
	
# 'And Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='AG', phaseName='AG')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=upAndBeginStepNum, addTransition=True, paramName=('end'+upstreamName))
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=False, instanceName=unitName, className='RECIRC', phaseName='RECIRC')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	monSyncParam(uP, priorStepNum=upAndBeginStepNum, addTransition=True, paramName=('end'+upstreamName))
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=False, instanceName=unitName, className='ANALYTICS', phaseName='ANALYTICS')
	upAndSteps.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=True, instanceName=unitName, className='XFER-IN', phaseName='XFER-IN')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	setSyncParam(uP, priorStepNum=(stepNum-1), addTransition=True, paramName=('end'+upstreamName), paramValue=1)
	
# 'And Begin' transition for SAMPLE and TIMER
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps_TimerSample1 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE1')
	upAndSteps_TimerSample1.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TIME', phaseName='TIMER1')
	upAndSteps_TimerSample1.append(stepNum) # track for AndEnd step
	
	# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEndMultiCondition(uP, andSteps=upAndSteps_TimerSample1)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT1')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='DILUTE', phaseName='DILUTION')
	stepTransitionBack = stepNum # track for transition BACK step
	stepTransitionConditionOnly = str(stepNum) # track for OrBegin transition condition
	
# 'Or Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrBegin1', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
	upOrSteps = []
	orBeginStepNum = stepNum
	uP.addLink(stepNum-1,stepNum)

	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression',str(stepTransitionConditionOnly)+'.Execute_Count < 2' + ' AND ' + stepTransitionConditionOnly+'.L_concentration_spec = "above range"')
	uP.addLink(orBeginStepNum,stepNum)
	
	
	
	# 'And Begin' transition for SAMPLE and TIMER
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps_TimerSample4 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE4')
	upAndSteps_TimerSample4.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TIME', phaseName='TIMER4')
	upAndSteps_TimerSample4.append(stepNum) # track for AndEnd step
	
	# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEndMultiCondition(uP, andSteps=upAndSteps_TimerSample4)


	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addLink('T - '+str(stepNum-1),str(stepTransitionBack))

	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression',str(stepTransitionConditionOnly)+'.Execute_Count >= 2' + ' AND ' + stepTransitionConditionOnly+'.L_concentration_spec = "above range"')
	uP.addLink(orBeginStepNum,stepNum)
	
	
	# 'And Begin' transition for SAMPLE and TIMER
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps_TimerSample2 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE2')
	upAndSteps_TimerSample2.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TIME', phaseName='TIMER2')
	upAndSteps_TimerSample2.append(stepNum) # track for AndEnd step
	
	# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEndMultiCondition(uP, andSteps=upAndSteps_TimerSample2)
	#upOrSteps.append(stepNum+1)	
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=stepNum-1, addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT5')	
	upOrSteps.append(stepNum+1)		
	
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_concentration_spec != "above range"')
	uP.addLink(orBeginStepNum,stepNum)
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=True)
	upOrSteps.append(stepNum+1)
	
# 'Or End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrEnd', stepNum, system.mes.batch.phase.getPhaseLink('Or End'))
	orEndStepNum = stepNum
	transitionExp = ''
	for stepNum in upOrSteps:
		uP.addLink(stepNum,orEndStepNum)
	
		
	
#	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
#	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT2')
#	stepPrompt_back = stepNum
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='CALC', phaseName='CALC1')
	stepPrompt_back = stepNum
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT3')
	stepTransitionConditionOnly = str(stepNum) # track for OrBegin transition condition
	
# 'Or Begin' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addStep('OrBegin2', stepNum, system.mes.batch.phase.getPhaseLink('Or Begin'))
	orBeginStepNum = stepNum
	uP.addLink(stepNum-1,stepNum)
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_out_select = 2')
	uP.addLink(orBeginStepNum,stepNum)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT4')
	
	
	
	
	# 'And Begin' transition for SAMPLE and TIMER
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndBegin(uP, priorStepNum=(stepNum-1))
	upAndBeginStepNum = stepNum
	upAndSteps_TimerSample4 = []
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='SAMPLE', phaseName='SAMPLE4')
	upAndSteps_TimerSample4.append(stepNum) # track for AndEnd step
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=upAndBeginStepNum, addTransition=False, instanceName=unitName, className='TIME', phaseName='TIMER4')
	upAndSteps_TimerSample4.append(stepNum) # track for AndEnd step
	
	# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEndMultiCondition(uP, andSteps=upAndSteps_TimerSample4)
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	step = addStep(uP, priorStepNum=(stepNum-1), addTransition=True, instanceName=unitName, className='PROMPT', phaseName='PROMPT2')
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	uP.addLink('T - '+str(stepNum-2),str(stepPrompt_back))
	
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	transition = uP.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
	transition.setParameterValueAsString('Transition_Expression', stepTransitionConditionOnly+'.L_out_select = 1')
	uP.addLink(orBeginStepNum,stepNum)
	
###
	
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addNoAction(uP, priorStepNum=(stepNum-1), addTransition=False)
	upAndSteps.append(stepNum) # track for AndEnd step
	
# 'And End' transition
	stepNum = uP.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEnd(uP, andSteps=upAndSteps, transitionConditionOnly=str(stepNum-1))
	
	endRecipeObj(uP)
	return uP
	

### CREATE
def drugSubstance_ver5():
	global filePath
	global dataHeaderRow
	global recipeParamSheet
	global deferalParamSheet

	global saveList
	global unitInstanceName
	
	stageProgress = 0
	runningLog = ''
	myLogger = ''
	
	# WM Sepasoft configuration file
	filePath='C:\WME\RE_Files\DS_Recipe.xlsx'
	dataHeaderRow = 7 
	recipeParamSheet = 14 # recipe params sheet
	deferalParamSheet = 15 # deferal params sheet
	
	# Define recipe name and recipe class
	recipeName = 'DrugSubstance_ver5'
	recipeClassName = 'CP: Drug Substance Recipes'
	parentRecipeClassLink = None
	saveList = system.mes.object.list.createList()
	procedure = createProc(recipeClassName, recipeName, parentRecipeClassLink)
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Recipe name and recipe class defined', loggerObj=myLogger, fullLog=runningLog)

	### Init
	if 1==1:
		instanceID = ''
		upstreamName = ''
		instanceName = 'Init'
		downstreamName = 'IVT'
	
		# AndBegin
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		addAndBegin(procedure, priorStepNum=(stepNum-1))
		andBeginStepNum = stepNum
		andSteps = []
	
		# setSync
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		setSyncParam(procedure, priorStepNum=andBeginStepNum, addTransition=True, paramName='start'+downstreamName, paramValue=1)
		
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		monSyncParam(procedure, priorStepNum=(stepNum-1), addTransition=True, paramName=('end'+instanceName))
		
		# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoAction(procedure, priorStepNum=(stepNum-1), addTransition=False)
	### IVT
	if 1==1:
		instanceID = 'UM01'
		upstreamName = 'Init'
		instanceName = 'IVT'
		downstreamName = 'IVTP'
		uP = createIVT(procedure, priorStepNum=andBeginStepNum, unitID=instanceID, unitName=instanceName, upstreamName=upstreamName, downstreamName=downstreamName)
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Unit procedure '+instanceName+' defined', loggerObj=myLogger, fullLog=runningLog)
		# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoAction(procedure, priorStepNum=(stepNum-1), addTransition=False)
	### IVTP
	if 1==1:
		instanceID = 'UM02'
		upstreamName = 'IVT'
		instanceName = 'IVTP'
		downstreamName = 'TF1P'
		uP = createIVTP(procedure, priorStepNum=andBeginStepNum, unitID=instanceID, unitName=instanceName, upstreamName=upstreamName, downstreamName=downstreamName)
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Unit procedure '+instanceName+' defined', loggerObj=myLogger, fullLog=runningLog)
		# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoAction(procedure, priorStepNum=(stepNum-1), addTransition=False)

	### TF1P_mod
	if 1==1:
		instanceID = 'UM04'
		upstreamName = 'IVTP'
		instanceName = 'TF1P'
		downstreamName = 'CHRL'
		uP = createTF1P(procedure, priorStepNum=andBeginStepNum, unitID=instanceID, unitName=instanceName, upstreamName=upstreamName, downstreamName=downstreamName)
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Unit procedure '+instanceName+' defined', loggerObj=myLogger, fullLog=runningLog)
		# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoAction(procedure, priorStepNum=(stepNum-1), addTransition=False)
	### CHRL
	if 1==1:
		instanceID = 'UM05'
		upstreamName = 'TF1P'
		instanceName = 'CHRL'
		downstreamName = 'CHRP'
		uP = createCHRL(procedure, priorStepNum=andBeginStepNum, unitID=instanceID, unitName=instanceName, upstreamName=upstreamName, downstreamName=downstreamName)
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Unit procedure '+instanceName+' defined', loggerObj=myLogger, fullLog=runningLog)
		# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoAction(procedure, priorStepNum=(stepNum-1), addTransition=False)
	### CHRP
	if 1==1:
		instanceID = 'UM07'
		upstreamName = 'CHRL'
		instanceName = 'CHRP'
		downstreamName = 'TF2P'
		uP = createCHRP(procedure, priorStepNum=andBeginStepNum, unitID=instanceID, unitName=instanceName, upstreamName=upstreamName, downstreamName=downstreamName)
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Unit procedure '+instanceName+' defined', loggerObj=myLogger, fullLog=runningLog)
		# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoAction(procedure, priorStepNum=(stepNum-1), addTransition=False)
	### TF2P
	if 1==1:
		instanceID = 'UM09'
		upstreamName = 'CHRP'
		instanceName = 'TF2P'
		downstreamName = ''
		uP = createTF2P(procedure, priorStepNum=andBeginStepNum, unitID=instanceID, unitName=instanceName, upstreamName=upstreamName, downstreamName=downstreamName)
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Unit procedure '+instanceName+' defined', loggerObj=myLogger, fullLog=runningLog)
		# noAction
		stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
		andSteps.append(stepNum) # track for AndEnd step
		addNoAction(procedure, priorStepNum=(stepNum-1), addTransition=False)


	# 'And End' transition
	stepNum = procedure.getComplexPropertyCount('BatchMasterLogicSteps')
	addAndEnd(procedure, andSteps=andSteps, transitionConditionOnly=str(stepNum-1))
	
# saveProcedure

	# end Procedure
	endRecipeObj(procedure)
	
	# save Recipe
	logs = system.mes.batch.recipe.validateRecipe(saveList)
	system.mes.batch.recipe.saveRecipe(saveList)
	system.mes.invalidateCache()
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, logs, loggerObj=myLogger, fullLog=runningLog)
	
if 1==2:
	pass