def do(obj,searchString):
	members = dir(obj)
	for member in members:
		if searchString.upper() in member.upper():
			print (member)

################################################################################

# add parameters to phase
def addPhaseParam(phaseName, sheetNumber):
	dataSet = WM_FIRE.dataset.excelToDataSet(filePath, headerRow, sheetNumber)
	
	# accepted data types: 
		# Enum
		# Integer
		# Byte
		# Double
		# Float
		# Long
		# Short
	
	for row in range(dataSet.getRowCount()):
		
		paramName = str(dataSet.getValueAt(row, 0))
		recordingType = str(dataSet.getValueAt(row, 1))
		valueSource = str(dataSet.getValueAt(row, 2))
		
		tagType = str(dataSet.getValueAt(row, 3))
		dataType = str(dataSet.getValueAt(row, 4))
		enumDefUUID = str(dataSet.getValueAt(row, 5))
		minValue = (dataSet.getValueAt(row, 6))
		maxValue = (dataSet.getValueAt(row, 7))
		defaultValue = (dataSet.getValueAt(row, 8))
		engUnits = str(dataSet.getValueAt(row, 9))
		
		# get the phase object
		phaseLink = system.mes.batch.phase.getPhaseLink(phaseName)
		phase = phaseLink.getMESObject()
		
		# check if the parameter already exists
		try:
			phase.getParameterName(paramName)
			
		# if parameter doesn't exist define parameter
		except Exception as error:
			# handle the exception
			# print ("phase error - An exception occurred:", error)
			param = phase.addParameter(paramName)
			param.setParamKindName('User Phase')
			param.setParamRecordingTypeName(recordingType)
			param.setParamValueSourceName(valueSource)
			
			if tagType != "NULL" and tagType != "n/a":
				param.setParamTagTypeName(tagType)
			
			param.setParamDataTypeName(dataType)
			
			if dataType == 'Enum':
				param.setParamEnumDefUUID(enumDefUUID)
			
			if dataType == 'Integer':
				defaultValue = int(float(defaultValue))
				param.setParamMaxValueAsString(str(int(float(maxValue))))
				param.setParamMinValueAsString(str(int(float(minValue))))
			
			if dataType == 'Byte' or dataType == 'Double' or dataType == 'Float' or dataType == 'Long' or dataType == 'Short':
				param.setParamMaxValueAsString(str(maxValue))
				param.setParamMinValueAsString(str(minValue))
						
			if defaultValue != "NULL":
				param.setParamValueAsString(str(defaultValue))
			
			param.setParamUnits(engUnits)
		
			phase.save()

# create a custom equipment phase
def createEquipmentPhase(phaseName, phaseClassName, version):
	phaseType = 'Equipment Phase'
	parentPhaseLink = system.mes.batch.phase.getPhaseLink(phaseType)
	parentClassLink = system.mes.batch.phase.getClassLink(phaseClassName)
	
	phase = system.mes.batch.phase.createPhase(phaseName, parentPhaseLink, parentClassLink)
	phase.setExposed(True)
	
	description = phaseClassName + ': ' + phaseName + ' phase'
	phase.setDescription(description)
	
	phase.save()

### CREATE EQUIPMENT PHASES
if 1==2:

	headerRow = 7 # do not modify if using WM Sepasoft phase creation template
	filePath='E:\WME\Book2.xlsx'
	phaseClassName = 'vesselPhaseClass'
	
	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('PROMPT')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'PROMPT', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'PROMPT', sheetNumber = 0)
	
	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('SETUP')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'SETUP', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'SETUP', sheetNumber = 1)

	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('SKID')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'SKID', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'SKID', sheetNumber = 2)

	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('XFER-IN')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'XFER-IN', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'XFER-IN', sheetNumber = 3)

	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('SAMPLE')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'SAMPLE', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'SAMPLE', sheetNumber = 4)

	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('DILUTE')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'DILUTE', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'DILUTE', sheetNumber = 5)

	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('XFER-OUT')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'XFER-OUT', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'XFER-OUT', sheetNumber = 6)

	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('TEMP')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'TEMP', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'TEMP', sheetNumber = 7)
	
	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('CALC')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'CALC', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'CALC', sheetNumber = 8)
	
	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('TIME')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'TIME', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'TIME', sheetNumber = 9)
	
	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('ANALYTICS')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'ANALYTICS', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'ANALYTICS', sheetNumber = 10)
	
	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('RECIRC')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'RECIRC', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'RECIRC', sheetNumber = 11)
	
	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('AG')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'AG', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'AG', sheetNumber = 12)
	
	try:
		phaseLink = system.mes.batch.phase.getPhaseLink('LSPP')
		phase = system.mes.batch.phase.removePhase(phaseLink)
	except:
		createEquipmentPhase(phaseName = 'LSPP', phaseClassName = 'vesselPhaseClass', version=1.0)
		addPhaseParam(phaseName = 'LSPP', sheetNumber = 13)

### ASSIGN EQUIPMENT PHASES TO UNIT CLASS
if 1==2:

	ucLink = system.mes.batch.unitclass.getLink('vesselType03')
	unitClass = ucLink.getMESObject()
	
	pLink0 = system.mes.batch.phase.getPhaseLink('PROMPT')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('SETUP')    
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('SKID')
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('XFER-IN')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('SAMPLE')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('DILUTE')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('XFER-OUT')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('TEMP')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('CALC')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('TIME')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('ANALYTICS')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('RECIRC')   
	unitClass.addPhase(pLink0)
	pLink0 = system.mes.batch.phase.getPhaseLink('AG')   
	unitClass.addPhase(pLink0)
	
#	pLink0 = system.mes.batch.phase.getPhaseLink('PROMPT')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('SETUP')    
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('XFER-IN')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('SAMPLE')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('DILUTE')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('XFER-OUT')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('TEMP')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('CALC')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('TIME')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('ANALYTICS')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('RECIRC')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('AG')   
#	unitClass.removePhase(pLink0)
#	pLink0 = system.mes.batch.phase.getPhaseLink('SKID')
#	unitClass.removePhase(pLink0)
	
	system.mes.batch.unitclass.save(unitClass)

################################################################################

# define tag configuration
def getTagStructure(unitName, phaseName2, paramName):
    tagName = paramName
    opcItemPath = 'ns=1;s=[PLC01]Program:PH_' + unitName + '_' + phaseName2 + '.X_' + paramName
    opcServer = "Ignition OPC UA Server"
    valueSource = "opc"
    sampleMode = "TagGroup"
    tagGroup = "Default"
    
    return {
        
        "name": tagName,           
        "opcItemPath" : opcItemPath,
        "opcServer": opcServer,
        "valueSource": valueSource,
        "sampleMode" : sampleMode,
        "tagGroup" : tagGroup
    }

def getStatsStructure(unitName, phaseName, paramName):
    tagName = paramName
    opcItemPath = 'ns=1;s=[PLC01]Program:PH_' + unitName + '_' + phaseName + '.PLI.' + paramName
    opcServer = "Ignition OPC UA Server"
    valueSource = "opc"
    sampleMode = "TagGroup"
    tagGroup = "Default"
    
    return {
        
        "name": tagName,           
        "opcItemPath" : opcItemPath,
        "opcServer": opcServer,
        "valueSource": valueSource,
        "sampleMode" : sampleMode,
        "tagGroup" : tagGroup
    }

# define tag configuration
def traverseEquipmentHelper(filePath, equipmentItem, phaseName):
	eqPath = equipmentItem.getEquipmentPath()
	unitName = eqPath.split('\\')[-1]
	
	filePath=filePath
	headerRow=7
	
	if phaseName =='PROMPT':
		sheetNumber2=0
		phaseName2='PROMPT'
		
	elif phaseName =='SETUP':
		sheetNumber2=1
		phaseName2='SETUP'
		
	elif phaseName =='SKID':
		sheetNumber2=2
		phaseName2='SKID'
		
	elif phaseName =='XFER-IN':
		sheetNumber2=3
		phaseName2='XFER_IN'
		
	elif phaseName =='SAMPLE':
		sheetNumber2=4
		phaseName2='SAMPLE'
		
	elif phaseName =='DILUTE':
		sheetNumber2=5
		phaseName2='DILUTION'
		
	elif phaseName =='XFER-OUT':
		sheetNumber2=6
		phaseName2='XFER_OUT'
		
	elif phaseName =='TEMP':
		sheetNumber2=7
		phaseName2='TEMP'
		
	elif phaseName =='CALC':
		sheetNumber2=8
		phaseName2='CALC'
		
	elif phaseName =='TIME':
		sheetNumber2=9
		phaseName2='TIMER'
		
	elif phaseName =='ANALYTICS':
		sheetNumber2=10
		phaseName2='ANALYTICS'
		
	elif phaseName =='RECIRC':
		sheetNumber2=11
		phaseName2='RECIRC'
		
	elif phaseName =='AG':
		sheetNumber2=12
		phaseName2='AG'
		
	elif phaseName =='LSPP':
		sheetNumber2=13
		phaseName2='SKID'
		
	else :
		sheetNumber2 = 0
		phaseName2 = ''
	
	dataSet2 = WM_FIRE.dataset.excelToDataSet(filePath, headerRow, sheetNumber2)
        	
	for row in range(dataSet2.getRowCount()):
	
		paramName = str(dataSet2.getValueAt(row, 0))
		
		tag = getTagStructure(unitName, phaseName2, paramName)
		baseTagPath = '[MES]' + eqPath.replace('\\','/') + '/Batch Phases' + '/' + phaseName
		system.tag.configure(baseTagPath, [tag], 'o')
	
	tag = getStatsStructure(unitName, phaseName2, paramName='Command_Number')
	system.tag.configure(baseTagPath, [tag], 'o')
	
	tag = getStatsStructure(unitName, phaseName2, paramName='State_Number')
	system.tag.configure(baseTagPath, [tag], 'o')

# define tag configuration
def traverseEquipment(filePath, eqPath, phaseName, providerName='[MES]'):
	root = system.mes.loadMESObjectByEquipmentPath(eqPath)
	traverseEquipmentHelper(filePath, root, phaseName)

### DEFINE PLC->BATCH AND BATCH->PLC TAGS
def defineBatchTags(filePath, processCellName, instanceName):
	dataSet = WM_FIRE.dataset.excelToDataSet(filePath=filePath, headerRow=7, sheetNumber=16)
	
	for row in range(dataSet.getRowCount()):
		
		unitName = str(instanceName)
		phaseName = str(dataSet.getValueAt(row, 1))
		
		print unitName, phaseName
		traverseEquipment(filePath=filePath, eqPath='Enterprise\\Site\\Area\\' + processCellName + '\\' + unitName, phaseName=phaseName)

################################################################################

global filePath
global dataHeaderRow
global recipeParamSheet
global deferalParamSheet
global saveList

global unitInstanceName

def do(obj,searchString):
	members = dir(obj)
	for member in members:
		if searchString.upper() in member.upper():
			print (member)

# add parameters to recipeObj
def addParams(obj, filePath, dataHeaderRow, recipeParamSheet):
	dataSet = WM_FIRE.dataset.excelToDataSet(filePath, dataHeaderRow, recipeParamSheet)
	
	for row in range(dataSet.getRowCount()):
		
		paramName = str(dataSet.getValueAt(row, 0))
		recordingType = str(dataSet.getValueAt(row, 1))
		valueSource = str(dataSet.getValueAt(row, 2))
		tagType = str(dataSet.getValueAt(row, 3))
		dataType = str(dataSet.getValueAt(row, 4))
		enumDefUUID = str(dataSet.getValueAt(row, 5))
		minValue = (dataSet.getValueAt(row, 6))
		maxValue = (dataSet.getValueAt(row, 7))
		defaultValue = (dataSet.getValueAt(row, 8))
		engUnits = str(dataSet.getValueAt(row, 9))
		
		# if parameter to be set during Recipe and Execution, define parameter
		if valueSource == 'Recipe and Execution':
			param = obj.addParameter(paramName)
			param.setParamKindName('User Phase')
			param.setParamRecordingTypeName(recordingType)
			param.setParamValueSourceName(valueSource)		
			if tagType != "NULL" and tagType != "n/a":
				param.setParamTagTypeName(tagType)
			param.setParamDataTypeName(dataType)
			if dataType == 'Enum':
				param.setParamEnumDefUUID(enumDefUUID)
			if dataType == 'Integer':
				defaultValue = int(float(defaultValue))
				param.setParamMaxValueAsString(str(int(float(maxValue))))
				param.setParamMinValueAsString(str(int(float(minValue))))
			if dataType == 'Byte' or dataType == 'Double' or dataType == 'Float' or dataType == 'Long' or dataType == 'Short':
				param.setParamMaxValueAsString(str(maxValue))
				param.setParamMinValueAsString(str(minValue))
			if defaultValue != "NULL":
				param.setParamValueAsString(str(defaultValue))
			param.setParamUnits(engUnits)
# set deferals to recipeObj
def setDeferals(step, instanceName, filePath, dataHeaderRow, deferalParamSheet, unitInstanceName):
	dataSet = WM_FIRE.dataset.excelToDataSet(filePath, dataHeaderRow, deferalParamSheet)

	for row in range(dataSet.getRowCount()):
		unitID = str(dataSet.getValueAt(row, 0))
		untiName = str(dataSet.getValueAt(row, 1))
		phaseClassName = str(dataSet.getValueAt(row, 2))
		phaseInstanceName = str(dataSet.getValueAt(row, 3))
		paramDesc = str(dataSet.getValueAt(row, 4))
		dataType = str(dataSet.getValueAt(row, 5))
		
		phaseParamName = str(dataSet.getValueAt(row, 6))
		phaseDeferParam = dataSet.getValueAt(row, 7)
		phaseCalcValue = dataSet.getValueAt(row, 8)
		phaseParamValue = dataSet.getValueAt(row, 9)
		recipeParamName = dataSet.getValueAt(row, 10)
		recipeParamValue = dataSet.getValueAt(row, 11)
		
		# define parameters
		if dataType == 'Integer' and phaseParamValue != 'n/a':
			phaseParamValue = int(float(phaseParamValue))
		
		if untiName == unitInstanceName and phaseInstanceName == instanceName:
			print untiName, unitInstanceName, ' - ', phaseInstanceName, instanceName, ' - ', phaseParamName
			#set params
			if phaseDeferParam == 1: #true
				print phaseParamName, phaseCalcValue
				step.setParameterCalculation(phaseParamName, phaseCalcValue)
			else:
				if phaseParamValue != 'n/a':
					step.setParameterValueAsString(str(phaseParamName), str(phaseParamValue))

# create procedure
def createProc(recipeClassName, recipeName, parentRecipeClassLink, saveList, filePath, dataHeaderRow, recipeParamSheet):
	
	# check if the recipe exists, and if yes, then delete it
	recipeClassLink = system.mes.batch.recipe.getRecipeClassLink(recipeClassName, None)
	try: 
		recipeLink = system.mes.batch.recipe.getRecipeLink(recipeName, recipeClassLink)
		system.mes.batch.recipe.removeRecipe(recipeLink)
	except:
		pass
	
	# create recipe object
	recipeCls = system.mes.batch.recipe.loadRecipeClass(recipeClassName, parentRecipeClassLink)
	recipe = system.mes.batch.recipe.createRecipe(recipeName, recipeCls.asLink())
	saveList.add(recipe)
	recipe.setRecipeState('')
	recipe.setRecipeScale(1.0)
	recipe.setUserVersion(1)
	
	# create procedure
	procedure = recipe.createLogic('Procedure')
	saveList.add(procedure)
	
	# add the start block
	procedure.addStep('Start', 0, system.mes.batch.phase.getBuiltInPhaseLink('Start'))
	
	# add recipe parameters
	addParams(procedure, filePath, dataHeaderRow, recipeParamSheet)
	
	return procedure
# create unit procedure
def createUP(obj, priorStepNum, addTransition, className, instanceName):
	global saveList
	
	# create unit procedure
	unitProcedure = obj.createLogic('Unit Procedure')
	unitClassLink = system.mes.batch.unitclass.getLink(className)
	unitProcedure.setUnitClassRef(unitClassLink)
	saveList.add(unitProcedure)

	# add step links to step in Procedure
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	pStep = obj.addStep(instanceName, stepNum, system.mes.batch.phase.getPhaseLink('Unit Procedure'))
	pStep.setLogicRefUUID(unitProcedure.getUUID())
	obj.addLink(priorStepNum,stepNum)
	
	# add links to transition in Procedure
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+instanceName, stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',str(instanceName)+'.Complete')
		obj.addLink(stepNum-1,stepNum)
	
	# add start block in UP
	unitProcedure.addStep('UP', 0, system.mes.batch.phase.getPhaseLink('Start'))
	
	return unitProcedure
# add step
def addStep(obj, priorStepNum, addTransition, className, instanceName):

	# add step links to step in UP
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	step = obj.addStep(str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink(className))
	obj.addLink(priorStepNum,stepNum)
	
	# add links to transition in UP
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+str(stepNum-1), stepNum, system.mes.batch.phase.getBuiltInPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',str(stepNum-1)+'.Complete')
		obj.addLink(stepNum-1,stepNum)
	
	# add parameters and deferals
	setDeferals(step, instanceName)
# add noAction
def addNoAction(obj, priorStepNum, addTransition):
	# add a no action phase
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	obj.addStep(str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('No Action'))
	obj.addLink(priorStepNum,stepNum)
	# add a transition
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+str(stepNum), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',str(stepNum-1)+'.Complete')
		obj.addLink(stepNum-1,stepNum)

def endStep():
	pass
# end recipeObject
def endRecipeObj(recipeObj):
	# add a terminator (within OP) and link with above step
	stepNum = recipeObj.getComplexPropertyCount('BatchMasterLogicSteps')
	recipeObj.addStep('End', stepNum, system.mes.batch.phase.getPhaseLink('Terminator'))
	recipeObj.addLink(stepNum-1,stepNum)


# set syncParam
def setSyncParam(obj, priorStepNum, addTransition, paramName, paramValue):
	# add a no action phase
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	step = obj.addStep(str(stepNum)+' - '+str(paramName), stepNum, system.mes.batch.phase.getPhaseLink('Set Parameter'))
	step.setParameterValue('Parameter_Path','/{}.xsync_'+paramName)
	step.setParameterValue('Parameter_Value',paramValue)
	obj.addLink(priorStepNum,stepNum)
	# add a transition
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression',str(stepNum-1)+' - '+str(paramName)+'.Complete')
		obj.addLink(stepNum-1,stepNum)
# monitor syncParam
def monSyncParam(obj, priorStepNum, addTransition, paramName):
	# add a no action phase
	stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
	obj.addStep(str(stepNum)+' - '+str(paramName), stepNum, system.mes.batch.phase.getPhaseLink('No Action'))
	obj.addLink(priorStepNum,stepNum)
	# add a transition
	if addTransition == True:
		stepNum = obj.getComplexPropertyCount('BatchMasterLogicSteps')
		transition = obj.addStep('T - '+str(stepNum-1), stepNum, system.mes.batch.phase.getPhaseLink('Transition'))
		transition.setParameterValueAsString('Transition_Expression','/{}.xsync_'+str(paramName)+'=true')
		obj.addLink(stepNum-1,stepNum)

################################################################################

if 1==2:
	pass