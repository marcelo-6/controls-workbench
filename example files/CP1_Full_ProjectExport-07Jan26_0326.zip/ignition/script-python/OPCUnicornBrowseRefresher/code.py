# WME - 
# See documentation for more info on this script. Intended for use with WM_OPCBrowserRefresh_UDT
# Ver. 1.0 - Released for QA
import system

# create recursive browseRefresher function with input parameters from WM_OPCBrowserRefresh_UDT instances
def browseRefresher(refreshStartPath, serverName, maxDepth, browseDepth = 0):
	myLogger =  system.util.getLogger('My Browse')
	nodeId = refreshStartPath
	children = system.opc.browseServer(serverName, nodeId)
    
	for child in children:
		elementType = str(child.getElementType())
		childNodeId = child.getNodeId()
			
		msg = 'Depth - %s, Node - %s' % (browseDepth, childNodeId)
		myLogger.info(msg)
		if (elementType == 'FOLDER' and browseDepth < maxDepth):
			browseRefresher(childNodeId, serverName, maxDepth, browseDepth + 1)
