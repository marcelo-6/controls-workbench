def getAlarmSummary(filterPath='*'):
	if filterPath.find(']') != -1:
		filterPath = filterPath.split(']')[1]
	alarms = system.alarm.queryStatus(priority=[1,2,3,4],
								 state=['ActiveAcked','ClearUnacked','ActiveUnacked'],
								 path=['*:/tag:%s*' % filterPath],
								 includeShelved=True)
	'''
	almCounts = {'ActiveAcked':0, 'ActiveUnacked':0, 'ClearUnacked':0}
	for alarm in alarms:
		if str(alarm.state) == 'Cleared, Unacknowledged':
			almCounts['ClearUnacked'] += 1
		if str(alarm.state) == 'Active, Unacknowledged':
			almCounts['ActiveUnacked'] += 1
		if str(alarm.state) == 'Active, Acknowledged':
			almCounts['ActiveAcked'] += 1
	
	#json = system.util.jsonEncode(almCounts)
	if({[.]Sts/Alarms.HasActive},
	
	if(!isNull({[.]Sts/Alarms.HighestUnackedPriority}) && {[.]Sts/Alarms.HighestUnackedPriority} = {[.]Sts/Alarms.HighestActivePriority},
	
	{[.]Sts/Alarms.HighestUnackedPriority}*2+1
	, //else
	{[.]Sts/Alarms.HighestAckedPriority}*2), 
	
	// Not Active, check for Unack
	if({[.]Sts/Alarms.HasUnacknowledged}, 1, 0))
	
	
	'''
	# 5 Columns: ParentPath, TagPath, Val_Notify, shelveCount, alarmCount
	singleValNotify = 0
	shelvedCount = 0
	alarmCount = 0
	headers = ["ParentPath", "TagPath", "ValNotify", "AlarmShevled", "AlarmCount"]
	data = []
	
	for alarm in alarms:
		# easier to count the whole column in an expression later (in the UDT)
		if alarm.IsShelved:
			shelvedCount = 1
			alarmCount = 0
		else:
			shelvedCount = 0
			alarmCount = 1
			if str(alarm.state) == 'Cleared, Unacknowledged': ##alarm.state == 0: # == 'Cleared, Unacknowledged':
				singleValNotify = 1
			if str(alarm.state) == 'Active, Unacknowledged': ##alarm.state == 2: # == 'Active, Unacknowledged':
				singleValNotify = alarm.priority.intValue*2+1
			if str(alarm.state) == 'Active, Acknowledged': ##alarm.state == 3: # == 'Active, Acknowledged':
				singleValNotify = alarm.priority.intValue*2
		
		##build path
		finalTagPath = str(alarm.source).split('prov:default:/tag:')[1].split(':')[0]
		finalParentPath = finalTagPath.rsplit("/", 2)[0]
		##build dataset
		data.append([finalParentPath, finalTagPath, singleValNotify, shelvedCount, alarmCount])
		singleValNotify = 0
		shelvedCount = 0
		alarmCount = 0
	
	#data.append(["Test", "Test", "Test", "Test"])
	finalAlarmDataset = system.dataset.toDataSet(headers, data)
	return finalAlarmDataset

def filterAlarmDatasetbyPath(dataset, pathToParentTagFromUDT=''):
	rowsList = []
	filterPath = pathToParentTagFromUDT.rsplit("/", 1)[0]
	for row in range(dataset.getRowCount()):
	    #get row indexes to be removed from new filtered dataset
	    if filterPath not in dataset.getValueAt(row, 0):
	    	rowsList.append(row)
	finalDataset = system.dataset.deleteRows(dataset, rowsList)
	return finalDataset

def filterAlarmDatasetbyUnit(dataset, pathToParentTagFromUDT='', unitInstance=''):
	rowsList = []
	editPath = pathToParentTagFromUDT.rsplit("/", 1)[0]
	filterPath = editPath + '/' + unitInstance + '_'
	for row in range(dataset.getRowCount()):
		print dataset.getValueAt(row, 1)
	    #get row indexes to be removed from new filtered dataset
		if filterPath not in dataset.getValueAt(row, 1):
			rowsList.append(row)
	finalDataset = system.dataset.deleteRows(dataset, rowsList)
	return finalDataset

def getRowCountAlarmDataset(dataset):
	return dataset.getRowCount()