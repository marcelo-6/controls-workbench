# WME - 
# See documentation for more info on this script. Intended for use with WM_XXX_UDT
# Ver. 1.0 - Released for QA

def getResult(connectionName, objectId, methodId, inputs):

	# Call the Server object's GetMonitoredItems method
	result = system.opcua.callMethod(
	        connectionName,
	        objectId,
	        methodId,
	        inputs
	    )