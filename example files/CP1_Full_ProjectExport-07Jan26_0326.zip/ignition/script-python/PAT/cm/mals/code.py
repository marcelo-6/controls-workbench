"""
PAT.cm.mals
---------------------------------
Control-Module wrapper for Wyatt **MALS** (Observer) via OPC UA Workflow.

Design
------
- CM is a thin, non-blocking tag adapter that:
  * Exposes commands: start, continue, pause, unpause, cancel, reset.
  * Provides `status_poll(wf_name)` → a compact dict with instrument states,
    results, and **parameter modes** (Manual / Timing In / Fixed Duration).
  * Updates its own CM state/message with **instrument-scoped** context such as:
        "Ready to collect baselines"
        "Collecting Baselines (Fixed 2.0 min)"
        "Ready to start data collection"
        "Collecting Data (Timing In end)"
    These messages are *low-level* and reflect what the hardware is doing
    (or waiting for) based on workflow booleans + parameter modes.

- Workflow selection is **never overwritten** here; operators choose it
  beforehand in UI and we only read/reflect it.

References
----------
Workflow states, prompts, and results:
  * State booleans (ReadyToCollectBaselines, CollectingBaselines, ReadyToStartTriggerConditions,
    CollectingData, TriggerConditionsDone, PostCollectionCometRunning, Done, Paused, Error, Cancelled)
    and client nodes Start/Continue. :contentReference[oaicite:5]{index=5}
  * Results (Outcome, ErrorEncountered, CollectionStarted). :contentReference[oaicite:6]{index=6}

Parameter modes affecting prompts:
  * BaselineCollectionStart/End[/Duration], TriggerConditionStart/End[/Duration]. :contentReference[oaicite:7]{index=7}

Common workflow control nodes:
  * SelectedWorkflow, Running, Cancel, PauseWorkflow, UnPauseWorkflow, ResetWorkflow. :contentReference[oaicite:8]{index=8}
"""
from PAT.cm.base import BaseCM, CMState
from PAT.infra   import tagio, log

__all__ = ["MalsCM"]

class MalsCM(BaseCM):
    # -------- static fragments (relative to tag_root) --------
    T_WF_SELECTED   = "/LM/Workflow/SelectedWorkflow"
    T_WF_RUNNING    = "/LM/Workflow/Running"
    T_WF_CANCEL     = "/LM/Workflow/Cancel"
    T_WF_PAUSE      = "/LM/Workflow/PauseWorkflow"
    T_WF_UNPAUSE    = "/LM/Workflow/UnPauseWorkflow"
    T_WF_RESET      = "/LM/Workflow/ResetWorkflow"

    # Parameter leaves under ".../Parameters"
    P_BASE_START    = "BaselineCollectionStart"      # 'Timing In' | 'Manual'
    P_BASE_END      = "BaselineCollectionEnd"        # 'Timing In' | 'Manual' | 'Fixed Duration'
    P_BASE_DUR      = "BaselineCollectionDuration"   # Float (min) when Fixed Duration
    P_TRIG_START    = "TriggerConditionStart"        # 'Timing In' | 'Manual'
    P_TRIG_END      = "TriggerConditionEnd"          # 'Timing In' | 'Manual' | 'Fixed Duration'
    P_TRIG_DUR      = "TriggerConditionDuration"     # Float (min) when Fixed Duration

    def __init__(self, tag_root):
        super(MalsCM, self).__init__(tag_root)
        self.log = log.get("PAT.CM.MALS")

        # cached parameter modes by workflow name
        self._modes_cache = {}  # { wf_name: {base_start, base_end, base_dur, trig_start, trig_end, trig_dur} }

    # ---------------- path helpers ----------------
    def _wf_base(self, wf_name):
        return "/LM/Workflow/%s" % wf_name

    def _t_state(self, wf_name, leaf):
        return "%s/State/%s" % (self._wf_base(wf_name), leaf)

    def _t_continue(self, wf_name):
        return self._t_state(wf_name, "Continue")

    def _t_results(self, wf_name, leaf):
        return "%s/Results/%s" % (self._wf_base(wf_name), leaf)

    def _t_params(self, wf_name, leaf):
        return "%s/Parameters/%s" % (self._wf_base(wf_name), leaf)

    # ---------------- BaseCM hooks ----------------
    def _device_heartbeat(self):
        try:
            _ = tagio.read_single(self.tag_root + self.T_WF_SELECTED)
            _ = bool(tagio.read_single(self.tag_root + self.T_WF_RUNNING))
            return True
        except:
            return False

    def _device_interlocks_met(self):
        if not self.is_online():
            return False, "Instrument offline"
        return True, "Interlocks OK"

    def _device_cancel(self):
        try:
            tagio.write_single(self.tag_root + self.T_WF_CANCEL, True)
            return True
        except Exception as exc:
            self.post_error(exc)
            return False

    # ---------------- Commands ----------------
    def cmd_start(self, wf_name):
        """Set State/Start = True (non-blocking). Workflow selection is never overwritten."""
        tagio.write_single(self.tag_root + self._t_state(wf_name, "Start"), True)
        self.set_state(CMState.READY, "Start command sent (%s)" % wf_name)

    def cmd_continue(self, wf_name):
        """Set LM/Workflow/<wf_name>/State/Continue = True.

        For MALS this is typically 
        called from the EM SFC *after* the operator confirms EM/Cmd_Confirm.
        """
        tagio.write_single(self.tag_root + self._t_continue(wf_name), True)
        self.set_state(CMState.READY, "Continue sent")

    def cmd_pause(self):
        tagio.write_single(self.tag_root + self.T_WF_PAUSE, True)
        self.set_state(CMState.PAUSED, "Pause requested")

    def cmd_unpause(self):
        tagio.write_single(self.tag_root + self.T_WF_UNPAUSE, True)
        self.set_state(CMState.READY, "UnPause requested")

    def cmd_cancel(self):
        self._device_cancel()
        self.set_state(CMState.STOPPED, "Cancel requested")

    def cmd_reset(self):
        tagio.write_single(self.tag_root + self.T_WF_RESET, True)
        self.set_state(CMState.READY, "Reset requested")

    # ---------------- internals ----------------
    def _read_modes(self, wf_name):
        """Load & cache parameter modes (Manual/Timing In/Fixed Duration)."""
        if wf_name in self._modes_cache:
            return self._modes_cache[wf_name]

        paths = [self.tag_root + p for p in (
            self._t_params(wf_name, self.P_BASE_START),
            self._t_params(wf_name, self.P_BASE_END),
            self._t_params(wf_name, self.P_BASE_DUR),
            self._t_params(wf_name, self.P_TRIG_START),
            self._t_params(wf_name, self.P_TRIG_END),
            self._t_params(wf_name, self.P_TRIG_DUR),
        )]
        vals = tagio.read_multi(paths)
        modes = {
            "base_start": vals[0], "base_end": vals[1], "base_dur": vals[2],
            "trig_start": vals[3], "trig_end": vals[4], "trig_dur": vals[5],
        }
        self._modes_cache[wf_name] = modes
        return modes

    def _compose_cm_message(self, polled, modes):
        """Return a low-level instrument-scoped CM message string."""
        if polled["error"]:
            return "ERROR - {}".format(polled["results"]["error_str"] or "Workflow error")
        if polled["cancelled"]:
            return "Stopped - Cancelled"
        if polled["paused"]:
            return "Paused - Awaiting UnPause"
        if polled["done"]:
            return "Completed - Outcome: {}".format(polled["results"]["outcome"] or "")

        if polled["running"]:
            # Baselines
            if polled["ready_to_collect_baselines"]:
                if (modes.get("base_start") or "").lower().startswith("manual"):
                    return "Ready to collect baselines"
                return "Preparing to collect baselines ({})".format(modes.get("base_start") or "")
            if polled["collecting_baselines"]:
                end_mode = (modes.get("base_end") or "")
                if end_mode.lower().startswith("manual"):
                    return "Collecting Baselines (Manual end)"
                if end_mode.lower().startswith("fixed"):
                    dur = modes.get("base_dur") or ""
                    return "Collecting Baselines (Fixed {} min)".format(dur)
                return "Collecting Baselines ({} end)".format(end_mode or "Timing In")
            if polled["baseline_done"] and not polled["ready_to_start_triggers"]:
                return "Baseline collection complete"

            # Trigger/Data collection
            if polled["ready_to_start_triggers"]:
                if (modes.get("trig_start") or "").lower().startswith("manual"):
                    return "Ready to start data collection"
                return "Preparing to start data collection ({})".format(modes.get("trig_start") or "")
            if polled["collecting_data"]:
                end_mode = (modes.get("trig_end") or "")
                if end_mode.lower().startswith("manual"):
                    return "Collecting Data (Manual end)"
                if end_mode.lower().startswith("fixed"):
                    dur = modes.get("trig_dur") or ""
                    return "Collecting Data (Fixed {} min)".format(dur)
                return "Collecting Data ({} end)".format(end_mode or "Timing In")
            if polled["triggers_done"]:
                return "Data collection complete"

            if polled["post_collection"]:
                return "Post-collection cleaning"

            return "Advancing..."

        return "Idle / Ready"

    # ---------------- public: status summary ----------------
    def status_poll(self, wf_name):
        """
        Read workflow booleans + results and report:
          - raw flags (running/paused/error/cancelled/done/…)
          - results strings (Outcome/ErrorEncountered)
          - **modes** affecting prompts (baseline/trigger start+end+duration)
          - a **CM message** with instrument-scoped context

        Returns dict:
          {
            <flags…>,
            "results": {"outcome": str|None, "error_str": str|None},
            "modes": {"base_start","base_end","base_dur","trig_start","trig_end","trig_dur"},
            "cm_message": "<string>"
          }
        """
        paths = [
            self.tag_root + self.T_WF_RUNNING,
            self.tag_root + self._t_state(wf_name, "Paused"),
            self.tag_root + self._t_state(wf_name, "Error"),
            self.tag_root + self._t_state(wf_name, "Cancelled"),
            self.tag_root + self._t_state(wf_name, "Done"),
            self.tag_root + self._t_state(wf_name, "ReadyToCollectBaselines"),
            self.tag_root + self._t_state(wf_name, "CollectingBaselines"),
            self.tag_root + self._t_state(wf_name, "BaselineCollectionDone"),
            self.tag_root + self._t_state(wf_name, "ReadyToStartTriggerConditions"),
            self.tag_root + self._t_state(wf_name, "CollectingData"),
            self.tag_root + self._t_state(wf_name, "TriggerConditionsDone"),
            self.tag_root + self._t_state(wf_name, "PostCollectionCometRunning"),
            self.tag_root + self._t_results(wf_name, "Outcome"),
            self.tag_root + self._t_results(wf_name, "ErrorEncountered"),
            self.tag_root + self._t_state(wf_name, "NotReady"),
            self.tag_root + self._t_state(wf_name, "NotSelected"),
            self.tag_root + self._t_state(wf_name, "ReadyToStart"),
        ]
        vals = tagio.read_multi(paths)
        ret = {
            "running":                    bool(vals[0]),
            "paused":                     bool(vals[1]),
            "error":                      bool(vals[2]),
            "cancelled":                  bool(vals[3]),
            "done":                       bool(vals[4]),
            "ready_to_collect_baselines": bool(vals[5]),
            "collecting_baselines":       bool(vals[6]),
            "baseline_done":              bool(vals[7]),
            "ready_to_start_triggers":    bool(vals[8]),
            "collecting_data":            bool(vals[9]),
            "triggers_done":              bool(vals[10]),
            "post_collection":            bool(vals[11]),
            "results": {"outcome": vals[12] or None, "error_str": vals[13] or None},
            "not_ready":                  bool(vals[14]),
            "not_selected":               bool(vals[15]),
            "ready":                      bool(vals[16]),
        }

        # Human-friendly CM state + message
        modes = self._read_modes(wf_name)
        cm_msg = self._compose_cm_message(ret, modes)
        if ret["error"]:
            self.set_state(CMState.ERROR, cm_msg)
        elif ret["paused"]:
            self.set_state(CMState.PAUSED, cm_msg)
        elif ret["cancelled"]:
            self.set_state(CMState.STOPPED, cm_msg)
        elif ret["done"]:
            self.set_state(CMState.READY, cm_msg)
        elif ret["running"]:
            self.set_state(CMState.SAMPLING, cm_msg)
        else:
            self.set_state(CMState.READY, cm_msg)

        ret["modes"] = modes
        ret["cm_message"] = cm_msg
        return ret