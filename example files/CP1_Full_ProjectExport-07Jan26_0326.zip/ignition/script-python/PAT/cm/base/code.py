"""
pat.cm.base
============

Common logic shared by *all* Control‑Module (CM) implementations.

Key responsibilities
--------------------
* Maintain a *small* state‑machine (`CMState`) and persist it to the
  CM tag‑folder.
* Provide basic *arbitration* (Owned / ChartID).
* Offer helper wrappers for tag I/O using `PAT.infra.tagio`.
* Remain completely device‑agnostic - concrete subclasses should only
  implement the three `_device_*` hooks.

"""

import json
import sys
import traceback
from collections import OrderedDict

from PAT.infra import tagio, log, retry

# ─────────────────────────────────────────────────────────────────────────────
# CM State abstraction
# ─────────────────────────────────────────────────────────────────────────────
class CMState(object):
    """Lightweight, *immutable* enumeration of CM runtime states.

    Attributes
    ----------
    code : int
        Persistent integer written to ``Val_StateCode``.
    name : unicode
        Human‑readable name written to ``Val_StateName``.
    """

    _MAP = {}  # type: dict[int, CMState]

    def __init__(self, code, name):
        self.code = int(code)
        self.name = unicode(name)
        CMState._MAP[self.code] = self

    # ------------------------ symbols ------------------------ #
    IDLE     = None  # created after class definition
    ACQUIRED = None
    READY    = None
    SAMPLING = None
    PAUSED   = None
    STOPPED  = None
    ALARM    = None
    ERROR    = None

    # --------------------------------------------------------- #
    @classmethod
    def by_code(cls, code):
        """Return **CMState** instance or :pydata:`CMState.ERROR`."""
        return cls._MAP.get(int(code), cls.ERROR)

    # --------------------------------------------------------- #
    def __unicode__(self):
        return self.name

    __str__ = __unicode__

# Populate enumeration values
CMState.IDLE     = CMState(0,   "Idle")
CMState.ACQUIRED = CMState(10,  "Acquired")
CMState.READY    = CMState(15,  "Ready")
CMState.SAMPLING = CMState(20,  "Sampling")
CMState.PAUSED   = CMState(30,  "Paused")
CMState.STOPPED  = CMState(40,   "Stopped")
CMState.ALARM    = CMState(900,  "In Alarm")
CMState.ERROR    = CMState(999, "Error")

# ─────────────────────────────────────────────────────────────────────────────
# Base Control‑Module
# ─────────────────────────────────────────────────────────────────────────────
class BaseCM(object):
    """Abstract base‑class for every instrument Control‑Module.

    Parameters
    ----------
    tag_root : unicode
        The fully‑qualified *folder* path for this CM instance,
        e.g. ``"[default]RBP/PAT/Irubis-01"``.
    logger_name : unicode, optional
        Name passed to :pyfunc:`PAT.infra.log.get`.  Defaults to
        ``PAT.CM``.

    Concrete subclasses *must* provide implementations for the three
    private hooks:

    * :pyfunc:`_device_heartbeat`
    * :pyfunc:`_device_interlocks_met`
    * :pyfunc:`_device_cancel`
    """

    # ------------------------tag relative paths---------------
    _T_OWNED      = "/CM/Sts_Owned"
    _T_CHART_ID   = "/EM/Val_ChartID"  # lives in EM folder but needed here
    _T_STATE_CODE = "/CM/Val_StateCode"
    _T_STATE_NAME = "/CM/Val_StateName"
    _T_MSG        = "/CM/Val_Msg"
    _T_ERR        = "/CM/Val_LastError"
    _T_INTERLOCKS = "/CM/Sts_InterlocksMet"
    _T_AVAILABLE  = "/CM/Sts_Available"
    _T_SAMPLE_NO  = "/CM/Val_SampleNumber"
    # --------------------------------------------------------------------- #
    def __init__(self, tag_root, logger_name=None):
        self.tag_root = tag_root.rstrip("/")
        self.log = log.get(logger_name or "PAT.CM" + tag_root.split("/")[-1])
        self.stateNameTag = self._T_STATE_NAME

    # ------------------------------util------------------------------ 
    #  • state helpers
    def set_state(self, state, msg=""):
        """
        Update ``Val_StateCode`` / ``Val_StateName`` (+ optional ``Val_Msg``).

        Parameters
        ----------
        code : int
            One of :pyattr:`CMState` values.
        msg : str or None
            Friendly operator message; ignored if ``None``.
        """
        tagio.write_multi(
            [self.tag_root + self._T_STATE_CODE,
             self.tag_root + self._T_STATE_NAME,
             self.tag_root + self._T_MSG],
            [state.code, state.name, msg])
        if msg:
            self.log.debug("[{}] {}".format(state.name, msg))
        return state

    #  • arbitration helpers --------------------------------------------
    def is_owned(self):
        return bool(tagio.read_single(self.tag_root + self._T_OWNED))

    def acquire(self):
		"""Mark CM as owned and go to ``ACQUIRED`` state."""
		if not self.is_owned():
		    tagio.write_single(self.tag_root + self._T_OWNED, True)
		    self.set_state(CMState.ACQUIRED, "Instrument Acquired")
		    return True
		return False        

    def release(self):
    	"""Clear ownership flag and go to ``IDLE``."""
        tagio.write_multi(
            [self.tag_root + self._T_OWNED,
             self.tag_root + self._T_SAMPLE_NO],
            [False, 0])
        self.set_state(CMState.IDLE, "Idle")

    # --------------------------API---------------------------------
    # The public interface intentionally stays *tiny* so EM/SFC logic is
    # agnostic of the concrete instrument.

    # ----------------------heartbeat--------------------------
    def heartbeat(self):
        """Boolean - *True* when the underlying device/API is alive."""
        try:
            ok = bool(self._device_heartbeat())
            tagio.write_single(self.tag_root + self._T_AVAILABLE, int(ok))
            return ok
        except Exception as exc:
            self.post_error(exc)
            return False
            
    def is_online(self):
    	return bool(tagio.read_single(self.tag_root + self._T_AVAILABLE))

    # -------------------interlock poll---------------------
    def interlocks_met(self):
        try:
            ok, reason = self._device_interlocks_met()
            tagio.write_single(self.tag_root + self._T_INTERLOCKS, int(ok))
            return ok, reason
        except Exception as exc:
            self.post_error(exc)
            return False, "fatal error"

    # -----------------------sampling-----------------------
    def next_sample(self):
        """Return device‑specific payload for *one* sample.

        The default implementation raises *NotImplementedError* - each
        subclass knows best how to trigger / retrieve data.
        """
        raise NotImplementedError

    # --  ------------------cancellation----------------------
    def cancel_active(self):
        """Abort an on‑going measurement / acquisition on the instrument."""
        try:
            self._device_cancel()
            self.set_state(CMState.READY, "Active measurement cancelled")
        except Exception as exc:
            self.post_error(exc)

    # ----------------------------error-------------------------------- 
    def post_error(self, exc, context=u""):
        """
        Serialize *exc* to JSON and drive CM → ERROR state..

        The JSON payload is stored in ``Val_LastError``.
        """
        info = {
        	"context": context,
            "type":   exc.__class__.__name__,
            "msg":    unicode(exc),
            "trace":  traceback.format_exc(limit=6),
            "timestamp": system.date.format(system.date.now(),"dd-MMM-YY HH:mm:ss"),
        }
        tagio.write_single(self.tag_root + self._T_ERR, json.dumps(info))
        self.set_state(CMState.ERROR, "ERROR - see logs or Val_LastError")
        self.log.error("{} - {}".format(context, info["msg"]))
        self.log.error(info["trace"])
        return info
        
    def clear_error(self):
        tagio.write_single(self.tag_root + self._T_ERR,None)
    # -----------------------------hooks--------------------------- 
    # Subclasses must override the trio below - they *can* access the
    # SCADA tag system, but might focus solely on the external protocol.
    # ----------------------------------------------------------------------
    def _device_heartbeat(self):
        raise NotImplementedError

    def _device_interlocks_met(self):
        raise NotImplementedError

    def _device_cancel(self):
        raise NotImplementedError