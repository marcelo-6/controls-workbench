"""
PAT.cm.mir
----------
Control-Module wrapper for the **MIR** instrument via REST API.

Relies on BaseCM for:
- state & message writes
- arbitration (Owned/ChartID)
- error serialization (post_error)
- tiny public API contract (heartbeat, interlocks, cancel)

No blocking loops / sleep calls here; everything is one-shot.

Tag interface (relative to UDT root)
------------------------------------
Reads:
  /Parameters/EP/0/Val_String   -> device IP (string)
  /Parameters/EP/1/Val_String   -> device Port (string/int)

Writes:
  /CM/Val_SampleNumber          -> framework's monotonically increasing sample #
  /LM/Val_SampleData            -> newline "x,y" pairs (legacy-friendly)
  /CM/Val_StateCode/Name/Msg    -> via BaseCM.set_state()
  /CM/Sts_Available             -> via BaseCM.heartbeat()

"""

import json
from collections import OrderedDict

from PAT.cm.base import BaseCM, CMState
from PAT.infra      import tagio, log
#import PAT.cm.base.BaseCM as BaseCMs
#import PAT.cm.base.CMState as CMState

__all__ = ["MirCM"]


class MirCM(BaseCM):
    """
    Concrete CM for MIR via REST.

    Endpoint map (from MIR update spec):
      GET  /api/device/status/ready          -> bool
      GET  /api/measurement/state            -> "available"|"running"|"paused"|"stopping"|...
      GET  /api/measurement/n-samples        -> int
      POST /api/measurement/start            -> accepts JSON with acquisition params (min/max ranges supported)
      POST /api/measurement/resume           -> 204
      POST /api/measurement/pause            -> 204
      POST /api/measurement/stop             -> 202
      GET  /api/spectrometer/wavenumbers     -> [float,...]
      GET  /api/storage/measurements/{measurement}/dynamic/{group}/{dataset}?index_from=i&index_to=i&...
           (we use group="processed", dataset="absorbance")
    """

    # Parameter tag paths (relative)
    _P_IP   = "/Parameters/EP/0/Val_String"
    _P_PORT = "/Parameters/EP/1/Val_String"

    # Output tags
    _T_SAMPLE_NO   = "/CM/Val_SampleNumber"      # already in BaseCM, exposed here for clarity
    _T_SAMPLE_DATA = "/LM/Val_SampleData"

    # Defaults for data retrieval
    _DEFAULT_GROUP   = "processed"
    _DEFAULT_DATASET = "absorbance"

    # Command-disagree timeout defaults (ms)
    _EXPECT_MS = 5000

    # ----------------------------ctor---------------------------------
    def __init__(self, tag_root):
        super(MirCM, self).__init__(tag_root)
        self.log = log.get("PAT.CM.MIR")

        # Runtime cache / latches
        self._wavenumbers = None
        self._last_seen_instr_sample = 0
        self._run_name = None
        self._expect = None      # dict: {"action": "stop|pause|resume|start", "want": "available|paused|running", "deadline": java.util.Date}
        self._last_emitted_idx = 0  # highest storage index we've surfaced via new_sample

    # ----------------------------helpers-------------------------------
    def _tag(self, rel):
        return self.tag_root + rel

    def _read_ip_port(self):
        ip   = tagio.read_single(self._tag(self._P_IP))
        port = tagio.read_single(self._tag(self._P_PORT))
        return ip, port

    def _base_url(self):
        ip, port = self._read_ip_port()
        return "http://%s:%s" % (ip, port)

    def _client(self, timeout_ms=6000):
        # Lazy local import (Ignition gateway scope)
#        return system.net.httpClient(timeout=timeout_ms) #, bypass_cert_validation=True
        return PAT.net.client

    def _request(self, method, path, params=None, body=None, timeout_ms=6000, fast=False):
        """
        Small wrapper around Ignition httpClient with minimal assumptions.
        Raises on HTTP errors to be caught by BaseCM.post_error callers.
        """
        if fast:
        	client = PAT.net.client_fast
        else:
        	client = self._client(timeout_ms)
        url = self._base_url() + path
        if method == "GET":
            resp = client.get(url, params=params or {})
        elif method == "POST":
            # The MIR API expects JSON for start (and possibly others)
            if body is None:
            	# non blocking request since it can take > 2min for a measurement to pause/stop/resume
                promise = client.postAsync(url)
                def got_response(response,error):
                	from PAT.infra      import log
                	log = log.get("PAT.CM.MIR")
                	if not error:
                	    log.debug("request url=%s" % response.url)
                	    log.debug("reponse code=%s" % response.getStatusCode())
                	    log.debug("reponse body=%s" % response.json)
                	else:
                		log.debug("error for=%s=%s" % (response.url,str(error)))
                	
                promise.whenComplete(got_response)
                return True
            else:
                # unified JSON body (client handles Content-Type)
                resp = client.post(url, data=json.dumps(body), headers={"Content-Type": "application/json"})
        elif method == "PUT":
            if body is None:
                resp = client.put(url)
            else:
                resp = client.put(url, data=json.dumps(body),headers={"Content-Type":"application/json"})
        else:
            raise ValueError("Unsupported method %s" % method)

        # Normalize
        code = getattr(resp, "statusCode", None) or getattr(resp, "getStatusCode", lambda: None)()
        if code is None:
            # fall back - some client versions expose getStatusCode()
            code = resp.getStatusCode()

        # Treat 2xx / 204 as success
        self.log.debug("request url=%s" % resp.url)
        self.log.debug("reponse code=%s" % code)
        self.log.debug("reponse body=%s" % resp.json)
        if 200 <= int(code) < 300:
            try:
                return resp.json    # Response supports .json in our env
            except:
                # Fallback to parsed text
                try:
                    txt = resp.getText()
                    return json.loads(txt) if txt and txt.strip().startswith(("{", "[")) else txt
                except:
                    return None
        if getattr(resp, "text", False) and resp.text:
            raise RuntimeError("HTTP %s %s failed (status %s). Body: %s" % (method, path, code,resp.getText()))
        else:
            raise RuntimeError("HTTP %s %s failed (status %s)." % (method, path, code))

    # -------------------------device hooks (BaseCM)--------------------
    def _device_heartbeat(self):
        """True when /api/device/status/ready is reachable and returns boolean."""
        try:
            data = self._request("GET", "/api/device/status/ready", timeout_ms=3000, fast=True)
            # allow true/false or {"ready":true}
            if isinstance(data, dict):
                return bool(data.get("ready", False))
            return bool(data)
        except:
            return False

    def _device_interlocks_met(self):
        """
        Interlocks:
          1) Spectrometer state must be 'ready'          (GET /api/spectrometer/status/state)
          2) No active alerts (is_active == true)        (GET /api/spectrometer/status/alerts)
        Returns (bool_ok, reason_str).
        """
        try:
            # --- 1) Spectrometer state must be "ready"
            st = self._request("GET", "/api/spectrometer/status/state", timeout_ms=3000)
            # accept raw string or {"state": "..."}
            state = st.get("state") if isinstance(st, dict) else st
            state = (unicode(state) if state is not None else u"unknown").lower()
            if state != u"ready":
                return (False, u"Spectrometer state='%s' (need 'ready')" % state)

            # --- 2) No active alerts
            alerts = self._request("GET", "/api/spectrometer/status/alerts", timeout_ms=4000)
            active = []
            if isinstance(alerts, dict):
                for name, meta in alerts.iteritems():
                    try:
                        if bool(meta.get("is_active")):
                            active.append(unicode(name))
                    except:
                        # ignore malformed entries
                        pass
            # If any alert is active, fail (regardless of severity)
            if active:
                return (False, u"Active alerts: %s" % (u", ".join(active)))

            return (True, u"")

        except Exception as exc:
            # BaseCM.interlocks_met() will post_error on exception; also return a tuple here.
            return (False, unicode(exc))
            
    def _device_cancel(self):
        """Abort any active acquisition."""
        try:
            self._request("POST", "/api/measurement/stop", timeout_ms=4000)
        except Exception as exc:
            # Let BaseCM.cancel_active() catch & post error; re-raise
            raise

    # -----------------------------public CM API------------------------
    def start(self, params=None):
        """
        Non-blocking start; accepts optional JSON dict with acquisition params.
        Example accepts min/max ranges per spec (passed through verbatim).
        """
        try:
            self._request("POST", "/api/measurement/start", body=(params or {}), timeout_ms=8000)
            # Expect instrument to move to "running"
            self._set_expect("start", want="running", within_ms=self._EXPECT_MS)
            self.set_state(CMState.READY, "Start command sent")
            self._run_name = params["name"]
        except Exception as exc:
            self.post_error(exc, context="MIR.start")

    def pause(self):
        try:
            self._request("POST", "/api/measurement/pause", timeout_ms=4000)
            self._set_expect("pause", want="paused", within_ms=self._EXPECT_MS)
            self.set_state(CMState.READY, "Pause command sent")
        except Exception as exc:
            self.post_error(exc, context="MIR.pause")

    def resume(self):
        try:
            self._request("POST", "/api/measurement/resume", timeout_ms=4000)
            self._set_expect("resume", want="running", within_ms=self._EXPECT_MS)
            self.set_state(CMState.READY, "Resume command sent")
        except Exception as exc:
            self.post_error(exc, context="MIR.resume")

    def stop(self):
        try:
            self._request("POST", "/api/measurement/stop", timeout_ms=1000)
            # Instrument finishes gracefully → state should settle at "available"
#            self._set_expect("stop", want="available", within_ms=self._EXPECT_MS)
            self.set_state(CMState.READY, "Stop command sent")
        except Exception as exc:
            self.post_error(exc, context="MIR.stop")

    # -------------------------polling helpers--------------------------
    def status_poll(self):
        """
        One-shot snapshot used by EM/SFC Monitor steps.

        Returns
        -------
        dict with keys:
          state:  instrument state string
          instr_sample: int (from /api/measurement/n-samples)
          new_sample: bool
          data_json: str (present only if new_sample True)
          stopping: bool (stop issued but still running)
          stopped:  bool (stop reached available)
        """
        ret = {
            "state": None,
            "instr_sample": 0,
            "new_sample": False,
            "stopping": False,
            "stopped": False
        }

        try:
            state = self._state_string()
            ret["state"] = state

            # Cache wavenumbers (only once; safe because we primed before start)
            self._fetch_wavenumbers()

            # Command-disagree watchdog
            self._check_expect_against(state)

            # Sample count & new sample detection
            instr_n = self._instr_sample_count()
            ret["instr_sample"] = instr_n

            if instr_n > max(1, int(self._last_seen_instr_sample)):
                # New sample arrived; fetch data once
                # Starting from when sample 2 is inprogress (meaning sample 1 completed)
                data_json,x_len, data_dict = self._fetch_latest_sample(instr_n - 1)
                if data_json is not None:
                    ret["new_sample"] = True
                    self.log.debug("data type=%s" % str(type(data_json)))
                    self.log.debug("data=%s" % str(data_json))
                    ret["data_json"] = data_json
                    ret["data_dict"] = data_dict
                    ret["x_len"] = x_len
                    # Advance our framework sample number & persist sample payload
                    current = int(tagio.read_single(self._tag(self._T_SAMPLE_NO)) or 0)
                    tagio.write_multi(
                        [self._tag(self._T_SAMPLE_NO), self._tag(self._T_SAMPLE_DATA)],
                        [current + 1, data_dict]
                    )
                self._last_seen_instr_sample = instr_n

            # Stopping/Stopped flags
            if self._expect and self._expect.get("action") == "stop":
                if state == "running" or state == "stopping":
                    ret["stopping"] = True
                elif state == "available":
                    ret["stopped"] = True
                    self._expect = None
                    self.set_state(CMState.READY, "Measurement stopped")

            # Map instrument state → CMState (display only; no blocking)
            if state == "running":
                self.set_state(CMState.SAMPLING, "Sample %s in progress" % instr_n)
            elif state == "paused":
                self.set_state(CMState.PAUSED, "Instrument paused")
            elif state == "available":
                # Do not overwrite a STOPPED explicitly; Ready is fine
                self.set_state(CMState.READY, "Instrument available")
            elif state == "stopping":
                self.set_state(CMState.READY, "Instrument stopping...")
            else:
                # Unknown → leave state alone but log it
                self.log.debug("MIR state=%s" % state)

            return ret

        except Exception as exc:
            self.post_error(exc, context="MIR.status_poll")
            return ret

    # ---------------------------private REST helpers-------------------
    def _state_string(self):
        data = self._request("GET", "/api/measurement/state", timeout_ms=3000)
        # accept {"state":"running"} or plain string
        if isinstance(data, dict):
            return unicode(data.get("state", u"unknown")).lower()
        return unicode(data).lower()

    def _instr_sample_count(self):
        data = self._request("GET", "/api/measurement/n-samples", timeout_ms=3000)
        try:
            return int(data if not isinstance(data, dict) else data.get("count", 0))
        except:
            return 0

    def _storage_sample_count(self):
        """
        GET /api/storage/measurements/{measurement}/params/n-samples
        Returns committed sample count even when /measurement/n-samples resets (paused).
        """
        try:
            if not self._run_name:
                return 0
            path = "/api/storage/measurements/%s/params/n-samples" % self._run_name
            data = self._request("GET", path, timeout_ms=3000)
            if isinstance(data, dict):
                # accept common shapes
                for k in ("count", "n_samples", "value"):
                    if k in data:
                        return int(data[k])
                # last resort: first value
                return int(data.get("0", 0))
            return int(data or 0)
        except:
            return 0

    def _fetch_wavenumbers(self):
        # Cache wavenumbers
        if self._wavenumbers is None:
            w = self._request("GET", "/api/spectrometer/wavenumbers", timeout_ms=4000)
            self._wavenumbers = list(w or [])

    def _fetch_latest_sample(self, instr_idx):
        """
        Returns (json_string, x_len) or (None, None).
        """

        # Build dynamic dataset URL (latest measurement, single index)
        # The spec shows: /api/storage/measurements/{measurement}/dynamic/{group}/{dataset}
        path = "/api/storage/measurements/%s/dynamic/%s/%s" % (self._run_name,self._DEFAULT_GROUP, self._DEFAULT_DATASET)
        params = {"index_from": instr_idx, "index_to": instr_idx} # "smoothing": 0

        data = self._request("GET", path, params=params, timeout_ms=8000)
        if not data:
            return None, None

        x = None
        y = None
#        self.log.debug(str(type(data)))
        if isinstance(data, list):
        	y = data[0]
        	x = self._wavenumbers
        self.log.debug(str(len(x)))
        self.log.debug(str(len(y)))

        if not x or not y:
            return None, None

        # Canonical “x,y” newline format (ordered)
#        json.dumps(OrderedDict((str(round(x, 4)), str(y)) for x, y in zip(x_arr, y_arr)))
#        combined = OrderedDict((str(round(float(xv), 6)), str(yv)) for xv, yv in zip(x, y))
        combined = OrderedDict((str(int(round(float(xv)))), '%.6f' % round(float(yv), 6)) for xv, yv in zip(x, y))
        return '\n'.join(['{},{}'.format(k, v) for k, v in combined.items()]), len(x), json.dumps(combined)
#        return '\n'.join(['{},{}'.format(k, v) for k, v in combined.items()]), len(x)

    # ---------------------------command disagree-----------------------
    def _set_expect(self, action, want, within_ms):
        now = system.date.now()
        deadline = system.date.addMillis(now, int(within_ms))
        self._expect = {"action": action, "want": want, "deadline": deadline}

    def _check_expect_against(self, current_state):
        """
        If we were expecting a target state by a deadline, raise ALARM if not met.
        """
        if not self._expect:
            return
        want = self._expect["want"]
        deadline = self._expect["deadline"]
        if current_state == want:
            self._expect = None
            return
        # Past deadline and still not in desired state → alarm
        if system.date.isAfter(system.date.now(), deadline):
            msg = u"Command disagree: expected '%s' but state is '%s' after timeout" % (want, current_state)
            # self.set_state(CMState.ALARM, msg)
            self.log.warn(msg)
            # keep latch set; SFC can decide to escalate/stop
            

    def set_parameters(self, path):
        """
        Single-arg Graphics helper: performs GETs and the light-source SET.
        - Pass one of the values from get_parameter_options().
        - If 'path' includes '?state=on|off' for /light-source, we PUT {"state": "..."}.
        - Otherwise we GET and return the parsed body as-is.
        Returns:
            For GET: dict/list/str/None (whatever the API returns)
            For SET: {"ok": True, "state": "on|off"} on success; None on failure
        """
        try:
            if not path:
                return None

            s = unicode(path).strip()
            # detect light-source state mutation encoded as query
            state = None
            if s.startswith("/api/spectrometer/light-source"):
                # parse '?state=on|off' (ignore any other query params)
                qpos = s.find("?state=")
                if qpos != -1:
                    state = s[qpos+7:].split("&", 1)[0].lower()
                    s = s[:qpos]  # strip query for the actual endpoint

            if state in ("on", "off"):
                # SET via PUT
                self._request("PUT", s, body={"state": state})
                return {"ok": True, "state": state}

            # Otherwise: plain GET
            return self._request("GET", s)

        except Exception as exc:
            self.post_error(exc, context="MIR.set_parameters[%s]" % path)
            return None
def get_parameter_options():
    """
    Provide Graphics a flat list of selectable options for GET/SET.
    NOTE: The light source ON/OFF actions are encoded as a single string arg
    using a query suffix ?state=on|off so 'set_parameters' can parse it.
    """
    return [
      {"value": "/api/spectrometer/status/state",               "label": "Get Spectrometer State"},
      {"value": "/api/spectrometer/status/alerts",              "label": "Get Spectrometer Alerts"},
      {"value": "/api/spectrometer/light-source/runtime",       "label": "Get Spectrometer Light Source Runtime"},
      {"value": "/api/spectrometer/light-source",               "label": "Get Spectrometer Light Source Status"},
      # Actions (single-arg encoded):
      {"value": "/api/spectrometer/light-source?state=on",      "label": "Set Spectrometer Light Source - ON"},
      {"value": "/api/spectrometer/light-source?state=off",     "label": "Set Spectrometer Light Source - OFF"},
      {"value": "/api/measurement/params",                      "label": "Get Current Measurement Params"},
      {"value": "/api/measurement/state",                       "label": "Get Current Measurement State"},
    ]
