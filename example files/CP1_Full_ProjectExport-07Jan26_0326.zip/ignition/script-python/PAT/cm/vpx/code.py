"""
Flow VPX Control Module (CM).

This module adapts the generic BaseCM abstraction to CTech FlowVPX / ViPER,
where all control is done via OPC UA method calls exposed through the
vpxGateway message handler, and 1D data is read directly from the UDT
(OPC-backed LM/Daq and LM/RawData tags).

Responsibilities
----------------
- Provide a CM wrapper (VpxCM) that:
    * Talks to VPX via system.util.sendRequest → vpxGateway.
    * Implements BaseCM hooks: heartbeat, interlocks, cancel.
    * Starts/stops DAQ instances (CreateDaqStart + startCollect/stopMethod).
    * Tracks the DAQ id SCADA expects vs. what VPX actually reports.
    * Exposes a lightweight status_poll() for EM/SFC to consume.

"""

from PAT.cm.base import BaseCM, CMState
from PAT.infra import tagio, log


__all__ = ["VpxCM"]


class VpxCM(BaseCM):
    """
    Control Module for Flow VPX / ViPER.

    Parameters
    ----------
    tag_root : unicode
        Root path for the Flow VPX UDT instance, for example
        "[default]PAT/FlowVPX-01".

    Optional keyword-only
    ---------------------
    project_name : unicode, optional
        Ignition project name used for system.util.sendRequest. If omitted,
        ``system.project.getProjectName()`` is used.
    gateway_handler : unicode, optional
        Name of the message handler that wraps VPXClient. Defaults to
        "vpxGateway".
    opc_server : unicode, optional
        Logical OPC server name; passed to the gateway in the "opcServer"
        field. Defaults to "VPX_OPC".
    """

    # ---------------- VPX-specific tag fragments ----------------

    # LM / Method
    T_METHOD_ID = "/LM/Method/ID"
    # Optional flag: when True we will (later) prompt for baseline first.
    T_METHOD_BASELINE_REQUIRED = "/LM/Method/BaselineRequired"

    # LM / System
    T_SYS_DEVICE_ID = "/LM/System/DeviceId"
    T_SYS_USER_ID = "/LM/System/UserId"

    # LM / Daq (OPC-facing)
    T_DAQ_SAMPLE_NAME = "/LM/Daq/SampleName"
    # Actual DAQ id as seen from ViPER / OPC (read-only from SCADA perspective).
    T_DAQ_ACTUAL_DAQ_ID = "/LM/Daq/CurrentDaqId"
    # Boolean "is collecting" (OPC-backed).
    T_DAQ_IS_COLLECTING = "/LM/Daq/IsCollecting"

    # LM / RawData (optional, informational)
    T_RAW_CYCLE_COUNT_ID = "/LM/RawData/CycleCountId"

    # LM / Results (SCADA-owned, master/summary)
    T_RES_CYCLE_COUNT = "/LM/Results/CycleCount"
    # "What SCADA believes is the current DAQ id" for this run.
    T_RES_EXPECTED_DAQ_ID = "/LM/Results/CurrentDaqId"
    T_RES_STARTED_TIME = "/LM/Results/StartedTime"
    T_RES_COMPLETION_TIME = "/LM/Results/CompletionTime"
    T_RES_SUMMARY = "/LM/Results/Summary"
    
    T_INSTRUMENT_ONLINE = "/CM/Sts_Available"

    # Defaults for gateway wiring
    DEFAULT_HANDLER = "vpxGateway"
    DEFAULT_OPC_SERVER = "VPX_OPC"

    def __init__(self, tag_root, project_name=None, gateway_handler=None, opc_server=None):
        super(VpxCM, self).__init__(tag_root)
        self.log = log.get("PAT.CM.VPX")

        # Gateway wiring
        if project_name is None:
            # No explicit import; Ignition injects the "system" scripting module.
            self.project_name = system.project.getProjectName()
        else:
            self.project_name = project_name
        opc_server = None
        opc_server = PAT.infra.tagio.read_single(tag_root+"/_Parameters.opcServer")

        self.gateway_handler = gateway_handler or self.DEFAULT_HANDLER
        self.opc_server = opc_server or self.DEFAULT_OPC_SERVER

        # In-memory tracking of DAQ id and whether we think a DAQ is active.
        self._expected_daq_id = None
        self._has_active_daq = False

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _call_gateway(self, action, extra=None, timeout_ms=10000):
        """
        Call the vpxGateway message handler with a given action.

        Parameters
        ----------
        action : unicode
            VPX action name understood by vpxGateway, for example
            "getUsers", "createDaqStart", "startCollect", "stopMethod".
        extra : dict, optional
            Extra key/value pairs to include in the payload. Can be None.
        timeout_ms : int, optional
            Request timeout in milliseconds. Defaults to 10 seconds.

        Returns
        -------
        dict
            Gateway response dict, expected to have at least:
            {
              "status": "ok" or "error",
              "action": action,
              "opcStatus": (code, name, desc) or None,
              "opcDiagnostic": ...,
              "payload": raw OPC payload,
              "parsed": parsed Python data or same as payload
            }

        Raises
        ------
        Exception
            If gateway returns a non-dict payload or "status" != "ok".
        """
        payload = {"opcServer": self.opc_server, "action": action}
        if extra:
            payload.update(extra)

        self.log.debug("VPX CM gateway call ({}): {}".format(action, payload))
        resp = system.util.sendRequest(
            project=self.project_name,
            messageHandler=self.gateway_handler,
            payload=payload,
            timeoutSec=timeout_ms,
        )

        if not isinstance(resp, dict):
            raise Exception(
                u"vpxGateway returned non-dict for action %s: %r" % (action, resp)
            )

        status = resp.get("status")
        if status != "ok":
            msg = resp.get("message") or u"Unknown vpxGateway error"
            raise Exception(
                u"vpxGateway action %s failed: %s" % (action, msg)
            )

        return resp

    def _parse_daq_id(self, payload):
        """
        Best-effort extraction of an integer DAQ id from an arbitrary payload.

        The vendor has not yet finalized the exact shape of the response for
        Daq/GetDaqId and CreateDaqStart, so this helper tries several common
        patterns:

        - Scalar int/long or numeric string.
        - Dict with keys like "daqId", "DAQID", "DaqId", "Id", "ID".
        - Nested lists/tuples of any of the above.

        Parameters
        ----------
        payload : object
            Raw payload or parsed payload from vpxGateway.

        Returns
        -------
        int or None
            Integer DAQ id if we can find/convert it, otherwise None.
        """
        from java.util import List, ArrayList
        # Nothing to parse.
        if payload is None:
            return None

        # Simple scalar: try to coerce to int (covers int, long, numeric strings).
        if not isinstance(payload, (dict, list, tuple, List, ArrayList)):
            try:
                return int(payload)
            except Exception:
                pass

        # Dict: look for common DAQ id keys.
        if isinstance(payload, dict):
            for key in ("daqId", "DAQID", "DaqId", "DaqID", "Id", "ID"):
                if key in payload:
                    try:
                        return int(payload.get(key))
                    except Exception:
                        # Ignore and keep searching.
                        pass

        # List/tuple: recurse into elements.
        if isinstance(payload, (list, tuple, List, ArrayList)):
            for item in payload:
                daq_id = self._parse_daq_id(item)
                if daq_id is not None:
                    return daq_id

        return None

    def _get_expected_daq_id_from_tag(self):
        """
        Helper to read the SCADA-expected DAQ id from LM/Results/CurrentDaqId.

        Returns
        -------
        int or None
        """
        try:
            value = tagio.read_single(self.tag_root + self.T_RES_EXPECTED_DAQ_ID)
        except Exception:
            return None

        if value in (None, "", 0):
            return None

        try:
            return int(value)
        except Exception:
            return None

    # ------------------------------------------------------------------ #
    # BaseCM hook implementations
    # ------------------------------------------------------------------ #

    def _device_heartbeat(self):
        """
        Connectivity probe for Flow VPX.
        """
        try:
            # for all OPC devices the realtime state is part of a expression tag
            # all we need to confirm if device is online is to read the tag
            isOnline = tagio.read_single(self.tag_root + self.T_INSTRUMENT_ONLINE)
            return isOnline
        except Exception as exc:
            self.log.debug("VPX heartbeat failed: {}".format(str(exc)))
            return False

    def _device_interlocks_met(self):
        """
        Basic interlocks for starting a new VPX DAQ.

        Current assumptions (v1):
        - VPX / OPC server must be online (heartbeat must be true).
        - VPX must not already be in a collecting state for *this* device.
        """
        if not self.is_online():
            return False, u"VPX / OPC server offline (heartbeat not OK)"

        try:
            collecting = bool(
                tagio.read_single(self.tag_root + self.T_DAQ_IS_COLLECTING)
            )
        except Exception as exc:
            # If we cannot even read IsCollecting, treat as an unsafe condition.
            self.log.debug(
                "VPX interlock check failed reading IsCollecting: {}".format(str(exc))
            )
            return False, u"Cannot read LM/Daq/IsCollecting"

        if collecting:
            # Either SCADA or a ViPER operator has an active DAQ.
            return False, u"VPX is already collecting (active DAQ present)"

        return True, u"Interlocks OK"

    def _device_cancel(self):
        """
        Issue a stop to any active VPX DAQ.

        This is invoked by BaseCM.cancel_active(), which will set CM state
        appropriately and call post_error() if this method raises.
        """
        try:
            resp = self._call_gateway("stopMethod", timeout_ms=10000)
            self.log.debug("VPX stopMethod response: {}".format(resp))
        except Exception as exc:
            # Log and re-raise so BaseCM.cancel_active() can post_error().
            self.log.error(u"VPX stopMethod failed: %s", exc)
            raise

    # ------------------------------------------------------------------ #
    # VPX-specific CM public API
    # ------------------------------------------------------------------ #

    def get_run_config(self):
        """
        Read current method / system / DAQ metadata from LM tags.

        Returns
        -------
        dict
            {
              "methodId":          int or None,
              "deviceId":          int or None,
              "userId":            int or None,
              "sampleName":        unicode or None,
              "baselineRequired":  bool
            }

        Notes
        -----
        - All IDs are returned as-is from tags (no validation beyond basic
          int conversion in create_daq_start()).
        - If LM/Method/BaselineRequired does not exist, the flag defaults
          to False.
        """
        paths = [
            self.tag_root + self.T_METHOD_ID,
            self.tag_root + self.T_SYS_DEVICE_ID,
            self.tag_root + self.T_SYS_USER_ID,
            self.tag_root + self.T_DAQ_SAMPLE_NAME,
        ]

        method_id, device_id, user_id, sample_name = tagio.read_multi(paths)

        # Optional baseline flag – treat missing tag as False.
        try:
            baseline_required = bool(
                tagio.read_single(self.tag_root + self.T_METHOD_BASELINE_REQUIRED)
            )
        except Exception:
            baseline_required = False

        cfg = {
            "methodId": method_id,
            "deviceId": device_id,
            "userId": user_id,
            "sampleName": sample_name,
            "baselineRequired": baseline_required,
        }

        self.log.debug(u"VPX run config from tags: {}".format(cfg))
        return cfg

    def create_daq_start(self, cfg):
        """
        Create a new VPX DAQ instance via vpxGateway.

        Parameters
        ----------
        cfg : dict
            Dictionary with at least:
            - methodId : int / unicode
            - deviceId : int / unicode
            - userId   : int / unicode
            - sampleName : unicode (optional, can be blank)

            Additional keys are ignored.

        Returns
        -------
        dict
            Gateway response dict, augmented with:
            - "daqId": integer DAQ id, if we could resolve one.
            - optionally "getCurrentDaqId": response from the follow-up call.

        Raises
        ------
        ValueError
            If required fields are missing in ``cfg``.
        Exception
            If the underlying vpxGateway call fails.
        """
        method_id = cfg.get("methodId")
        device_id = cfg.get("deviceId")
        user_id = cfg.get("userId")
        sample_name = cfg.get("sampleName")

        if method_id in (None, ""):
            raise ValueError("create_daq_start: cfg['methodId'] is required")
        if device_id in (None, ""):
            raise ValueError("create_daq_start: cfg['deviceId'] is required")
        if user_id in (None, ""):
            raise ValueError("create_daq_start: cfg['userId'] is required")

        payload = {
            "methodId": method_id,
            "deviceId": device_id,
            "userId": user_id,
        }

        if sample_name not in (None, ""):
            payload["sampleName"] = sample_name

        self.log.debug(
            "VPX createDaqStart: methodId={} deviceId={} userId={} sampleName={}".format(
            method_id,
            device_id,
            user_id,
            sample_name)
        )

        resp = self._call_gateway("createDaqStart", payload)

        # First attempt: pick DAQ id from createDaqStart payload itself.
        daq_id = self._parse_daq_id(resp.get("payload"))

        if daq_id is not None:
            self._expected_daq_id = daq_id
            self._has_active_daq = True

            # Persist SCADA's expected DAQ id under LM/Results/CurrentDaqId.
            try:
                tagio.write_single(
                    self.tag_root + self.T_RES_EXPECTED_DAQ_ID,
                    daq_id,
                )
            except Exception as exc:
                # Non-fatal; we still keep the in-memory copy.
                self.log.debug(
                    "VPX failed to write LM/Results/CurrentDaqId: {}".format(str(exc))
                )

            resp["daqId"] = daq_id

            # Friendly CM message
            self.set_state(
                CMState.READY,
                u"DAQ {} created; ready to start collection".format(daq_id),
            )

        return resp

    def start_collect(self, daq_id=None):
        """
        Request VPX to start collecting for the given DAQ id.

        Parameters
        ----------
        daq_id : int or unicode, optional
            DAQ id for which to start collection. If None, uses the cached
            expected DAQ id, falling back to LM/Results/CurrentDaqId.

        Returns
        -------
        dict
            Gateway response dict from the 'startCollect' action.

        Raises
        ------
        ValueError
            If no DAQ id can be resolved.
        Exception
            If the underlying vpxGateway call fails.
        """
        # Prefer explicit daq_id argument if provided.
        if daq_id in (None, ""):
            # Use in-memory cache if we have one.
            if self._expected_daq_id is not None:
                daq_id = self._expected_daq_id
            else:
                daq_id = self._get_expected_daq_id_from_tag()

        if daq_id in (None, ""):
            raise ValueError(
                "start_collect: no DAQ id specified and none cached / in LM/Results"
            )

        try:
            daq_id_int = int(daq_id)
        except Exception:
            # Pass through as-is; OPC will see it as a variant string/int.
            daq_id_int = daq_id

        self.log.debug("VPX startCollect for daqId={}".format(daq_id_int))

        resp = self._call_gateway("startCollect", {"daqId": daq_id_int})
        self._has_active_daq = True

        # Move CM to SAMPLING; actual data flow is reflected in IsCollecting.
        self.set_state(
            CMState.SAMPLING,
            u"DAQ %s - StartCollect requested" % daq_id_int,
        )

        return resp

    def status_poll(self):
        """
        Lightweight status poll for Flow VPX.

        - Reads LM/Daq/IsCollecting and DAQ id tags.
        - Reads LM/Results/CurrentDaqId (SCADA's expected DAQ id).
        - Optionally reads LM/Results/CycleCount and LM/RawData/CycleCountId.
        - Updates the CM state and returns a small status dictionary.

        Returns
        -------
        dict
            {
            "daq_id":             int or None,
            "expected_daq_id":    int or None,
            "actual_daq_id":      int or None,
            "collecting":         bool,
            "complete":           bool,
            "error":              bool,
            "daq_id_mismatch":    bool,
            "cycle_count":        int or None,
            "raw_cycle_count_id": object or None,
            "status_msg":         unicode,
            "cm_message":         unicode,
            }
        """
        collecting, actual_id, expected_id, cycle_count = tagio.read_multi(
            [
                self.tag_root + self.T_DAQ_IS_COLLECTING,
                self.tag_root + self.T_DAQ_ACTUAL_DAQ_ID,
                self.tag_root + self.T_RES_EXPECTED_DAQ_ID,
                self.tag_root + self.T_RES_CYCLE_COUNT,
            ]
        )

        # Optional RawData cycle id
        try:
            raw_cycle_id = tagio.read_single(
                self.tag_root + self.T_RAW_CYCLE_COUNT_ID
            )
        except Exception:
            raw_cycle_id = None

        collecting = bool(collecting)

        # Normalize DAQ ids
        actual_daq_id = None
        expected_daq_id = None

        try:
            if actual_id not in (None, "", 0):
                actual_daq_id = int(actual_id)
        except Exception:
            actual_daq_id = None

        try:
            if expected_id not in (None, "", 0):
                expected_daq_id = int(expected_id)
        except Exception:
            expected_daq_id = None

        # Allow in-memory cache to supply expected id if tag is empty.
        if expected_daq_id is None and self._expected_daq_id is not None:
            expected_daq_id = self._expected_daq_id

        # Keep cache in sync with tag.
        self._expected_daq_id = expected_daq_id

        # ---------------- Mismatch semantics ----------------
        #
        # - When IsCollecting == False:
        #     LM/Daq/CurrentDaqId is *last* run DAQ; it will not match the
        #     newly-created DAQ id yet. This is **not** a true mismatch.
        #
        # - When IsCollecting == True:
        #     LM/Daq/CurrentDaqId should reflect the *current* DAQ. If it is
        #     strictly greater than what SCADA expected, we consider that the
        #     instrument has moved on (e.g., operator started a newer DAQ in ViPER).
        #
        mismatch = False
        if collecting and expected_daq_id is not None and actual_daq_id is not None:
            # Only treat as mismatch if the instrument jumped *ahead* of us.
            # (We explicitly ignore the “previous DAQ” case where actual < expected.)
            if actual_daq_id > expected_daq_id:
                mismatch = True

        error = mismatch
        complete = False

        # State logic based on IsCollecting and whether we had an active DAQ
        if collecting:
            self._has_active_daq = True
            cm_state = CMState.SAMPLING
            status_msg = u"Collecting data (DAQ {}) - Cycle {}".format(
                actual_daq_id or expected_daq_id or u"?",raw_cycle_id
            )
        else:
            if self._has_active_daq:
                # We had an active DAQ and now it stopped → treat as complete.
                complete = True
                self._has_active_daq = False
                cm_state = CMState.READY
                status_msg = u"DAQ {} finished; not collecting".format(
                    actual_daq_id or expected_daq_id or u"?"
                )
            else:
                cm_state = CMState.IDLE
                status_msg = u"Idle; no active DAQ"

        if mismatch:
            status_msg = u"DAQ id mismatch while collecting: SCADA={}, VPX={}".format(
                expected_daq_id,
                actual_daq_id,
            )
            cm_state = CMState.ERROR

        # Push derived CM state to tags
        if error:
            self.set_state(CMState.ERROR, status_msg)
        else:
            self.set_state(cm_state, status_msg)

        info = {
            "daq_id":             expected_daq_id or actual_daq_id,
            "expected_daq_id":    expected_daq_id,
            "actual_daq_id":      actual_daq_id,
            "collecting":         collecting,
            "complete":           complete,
            "error":              error,
            "daq_id_mismatch":    mismatch,
            "cycle_count":        cycle_count,
            "raw_cycle_count_id": raw_cycle_id,
            "status_msg":         status_msg,
        }
        info["cm_message"] = info["status_msg"]

        self.log.debug("VPX status_poll: {}".format(info))
        return info