"""pat.cm.sim
================

In‑memory *simulator* Control‑Module implementation.
----------------------------------------------------

*   Feeds deterministic spectral samples from a CSV file.
*   Respects the common CM tag contract implemented in :pymod:`PAT.cm.base`.
*   Heartbeat & interlocks **always report healthy** (no external I/O).
*   Supports automatic or manual wrap‑around of the sample cursor.

Tag interface (relative to the UDT root)
---------------------------------------

+ ``Parameters/OP/0/Val_Integer`` - Delay **ms** between samples (optional).
+ ``Parameters/OP/1/Val_String``   - Path to CSV file.
+ ``Parameters/OP/2/Val_Boolean``  - Auto‑reset sample counter when end reached.
+ ``CM/Val_SampleNumber``          - Current sample index (1‑based).

CSV layout
~~~~~~~~~~
```
# Row‑0 :           X‑axis (wavelength) values
# Row‑1..N : line per sample with Y values matching the headers
SampleNo,  X0, X1, X2, ...
1,         Y0, Y1, Y2, ...
2,         Y0, Y1, Y2, ...
```
Each sample is converted to the newline‑separated ``"x,y"`` block required
by legacy SFC logic.

"""

import csv
import os
import time
from collections import OrderedDict

from PAT.cm.base import BaseCM, CMState
from PAT.infra import tagio, log, retry

__all__ = ["SimCM"]

# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# Control‑Module implementation
# -----------------------------------------------------------------------------
class SimCM(BaseCM):
    """Simulator CM - no external hardware, data comes from a CSV file."""

    # Tag relative paths -----------------------------------------------------
    _P_DELAY       = "/Parameters/OP/0/Val_Integer"
    _P_CSV_PATH    = "/Parameters/OP/1/Val_String"
    _P_AUTO_RESET  = "/Parameters/OP/2/Val_Boolean"

    _T_SAMPLE_DATA = "/LM/Val_SampleData"

    # ----------------------------ctor--------------------------------- 
    def __init__(self, tag_root):
        super(SimCM, self).__init__(tag_root)
        self.log = log.get("PAT.CM.Sim")

        # Parameters (read once - operators can re‑load via *reload()* )
        self.delay_ms   = tagio.read_single(self._tag(self._P_DELAY)) or 0
        self.csv_path   = tagio.read_single(self._tag(self._P_CSV_PATH)) or u""
        self.auto_reset = bool(tagio.read_single(self._tag(self._P_AUTO_RESET)))

        # Runtime
        self._samples = None  # lazy parsed list[str]
        self._idx     = 0     # 0‑based cursor

        self.log.debug("SimCM created - lazy data loading enabled")

    # -------------------------------utils------------------------------ 
    def _tag(self, rel):
        """Return absolute tag path for *rel*."""
        return self.tag_root + rel

    def _ensure_loaded(self):
        if self._samples is None:
            self.load_data()
            self.set_state(CMState.READY, "CSV loaded ({} samples)".format(len(self._samples)))

    # ------------------------------public API--------------------------- 
    def load_data(self):
        """(Re)load the CSV, resetting the sample cursor."""
        t0 = time.time()
        self._samples = PAT.sfc.read_csv_to_list(self.csv_path)
        self._idx = 0
        self.log.debug("Loaded {} samples from {} ({:.1f} ms)".format(len(self._samples), self.csv_path, (time.time() - t0)*1000))

    # -----------------------CM contract overrides----------------------- 
    def _device_heartbeat(self):
        return True

    def _device_interlocks_met(self):
        return True

    # -------------------------sampling-------------------------- 
    @retry.retry(attempts=3, delay_ms=10)
    def next_sample(self):
        """Return the next sample block (str). Auto‑wrap if configured."""
        if not self.is_owned():
            raise RuntimeError("CM must be acquired before sampling")

        self._ensure_loaded()
        cur_no = self._idx + 1
        payload = self._samples[self._idx]

        # advance cursor & optionally wrap
        self._idx += 1
        if self._idx >= len(self._samples):
            if self.auto_reset:
                self._idx = 0
            else:
                self._idx = len(self._samples) - 1  # clamp

        # expose sample number and data tag
        self._persist_sample_no(cur_no)
        self._persist_sample_data(payload)

        #  ------------------state transitions-----------------
        self.set_state(CMState.SAMPLING, "Sample #{} generating ({}s)".format(cur_no,int(self.delay_ms/1000.0)))
        if self.delay_ms:
            time.sleep(self.delay_ms / 1000.0)
        self.set_state(CMState.READY, "Sample #{} ready".format(cur_no))
        return payload

    # -----------------------utility helpers----------------------- 
    def reset_cursor(self, index=0):
        """Move the sample pointer to *index* (defaults to 0)."""
        self._ensure_loaded()
        self._idx = max(0, min(index, len(self._samples)-1))
        self._persist_sample_no(self._idx + 1)
        self.log.debug("Cursor reset to {}".format(self._idx))
        
    # -----------------------Internal helpers----------------------- 
    def _persist_sample_no(self, value):
        """Persist current sample number to `CM/Val_SampleNumber`."""
        try:
        	tagio.write_single(self._tag(self._T_SAMPLE_NO), value)
        except Exception as exc:
            self.log.warn("Failed to persist sample number: {}".format(exc))
            
    def _persist_sample_data(self, value):
        """Persist current sample number to `LM/Val_SampleData`."""
        try:
        	tagio.write_single(self._tag(self._T_SAMPLE_DATA), value)
        except Exception as exc:
            self.log.warn("Failed to persist sample data: {}".format(exc))