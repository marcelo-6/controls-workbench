import json
import java.util.UUID

def generate_uuid():
    """
    Generates a random UUID using Java's java.util.UUID class.

    Returns
    -------
    str
        A string representation of the generated UUID.
    """
    return str(java.util.UUID.randomUUID())

def toDict(perspective_object):
	"""Formats a perspective object as Dict
	
	Adapted from http://forum.inductiveautomation.com/t/ideal-way-to-display-objects-on-a-screen/41575

	Args:
		perspective_object: A perspective property object
	"""
	from com.inductiveautomation.ignition.common import TypeUtilities
	
	# Convert the Perspective property object to Gson and back to a Py Object
	return TypeUtilities.gsonToPy(TypeUtilities.pyToGson(perspective_object))
	

def toMarkdown(perspective_object, indent=3):
	"""Formats a perspective object as Markdown

	Args:
		perspective_object: A perspective property object
	"""
	from json import dumps
	json_string = dumps(toDict(perspective_object), indent=indent)
	return "```\n{}\n```".format(json_string)

def toUTCstr(date):
    """
    Converts a java.util.Date (e.g. system.date.now()) to a UTC string.
    Can be used to store UTC date in DB.

    Args:
        date (java.util.Date): Date class from system.date.now().

    Returns:
        str: UTC conversion, or None if input is not a java.util.Date.
    """
    # Import the necessary module for type checking
    from java.util import Date

    # Check if the input is an instance of java.util.Date
    if not isinstance(date, Date):
        return None

    # Convert to UTC string
    return date.toInstant().toString()

def fromUTCtoLocal(date):
    """
    Converts a java.util.Date (e.g. system.date.now()) in UTC to local time date.

    Args:
        date (java.util.Date): Date class from system.date.now().

    Returns:
        str: UTC conversion, or None if input is not a java.util.Date.
    """
    # Import the necessary module for type checking
    from java.util import Date

    # Check if the input is an instance of java.util.Date
    if not isinstance(date, Date):
        return None

    # Convert to UTC string
    return system.date.addHours(date, int(system.date.getTimezoneOffset(system.date.now())))

def json_to_markdown(json_data):
    """
    Convert a JSON object to a nicely formatted markdown code block.

    Parameters
    ----------
    json_data : dict or str
        The JSON data, either as a Python dictionary or a JSON string.

    Returns
    -------
    markdown : str
        The JSON formatted as a markdown code block.
    """
    # If json_data is a string, parse it into a dictionary
    if isinstance(json_data, str):
        json_data = json.loads(json_data)

    # Pretty-print the JSON data with indentation for readability
    pretty_json = json.dumps(json_data, indent=4)

    # Format it for markdown by wrapping in triple backticks
    markdown = "```json\n" + pretty_json + "\n```"

    return markdown

import sys
import traceback
import inspect

def log_exception(message="An error occurred"):
    """
    Logs the full stack trace of an exception within an script context.

    Args:
        chart (object): The chart object containing `chartPath` and `step_name`.
        message (str): Additional context message for the log.
    """
    try:
        # Get the current script name
        script_name = inspect.currentframe().f_back.f_code.co_name  # Get the caller function name

        # Get the logger based on the chart path
        logger = system.util.getLogger("PAT-Exception")

        # Get exception details
        ex_type, ex, tb = sys.exc_info()

        # Format the full stack trace
        full_stack_trace = "".join(traceback.format_exception(ex_type, ex, tb))
        # Log the full stack trace
        logger.error("ERROR':\n{}\n{}\n".format(
            message, full_stack_trace
        ))
    except Exception as logging_error:
        # Handle unexpected issues in the error logging itself
        fallback_logger = system.util.getLogger("PAT-FallbackLogger")
        fallback_logger.error("Failed to log exception: {}".format(logging_error))

import json
from collections import OrderedDict

def json_to_ordered_dict(json_str):
    """
    Convert a JSON string to an OrderedDict.
    
    Args:
        json_str (str): A JSON formatted string.
        
    Returns:
        OrderedDict: An ordered dictionary preserving the key order from the JSON.
    """
    return json.loads(json_str, object_pairs_hook=OrderedDict)

def ordered_dict_to_json(ordered_dict):
    """
    Convert an OrderedDict to a JSON string.
    
    Args:
        ordered_dict (OrderedDict): An ordered dictionary.
        
    Returns:
        str: A JSON string representing the ordered dictionary.
    """
    return json.dumps(ordered_dict)

def copy_to_clipboard(text, showToast=True):
    """
    Copy `text` to the clipboard from a Perspective session.

    Notes:
      - Clipboard API requires HTTPS (or localhost). We'll auto-fallback when not available.
      - Works inside Perspective only (Gateway/designer/client).
      - Optionally shows a toast in the browser session.

    Returns:
        True if the JS was dispatched to the client. (Success/failure of the copy
        happens on the client side; this call is async.)
    """
    if not hasattr(system.perspective, "runJavaScriptAsync"):
        return False

    js = r'''(text, wantToast) => {
        const notify = (msg, type='success') => {
            try {
                if (typeof periscope !== 'undefined' && periscope.toast) {
                    periscope.toast(msg, {
                        type,
                        autoClose: 2000,
                        position: 'bottom-center',
                        theme: 'dark',
                        closeOnClick: true
                    });
                }
            } catch (e) { /* no-op */ }
        };

        const doFallback = () => {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.setAttribute('readonly','');
            ta.style.position = 'fixed';
            ta.style.top = '-1000px';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            let ok = false;
            try {
                ok = document.execCommand('copy');
            } catch (e) {
                ok = false;
            }
            document.body.removeChild(ta);
            if (wantToast) notify(ok ? 'Copied to clipboard' : 'Copy failed', ok ? 'success' : 'error');
        };

        // Prefer modern Clipboard API in secure contexts
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(
                () => { if (wantToast) notify('Copied to clipboard', 'success'); },
                () => { doFallback(); }
            );
        } else {
            doFallback();
        }
    }'''

    args = {"text": text or "", "wantToast": bool(showToast)}
    system.perspective.runJavaScriptAsync(js, args)
    return True
    
def build_hist_path_from_browse(default_tail="/drv:default:default:/tag:USBOX-HIST-CAN/PROD_DATA"):
    """
    Find a historical provider whose name matches 'HIST_*' and prepend it to default_tail.

    # Canary-style tail (site-specific root)
    tail = "/drv:default:default:/tag:USBOX-HIST-CAN/PROD_DATA"
    path = build_hist_path_from_browse(tail)
    # -> "histprov:HIST_PROV:/drv:default:default:/tag:USBOX-HIST-CAN/PROD_DATA"

    # Internal Ignition historian tail
    tail = "/drv:pat-ign:default:/tag:pat/io/dls/lm/control/command"
    path = build_hist_path_from_browse(tail)
    # -> "histprov:HIST_DB:/drv:pat-ign:default:/tag:pat/io/dls/lm/control/command"

    Args:
      default_tail (str): The remainder of the path after 'histprov:<NAME>:/',
                         e.g. "/drv:default:default:/tag:USBOX-HIST-CAN/PROD_DATA"

    Returns:
      str|None: e.g. "histprov:HIST_PROV:/drv:default:default:/tag:USBOX-HIST-CAN/PROD_DATA",
                or None if no providers found.
    """
    try:
        results = system.tag.browseHistoricalTags('').getResults()
        paths = [a.path for a in results]
    except Exception:
        return None

    provider = None
    for path in paths:
        p = path.toString()
        if p.startswith("histprov:"):
            name = p[len("histprov:"):].split(":/", 1)[0]
            if name.startswith("HIST_"):
                provider = name
                break

    # Fallback: if no HIST_* match, use the first provider (optional)
    if not provider and paths:
        first = paths[0]
        if first.startswith("histprov:"):
            provider = first[len("histprov:"):].split(":/", 1)[0]

    if not provider:
        return None

    tail = default_tail.lstrip("/")  # ensure single slash after ':/'
    return "histprov:%s:/%s" % (provider, tail)