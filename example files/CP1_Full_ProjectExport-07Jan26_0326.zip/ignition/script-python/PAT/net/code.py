#client_no_cert = system.net.httpClient(timeout=timeout_ms, bypass_cert_validation=True)

client = system.net.httpClient(timeout=5000)
client_fast = system.net.httpClient(timeout=1000)

#http v1.1
client_v1 = system.net.httpClient(version="HTTP_1_1", timeout=5000)
client_v1_fast = system.net.httpClient(version="HTTP_1_1", timeout=1000)