"""
pat.tools.bench
===============

Quick-and-dirty micro-benchmark utility for Ignition (Jython 2.7).

Example – compare tagio.read_single vs. system.tag.readBlocking
---------------------------------------------------------------

>>> from pat.infra import tagio
>>> from pat.tools import bench
>>> TAG = "[default]RBP/PAT/Demo/Val_Msg"
>>>
>>> bench.run(
...     ("tagio.read_single", lambda: tagio.read_single(TAG)),
...     ("system.tag.readBlocking", lambda: system.tag.readBlocking([TAG])[0].value),
...     runs=50
... )
Benchmark results (50 runs each):
┌──────────────────────────────┬────────┬────────┬────────┬────────┐
│ Function                     │  mean  │   min  │   max  │   σ    │
├──────────────────────────────┼────────┼────────┼────────┼────────┤
│ tagio.read_single            │ 0.29ms │ 0.24ms │ 0.44ms │ 0.04ms │
│ system.tag.readBlocking      │ 0.28ms │ 0.23ms │ 0.42ms │ 0.05ms │
└──────────────────────────────┴────────┴────────┴────────┴────────┘
"""

from java.lang import System as JSystem
import math


# ----------------------------------------------------------------------
def _time_ns(fn):
    """Return elapsed nanoseconds for one call to *fn*()."""
    start = JSystem.nanoTime()
    fn()
    return JSystem.nanoTime() - start


def _stats(ns_list):
    n = len(ns_list)
    mean = float(sum(ns_list)) / n
    variance = sum((x - mean) ** 2 for x in ns_list) / n
    return {
        "mean": mean,
        "min": min(ns_list),
        "max": max(ns_list),
        "std": math.sqrt(variance),
    }


def _fmt(ns):
    """ns → ms string with two decimals."""
    return "{:.2f}ms".format(ns / 1e6)


def run(*funcs, **kw):
    """
    Benchmark *funcs* sequentially.

    Parameters
    ----------
    *funcs
        Tuples of ``(label, callable)``. The callables must take **no**
        positional arguments. Capture anything needed via ``lambda`` or
        ``functools.partial``.
    runs : int, keyword-only, default 20
        Loop count per function.

    Returns
    -------
    dict[str, dict]
        Mapping label → stats  (useful for programmatic inspection).
    """
    runs = int(kw.get("runs", 20))
    results = {}

    for label, fn in funcs:
        elapsed = [_time_ns(fn) for _ in xrange(runs)]
        results[label] = _stats(elapsed)

    # ── pretty print ────────────────────────────────────────────────
    print "Benchmark results ({} runs each):".format(runs)
    print "┌{:28s}┬{:>8s}┬{:>8s}┬{:>8s}┬{:>8s}┐".format(
        "─" * 28, "────", "────", "────", "────"
    )
    print "│ {:26s} │ {:>6s} │ {:>6s} │ {:>6s} │ {:>6s} │".format(
        "Function", "mean", "min", "max", "σ"
    )
    print "├{:28s}┼{:8s}┼{:8s}┼{:8s}┼{:8s}┤".format(
        "─" * 28, "────────", "────────", "────────", "────────"
    )
    for label, st in results.items():
        print "│ {:26s} │ {:>6s} │ {:>6s} │ {:>6s} │ {:>6s} │".format(
            label[:26],
            _fmt(st["mean"]),
            _fmt(st["min"]),
            _fmt(st["max"]),
            _fmt(st["std"]),
        )
    print "└{:28s}┴{:8s}┴{:8s}┴{:8s}┴{:8s}┘".format(
        "─" * 28, "────────", "────────", "────────", "────────"
    )

    return results