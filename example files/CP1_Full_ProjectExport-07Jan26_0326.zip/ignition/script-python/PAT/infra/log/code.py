"""
pat.infra.log
=============

Wrapper for Ignition's :class:`com.inductiveautomation.ignition.common.util.LoggerEx`
that guards *only* the noisy `debug` calls with `isDebugEnabled()`.

Usage
-----
```python
from pat.infra import log

lg = log.get("PAT.CM.Irubis-01")

lg.debug("payload ☺: %s", some_large_dict)
lg.info("human-facing message")
````

"""

from java.lang import Object

class _PatLogger(Object):
	"""
	A very thin decorator that forwards everything to the wrapped
	\:class:`LoggerEx`, except `debug(*)` ,
	which first consult `isDebugEnabled()`.
	"""


	def __init__(self, delegate):
	    self._d = delegate  # type: LoggerEx
	
	# ------------------------------------------------------------------
	# Guarded noisy levels
	# ------------------------------------------------------------------
	def debug(self, msg, *args):
	    """
	    Emit *msg* only when `isDebugEnabled()` returns ``True``.
	    """
	    if self._d.isDebugEnabled():
	        self._d.debug(msg, *args)
	
	# ------------------------------------------------------------------
	# Pass-through levels (no extra cost)
	# ------------------------------------------------------------------
	def info(self, msg, *args):
	    self._d.info(msg, *args)
	
	def warn(self, msg, *args):
	    self._d.warn(msg, *args)
	
	def error(self, msg, *args):
	    self._d.error(msg, *args)
	
	def fatal(self, msg, *args):
	    self._d.fatal(msg, *args)
	
	def isDebugEnabled(self):
	    return self._d.isDebugEnabled()
	

def get(name):
	"""
	Obtain a debug-aware logger. What that means is a logger.debug will only log if debug is enabled on the gateway logs. This minimizes the log entries when troubleshooting
	
	```
	Parameters
	----------
	name : str
	    The logger name (e.g. ``"PAT.SFC.Acquire"``).
	
	Returns
	-------
	_PatLogger
	    A wrapper honouring `isDebugEnabled()` guards.
	"""
	return _PatLogger(system.util.getLogger(name))
