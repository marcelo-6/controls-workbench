"""
pat.infra.retry
===============

Decorator-based retry / back-off helper.

Usage
-----
>>> from PAT.infra import tagio
>>> from PAT.infra.retry import retry
>>> TAG = "[default]RBP/PAT/Demo/Val_Msg"
>>>
>>> @retry(attempts=5, delay_ms=500, backoff=2.0)  # decorator!
... def read_demo_msg():
...     return tagio.read_single(TAG, validate=True)
...
>>> value = read_demo_msg()
>>> print value

Features
~~~~~~~~
• Works on any callable (incl. methods) – preserves *args / **kwargs*.  
• Exponential back-off.  
• Can be used **with or without** arguments:

    @retry.retry                     # uses defaults (3 attempts)
    def foo(): ...

    @retry.retry(attempts=4, delay_ms=250)
    def bar(): ...
"""

import functools
from java.lang import Thread


__all__ = ["retry"]


# ----------------------------------------------------------------------
def _sleep(ms):
    Thread.sleep(int(ms))


def _make_decorator(attempts, delay_ms, backoff, retry_ex, logger):
    """
    Internal factory returning the actual decorator.
    """

    def decorator(fn):

        @functools.wraps(fn)
        def _wrapped(*args, **kwargs):
            cur_delay = float(delay_ms)

            for attempt in xrange(1, attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except retry_ex as exc:
                    # ---------- optional on-retry hook ----------
                    # can be called to print retry count
                    hook = getattr(args[0], fn.__name__ + "__on_retry", None)
                    if callable(hook):
                        hook(attempt, exc)
                        
                    if attempt == attempts:
                        raise

                    if logger:
                        logger.debug(
                            "Retry {} / {} after {} ms - {}"
                            .format(attempt, attempts, int(cur_delay), exc)
                        )
                    _sleep(cur_delay)
                    cur_delay *= backoff    # exponential back-off

        return _wrapped

    return decorator


# ----------------------------------------------------------------------
def retry(*dargs, **dkw):
    """
    Can be used **both** as `@retry` and `@retry(...)`.

    Parameters (same as previous helper)
    ------------------------------------
    attempts : int       default **3**
    delay_ms : int       default **1000**
    backoff  : float     default **1.0**
    retry_ex : tuple     default **(Exception,)**
    logger   : InfraLog  default **None**
    """

    def is_decorator_no_args(arg):
        # If called as @retry without (), the first positional arg is the fn
        return len(dargs) == 1 and callable(arg) and not dkw

    if dargs and is_decorator_no_args(dargs[0]):
        # @retry   →  dargs[0] is the target function
        return _make_decorator(
            attempts=3, delay_ms=1000, backoff=1.0,
            retry_ex=(Exception,), logger=None
        )(dargs[0])

    # @retry(...)
    attempts = int(dkw.get("attempts", 3))
    delay_ms = int(dkw.get("delay_ms", 1000))
    backoff = float(dkw.get("backoff", 1.0))
    retry_ex = dkw.get("retry_ex", (Exception,))
    logger = dkw.get("logger",PAT.infra.log.get("PAT."+__name__))

    if attempts < 1:
        raise ValueError("attempts must be ≥ 1")

    return _make_decorator(attempts, delay_ms, backoff, retry_ex, logger)