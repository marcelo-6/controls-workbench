"""
pat.infra.tagio (v0.2)

Sync helpers around Ignition tag reads & writes.

Key improvements
----------------
• Quality checking is **opt-in** via `validate=True`.  
  Omitting it skips the check.

Functions
---------
read_single(path, validate=False, return_qv=False)
read_multi(paths, validate=False, return_qv=False)
write_single(path, value, validate=False)
write_multi(paths, values, validate=False)
"""

__all__ = [
    "read_single",
    "read_multi",
    "write_single",
    "write_multi",
]


# ---------------------------------------------------------------------- #
def _ensure_iterable(obj):
    return obj if isinstance(obj, (list, tuple)) else [obj]


def _assert_good(qv, path):
    if not qv.quality.isGood():
        raise IOError("Bad quality for tag {!r}: {}".format(path, qv.quality))


# ---------------------------------------------------------------------- #
# READ API
# ---------------------------------------------------------------------- #
def read_single(path, validate=False, return_qv=False):
    """
    Parameters
    ----------
    path : str
    validate : bool, default **False**
        When True, raise IOError on bad quality.
    return_qv : bool, default False
        When True, return the full QualifiedValue.
    """
    qv = system.tag.readBlocking([path])[0]
    if validate:
        _assert_good(qv, path)
    return qv if return_qv else qv.value


def read_multi(paths, validate=False, return_qv=False):
    """
    Batch read; order preserved.

    validate / return_qv behave the same as in `read_single`.
    """
    paths = _ensure_iterable(paths)
    qvs = system.tag.readBlocking(paths)
    if validate:
        for p, qv in zip(paths, qvs):
            _assert_good(qv, p)
    return qvs if return_qv else [qv.value for qv in qvs]


# ---------------------------------------------------------------------- #
# WRITE API
# ---------------------------------------------------------------------- #
def write_single(path, value, validate=False):
    """
    Write one tag.  If *validate* is True, raise on bad quality.
    """
    qlty = system.tag.writeBlocking([path], [value])[0]
    if validate and not qlty.isGood():
        raise IOError("Write failed for {!r}: {}".format(path, qlty))


def write_multi(paths, values, validate=False):
    """
    Batch write keeping order correspondence between *paths* & *values*.
    """
    if len(paths) != len(values):
        raise ValueError("paths and values length mismatch")
    qlts = system.tag.writeBlocking(paths, values)
    if validate:
        for p, q in zip(paths, qlts):
            if not q.isGood():
                raise IOError("Write failed for {!r}: {}".format(p, q))