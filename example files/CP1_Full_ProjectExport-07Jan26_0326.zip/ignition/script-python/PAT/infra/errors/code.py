"""
Local error taxonomy so retry / hold / fatal can be handled cleanly
in SFC steps or orchestrator logic.
"""

from java.lang import Exception as JavaException  # Jython compatible

class RetryableSoft(JavaException):
    """Temporary failure – safe to retry automatically."""

class HoldableHard(JavaException):
    """Requires operator intervention (Hold)."""

class Fatal(JavaException):
    """Irrecoverable; abort the chart."""