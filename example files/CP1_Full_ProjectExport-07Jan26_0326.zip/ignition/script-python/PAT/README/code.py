"""
# PAT Jython Framework – Developer Guide

> **Scope**  This document describes the small but opinionated ‘CM ⇄ EM ⇄ SFC’ framework that now powers every PAT instrument integration in our Ignition SCADA project.  After reading you should be able to:
>
> * understand the role of each layer (CM / EM / SFC),
> * add a *new* instrument (e.g. MIR, DLS, RAMAN),
> * extend / maintain an existing integration

---

## 1. Vocabulary in one slide

| Layer                                | Python package | Runtime object     | Ignition concept               | Purpose                                                                                                                   |
| ------------------------------------ | -------------- | ------------------ | ------------------------------ | ------------------------------------------------------------------------------------------------------------------------- |
| **CM** (*Control Module*)            | `PAT.cm.*`     | `BaseCM` subclass  | Instrument **UDT – CM folder** | **Raw I/O**.  Only talks HTTP / OPC. Knows **nothing** about runs, samples or databases.                         |
| **EM** (*Equipment Module*)          | `PAT.em.*`     | `BaseEM` subclass  | Instrument **UDT – EM folder** | Presents **commands** (start/stop/hold/…) & **status** to GUI/SFC.  Converts low‑level CM errors to user‑friendly states. |
| **SFC** (*Sequencer / Orchestrator*) | `PAT.em.sfc.*` | `BaseSFC` subclass | **Main SFC chart**             | Brains.  Drives the measurement sequence, does arbitration, inserts DB rows, pushes data to ML endpoint…                  |

```
┌────────┐  IO    ┌────────┐  cmds/sts  ┌────────┐
│ Device │◀──────▶│  CM    │◀──────────▶│  EM    │
└────────┘        └────────┘            │  ▲     │
                                        │  │     │  chart.step()
                                        │  ▼     │
                                      ┌────────┐ │
                                      │  SFC   │◀┘
                                      └────────┘
```

---

## 2. State objects

`PAT.state.FiniteState` is a tiny value‑object helper to make integer codes readable.  We pre‑define the following:

```python
from PAT.state import FiniteState

CMState  = FiniteState
EMState  = FiniteState

CMState.IDLE      = CMState(0,   "Idle")
CMState.ACQUIRED  = CMState(10,  "Acquired")
CMState.READY     = CMState(15,  "Ready")
CMState.SAMPLING  = CMState(20,  "Sampling")
CMState.PAUSED    = CMState(30,  "Paused")
CMState.STOPPED   = CMState(40,  "Stopped")
CMState.ALARM     = CMState(900, "Alarm")
CMState.ERROR     = CMState(999, "Error")

# EMState mirrors the S88 life‑cycle
EMState.STARTING  = EMState(100, "Starting")
EMState.RUNNING   = EMState(200, "Running")
EMState.HOLDING   = EMState(400, "Holding")
EMState.HELD      = EMState(401, "Held")
EMState.STOPPING  = EMState(600, "Stopping")
EMState.STOPPED   = EMState(601, "Stopped")
EMState.ERROR     = EMState(999, "Error")
```

All writes to tag folders **must** use these.  *Never* write raw integers from higher layers.

---

## 3. Base classes

### 3.1  `PAT.cm.base.BaseCM`

* Handles one **instrument UDT root path** (e.g. `[default]RBP/PAT/Irubis‑01/CM/`).
* Provides high‑level helpers:

  * `read(tag_name)` / `write(tag_name, value)` – relative to CM folder.
  * `acquire()`, `release()`, `is_owned()` – arbitration helpers.
  * `set_state(CMState, message="", write_tag=True)` – centralised state+message handling.
* No business logic – only transport & housekeeping.

\### 3.2  `PAT.em.base.BaseEM`

* Knows *which* CM it is supervising.
* Exposes one‐shot **command polls** (`poll_commands()`) and **acknowledge** helpers (`ack_command("hold")`).  Commands are edge‑triggered (0→1).
* Holds the *chart\_id* so that CM/EM arbitration survives gateway restarts.
* `set_state(EMState, message, write_tag=True)` updates both `/Val_EM_Status` and `/EM/Val_Msg`.

\### 3.3  `PAT.em.sfc.base.BaseSFC`

* The **tiny** orchestrator:

  * `acquire(chart_id)` – arbitration & interlocks.
  * `initialize()` – calls subclass hook `_initialize_after_acquire()`.
  * Runtime helpers like `sample()`, `monitor()`, `store_sample_data()` … each calling a protected hook overridable per instrument.
* Maintains bookkeeping (`db_run_insert_id`, `sample_no`, …) so every subclass does not repeat boiler‑plate.

---

## 4. Implementing a *new* instrument

1. **Clone** the SIM reference implementation:

   ```text
   PAT/
     cm/myinstr.py      ← subclass BaseCM (HTTP paths, heartbeat, sample fetch, …)
     em/myinstr.py      ← (optional) if GUI behaviour differs from BaseEM
     em/sfc/myinstr.py  ← subclass BaseSFC, implement 5 hooks:
                            _initialize_after_acquire()
                            _sample_after_initialize()
                            _monitor_sample()
                            _next_sample()
                            _store_sample_data()
   ```
2. **Tag template**: follow the same CM/EM/Parameters layout.
4. **Test**:

   ```bash
   # inside Gateway scripting console or tests/
   python tests/sfc_myinstr_integration.py
   ```

---

## 5. Project layout (recap)

```
PAT/
├─ cm/
│   ├─ base.py      # BaseCM
│   ├─ sim.py       # SimCM (example)
│   ├─ raman.py     # RamanMarqCM (for MarqMetrix Ramans)
│   └─ …
├─ em/
│   ├─ base.py      # BaseEM
│   ├─ sfc/
│   │   ├─ base.py  # BaseSFC
│   │   ├─ sim.py   # SimSFC (example)
│   │   ├─ raman.py # RamanMarqSFC
│   │   └─ …
│   └─ …
├─ infra/
│   ├─ tagio.py     # thin wrapper around system.tag.* helpers
│   ├─ log.py       # project‑level logger helper
│   └─ retry.py     # @retry decorator
└─ state.py         # FiniteState helper
```

"""