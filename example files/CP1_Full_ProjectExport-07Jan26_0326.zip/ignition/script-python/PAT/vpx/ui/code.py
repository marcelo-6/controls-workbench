# pat.vpx.ui - VPX UI helpers for perspective dropdowns

def _methods_to_dropdown_dataset(methods, includePlaceholder=True):
    """
    Convert a VPX method list (getMethodsByDate 'methods') into a perspective
    dropdown dataset with 'value' and 'label' columns.

    Parameters
    ----------
    methods : list of dict
        From vpxGateway getMethodsByDate, each row like:
            {"id": 1022, "name": "Method_20251216193557"}
    includePlaceholder : bool
        If True, adds a first row with value=None, label="<Select Method>".

    Returns
    -------
    Dataset
        Columns: value (int), label (str)
    """
    headers = ["value", "label"]
    rows = []

    if includePlaceholder:
        rows.append([None, "<Select Method>"])

    if not methods:
        return system.dataset.toDataSet(headers, rows)

    # Normalize + collect
    tmp = []
    for m in methods:
        try:
            mid = (m.get("id") or
                   m.get("ID") or
                   m.get("Id"))
            name = (m.get("name") or
                    m.get("Name"))
        except AttributeError:
            # Not a dict-like, just skip
            continue

        if mid is None:
            continue

        if not name:
            name = "Method %s" % mid

        tmp.append({"value": mid, "label": name})

    # Sort by label (alpha). Change if you want by id/date.
    tmp.sort(key=lambda r: str(r["label"]))

    for r in tmp:
        rows.append([r["value"], r["label"] + " | id:{}".format(str(r["value"]))])

    return system.dataset.toDataSet(headers, rows)


def getMethodDropdownForPastDays(opcServer, daysBack, projectName=None,
                                 includePlaceholder=True, timeoutSec=100):
    """
    Convenience wrapper:
    - Computes start/end date = now - daysBack .. now
    - Calls vpxGateway/getMethodsByDate
    - Converts the result into a Perspective dropdown dataset.

    Parameters
    ----------
    opcServer : str
        Name of the VPX OPC connection (e.g. "VptOpcServerForm1").
    daysBack : int
        How many days in the past to search (e.g. 7 for last week).
    projectName : str or None
        Ignition project name. If None, uses system.project.getProjectName().
    includePlaceholder : bool
        Add the "<Select Method>" first row if True.
    timeoutSec : int
        sendRequest timeout in seconds.

    Returns
    -------
    Dataset
        value,label columns suitable for a Vision Dropdown's .data property.
    """
    if projectName is None:
        projectName = system.project.getProjectName()

    try:
        days = int(daysBack)
    except Exception:
        days = 7

    end_date = system.date.now()
    start_date = system.date.addDays(end_date, -days)

    payload = {
        "opcServer": opcServer,
        "action": "getMethodsByDate",
        "startDate": start_date,
        "endDate": end_date,
    }

    resp = system.util.sendRequest(
        project=projectName,
        messageHandler="vpxGateway",
        payload=payload,
        timeoutSec=timeoutSec,
    )

    # Basic sanity check
    if not resp or resp.get("status") != "ok":
        msg = "getMethodsByDate failed"
        if resp:
            msg = resp.get("message") or msg
        system.util.getLogger("PAT.VPX.UI").debug(
            "getMethodDropdownForPastDays: %s, resp=%s" % (msg, resp)
        )
        # Return dataset with a single "error" row instead of exploding
        headers = ["value", "label"]
        rows = [[None, "Error: %s" % msg]]
        return system.dataset.toDataSet(headers, rows)

    methods = resp.get("methods") or []
    return _methods_to_dropdown_dataset(methods, includePlaceholder)