"""
**VPXClient** – `PAT.vpx.core.VPXClient`

- Centralizes all `system.opcua.callMethod` calls:
    
    - `_call_raw` → logs, catches Java exceptions (including `Bad_EncodingLimitsExceeded`), raises consistent Python exceptions.
        
    - `_split_result` → `(statusTuple, diagnostic, payload)`.
        
    - `_check_status_or_raise` → enforces OPC `Good`.
        
    - `_call_with_parser` → returning a standard dict:
        
        ```python
        {
          "statusTuple": (code, name, description) or None,
          "diagnostic":  diagnostic,
          "payload":     raw,
          "parsed":      parsed_or_raw,
        }
        ```
        
- Parsing helpers:
    
    - `_parse_item1_item2_list(payload, key1, key2)` → generic Item1/Item2 → dict list.
        
    - `_parse_method_list(payload)` → list of `{id, name}` methods.
        
- Public VPX methods:
    
    - System: `get_users()`, `get_devices()`, `get_flow_cell_types()`, `get_flow_cells(flow_cell_type_id)`
        
    - Method: `clear_method()`, `open_method(method_id)`, `save_method()`, `get_methods_by_date(start, end)`
        
    - DAQ: `create_daq_start(method_id, device_id, user_id, sample_name=None)`, `get_current_daq_id()`, `start_collect(daq_id)`, `stop_method()`, `get_daq_start_info(start_date, end_date)`, `get_cycle_data(daq_id)`.
        

**Gateway message handler** – `vpxGateway.handleMessage(payload)`

- Exposes VPXClient via `system.util.sendRequest("Project", "vpxGateway", payload, timeout)`.
    
- Defines `action` names:
    
    - Discovery: `getUsers`, `getDevices`, `getFlowCellTypes`, `getFlowCells`
        
    - Methods: `getMethodsByDate`, `clearMethod`, `openMethod`, `saveMethod`
        
    - DAQ history/control: `getDaqStartInfo`, `createDaqStart`, `getCurrentDaqId`, `startCollect`, `stopMethod`, `getCycleData`
        
- Normalizes response envelopes:
    
    ```python
    {
      "status": "ok" | "error",
      "action": "<action>",
      "opcStatus": (code, name, description) or None,
      "opcDiagnostic": <diagnostic> or None,
      # plus action-specific keys:
      "users" | "devices" | "flowCellTypes" | "flowCells" | "methods"
      "daqRuns" | "cycleData" | "payload",
      "rawPayload": raw OPC payload,
      "noResults": bool,
      "message": "<error text>"   # only on error
    }
    ```
Note: vpxGateway message handler is needed. If multiple gateways are involved either replicate the message handler OR relay the request from the first gateway sending request 
use the remoteServer option of system.util.sendRequest(project, messageHandler, [payload], [remoteServer], [timeoutSec]) while the second gateway handles the actual request to
the flow vpx OPC server. I would recommend the 1st option since the graphics dont make many requests, but the first option means you need to maintain the same code in 2 places
therefore any changes need to be done twice.
"""