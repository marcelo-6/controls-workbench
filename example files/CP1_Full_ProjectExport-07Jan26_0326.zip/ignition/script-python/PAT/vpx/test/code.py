# ------------------------------------------------------------
# Common setup
# ------------------------------------------------------------

PROJECT = system.project.getProjectName()
OPC_SERVER = "VptOpcServerForm1"  # adjust if needed


def call_vpx(action, timeout=15, **kwargs):
    """
    Convenience wrapper for calling the vpxGateway message handler.

    Parameters
    ----------
    action : str
        VPX action name (see vpxGateway).
    timeout : int
        Timeout in seconds for sendRequest.
    **kwargs : dict
        Extra fields to include in the payload.

    Returns
    -------
    dict
        Response from vpxGateway, already printed in a readable way.
    """
    payload = {"opcServer": OPC_SERVER, "action": action}
    payload.update(kwargs)

    print "------------------------------------------------------------"
    print "VPX action:", action
    print "Payload:", payload

    resp = system.util.sendRequest(
        project=PROJECT,
        messageHandler="vpxGateway",
        payload=payload,
        timeoutSec=timeout,
    )

    print "Response:", resp

    status = resp.get("status")
    if status != "ok":
        print "STATUS:", status
        print "ERROR MESSAGE:", resp.get("message")
        return resp

    print "STATUS: ok"
    print "OPC status tuple:", resp.get("opcStatus")
    print "OPC diagnostic:", resp.get("opcDiagnostic")
    return resp


# ------------------------------------------------------------
# 1) Discovery: Users and Devices
# ------------------------------------------------------------

def test_get_users():
    resp = call_vpx("getUsers")
    if resp.get("status") == "ok":
        print "Users (parsed):"
        for u in resp.get("users") or []:
            print "  id=%s, username=%s" % (u.get("id"), u.get("username"))


def test_get_devices():
    resp = call_vpx("getDevices")
    if resp.get("status") == "ok":
        print "Devices (parsed):"
        for d in resp.get("devices") or []:
            print "  id=%s, serial=%s" % (d.get("id"), d.get("serialNumber"))


# ------------------------------------------------------------
# 2) OPTIONAL: Flow cell types and cells (you said skip for now)
# ------------------------------------------------------------

def test_get_flow_cell_types():
    resp = call_vpx("getFlowCellTypes")
    if resp.get("status") == "ok":
        print "Flow cell types (parsed):"
        for t in resp.get("flowCellTypes") or []:
            print "  typeId=%s, name=%s" % (
                t.get("flowCellTypeId"),
                t.get("cellName"),
            )


def test_get_flow_cells(flow_cell_type_id):
    resp = call_vpx("getFlowCells", flowCellTypeId=flow_cell_type_id)
    if resp.get("status") == "ok":
        print "Flow cells (parsed) for type %s:" % flow_cell_type_id
        for c in resp.get("flowCells") or []:
            print "  id=%s, serial=%s" % (
                c.get("id"),
                c.get("serialNumber"),
            )


# ------------------------------------------------------------
# 3) Methods: browse by date, open, save
# ------------------------------------------------------------

def test_get_methods_by_date(days_back=14):
    """
    List methods saved in the last N days and print IDs and names.
    """
    end_date = system.date.now()
    start_date = system.date.addDays(end_date, -days_back)

    resp = call_vpx(
        "getMethodsByDate",
        startDate=start_date,
        endDate=end_date,
    )

    if resp.get("status") == "ok":
        methods = resp.get("methods") or []
        print "Methods in range (%s -> %s):" % (start_date, end_date)
        if not methods:
            print "  no methods found"
        for m in methods:
            print "  id=%s, name=%s" % (m.get("id"), m.get("name"))


def test_open_method(method_id):
    """
    Open a specific method by ID. This should populate Method/* tags
    on the VPX OPC server side.
    """
    resp = call_vpx("openMethod", methodId=method_id)
    # We do not know the payload structure, so we just show it.
    if resp.get("status") == "ok":
        print "openMethod payload:", resp.get("payload")


def test_save_method():
    """
    Save the current Method/* values as a method in VPX.
    """
    resp = call_vpx("saveMethod")
    if resp.get("status") == "ok":
        print "saveMethod payload:", resp.get("payload")


def test_clear_method():
    """
    Try to call Method/ClearMethod.

    Note:
    On your current server install this may fail with Bad_MethodInvalid.
    The error will be exposed clearly in the response.
    """
    resp = call_vpx("clearMethod")
    # If server does not support it, you should see an error message.


# ------------------------------------------------------------
# 4) DAQ history: GetDaqStartInfo
# ------------------------------------------------------------

def test_get_daq_start_info(days_back=2):
    """
    Call Daq/GetDaqStartInfo and print the raw payload.
    We are not parsing this yet, only surfacing the raw structure.
    """
    end_date = system.date.now()
    start_date = system.date.addDays(end_date, -days_back)

    resp = call_vpx(
        "getDaqStartInfo",
        startDate=start_date,
        endDate=end_date,
    )

    if resp.get("status") == "ok":
        print "DAQ runs noResults:", resp.get("noResults")
        print "DAQ rawPayload:", resp.get("rawPayload")

def test_get_daq_cycle_data(daq_id):
    """
    Call Daq/GetCycleData and print the raw payload.
    We are not parsing this yet, only surfacing the raw structure.
    """
    resp = call_vpx(
        "getCycleData",
        daqId=daq_id,
    )
    if resp.get("status") == "ok":
        print "getCycleData payload:", resp.get("cycleData")

# ------------------------------------------------------------
# 5) DAQ control path A: explicit IDs
# ------------------------------------------------------------

def test_create_daq_start_explicit(method_id, device_id, user_id, sample_name=None):
    """
    Create a DAQ entry using explicit IDs.

    Parameters
    ----------
    method_id : int like
    device_id : int like
    user_id   : int like
    sample_name : str or None
    """
    resp = call_vpx(
        "createDaqStart",
        methodId=method_id,
        deviceId=device_id,
        userId=user_id,
        sampleName=sample_name,
    )
    if resp.get("status") == "ok":
        print "createDaqStart payload:", resp.get("payload")


def test_get_current_daq_id():
    """
    Get the current or last DAQ id (shape is vendor-specific).
    """
    resp = call_vpx("getCurrentDaqId")
    if resp.get("status") == "ok":
        print "Current DAQ payload:", resp.get("payload")


def test_start_collect(daq_id):
    """
    Start collection for a given DAQ id.
    """
    resp = call_vpx("startCollect", daqId=daq_id)
    if resp.get("status") == "ok":
        print "startCollect payload:", resp.get("payload")


def test_stop_method():
    """
    Stop the currently running method / DAQ.
    """
    resp = call_vpx("stopMethod")
    if resp.get("status") == "ok":
        print "stopMethod payload:", resp.get("payload")


# ------------------------------------------------------------
# Example: call a few tests manually from the console
# ------------------------------------------------------------

# Uncomment what you want to test:

# 1) Basic tests
#test_get_users()
#test_get_devices()

# 2) Methods
#test_get_methods_by_date(days_back=2)
#test_open_method(method_id=1023)   # replace with a real ID, 1023 no baseline, 1025 baselines
##test_save_method() # skip
##test_clear_method() # skip

# 3) DAQ history
#test_get_daq_start_info(days_back=5)
#test_get_daq_cycle_data(daq_id=4150)

# 4) DAQ control, explicit IDs
#test_create_daq_start_explicit(method_id=1025, device_id=1, user_id=2, sample_name="SCADA-ma-test-designer-baseline")
#test_get_current_daq_id()
#test_start_collect(daq_id=4154)  # replace with a real DAQ id
#test_stop_method()