"""
VPX / CTech ViPER OPC UA integration helpers for Ignition.

This module defines the VPXClient class, which wraps the VPX OPC UA
MethodNodeClass calls into a simple Python API that is easy to use from:

- Gateway message handlers
- SFC step scripts
- Perspective graphics (via sendRequest, not direct OPC)

The goals are:

- Centralize all system.opcua.callMethod usage in one place.
- Enforce consistent error handling and logging.
- Provide parsed, human friendly data structures where possible.
- Fail fast and clear when inputs are wrong or OPC returns non Good status.

"""

try:
    from java.lang import Throwable as JavaThrowable
except ImportError:
    #  fall back so code can still import
    class JavaThrowable(Exception):
        pass

class VPXClient(object):
    """
    High level wrapper around the VPX OPC UA server.

    This class is intended to be used from GATEWAY scope, typically from
    a message handler (see vpxGateway) or from SFC step scripts.

    Example
    -------
    >>> client = VPXClient("VPX_OPC")
    >>> users = client.get_users()
    >>> users["parsed"]
    [{'id': 2, 'username': 'admin'}, {'id': 1, 'username': 'csupport'}]

    All public methods return a dictionary with the following keys:

        {
          "statusTuple": (statusCode, statusName, statusDescription) or None,
          "diagnostic":  OPC diagnostic data or None,
          "payload":     raw payload object from OPC,
          "parsed":      parsed Python data or same as payload
        }

    Any non Good OPC status raises an Exception before the dict is returned.
    """

    def __init__(self, opc_server):
        """
        Initialize a new VPXClient.

        Parameters
        ----------
        opc_server : str
            Ignition OPC UA connection name for the VPX server.
            This is the same name you pass as the first argument to
            system.opcua.callMethod.
        """
        self.opc_server = opc_server
        self.log = system.util.getLogger("PAT.VPX")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _node(self, path):
        """
        Build a NodeId string for namespace 2 using a simple string path.

        The VPX OPC UA server uses namespace index 2 with string NodeIds
        like "System", "System/GetUsers", "Daq/GetDaqStartInfo", etc.

        Parameters
        ----------
        path : str
            Path part of the NodeId, for example "System" or
            "System/GetUsers" or "Daq/GetDaqStartInfo".

        Returns
        -------
        str
            NodeId in the form "ns=2;s=<path>".
        """
        return "ns=2;s=" + path

    def _call_raw(self, object_path, method_path, args):
        """
        Low level wrapper around system.opcua.callMethod with logging.

        This is the only place where system.opcua.callMethod is used.
        All higher level public methods should use _call_with_parser.

        Parameters
        ----------
        object_path : str
            Path for the object NodeId, for example "System", "Daq", "Method".
        method_path : str
            Path for the method NodeId, for example "System/GetUsers".
        args : list
            List of input arguments for the OPC UA method.

        Returns
        -------
        object
            Raw result from system.opcua.callMethod. This is usually a list or
            tuple with at least one element containing the OPC status, and
            additional elements for diagnostics and payload.

        Raises
        ------
        Exception
            If system.opcua.callMethod itself throws an exception.
        """
        obj_id = self._node(object_path)
        method_id = self._node(method_path)

        self.log.debug(
            "VPX callMethod: server=%s, object=%s, method=%s, args=%s"
            % (self.opc_server, obj_id, method_id, args)
        )

        try:
            result = system.opcua.callMethod(self.opc_server, obj_id, method_id, args)

        except JavaThrowable, jex:
            # This catches Java-side exceptions (UaServiceFaultException, etc.)
            msg = str(jex) or jex.__class__.__name__

            if "Bad_EncodingLimitsExceeded" in msg:
                self.log.error(
                    "VPX callMethod Bad_EncodingLimitsExceeded: "
                    "server=%s, object=%s, method=%s, args=%s, error=%s"
                    % (self.opc_server, obj_id, method_id, args, msg)
                )
                # Normalize into a simpler Python Exception
                raise Exception(
                    "OPC UA Error Bad_EncodingLimitsExceeded while calling "
                    "%s/%s; DAQ response may be too large or OPC UA stack "
                    "limits are too strict. Original: %s"
                    % (object_path, method_path, msg)
                )

            self.log.error(
                "VPX callMethod Java exception: server=%s, object=%s, "
                "method=%s, args=%s, error=%s"
                % (self.opc_server, obj_id, method_id, args, msg)
            )
            raise Exception(
                "OPC UA Java exception while calling %s/%s: %s"
                % (object_path, method_path, msg)
            )

        except Exception, ex:
            # Any pure Jython/Python-level problems
            msg = str(ex) or ex.__class__.__name__
            self.log.error(
                "VPX callMethod Python exception: server=%s, object=%s, "
                "method=%s, args=%s, error=%s"
                % (self.opc_server, obj_id, method_id, args, msg)
            )
            raise

        self.log.debug(
            "VPX callMethod RAW result: %s (type=%s)" % (result, type(result))
        )
        return result

    def _split_result(self, raw):
        """
        Split a raw callMethod result into (statusTuple, diagnostic, payload).

        Observed pattern for VPX methods (for example System/GetUsers):

            raw == [
                (0L, "Good", "Good; unspecified."),   # status tuple
                [],                                    # diagnostic list
                <payload>                              # often JSON like
            ]

        Sometimes the return type is a tuple instead of a list, but the
        structure is the same.

        Parameters
        ----------
        raw : object
            Raw result from system.opcua.callMethod.

        Returns
        -------
        (statusTuple, diagnostic, payload)
            statusTuple : tuple or None
            diagnostic  : object or None
            payload     : object
        """
        status = None
        diag = None
        payload = raw

        try:
            n = len(raw)
            if n >= 1 and isinstance(raw[0], tuple) and len(raw[0]) >= 3:
                status = raw[0]
                if n == 1:
                    payload = None
                elif n == 2:
                    payload = raw[1]
                else:
                    diag = raw[1]
                    payload = raw[-1]
        except Exception:
            # raw is not indexable in a useful way, leave payload as is.
            pass

        return status, diag, payload

    def _check_status_or_raise(self, status_tuple, object_path, method_path):
        """
        Check an OPC status tuple and raise if it is not Good.

        VPX returns status tuples like:
            (0L, "Good", "Good; unspecified.")
        or:
            (2155151360L, "Bad_MethodInvalid", "...")

        Parameters
        ----------
        status_tuple : tuple or None
            OPC status tuple. If None, this method does nothing.
        object_path : str
            Object path passed to _call_raw, used for error messages.
        method_path : str
            Method path passed to _call_raw, used for error messages.

        Raises
        ------
        Exception
            If the status code is not 0 or 0L.
        """
        if status_tuple is None:
            return

        try:
            code = status_tuple[0]
        except Exception:
            # If we cannot interpret the code, do not enforce it.
            return

        if code not in (0, 0L):
            msg = "OPC method %s/%s failed with status=%s" % (
                object_path, method_path, status_tuple,
            )
            raise Exception(msg)

    def _call_with_parser(self, object_path, method_path, args, parse_func):
        """
        Core helper: call an OPC method, split the result, check status,
        and optionally parse the payload.

        Parameters
        ----------
        object_path : str
            Object path for the NodeId, for example "System" or "Daq".
        method_path : str
            Method path for the NodeId, for example "System/GetUsers".
        args : list
            Input arguments for the OPC UA method.
        parse_func : callable or None
            If not None, this callable is applied to the payload and should
            return a parsed Python object. If None, the payload is returned
            as parsed unchanged.

        Returns
        -------
        dict
            A dictionary with keys:
                "statusTuple" : OPC status tuple or None
                "diagnostic"  : OPC diagnostic data or None
                "payload"     : raw payload
                "parsed"      : parsed payload or same as payload

        Raises
        ------
        Exception
            If OPC status is not Good or if system.opcua.callMethod fails.
        """
        raw = self._call_raw(object_path, method_path, args)
        status, diag, payload = self._split_result(raw)
        self._check_status_or_raise(status, object_path, method_path)

        if parse_func is not None:
            parsed = parse_func(payload)
        else:
            parsed = payload

        return {
            "statusTuple": status,
            "diagnostic": diag,
            "payload": payload,
            "parsed": parsed,
        }

    def _parse_item1_item2_list(self, payload, key1, key2):
        """
        Parse a payload that contains a list of objects with Item1 and Item2.

        Many VPX System methods return JSON like this:

            [
              [
                {"Item1": 2, "Item2": "admin"},
                {"Item1": 1, "Item2": "csupport"}
              ]
            ]

        or similar variants such as:

            "[[{\"Item1\":2,\"Item2\":\"admin\"}, ...]]"
            [ "[[{\"Item1\":2,...}]]" ]
            [ {"Item1":2,"Item2":"admin"}, {...} ]

        This helper normalizes those into:

            [
              {key1: <Item1>, key2: <Item2>},
              ...
            ]

        Parameters
        ----------
        payload : object
            Raw payload from OPC. Can be a JSON string, list, or nested list.
        key1 : str
            Output key name for Item1.
        key2 : str
            Output key name for Item2.

        Returns
        -------
        list of dict
            Parsed list of dictionaries, or [{"raw": <something>}] when a
            row cannot be interpreted.
        """
        out = []

        self.log.debug("VPX parse_item1_item2_list: payload type=%s, value=%s"
                       % (type(payload), payload))

        if payload is None:
            return out

        # Case 1: payload itself is a JSON string.
        if isinstance(payload, basestring):
            try:
                decoded = system.util.jsonDecode(payload)
                return self._parse_item1_item2_list(decoded, key1, key2)
            except Exception, ex:
                self.log.warn("VPX parse_item1_item2_list: jsonDecode(payload) "
                              "failed: %s" % ex)
                out.append({"raw": payload})
                return out

        # Case 2: payload is list like.
        try:
            length = len(payload)
        except Exception:
            out.append({"raw": payload})
            return out

        if length == 0:
            return out

        first = payload[0]
        self.log.debug("VPX parse_item1_item2_list: first type=%s, value=%s"
                       % (type(first), first))

        # Case 2a: first element is JSON string.
        if isinstance(first, basestring):
            try:
                decoded = system.util.jsonDecode(first)
                return self._parse_item1_item2_list(decoded, key1, key2)
            except Exception, ex:
                self.log.warn("VPX parse_item1_item2_list: "
                              "jsonDecode(first) failed: %s" % ex)
                for row in payload:
                    out.append({"raw": row})
                return out

        # Case 2b: first element looks like a dict (has get attribute).
        if hasattr(first, "get"):
            rows = payload
        else:
            # Case 2c: payload is a list with a single nested list.
            try:
                len(first)
                rows = first
            except Exception:
                rows = payload

        # Now iterate rows and extract Item1 and Item2.
        for row in rows:
            # Row can still be a JSON string.
            if isinstance(row, basestring):
                try:
                    decoded = system.util.jsonDecode(row)
                    sub = self._parse_item1_item2_list(decoded, key1, key2)
                    out.extend(sub)
                    continue
                except Exception:
                    out.append({"raw": row})
                    continue

            if hasattr(row, "get"):
                try:
                    item1 = row.get("Item1")
                    item2 = row.get("Item2")
                except Exception:
                    item1 = row.get("Item1", None)
                    item2 = row.get("Item2", None)
                out.append({key1: item1, key2: item2})
            else:
                out.append({"raw": row})

        return out

    def _parse_method_list(self, payload):
        """
        Parse a Method/GetMethodsByDateRange payload into a list of methods.

        The VPX server returns methods as JSON structures like:

            [
              [
                {"ID": 1022, "Name": "Method_20251216193557"},
                {"ID": 1021, "Name": "Method_20251216193438"}
              ]
            ]

        or similar variants. This helper normalizes into:

            [
              {"id": 1022, "name": "Method_20251216193557"},
              {"id": 1021, "name": "Method_20251216193438"}
            ]

        Parameters
        ----------
        payload : object
            Raw payload from OPC.

        Returns
        -------
        list of dict
            Parsed list with keys "id" and "name", or "raw" entries when a
            row cannot be interpreted.
        """
        out = []

        self.log.debug("VPX parse_method_list: payload type=%s, value=%s"
                       % (type(payload), payload))

        if payload is None:
            return out

        # Case 1: payload itself is a JSON string.
        if isinstance(payload, basestring):
            try:
                decoded = system.util.jsonDecode(payload)
                return self._parse_method_list(decoded)
            except Exception, ex:
                self.log.warn("VPX parse_method_list: jsonDecode(payload) "
                              "failed: %s" % ex)
                out.append({"raw": payload})
                return out

        # Case 2: payload is list like.
        try:
            length = len(payload)
        except Exception:
            out.append({"raw": payload})
            return out

        if length == 0:
            return out

        first = payload[0]
        self.log.debug("VPX parse_method_list: first type=%s, value=%s"
                       % (type(first), first))

        # Case 2a: [ JSON string ].
        if isinstance(first, basestring):
            try:
                decoded = system.util.jsonDecode(first)
                return self._parse_method_list(decoded)
            except Exception, ex:
                self.log.warn("VPX parse_method_list: jsonDecode(first) "
                              "failed: %s" % ex)
                for row in payload:
                    out.append({"raw": row})
                return out

        # Case 2b: [ {ID, Name}, ... ].
        if hasattr(first, "get"):
            rows = payload
        else:
            # Case 2c: [ [ {ID, Name}, ... ] ].
            try:
                len(first)
                rows = first
            except Exception:
                rows = payload

        # Extract ID and Name.
        for row in rows:
            if isinstance(row, basestring):
                try:
                    decoded = system.util.jsonDecode(row)
                    sub = self._parse_method_list(decoded)
                    out.extend(sub)
                    continue
                except Exception:
                    out.append({"raw": row})
                    continue

            if hasattr(row, "get"):
                mid = (row.get("ID") or
                       row.get("Id") or
                       row.get("id"))
                name = (row.get("Name") or
                        row.get("name"))
                out.append({"id": mid, "name": name})
            else:
                out.append({"raw": row})

        return out

    def _to_vpx_date_string(self, value):
        """
        Convert a date like value into the string format VPX expects.

        Some date range methods (such as Daq/GetDaqStartInfo) indicate that
        dates must be passed as strings in "MM/DD/YYYY" format.

        This helper accepts:

        - java.util.Date produced by system.date.* functions.
        - string values (returned as is).
        - any other value, which falls back to str(value).

        Parameters
        ----------
        value : object
            Date like value or string.

        Returns
        -------
        str or None
            Formatted date string, or None if input was None.
        """
        if value is None:
            return None

        if isinstance(value, basestring):
            return value

        try:
            return system.date.format(value, "MM/dd/yyyy")
        except Exception:
            self.log.warn("VPX _to_vpx_date_string: could not format %r"
                          % (value,))
            return str(value)

    # ------------------------------------------------------------------
    # SYSTEM (discovery) methods
    # ------------------------------------------------------------------

    def get_users(self):
        """
        Call System/GetUsers and parse result into a list of users.

        OPC documentation:
            System/GetUsers
            Returns users as Item1 = Id, Item2 = Username.

        Returns
        -------
        dict
            {
              "statusTuple": (code, name, description) or None,
              "diagnostic":  diagnostic object or None,
              "payload":     raw payload from OPC,
              "parsed":      [
                                {"id": <int>, "username": <str>},
                                ...
                             ]
            }

        Raises
        ------
        Exception
            If OPC status is not Good.
        """
        return self._call_with_parser(
            "System",
            "System/GetUsers",
            [],
            lambda payload: self._parse_item1_item2_list(
                payload, "id", "username"
            ),
        )

    def get_devices(self):
        """
        Call System/GetDevices and parse result into a list of devices.

        OPC documentation:
            System/GetDevices
            Returns devices as Item1 = Id, Item2 = Serial Number.

        Returns
        -------
        dict
            Parsed list under "parsed" with keys "id" and "serialNumber".
        """
        return self._call_with_parser(
            "System",
            "System/GetDevices",
            [],
            lambda payload: self._parse_item1_item2_list(
                payload, "id", "serialNumber"
            ),
        )

    def get_flow_cell_types(self):
        """
        Call System/GetFlowCellTypes and parse result.

        OPC documentation:
            System/GetFlowCellTypes
            Item1 = FlowCellTypeID, Item2 = CellName.

        Returns
        -------
        dict
            Parsed list under "parsed" with keys "flowCellTypeId" and
            "cellName".
        """
        return self._call_with_parser(
            "System",
            "System/GetFlowCellTypes",
            [],
            lambda payload: self._parse_item1_item2_list(
                payload, "flowCellTypeId", "cellName"
            ),
        )

    def get_flow_cells(self, flow_cell_type_id):
        """
        Call System/GetFlowCells for a specific Flow Cell Type.

        OPC documentation:
            System/GetFlowCells
            Get a list of Flow Cell by Type.
            Item1 = ID, Item2 = Serial Number.
            Input argument is the FlowCellTypeID.

        Parameters
        ----------
        flow_cell_type_id : int like
            FlowCellTypeID value, usually obtained from get_flow_cell_types.

        Returns
        -------
        dict
            Parsed list under "parsed" with keys "id" and "serialNumber".

        Raises
        ------
        Exception
            If flow_cell_type_id cannot be converted to int.
            If OPC status is not Good.
        """
        try:
            fc_type_id_int = int(flow_cell_type_id)
        except Exception, ex:
            raise Exception(
                "flow_cell_type_id must be an integer; got %r (type=%s). "
                "Original error: %s"
                % (flow_cell_type_id, type(flow_cell_type_id), ex)
            )

        return self._call_with_parser(
            "System",
            "System/GetFlowCells",
            [fc_type_id_int],
            lambda payload: self._parse_item1_item2_list(
                payload, "id", "serialNumber"
            ),
        )

    # ------------------------------------------------------------------
    # METHOD methods (read only and control)
    # ------------------------------------------------------------------

    def clear_method(self):
        """
        Call Method/ClearMethod to clear all Method/* nodes.

        Note
        ----
        Vendor documentation mentions Method/ClearMethod and sometimes
        Method/ClearMethodBool. On your current server installation the
        method node may not actually exist or may not be wired correctly.
        This method still calls Method/ClearMethod as documented and will
        raise an Exception when OPC returns a non Good status
        (for example Bad_MethodInvalid).

        Returns
        -------
        dict
            A dict with "statusTuple", "diagnostic", "payload", "parsed".

        Raises
        ------
        Exception
            If OPC status is not Good.
        """
        return self._call_with_parser(
            "Method", "Method/ClearMethod", [], None
        )

    def open_method(self, method_id):
        """
        Call Method/OpenMethod to populate Method/* nodes from a method id.

        OPC documentation:
            Method/OpenMethod
            Populates the Method/* tags from the method of the specified id.

        Typical usage is:
        - Graphics or SFC pick a method from getMethodsByDate.
        - They pass the selected methodId to open_method (via vpxGateway).
        - The Method/* tags update, then can be edited or used for DAQ.

        Parameters
        ----------
        method_id : int like
            Method ID to load.

        Returns
        -------
        dict
            Dict with OPC status and raw payload (if any).

        Raises
        ------
        Exception
            If method_id is not int like.
            If OPC status is not Good.
        """
        try:
            mid = int(method_id)
        except Exception, ex:
            raise Exception(
                "methodId must be an integer; got %r (type=%s). "
                "Original error: %s"
                % (method_id, type(method_id), ex)
            )

        return self._call_with_parser(
            "Method", "Method/OpenMethod", [mid], None
        )

    def save_method(self):
        """
        Call Method/SaveMethod to save the current Method/* node values.

        OPC documentation:
            Method/SaveMethod
            Saves the method defined by the current Method/* tags.

        Typical usage:
        - Operator or SFC writes desired parameters into Method/* tags.
        - Call save_method (via vpxGateway).
        - OPC server persists the method and may return information
          such as the new method id.

        This wrapper does not attempt to parse the payload because the
        exact structure is vendor specific.

        Returns
        -------
        dict
            Dict with OPC status and raw payload (if any).

        Raises
        ------
        Exception
            If OPC status is not Good.
        """
        return self._call_with_parser(
            "Method", "Method/SaveMethod", [], None
        )

    def get_methods_by_date(self, start_date, end_date):
        """
        Call Method/GetMethodsByDateRange to list methods between dates.

        For this method the server accepts OPC DateTime values, so this
        wrapper forwards the arguments as is. Use system.date.* functions
        on the client side to build start_date and end_date.

        The result payload is parsed into a list of dictionaries with
        keys "id" and "name".

        Parameters
        ----------
        start_date : java.util.Date
            Start of date range.
        end_date : java.util.Date
            End of date range.

        Returns
        -------
        dict
            {
              "statusTuple": ...,
              "diagnostic":  ...,
              "payload":     raw payload (nested lists or JSON),
              "parsed":      [{"id": <ID>, "name": <Name>}, ...]
            }

        Raises
        ------
        Exception
            If OPC status is not Good.
        """
        return self._call_with_parser(
            "Method",
            "Method/GetMethodsByDateRange",
            [start_date, end_date],
            self._parse_method_list
        )

    # ------------------------------------------------------------------
    # DAQ control and history methods
    # ------------------------------------------------------------------

    def create_daq_start(self, method_id, device_id, user_id, sample_name=None):
        """
        Call Daq/CreateDaqStart to create a DAQ entry for a method run.

        OPC documentation (simplified):
            Daq/CreateDaqStart
            Creates a DAQ record based on:
              - Method ID
              - Device ID
              - User ID
              - Optional Sample Name

        Typical usage:
        - Graphics or SFC determine methodId, deviceId, userId and sampleName.
        - They call this wrapper (via vpxGateway).
        - The OPC server creates a DAQ entry and returns confirmation data.

        Parameters
        ----------
        method_id : int like
            Method id to run.
        device_id : int like
            Device id to use (from System/GetDevices).
        user_id : int like
            User id responsible for the run (from System/GetUsers).
        sample_name : str or None, optional
            Optional sample name label.

        Returns
        -------
        dict
            Dict with OPC status and raw payload (structure is vendor
            specific and not parsed here).

        Raises
        ------
        Exception
            If any of method_id, device_id, or user_id are not int like.
            If OPC status is not Good.
        """
        try:
            mid = int(method_id)
            did = int(device_id)
            uid = int(user_id)
        except Exception, ex:
            raise Exception(
                "methodId, deviceId, and userId must be integers; got "
                "methodId=%r, deviceId=%r, userId=%r. Original error: %s"
                % (method_id, device_id, user_id, ex)
            )

        args = [mid, did, uid]
        if sample_name not in (None, ""):
            args.append(sample_name)

        return self._call_with_parser(
            "Daq", "Daq/CreateDaqStart", args, None
        )

    def get_current_daq_id(self):
        """
        Call Daq/GetDaqId to obtain the current DAQ id.

        OPC documentation:
            Daq/GetDaqId
            Returns the DAQ id for the current or last run.

        This wrapper does not interpret the payload. The calling code should
        inspect the "payload" or "parsed" field to determine the DAQ id
        shape based on vendor behavior.

        Returns
        -------
        dict
            Dict with OPC status and raw payload.

        Raises
        ------
        Exception
            If OPC status is not Good.
        """
        return self._call_with_parser(
            "Daq", "Daq/GetDaqId", [], None
        )

    def start_collect(self, daq_id):
        """
        Call Daq/StartCollect to start data acquisition for a DAQ.

        OPC documentation:
            Daq/StartCollect
            Input: DAQ id created by Daq/CreateDaqStart or similar.

        Typical sequence:
        - Call create_daq_start.
        - Optionally confirm or query the DAQ id.
        - Call start_collect with that DAQ id.
        - Monitor DAQ and raw data using other methods.

        Parameters
        ----------
        daq_id : int like
            DAQ id to start collecting for.

        Returns
        -------
        dict
            Dict with OPC status and raw payload.

        Raises
        ------
        Exception
            If daq_id is not int like.
            If OPC status is not Good.
        """
        try:
            did = int(daq_id)
        except Exception, ex:
            raise Exception(
                "daqId must be an integer; got %r (type=%s). "
                "Original error: %s"
                % (daq_id, type(daq_id), ex)
            )

        return self._call_with_parser(
            "Daq", "Daq/StartCollect", [did], None
        )

    def stop_method(self):
        """
        Call Daq/StopMethod to stop a running method.

        OPC documentation:
            Daq/StopMethod
            Stops the currently running method and associated DAQ.

        Typical usage:
        - Called from SFCs or graphics when operator presses Stop.
        - OPC server stops collection and finalizes DAQ.

        Returns
        -------
        dict
            Dict with OPC status and raw payload.

        Raises
        ------
        Exception
            If OPC status is not Good.
        """
        return self._call_with_parser(
            "Daq", "Daq/StopMethod", [], None
        )

    def get_daq_start_info(self, start_date, end_date):
        """
        Call Daq/GetDaqStartInfo to list DAQ runs in a date range.

        OPC documentation:
            Daq/GetDaqStartInfo
            Accepts start and end date values (MM/DD/YYYY format) and returns
            runs performed within the specified range.

        This method normalizes the date arguments into strings using
        _to_vpx_date_string. It does not have a dedicated parser for the
        payload yet, so the "parsed" field is the same as the raw payload.

        Parameters
        ----------
        start_date : java.util.Date or str
            Start of date range.
        end_date : java.util.Date or str
            End of date range.

        Returns
        -------
        dict
            Dict with OPC status and raw payload.

        Raises
        ------
        Exception
            If OPC status is not Good.
        """
        start_str = self._to_vpx_date_string(start_date)
        end_str = self._to_vpx_date_string(end_date)

        return self._call_with_parser(
            "Daq",
            "Daq/GetDaqStartInfo",
            [start_str, end_str],
            None
        )
        
    def get_cycle_data(self, daq_id):
        """
        Call Daq/GetCycleData to retrieve cycle data for a DAQ run.

        OPC documentation:
            Daq/GetCycleData
            Will provide cycle data information on all cycles collected
            within DAQ ID input.

        This helper only normalizes the DAQ ID to an integer-like value and
        does not apply additional parsing yet, so the "parsed" field is the
        same as the raw payload.

        Parameters
        ----------
        daq_id : int like
            DAQ ID for which to retrieve cycle data.

        Returns
        -------
        dict
            Dict with OPC status tuple, diagnostic, raw payload and parsed
            payload (same as raw for now).

        Raises
        ------
        Exception
            If daq_id cannot be converted to int.
            If OPC status is not Good.
        """
        try:
            daq_id_int = int(daq_id)
        except Exception, ex:
            raise Exception(
                "daq_id must be an integer; got %r (type=%s). Original error: %s"
                % (daq_id, type(daq_id), ex)
            )

        return self._call_with_parser(
            "Daq",
            "Daq/GetCycleData",
            [daq_id_int],
            None
        )