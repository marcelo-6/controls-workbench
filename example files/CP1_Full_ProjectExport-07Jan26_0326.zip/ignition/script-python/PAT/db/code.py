'''
***************************************************************************************************
Procedure:          PAT.db
Create Date:       	23Sep24
Author:             Marcelo Amorim
Description:        This module provides functions to interact with a database using stored procedures to manage
                    equipment run data and sample data for a process monitoring system.

Used By:            PAT SFC

This module contains functions to handle database interactions for managing process data:
1. Insert a new equipment run (`insert_run`).
2. Insert sample data for a specific run (`insert_sample_data`).
3. Check if a run name is unique for a specific equipment (`check_run_name_unique`).

These functions wrap the execution of corresponding stored procedures in the database with error handling using try-except blocks. Each function returns a boolean indicating success or failure:
- `True` if rows were successfully added or modified.
- `False` if the operation failed.

Functions:
----------
insert_run(run_name, equip_name, unit_name, batch_id):
    Inserts a new equipment run into the database using the 'InsertRun' stored procedure.
    - Parameters: 
        - `run_name` (str): Name of the run.
        - `equip_name` (str): Name of the equipment.
        - `unit_name` (str): Name of the unit.
        - `batch_id` (str): Batch ID for the run.
    - Returns:
        - `True` if the run was inserted successfully, `False` otherwise.
        - The ID of the created run (`run_id`).

insert_sample_data(run_id, sample_id, sample_number, json_data_array, data_type):
    Inserts sample data into the database using the 'InsertSampleData' stored procedure.
    - Parameters:
        - `run_id` (int): ID of the run.
        - `sample_id` (str): Unique identifier for the sample.
        - `sample_number` (int): The sample number in the sequence.
        - `json_data_array` (str): JSON-formatted data containing the sample's data points (key-value pairs).
        - `data_type` (str): Type of data (e.g., 'raw', 'processed').
    - Returns:
        - `True` if sample data was inserted successfully, `False` otherwise.

check_run_name_unique(run_name, equipment_name):
    Checks if the provided run name already exists for the given equipment in the database.
    - Parameters:
        - `run_name` (str): The name of the run.
        - `equipment_name` (str): The equipment name.
    - Returns:
        - `True` if the run name already exists for the equipment, `False` otherwise.

Usage:
------
These functions require interaction with a database through a stored procedure call. A database cursor object 
is used to execute the stored procedures.

Error handling is included for all functions to log issues that arise during execution. The logs can be checked for 
detailed information about the data being processed.

TODO:
-----
- Add logging of data being inserted to the audit trail. MA 23Sep24

***************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			23Sep24			MA			Created
1.1			21Nov24			MA			Added extra columns to the insert run table
1.2			02Dec24			MA			Added check for unique run name
1.3			09Apr25			MA			Added functions to allow use of store & forward functionaliy of SCADA
***************************************************************************************************
'''

import java.lang.Exception
import traceback
global logging, runningLog, stageProgress
logging = system.util.getLogger("PAT." + __name__)
runningLog = ""
stageProgress = 0
		
def get_transposed_sample_data(run_name):
    '''
    Purpose:
    --------
    Retrieves transposed sample data for a specific run from the database using the 'GetTransposedSampleDataForRun' stored procedure.

    Args:
    -----------
    run_name (str): The name of the run to retrieve transposed sample data for.
    
    Returns:
    --------
    list: A list of dictionaries containing the transposed sample data if the query was successful, or an empty list otherwise.

    Example Usage:
    ---------------
    run_name = "ma_mir_test_024"
    data = PAT.db.get_transposed_sample_data(run_name)
    if data:
        print("Retrieved data:", data)
    else:
        print("No data retrieved for the specified run.")
    '''
    try:
		# Create a dictionary of parameters to pass to the query
		parameters = {"run_name": run_name}
		result = system.db.runNamedQuery("PAT/GetTransposedSampleDataForRun", parameters)
		
		# Return the data
		return result

    except Exception as e:
        return str(e)
    except java.lang.Exception as e:
        return str(e)


'''

***************************************************************************************************
NEW SCHEMA
***************************************************************************************************
'''
def _get_query_path(location={}):
	"""Return the path for other other functions to format path to based root folder or named queries"""
	base_path = 'PAT/{location}'
	args = {'location': location}
	return base_path.format(**args)
	
def initialize_tables():
	"""Create machine learning tables if they do not exist"""
	tables = ['[run]', '[sample]', '[sample_data]']
	query_path = _get_query_path(location='Create/{}')
	try:
		for tbl in tables:
			system.db.runNamedQuery(query_path.format(tbl), None)
		return True
	except Exception as e:
		PAT.utils.log_exception()
		return False
	except java.lang.Exception as e:
		PAT.utils.log_exception()
		return False
	
def run_exists(run_name, equipment_name):
	"""Check [run] if run name has been taken
	
	Args:
		name: run name to check db for
	Returns:
		int: 1 if exists else 0, -1 on exception, but not raised only logged
	"""

	try:
		path = _get_query_path(location='Run/Exists')
		params = {
            "run_name": run_name,
            "equipment_name": equipment_name
        }
		result = system.db.runNamedQuery(path=path, parameters=params)

		return int(result.getValueAt(0, 'run_count'))
	except Exception as e:
		PAT.utils.log_exception()
		return -1
	except java.lang.Exception as e:
		PAT.utils.log_exception()
		return -1

def run_insert(run_name,
               equipment_name,
               batch_id=None,
               unit_name=None,
               model_class=None,
               model_version=None):
    """
    Insert a new row into the [run] table using a client-generated UUID
    and store-and-forward named query. If DB is offline, the query is queued.

    Steps:
      1) Attempt to see if (run_name, equipment_name) already exists.
         - If True, return -1 (already in DB).
         - If DB is offline (None returned), append a time-based suffix to run_name.
      2) Generate run_uuid (client side).
      3) Insert via runSFNamedQuery -> returns a boolean indicating if 
         the query was successfully queued or sent to the DB.
      4) If the call returns False, return -1.
      5) Otherwise, return the run_uuid if success.

    Args:
        run_name (str): Human-readable run name.
        equipment_name (str): Equipment name used for run.
        batch_id (str, optional)
        unit_name (str, optional)
        model_class (str, optional)
        model_version (str, optional)

    Returns:
        str: run_uuid if inserted/queued successfully, else -1.
    """
    exists_check = run_exists(run_name, equipment_name)
    # 1) Check if run_name + equipment_name already exist
    exists_check = run_exists(run_name, equipment_name)
    if exists_check == True:
    	if logging.isDebugEnabled(): logging.debug("%s aborted: (run_name=%s, equipment=%s) already in DB." 
                    % (__name__,run_name, equipment_name))
        return -1
    elif exists_check == -1:
        # Possibly DB offline => we can't do a definitive check
        # We'll append a time-based suffix to ensure uniqueness
        suffix = system.date.format(system.date.now(), "yyyyMMddHHmmss")
        new_run_name = run_name + "_" + suffix
        if logging.isDebugEnabled(): logging.debug("%s DB check offline, appending suffix => new run_name: %s" 
                    % (__name__,new_run_name))
        run_name = new_run_name
        
    # 2) Generate new uuid
    new_uuid = PAT.utils.generate_uuid()
    if logging.isDebugEnabled(): logging.debug("%s run uuid %s" 
                    % (__name__,new_uuid))
    # 3) Build parameters for the Named Query
    params = {
        "run_uuid": new_uuid,
        "equipment_name": equipment_name,
        "run_name": run_name,
        "batch_id": batch_id,
        "unit_name": unit_name,
        "model_class": model_class,
        "model_version": model_version,
        "client_timestamp": PAT.utils.toUTCstr(system.date.now()) # convert to raw UTC
    }
    try:
        path = _get_query_path(location='Run/Insert')
        # if the query was successfully queued or delivered.
        success = system.db.runSFNamedQuery(path, params)

        if not success:
        	logging.error("%s failed for run_uuid=%s" % (__name__, new_uuid))
        	return -1
        
        return new_uuid

    except Exception as e:
        PAT.utils.log_exception()
        return -1
    except java.lang.Exception as e:
        PAT.utils.log_exception()
        return -1

def run_get_all_data_by_run_equipment_name(run_name, equipment_name):
    """
    Retrieve all data for given run name and equipment name match

    Args:
        run_name (str): run name.
        equipment_name (str): equipment name for given run

    Returns:
        Dataset: A dataset containing all the data
        or None (or -1) on exception.
    """
    try:
        # 1) Build the named query path
        path = _get_query_path(location='Run/GetAllDataByRunEquipmentName')

        # 2) Define parameters for the named query
        params = {
            'run_name': run_name,
            'equipment_name': equipment_name
        }

        # 3) Run the named query
        result = system.db.runNamedQuery(path=path, parameters=params)

        # 4) Return the result dataset
        return result

    except Exception as e:
        PAT.utils.log_exception()
        return None

    except java.lang.Exception as e:
        PAT.utils.log_exception()
        return None
        
def runs_by_time_range(start_time, end_time):
    """
    Retrieve all runs within a specified time range, including sample_count.

    Args:
        start_time (datetime or str): Start of the time window (inclusive or exclusive as defined in the query).
        end_time (datetime or str):   End of the time window.

    Returns:
        Dataset: A dataset containing one row per run, with columns:
            [run_id, equipment_name, run_name, timestamp, batch_id, 
             unit_name, model_class, model_version, sample_count]
        or None (or -1) on exception.
    """
    try:
        # 1) Build the named query path
        path = _get_query_path(location='Run/GetByTimeRange')

        # 2) Define parameters for the named query
        params = {
            'start_time': start_time,
            'end_time': end_time
        }

        # 3) Run the named query
        result = system.db.runNamedQuery(path=path, parameters=params)

        # 4) Return the result dataset
        return result

    except Exception as e:
        PAT.utils.log_exception()
        return None

    except java.lang.Exception as e:
        PAT.utils.log_exception()
        return None

def sample_insert(run_id, sample_number, timestamp=None):
    """
    Inserts a new row into the [sample] table for a given run_uuid, using
    store-and-forward. A new sample_uuid is generated client-side.

    Args:
        run_id (str): The run_uuid to which this sample belongs.
        sample_number (int): Sequential sample number within the run.
        timestamp (datetime, optional): The time the sample was taken 
        								(if none provided, system.date.now() will be used

    Returns:
        str:  The newly generated sample_uuid on success,
        -1 :  If any failure occurs (logged).
    """
                    
    # 1) Generate a new sample_uuid
    new_uuid = PAT.utils.generate_uuid()
    if logging.isDebugEnabled(): logging.debug("%s sample uuid %s" 
                    % (__name__,new_uuid))
    timestamp = PAT.utils.toUTCstr(system.date.now()) if timestamp is None else PAT.utils.toUTCstr(timestamp)
    # 2) Build parameters for the Named Query
    path = _get_query_path(location='Sample/Insert')
    params = {
        "sample_uuid":    new_uuid,
        "run_uuid":       run_id,
        "sample_number":  sample_number,
        "client_timestamp": timestamp
    }
    
    try:
        # 3) Run the named query
        success = system.db.runSFNamedQuery(path, params)

        # 4) Extract the newly inserted sample_id
        if not success:
        	logging.error("%s failed for sample_uuid=%s" % (__name__, new_uuid))
        	return -1
        
        return new_uuid

    except Exception as e:
        PAT.utils.log_exception(str(e))
        return -1
    except java.lang.Exception as e:
        PAT.utils.log_exception(str(e))
        return -1

def sample_data_insert(sample_id,
                       data_type,
                       model_name=None,
                       data_json=None,
                       timestamp=None,
                       failure_reason=None):
    """
    Insert a new row into the [sample_data] table by referencing sample_uuid.
    Uses store-and-forward. We do NOT generate a separate UUID for the data.

    Args:
        sample_uuid (str): The sample_uuid to which this data belongs.
        data_type (str): Type of data (e.g. 'raw', 'prediction').
        model_name (str, optional): Model name if applicable.
        data_json (str, optional): JSON contents for the data.
        timestamp (datetime, optional): The time the data was measured or data was acquired by SCADA
        failure_reason (str, optional): If this sample data indicates a failure,
                                        supply the reason/description.
    Returns:
        int: 1 if the insert was successfully queued,
            -1 if an error or store-and-forward queueing failed.
    """
    try:
        # 1) Build the named query path
        path = _get_query_path(location='SampleData/Insert')

        # 2) Define parameters for the named query
        timestamp = PAT.utils.toUTCstr(system.date.now()) if timestamp is None else PAT.utils.toUTCstr(timestamp)
        params = {
            'sample_uuid': sample_id,
            'data_type': data_type,
            'model_name': model_name,
            'data_json': data_json,
            'client_timestamp': timestamp,
            'failure_reason': failure_reason
        }

        # 3) Run the named query
        success = system.db.runSFNamedQuery(path, params)
        
        # Store-and-forward call returns a Boolean (true if queued or delivered)
        if not success:
            logging.error("%s data insert failed for sample_uuid=%s" % (__name__, new_uuid))
            return -1
            
        return 1

    except Exception as e:
        PAT.utils.log_exception()
        return -1
    except java.lang.Exception as e:
        PAT.utils.log_exception()
        return -1

def sample_data_get_by_run_name(run_name, sample_number, data_type):
    """
    Retrieve all rows from [sample_data] for the specified run name, sample number, and data type.

    Args:
        run_name (str): The name of the run (matches run.run_name).
        sample_number (int): The sample number within that run.
        data_type (str): The data type in sample_data (e.g. 'raw', 'transformed', 'prediction').

    Returns:
        Dataset: The query result with columns:
            [sample_data_id, model_name, data_json, created_at].
        None (or -1) if an exception occurs (logged but not raised).
    """
    try:
        # 1) Get Named Query path
        path = _get_query_path(location='SampleData/GetByRunNameNumberType')
        
        # 2) Define parameters
        params = {
            'run_name': run_name,
            'sample_number': sample_number,
            'data_type': data_type
        }

        # 3) Run the Named Query
        result = system.db.runNamedQuery(path=path, parameters=params)

        # 4) Return the dataset
        return result

    except Exception as e:
        PAT.utils.log_exception()
        return None
    except java.lang.Exception as e:
        PAT.utils.log_exception()
        return None
        
def sample_data_get_all_predictions_by_run_name(run_name):
    """
    Retrieve all prediction data (data_type='prediction') for all models
    within a run identified by run_name.

    Args:
        run_name (str): The name of the run (from run.run_name).

    Returns:
        Dataset: Columns: [sample_number, model_name, data_json, created_at].
                 or None on exception.
    """
    try:
        path = _get_query_path(location='SampleData/GetAllPredictionsByRunName')
        params = {
            'run_name': run_name
        }
        ds = system.db.runNamedQuery(path=path, parameters=params)
        return ds

    except Exception as e:
        PAT.utils.log_exception()
        return None
    except java.lang.Exception as e:
        PAT.utils.log_exception()
        return None
        
import json
from collections import OrderedDict, defaultdict
import time

def generate_excel_export(run_name, equipment_name):
	"""
	Transforms database results into structured datasets:
	- A dataset for raw data with pivoted headers.
	- Separate datasets per model containing both transformed and prediction data.
	
	Parameters
	----------
	db_rows : list of tuples
	    List of database rows, each tuple represents a row with the following format:
	    (run_name, equipment_name, model_class, model_version, batch_id, unit_name, 
	     run_start_timestamp, sample_number, sample_start_timestamp, data_type, 
	     model_name, data_json, sample_data_timestamp)
	
	Returns
	-------
	dict of lists
	    {
	        "raw_data": [list of lists],
	        "models": {
	            "modelA": [list of lists],
	            "modelB": [list of lists],
	            ...
	        }
	    }
	"""
	start_time = time.time()
	
	db_rows = run_get_all_data_by_run_equipment_name(run_name, equipment_name)
	errors = None
	try:
	    # Core columns to keep at the start of every dataset
	    core_columns = [
	        "run_name", "equipment_name", "model_class", "model_version", "batch_id", "unit_name",
	        "run_start_timestamp", "sample_number", "sample_start_timestamp", "data_type",
	        "model_name", "sample_data_timestamp", "failure_reason"
	    ]
	
	    # Storage for raw data and model-specific datasets
	    raw_data = []
	    model_data_sets = OrderedDict()
	
	    # Track headers dynamically for raw and model datasets
	    raw_headers = []
	    model_headers = OrderedDict()
	    merged_model_data = OrderedDict()#defaultdict(lambda: OrderedDict())
	    
	    for row in db_rows:
	        (
	            run_name, equipment_name, model_class, model_version, batch_id, unit_name,
	            run_start_timestamp, sample_number, sample_start_timestamp, data_type,
	            model_name, data_json, sample_data_timestamp, failure_reason, run_start_server_timestamp,
	            sample_start_server_timestamp, sample_data_server_timestamp
	        ) = row
	#        if sample_number == 1:# and data_type == "raw":
	        # Parse JSON data safely
	        #parsed_data = json.loads(data_json) if data_json else {}
	        if data_json:
	        	logging.debug("Attemping to extract run name {} - sample number {} - data type {} - len {}".format(run_name,sample_number,data_type,len(data_json)))
	        else:
	        	logging.debug("Attemping to extract run name {} - sample number {} - data type {} - len {}".format(run_name,sample_number,data_type, 0))
	        parsed_data = PAT.utils.json_to_ordered_dict(data_json) if data_json else {}
	        # parse timestamps from utc to local
	        run_start_timestamp = PAT.utils.fromUTCtoLocal(run_start_timestamp)
	        sample_start_timestamp = PAT.utils.fromUTCtoLocal(sample_start_timestamp)
	        sample_data_timestamp = PAT.utils.fromUTCtoLocal(sample_data_timestamp)
	#        print(json.dumps(parsed_data, indent=4)[:200]) # print in order and only first few items
	        # Core row data to prepend
	        core_data = [
	            run_name, equipment_name, model_class, model_version, batch_id, unit_name,
	            run_start_timestamp, sample_number, sample_start_timestamp, data_type,
	            model_name, sample_data_timestamp, failure_reason
	        ]
	
	        # Process raw data type
	        if data_type == "raw":
	            row_data = core_data[:]
	            for x_value in parsed_data.keys():
	                row_data.append(parsed_data[x_value])
	                if sample_number == 1: # first pass  for transposed header data
	                	raw_headers.append(x_value) 
	            raw_data.append(row_data)
	        # Process transformed data and predictions (grouped by model_name)
	        elif data_type in ("transformed", "prediction"):
	            key = (sample_number, model_name)
	            
	            # Initialize storage if not exists
	            if model_name not in model_headers:
	                model_headers[model_name] = []
	                model_data_sets[model_name] = []
	
	            if key not in merged_model_data:
	            	merged_model_data[key] = OrderedDict()
	                merged_model_data[key]["core_data"] = core_data[:]
	                merged_model_data[key]["transformed"] = OrderedDict()
	                merged_model_data[key]["prediction"] = OrderedDict()
	            
	            if data_type == "transformed":
	                for x_value in parsed_data.keys():
	                    merged_model_data[key]["transformed"][x_value] = parsed_data[x_value]
	                    if x_value not in model_headers[model_name]:
	                        model_headers[model_name].append(x_value)
	            
	            elif data_type == "prediction":
	                for param_name in parsed_data.keys():
	                    merged_model_data[key]["prediction"][param_name] = parsed_data[param_name]
	                    if param_name not in model_headers[model_name]:
	                        model_headers[model_name].append(param_name)
	
	    # Compile merged rows for model datasets
	    for (sample_number, model_name), merged_values in merged_model_data.items():
	#    	print(sample_number)
	        row_data = merged_values["core_data"][:]
	        
	        # Add transformed data
	        for header in model_headers[model_name]:
	            if header in merged_values["transformed"]:
	                row_data.append(merged_values["transformed"].get(header, ""))
	        
	        # Add prediction data
	        for header in model_headers[model_name]:
	            if header in merged_values["prediction"]:
	                row_data.append(merged_values["prediction"].get(header, ""))
	        
	        model_data_sets[model_name].append(row_data)
	
	    # Compile headers for raw data
	    raw_data_headers = core_columns + raw_headers
	
	    # Compile headers for each model dataset
	    model_data_headers = OrderedDict()
	    for model_name, headers in model_headers.items():
	        model_data_headers[model_name] = core_columns + headers
	
	    # Combine headers with row data
	    final_output = {
	        "raw_data": [raw_data_headers] + raw_data,
	        "models": {
	            model_name: [model_data_headers[model_name]] + model_data_sets[model_name]
	            for model_name in model_data_sets
	        }
	    }
	
	    data = datasets_to_excel(final_output)
	    end_time = time.time()
	    execution_time = end_time - start_time
	
	except Exception as e:
		logging.debug("failed")
		PAT.utils.log_exception()
		
		
		# Exception, now try to atleast return data as in from SQL:
		try:
			converted_dataset = []
			flat_json_data_list = []
			data_column_name = "data_json"
			json_data_column_index = db_rows.getColumnIndex(data_column_name)
			column_names = list(db_rows.getColumnNames())
			column_names.remove(data_column_name)
			
			# Flat each json data into a string
			for row in range(db_rows.getRowCount()):
				
				flat_json_data_list.append(json.dumps(db_rows.getValueAt(row, data_column_name)))
				
			# append flat json data list into final dataset
			converted_dataset = system.dataset.filterColumns(db_rows, column_names)
			data = system.dataset.addColumn(converted_dataset, flat_json_data_list, data_column_name, str)
			execution_time = 0
			errors = str(e)
		except Exception as e:
			PAT.utils.log_exception()
			data = None
			execution_time = 0
			errors = str(e)
	finally:
		return data, execution_time, errors

def datasets_to_excel(data, show_headers=True, nulls_empty=False):
    """
    Converts transformed datasets into an Excel workbook with each dataset as a separate worksheet.

    Parameters
    ----------
    transformed_data : dict
        A dictionary containing:
        - "raw_data": List of lists representing the raw data.
        - "models": Dictionary where each key is a model name and the value is a list of lists representing model data.
    
    show_headers : bool, optional
        If True, includes headers in the Excel sheets. Defaults to True.
    
    nulls_empty : bool, optional
        If True, empty cells will remain empty instead of showing default Excel values. Defaults to False.
    
    Returns
    -------
    byte array
        An Excel workbook as a byte array, suitable for downloading or saving to disk.
    """

    # Prepare datasets for the Excel file
    datasets = []
    sheet_names = []
    model_dataset = []

    # Convert raw data to an Ignition dataset
    if "raw_data" in data:
        raw_data = data["raw_data"]
        if raw_data:
            headers = raw_data[0]
            rows = raw_data[1:]
            raw_dataset = system.dataset.toDataSet(headers, rows)
            datasets.append(raw_dataset)
            sheet_names.append("Raw Data")

    # Convert each model's data to an Ignition dataset
    if "models" in data:
        for model_name, model_data in data["models"].items():
            if model_data:
                headers = model_data[0]
                rows = model_data[1:]
                try:
                	header_length = len(headers)
                	
                	# Loop through each row in the data
                	for row in rows:
                		# Check if the row is shorter than the headers
                		if len(row) < header_length:
                			# Append blanks to the row to match the header length
                			row.extend([None] * (header_length - len(row)))

                	model_dataset = system.dataset.toDataSet(headers, rows)
                except Exception as e:
                	model_dataset = system.dataset.toDataSet([], [])
                
                
                datasets.append(model_dataset)
                sheet_names.append("Model - {} Data".format(model_name))

    # Generate the Excel file as a byte array
#    return False
    excel_bytes = system.dataset.toExcel(
        showHeaders=show_headers,
        dataset=datasets,
        nullsEmpty=nulls_empty,
        sheetNames=sheet_names
    )

    return excel_bytes