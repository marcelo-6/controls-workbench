"""PAT.em.sfc.mir
---------------------------------
SFC wrapper for **MIR** (mid-IR) instrument using the PAT framework.

Design notes:
- Keep this layer thin like DLS/SIM; all arbitration, error posting and state transitions live in BaseSFC.
- Hold uses PAUSE/RESUME semantics per MIR workflow; Stop uses STOP and we poll for completion (no sleeps).
- MIR will still take a sample when issued a pause command. So we acquire that data before going to hold
- MIR will create a blank (all zeros sample) when restarting from a paused state, we will also gather data data.
"""

import json
from collections import OrderedDict

# framework imports
from PAT.em.sfc.base import BaseSFC
from PAT.em.base     import EMState
from PAT.infra       import tagio, log
import PAT.db as _db

# MIR CM
from PAT.cm.mir import MirCM  # expects: start(name=None, params=None), pause(), resume(), stop(), status_poll(), interlocks_met()

class MirSFC(BaseSFC):
    """Orchestrator for MIR."""

    # Bulk-read parameter map → *relative* tag paths under the UDT root.
    # Mirrors DLS/SIM for setup fields; adds optional JSON payload for /api/measurement/start.
    _P_TAGS = OrderedDict([
        ("run_name",      "/Parameters/Setup/1/Val_String"),
        ("batch_id",      "/Parameters/Setup/4/Val_String"),
        ("unit_op",       "/Parameters/Setup/5/Val_String"),
        ("model_name",    "/Parameters/Setup/2/Val_String"),
        ("model_version", "/Parameters/Setup/3/Val_Integer"),
        ("use_model",     "/Parameters/Setup/0/Val_Boolean"),
        # Start Parameters: JSON body for /api/measurement/start (acquisition params).
        ("polarization_mode",             "/Parameters/OP/0/Val_Enum"),
        ("sensor_acquisition_interval",   "/Parameters/OP/1/Val_Integer"),
        ("spectrometer_resolution",       "/Parameters/OP/2/Val_Real"),
        ("spectrometer_measurement_time", "/Parameters/OP/3/Val_Integer"),
        ("data_capture_mode",             "/Parameters/OP/4/Val_Enum"),
        ("blanking_mode",                 "/Parameters/OP/5/Val_Enum"),
        ("num_blanking_cycles",           "/Parameters/OP/6/Val_Integer"),
        ("num_blanking_scans_per_angle",  "/Parameters/OP/7/Val_Integer"),
        ("preprocessing_type",            "/Parameters/OP/8/Val_Boolean"),
        ("preprocessing_type_2",          "/Parameters/OP/9/Val_Boolean"),
        ("analytics_type",                "/Parameters/OP/10/Val_Enum"),
    ])

    _ENUM_POLARIZATION = ["standard", "standard_v2", "evaluation"]        # /start: "standard"|"standard_v2"|"evaluation"
    _ENUM_DATA_CAPTURE = ["raw", "processed"]                              # /start: "raw"|"processed"
    _ENUM_BLANKING     = ["default", "skip", "first_spectrum"]             # /start: "default"|"skip"|"first_spectrum"
    _ENUM_ANALYTICS    = ["no_analytics", "trending"]                      # /start: "no_analytics"|"trending"

    # -----------------------------init------------------------------
    def __init__(self, cm, em):
        if not isinstance(cm, MirCM):
            raise TypeError("cm must be an instance of MirCM")
        super(MirSFC, self).__init__(cm, em)
        self.log = log.get("PAT.EM.SFC.MIR")

        # runtime
        self.sample_no              = 1
        self.run_params             = {}
        self.latest_sample_data     = None
        self.latest_sample_data_json= None
        self._stop_cmd_first_seen   = None   # timestamp for command-disagree timeout
        self._stop_cmd_timeout_ms   = 60000  # soft default (no sleep; checked via repeated polls)
        # HOLD latches
#        self._hold_pause_issued     = False  # ensured we sent PAUSE once
        self._hold_tail_committed   = False  # ensured we stored the “tail” sample once


    # -----------------------init-after-acquire------------------------
    def _initialize_after_acquire(self):
        """Initialization once the CM has been acquired."""
        # Interlocks
        ok, why = self.cm.interlocks_met()
        if not ok:
            self.em.set_state(EMState.ERROR, why)
            # We'll skip explicit stop() later since device is not ready.
            self.skip_stop = True
            self.skip_stop_reason = why
            return False

        # Reset sample number (GUI shows 1 for first sample)
        self.sample_no = 1

        # Bulk read run params
        paths  = [self.cm.tag_root + p for p in self._P_TAGS.values()]
        values = tagio.read_multi(paths)
        self.run_params = dict(zip(self._P_TAGS.keys(), values))

        # Ensure unique run name → append timestamp when needed (same as DLS)
        run_name = self.run_params["run_name"]
        equip    = self.em.udt_instance_name
        if _db.run_exists(run_name, equip):
            import re
            pattern = re.compile(r'^(?P<prefix>.*)___\d{2}_\d{2}_\d{2}$')
            m = pattern.match(run_name)
            run_name = m.group('prefix') if m else run_name
            ts = system.date.format(system.date.now(), "___HH_mm_ss")
            run_name = "{}{}".format(run_name, ts)
            tagio.write_single(self.cm.tag_root + self._P_TAGS["run_name"], run_name)
            self.log.debug("Duplicate run name detected, renamed={}".format(run_name))
            self.run_params["run_name"] = run_name

        # Insert DB run & first sample rows
        self.db_run_insert_id = _db.run_insert(
            run_name       = run_name,
            equipment_name = equip,
            unit_name      = self.run_params["unit_op"],
            batch_id       = self.run_params["batch_id"],
            model_class    = self.run_params["model_name"],
            model_version  = self.run_params["model_version"],
        )
        if self.db_run_insert_id == -1:
            raise RuntimeError("DB run_insert failed")

        self.db_sample_insert_id = _db.sample_insert(
            run_id        = self.db_run_insert_id,
            sample_number = self.sample_no,
            timestamp     = system.date.now(),
        )
        if self.db_sample_insert_id == -1:
            raise RuntimeError("DB sample_insert failed")

        # get wavenumbers before we issue the start command
        self.cm.status_poll()
        
#        tagio.write_single(self.cm.tag_root + self.cm._T_SAMPLE_NO, 1)
        return True

    # ---------------------------sample start------------------------------------
    def _sample_after_initialize(self):
        """Trigger MIR measurement."""
        self.em.set_state(EMState.RUNNING, "Start command issued - awaiting data")

        # Build /api/measurement/start body:
        payload = self._encode_start_params()
        self.log.warn(system.util.jsonEncode(payload))

        # CM will translate into REST POST /api/measurement/start (non-blocking)
        self.cm.start(params=payload)
        return True

    # --------------------------monitor sample----------------------------------
    def _monitor_sample(self):
        """Poll CM; advance on new sample; handle comm loss and stop/hold paths."""
        # If device comm lost → HOLD (same as DLS)
        if not tagio.read_single(self.cm.tag_root + self.cm._T_AVAILABLE):
            self.em.set_state(EMState.HOLDING, "Device comm lost!")
            self.held_reason = "Device comm lost"
            return False

        polled = self.cm.status_poll()

        # Always show progress with instrument's own sample #
        instr_no = polled.get('instr_sample', 0)
        self.em.set_state(EMState.RUNNING, "Sample {} - MIR sample {} in progress".format(self.sample_no, instr_no))

        # New data available → stash & advance
        if polled.get("new_sample"):
            self.latest_sample_data = polled["data_dict"]  # JSON already formatted by CM (e.g., wavenumbers→absorbance)
            self.latest_sample_data_json = polled["data_json"]
            return True

        # If CM has transitioned to stopped/idle, reflect it
        if polled.get("stopped") or polled.get("state") == "available":
            self.em.set_state(EMState.STOPPING, "Instrument stopped")
            return False

        return False

    # ----------------------------next sample prep-------------------------------
    def _next_sample(self):
        """Prepare DB and EM for the *next* sample run."""
        self.sample_no += 1
        self.em.set_state(EMState.RUNNING, "Initializing next sample")

        self.db_sample_insert_id = _db.sample_insert(
            run_id        = self.db_run_insert_id,
            sample_number = self.sample_no,
            timestamp     = system.date.now(),
        )
        if self.db_sample_insert_id == -1:
            raise RuntimeError("DB sample_insert failed (next)")
        return True

    # ------------------------------store sample data----------------------------
    def _store_sample_data(self):
        """Push raw data to DB-insert SFC and optionally to the prediction pipeline."""
        self.em.set_state(EMState.RUNNING, "Storing sample data")

        udt_root = self.cm.tag_root.rsplit('/', 1)[0] + "/"

        # --- Database sub-SFC (same as DLS)
        db_params = {
            "data":                          self.latest_sample_data,
            "step_counter":                  self.sample_no,
            "run_insert_id":                 self.db_run_insert_id,
            "sample_id":                     self.db_sample_insert_id,
            "data_type":                     "raw",
            "pat_equipment_tag_path_prefix": udt_root,
            "pat_equipment_tag_name":        self.em.udt_instance_name,
            "run_name":                      self.run_params["run_name"],
            "model_name":                    "",
            "sample_number":                 self.sample_no,
        }
        db_chart = system.sfc.startChart(
            system.project.getProjectName(),
            "PAT/Common/Database",
            db_params,
        )
        self.em.set_state(EMState.RUNNING, "PAT/Common/Database chartId={}".format(db_chart), False)

        # --- Prediction sub-SFC (match DLS toggle)
        if self.run_params.get("use_model"):
            ml_params = {
                "In_RunName":                 self.run_params["run_name"],
                "In_EquipmentTagPathPrefix":  udt_root,
                "In_EquipmentName":           self.em.udt_instance_name,
                "In_ModelName":               self.run_params["model_name"],
                "In_ModelVersion":            self.run_params["model_version"],
                "In_RunId":                   self.db_run_insert_id,
                "sample_id":                  self.db_sample_insert_id,
                "In_SampleNumber":            self.sample_no,
                "In_Data":                    self.latest_sample_data_json,
            }
            ml_chart = system.sfc.startChart(
                system.project.getProjectName(),
                "PAT/Common/Sub-Model-Process",
                ml_params,
            )
            self.em.set_state(EMState.RUNNING, "PAT/Common/Sub-Model-Process chartId={}".format(ml_chart), False)
        else:
            self.em.set_state(EMState.RUNNING, "Use model run param set to false, skipping model processing", False)

        # --- Operator commands while storing (same pattern as DLS)
        cmds = self.em.poll_commands()
        if cmds.get("hold"):
            self.em.ack_command("hold")
            self.em.set_state(EMState.HOLDING, "Operator hold received", False)
            self.held_reason = "Operator Hold"
            return True
        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.cm.stop()
            self.em.set_state(EMState.STOPPING, "Operator stop received", False)
            return False

        return True

    def _clamp(self, v, lo, hi):
        try:
            v = float(v)
        except:
            return lo
        return max(lo, min(hi, v))

    def _enum_pick(self, items, idx, default_idx=0):
        try:
            i = int(idx)
            if 0 <= i < len(items):
                return items[i]
        except:
            pass
        return items[default_idx]

    def _snap(self, v, step, lo, hi):
        """Clamp to [lo, hi], then round to nearest multiple of `step`."""
        try:
            x = float(v)
        except:
            x = lo
        x = max(lo, min(hi, x))
        snapped = int(round(x / float(step))) * int(step)
        # guard for edge rounding outside bounds
        return max(lo, min(hi, snapped))

    def _encode_start_params(self):
        """
        Build MIR /api/measurement/start payload from self.run_params.
        - Enum indices from UI -> strings required by MIR.
        - Resolution (2–8 cm-1) -> 200–800 via ×100 (int).
        - Clamp numeric ranges per spec (10–600s, 1–100, 10–100).
        """
        rp = self.run_params

        # ----- Enumerations: indices -> strings -----
        pol_mode   = self._enum_pick(self._ENUM_POLARIZATION, rp.get("polarization_mode"))
        data_mode  = self._enum_pick(self._ENUM_DATA_CAPTURE, rp.get("data_capture_mode"))
        blank_mode = self._enum_pick(self._ENUM_BLANKING,     rp.get("blanking_mode"))
        analytics  = self._enum_pick(self._ENUM_ANALYTICS,    rp.get("analytics_type"))

        # ----- Numeric ranges (with step-of-10 for SAI/SMT) -----
        sai = int(self._snap(rp.get("sensor_acquisition_interval"),   step=10, lo=10, hi=600))   # seconds, multiple of 10
        smt = int(self._snap(rp.get("spectrometer_measurement_time"), step=10, lo=10, hi=600))   # seconds, multiple of 10
        # UI stores 2–8 cm-1; API wants 200–800
        res_ui = self._clamp(rp.get("spectrometer_resolution"), 2, 8)
        sres   = int(round(res_ui * 100.0))                                           # 200–800

        n_blank_cycles = int(self._clamp(rp.get("num_blanking_cycles"),          1, 100))
        n_scans_angle  = int(self._snap(rp.get("num_blanking_scans_per_angle"), step=10, lo=10, hi=100))

        # ----- Preprocessing block (exact structure per spec) -----
        preprocessing_steps = []
        if rp.get("preprocessing_type"):
            preprocessing_steps.append({
                "preprocessing_type": "background_subtraction",
                "params": {}
            })
        if rp.get("preprocessing_type_2"):
            preprocessing_steps.append({
                "preprocessing_type": "temperature_correction",
                "params": {}
            })
            
        # ----- Assemble payload -----
        payload = {
            "components": [],
            "preprocessing_steps": preprocessing_steps,
            "analytics_type": analytics,
            "name": rp.get("run_name"),
            "sensor_acquisition_interval": sai,
            "spectrometer_measurement_time": smt,
            "spectrometer_resolution": sres,                  # 200–800 -> 2–8 cm-1 mapping
            "polarization_mode": pol_mode,
            "data_capture_mode": data_mode,
            "blanking_mode": blank_mode,
            "num_blanking_cycles": n_blank_cycles,
            "num_blanking_scans_per_angle": n_scans_angle
        }

        # Drop any Nones/empties to let device defaults kick in
        return dict((k, v) for (k, v) in payload.iteritems() if v is not None and v != "")

    # -------------------------------utility-----------------------------------
    def held_poll(self):
        """Called while HELD → look for restart/stop."""
        cmds = self.em.poll_commands()
        if cmds.get("restart"):
            self.em.ack_command("restart")
            # MIR workflow prefers RESUME of current measurement session.
            try:
                self.cm.resume()
                self.em.set_state(EMState.RUNNING, "Restart command issued (resume current measurement)")
            except Exception as exc:
                # If resume fails, remain held and surface reason
                self.em.set_state(EMState.HOLDING, "Resume failed: {}".format(exc), False)

        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.cm.stop()
            self.em.set_state(EMState.STOPPING, "Operator stop received", False)

    def hold(self):
        """Pause the current measurement when transitioning into HOLD."""
        self.em.set_state(EMState.HOLDING, "Holding - {}".format(getattr(self, "held_reason", "")))
        try:
        	# Issue PAUSE once unless already paused/stopped/stopping
            polled = self.cm.status_poll()
            st = polled.get("state")
            if not bool(polled.get("stopping") or polled.get("stopped") or st in ("paused", "stopping")):
            	self.cm.pause()
        finally:
            polled = self.cm.status_poll()
            # If a “tail” sample popped after pause, commit it using our normal store path
            if polled.get("new_sample"):
                self.latest_sample_data = polled["data_dict"]  # JSON already formatted by CM (e.g., wavenumbers→absorbance)
                self.latest_sample_data_json = polled["data_json"]
                self._next_sample()
                self._store_sample_data()
            # Consider 'paused' OR 'stopped' as a safe held condition as long as we stored the data
            return (polled.get("state") == "paused" or polled.get("stopped")) and (not polled.get("new_sample"))

    def held(self):
        due_to = " - {}".format(self.held_reason) if getattr(self, "held_reason", "") else ""
        self.em.set_state(EMState.HELD, "Sequence held{}".format(due_to))

    def stop(self):
        """Issue STOP and keep polling until instrument acknowledges."""
        if not getattr(self, "skip_stop", False):
            # issue stop once, then rely on future invocations to check completion
            if self._stop_cmd_first_seen is None:
                self.cm.stop()
                self.em.set_state(EMState.STOPPING, "Stopping ...")
                self._stop_cmd_first_seen = system.date.now()

            polled = self.cm.status_poll()
            if polled.get("stopped") or polled.get("state") == "available":
                self.em.set_state(EMState.STOPPED, "Sequence stopped")
                return True

            # Command-disagree/timeout handling (no sleep; based on elapsed wall-clock)
            elapsed_ms = system.date.millisBetween(self._stop_cmd_first_seen, system.date.now())
            if elapsed_ms >= self._stop_cmd_timeout_ms:
                self.em.set_state(EMState.STOPPING, "Stop timeout - proceeding to stopped")
                return True

            return False

        # If we decided to skip stopping (e.g., interlocks not met at init)
        self.em.set_state(EMState.STOPPING, "Stopping - {}".format(getattr(self, "skip_stop_reason", "skip")))
        return True
        