"""PAT.em.sfc.dls
---------------------------------
SFC wrapper for the **DLS** (Dynamic Light Scattering) instrument
using the new PAT framework.  It exposes one concrete class:

* ``DlsSFC`` – concrete implementation of :class:`PAT.em.sfc.base.BaseSFC`
  (no dedicated EM subclass is required – we reuse :class:`PAT.em.base.BaseEM`).

All tag‑path glue lives inside *DlsCM*; *DlsSFC* only provides the
Initialize / Sample / Monitor hooks mirroring the SIM workflow.

"""
import json
from collections import OrderedDict

# framework
from PAT.cm.base    import BaseCM, CMState
from PAT.em.base     import BaseEM, EMState
from PAT.em.sfc.base import BaseSFC
from PAT.cm.dls import DlsCM
from PAT.infra       import tagio, log, retry
import PAT.db as _db

class DlsSFC(BaseSFC):
	"""Orchestrator for DLS."""
	
	# -----------------------------------------------------------------------------
	# Constants
	# -----------------------------------------------------------------------------
	
	#: Bulk‑read parameter map → *relative* tag paths under the UDT root.
	
	_P_TAGS = OrderedDict([
	    ("run_name",      "/Parameters/Setup/1/Val_String"),
	    ("batch_id",      "/Parameters/Setup/4/Val_String"),
	    ("unit_op",       "/Parameters/Setup/5/Val_String"),
	    ("model_name",    "/Parameters/Setup/2/Val_String"),
	    ("model_version", "/Parameters/Setup/3/Val_Integer"),
	    ("use_model", "/Parameters/Setup/0/Val_Boolean"),
	    ("use_project", "/Parameters/OP/0/Val_Boolean"),
	])
	
	# -----------------------------init------------------------------ 
	def __init__(self, cm, em):
	    if not isinstance(cm, DlsCM):
	        raise TypeError("cm must be an instance of DlsCM")
	    super(DlsSFC, self).__init__(cm, em)  # BaseSFC initialization
	    self.log = log.get("PAT.EM.SFC.DLS")
	
	    # -----------------Runtime attributes---------------------------
	    self.sample_no           = 1             # Current sample number (1‑based)
	    self.run_params          = {}            # Dict with bulk‑read parameters
	    self.latest_sample_data  = None          # Sample data json string
	    self.stop_commad_latch   = False
	    self.stop_command_complete = False
	    self.skip_stop           = False         # if device offline during init we will abort and skip the stop logic
	    self.skip_stop_reason    = None
	# -----------------------init‑after‑acquire (DB row, etc.)------------------------
	def _initialize_after_acquire(self):
		"""Initialization logic executed once the CM has been acquired."""
		# Bulk‑read operator / setup parameters
		interlock_not_active, interlock_desc = self.cm.interlocks_met()
		if not interlock_not_active:
			self.skip_stop = True
			self.skip_stop_reason = interlock_desc
			self.em.set_state(EMState.ERROR, interlock_desc)
			return False
		
		self.sample_no = 1
		paths  = [self.cm.tag_root + p for p in self._P_TAGS.values()]
		values = tagio.read_multi(paths)
		self.run_params = dict(zip(self._P_TAGS.keys(), values))
		
		# Ensure unique run name ------------------------------------------------
		run_name = self.run_params["run_name"]
		equip     = self.em.udt_instance_name
		if _db.run_exists(run_name, equip):
			# Ensure uniqueness by appending a timestamp	    
			import re
			# remove appended suffix if the run_name was appended by an SFC before
			pattern = re.compile(r'^(?P<prefix>.*)___\d{2}_\d{2}_\d{2}$')
			m = pattern.match(run_name)
			run_name = m.group('prefix') if m else run_name
			ts       = system.date.format(system.date.now(), "___HH_mm_ss")
			run_name = "{}{}".format(run_name, ts)
			tagio.write_single(self.cm.tag_root + self._P_TAGS["run_name"], run_name)
			self.log.debug("Duplicate run name detected, renamed={}".format(run_name))
			self.run_params["run_name"] = run_name
		
		# Insert [run] & first [sample] row ------------------------------------
		self.db_run_insert_id = _db.run_insert(
		    run_name       = run_name,
		    equipment_name = equip,
		    unit_name      = self.run_params["unit_op"],
		    batch_id       = self.run_params["batch_id"],
		    model_class    = self.run_params["model_name"],
		    model_version  = self.run_params["model_version"],
		)
		
		if self.db_run_insert_id == -1:
		    raise RuntimeError("DB run_insert failed")
		    
		self.db_sample_insert_id = _db.sample_insert(
		    run_id        = self.db_run_insert_id,
		    sample_number = self.sample_no,
		    timestamp     = system.date.now(),
		)
		if self.db_sample_insert_id == -1:
		    raise RuntimeError("DB sample_insert failed")
		    
		tagio.write_single(self.cm.tag_root + self.cm.TAG_INST_SAMPLE, 1)
		return True
	
	# ---------------------------sample start------------------------------------
	def _sample_after_initialize(self):
	    self.em.set_state(EMState.RUNNING, "Start command issued - awaiting data")
	    self.cm.start(self.run_params["use_project"])
	    return True
	
	#	@retry.retry()
	# --------------------------monitor sample----------------------------------
	def _monitor_sample(self):
		"""Pull CM for data, if data is received return true"""
		if not tagio.read_single(self.cm.tag_root + self.cm._T_AVAILABLE):
			self.em.set_state(EMState.HOLDING, "Device comm lost!")
			self.held_reason = "Device comm lost"
			return False
#			raise RuntimeError("Device comm lost!")
		polled = self.cm.status_poll()
		
		# Condition for when the DLS settings are for a limited amount of measurements. We hold
		if (self.sample_no > 1 and 
			polled['state'] == self.cm.STATUS_READY and
			polled['command'] == self.cm.CMD_STOP and 
			(not polled["stopped"] or not polled["stopping"]) and 
			polled['status_msg'] == "Measure and analysis stopped."):
			self.em.set_state(EMState.HOLDING, "Command Disagree")
			self.held_reason = "Command Disagree"
			return False
		
		# Always show numbers in message ----------------------------------
		self.em.set_state(
		    EMState.RUNNING,
		    "Sample {} - DLS completed sample {}".format(self.sample_no,polled['instr_sample']))
		
		# --- new valid sample -------------------------------------------
		if polled["new_sample"]:
		    self.latest_sample_data = polled["data_json"]
		    return True   # exit Monitor step
		    
		if polled["stopped"]:
			self.em.set_state(EMState.STOPPING, "Instrument stopped")
			return False
		
		return False
	    
	# ----------------------------next sample prep (DB insert)---------------------
	def _next_sample(self):
	    """Prepare DB and EM for the *next* sample run."""
	    self.sample_no += 1 #= tagio.read_single(self.cm.tag_root + self.cm._T_SAMPLE_NO)
	    self.em.set_state(EMState.RUNNING, "Initializing next sample")
	    
	    self.db_sample_insert_id = _db.sample_insert(
	        run_id        = self.db_run_insert_id,
	        sample_number = self.sample_no,
	        timestamp     = system.date.now(),
	    )
	    if self.db_sample_insert_id == -1:
	        raise RuntimeError("DB sample_insert failed (next)")
	    return True
	
	# ------------------------------store sample data-------------------------------
	def _store_sample_data(self):
		"""Push raw data to the DB‑insert SFC and to the prediction pipeline."""
#		self.sample_no = tagio.read_single(self.cm.tag_root + self.cm._T_SAMPLE_NO)
		self.em.set_state(EMState.RUNNING, "Storing sample data")
		
		udt_root        = self.cm.tag_root.rsplit('/', 1)[0] + "/"
		
		# -------- DB insert SFC -------------------------------------------------------------
#		self.log.debug("data_json is = {}".format(self.latest_sample_data))
#		if False: # temp force to false for now
		db_params = {
		    "data":                         self.latest_sample_data,
		    "step_counter":                 self.sample_no,
		    "run_insert_id":                self.db_run_insert_id,
		    "sample_id":                    self.db_sample_insert_id,
		    "data_type":                    "raw",
		    "pat_equipment_tag_path_prefix": udt_root,
		    "pat_equipment_tag_name":       self.em.udt_instance_name,
		    "run_name":                     self.run_params["run_name"],
		    "model_name":                   "",
		    "sample_number":                self.sample_no,
		}
		db_chart = system.sfc.startChart(
		    system.project.getProjectName(),
		    "PAT/Common/Database",
		    db_params,
		)
		self.em.set_state(EMState.RUNNING, "PAT/Common/Database chartId={}".format(db_chart), False)
		
		# -------- Prediction SFC ------------------------------------------------------------
		if self.run_params["use_model"] and False: # temp force to false for now
		    ml_params = {
		        "In_RunName":              self.run_params["run_name"],
		        "In_EquipmentTagPathPrefix": udt_root,
		        "In_EquipmentName":        self.em.udt_instance_name,
		        "In_ModelName":            self.run_params["model_name"],
		        "In_ModelVersion":         self.run_params["model_version"],
		        "In_RunId":                self.db_run_insert_id,
		        "sample_id":               self.db_sample_insert_id,
		        "In_SampleNumber":         self.sample_no,
		        "In_Data":                 spectral_data,
		    }
		    ml_chart = system.sfc.startChart(
		        system.project.getProjectName(),
		        "PAT/Common/Sub-Model-Process",
		        ml_params,
		    )
		    self.em.set_state(EMState.RUNNING, "PAT/Common/Sub-Model-Process chartId={}".format(ml_chart), False)
		else:
			self.em.set_state(EMState.RUNNING, "Use model run param set to false, skipping model processing", False)
		
		# ----------------------------Operator commands------------------------ 
		cmds = self.em.poll_commands()
		if cmds.get("hold"):
		    self.em.ack_command("hold")
#		    self.cm.stop()
		    self.em.set_state(EMState.HOLDING, "Operator hold received", False)
		    self.held_reason = "Operator Hold"
		    return True
		if cmds.get("stop"):
		    self.em.ack_command("stop")
		    self.cm.stop()
		    self.em.set_state(EMState.STOPPING, "Operator stop received", False)
		    return False
		
		return True
		
	# -------------------------------utility-----------------------------------
	def held_poll(self):
	    """Called from the *Held* state to look for *restart/stop* operator cmds."""
	    cmds = self.em.poll_commands()
	    if cmds.get("restart"):
	        self.em.ack_command("restart")
	        self.cm._stop_requested = False
	        self.em.set_state(EMState.RUNNING, "Operator restart received", False)
	        tagio.write_single(self.cm.tag_root + self.cm.TAG_INST_SAMPLE, 1)
	        self.cm.start()
	        self.em.set_state(EMState.RUNNING, "Restart command issued")
	    if cmds.get("stop"):
	        self.em.ack_command("stop")
	        self.cm.stop()
	        self.em.set_state(EMState.STOPPING, "Operator stop received", False)
	        
	def hold(self):
#		super(DlsSFC, self).hold(cm, em) # start from the hold logic
		self.em.set_state(EMState.HOLDING, "Holding - %s" % self.held_reason)
		self.cm.stop()
		polled = self.cm.status_poll()
		return polled["stopped"]
		
	def held(self):
		"""Indicate the SFC is now *HELD* and waiting for further commands."""
		due_to = ""
		if self.held_reason:
			due_to =  " - {}".format(self.held_reason)
		self.em.set_state(EMState.HELD, "Sequence held{}".format(due_to))

	def stop(self):
		if not self.skip_stop:
			self.em.set_state(EMState.STOPPING, "Stopping ...")
			self.cm.stop()
			polled = self.cm.status_poll()
			if polled["stopped"]:
				self.em.set_state(EMState.STOPPED,  "Sequence stopped")
			return polled["stopped"]
#		self.em.set_state(EMState.ERROR,  "Sequence stopped")
		
		self.em.set_state(EMState.STOPPING, "Stopping - {}".format(self.skip_stop_reason))
		return True
		