"""
PAT.em.sfc.mals
---------------------------------
SFC Orchestrator for the MALS workflow.

Responsibilities
---------------
- Enforce orchestration rules:
  * Do **not** overwrite SelectedWorkflow (operators choose).
  * Do **not** auto-continue; we only monitor/report.
  * Start → monitor states → store minimal metadata on completion.
  * Hold on Paused; operators clear alarms and we issue UnPause on restart.
  * Abort on unrecoverable Error; reflect Cancelled / Done outcomes.

- EM messages are **operator-facing high-level summaries** derived from CM’s
  status_poll + parameter modes. Example mappings:
    CM: "Running - Ready to collect baselines"  →  EM: "Ready to collect baselines - press Continue"
    CM: "Running - Collecting Baselines (Fixed 2.0 min)" → EM: "Collecting baselines - ending automatically in 2.0 min"
    CM: "Running - Collecting Data (Manual end)" → EM: "Collecting data - press Continue to stop"

- MALS raw signals are historian-only; SFC does not fetch 2D curves.
  We keep a single logical sample_no=1 and store *metadata only* (Outcome/Error).

Key OPC/Workflow references:
- States & client prompts (Start/Continue) and results nodes. :contentReference[oaicite:9]{index=9} :contentReference[oaicite:10]{index=10}
- Parameter modes that drive prompts (Baseline/Trigger). :contentReference[oaicite:11]{index=11}
"""
import json
from collections import OrderedDict

from PAT.em.sfc.base import BaseSFC
from PAT.em.base     import EMState
from PAT.cm.mals     import MalsCM
from PAT.infra       import tagio, log
import PAT.db as _db

class MalsSFC(BaseSFC):
    # Read-only setup fields (no auto-continue flag here by requirement)
    _P_TAGS = OrderedDict([
        ("run_name",      "/Parameters/Setup/1/Val_String"),
        ("batch_id",      "/Parameters/Setup/4/Val_String"),
        ("unit_op",       "/Parameters/Setup/5/Val_String"),
        ("model_name",    "/Parameters/Setup/2/Val_String"),
        ("model_version", "/Parameters/Setup/3/Val_Integer"),
        ("workflow_name", "/LM/Workflow/SelectedWorkflow"),  # operators set this
    ])

    def __init__(self, cm, em):
        if not isinstance(cm, MalsCM):
            raise TypeError("cm must be MalsCM")
        super(MalsSFC, self).__init__(cm, em)
        self.log = log.get("PAT.EM.SFC.MALS")
        self.sample_no          = 1              # fixed (historian-first design)
        self.run_params         = {}
        self.latest_result_meta = None
        self.prompt_being_confirmed = False      # this is due to the SFC trying to execute functions on a 1sec scan while tag value check/change for prompts might not be done within 1sec

    # ---------------- Acquire/Initialize ----------------
    def _initialize_after_acquire(self):
        ok, reason = self.cm.interlocks_met()
        if not ok:
            self.em.set_state(EMState.ERROR, reason)
            return False

        # Bulk-read operator/setup parameters
        paths  = [self.cm.tag_root + p for p in self._P_TAGS.values()]
        values = tagio.read_multi(paths)
        self.run_params = dict(zip(self._P_TAGS.keys(), values))
        self.workflow_name = self.run_params.get("workflow_name").replace(" ", "") or "InlineNanoparticle"

        # (Optional) create a run record once, using sample_no=1 convention
        run_name = self.run_params["run_name"]
        equip    = self.em.udt_instance_name

        if _db.run_exists(run_name, equip):
            ts = system.date.format(system.date.now(), "___HH_mm_ss")
            run_name = "{}{}".format(run_name, ts)
            tagio.write_single(self.cm.tag_root + self._P_TAGS["run_name"], run_name)
            self.run_params["run_name"] = run_name

        self.db_run_insert_id = _db.run_insert(
            run_name       = run_name,
            equipment_name = equip,
            unit_name      = self.run_params["unit_op"],
            batch_id       = self.run_params["batch_id"],
            model_class    = self.run_params["model_name"],
            model_version  = self.run_params["model_version"],
        )
        if self.db_run_insert_id == -1:
            raise RuntimeError("DB run_insert failed")

        # One logical sample record (fixed = 1)
        self.db_sample_insert_id = _db.sample_insert(
            run_id        = self.db_run_insert_id,
            sample_number = self.sample_no,
            timestamp     = system.date.now(),
        )
        if self.db_sample_insert_id == -1:
            raise RuntimeError("DB sample_insert failed")

        # High-level EM message
        self.em.set_state(EMState.RUNNING, "Monitoring instrument")
        return True

    # ---------------- Start Sample ----------------------
    def _sample_after_initialize(self):
        self.cm.cmd_start(self.workflow_name)  # never override SelectedWorkflow
        self.em.set_state(EMState.RUNNING, "Monitoring instrument - workflow started")
        return True

    # ---------------- Monitor Sample --------------------

    def _monitor_sample(self):
        if not self.cm.is_online():
            self.held_reason = "Device comm lost"
            self.em.set_state(EMState.HOLDING, self.held_reason)
            return False

        polled = self.cm.status_poll(self.workflow_name)
        modes  = polled.get("modes") or {}

        # Build EM high-level message based on gates + modes (no auto-continue!)
        if polled["error"]:
            self.em.set_state(EMState.ERROR, polled["results"]["error_str"] or "Workflow error")
            raise RuntimeError(polled["results"]["error_str"] or "Workflow error")
            return False
        if polled["cancelled"]:
            self.em.set_state(EMState.STOPPING,"Cancelled by operator")
            return False
        if polled["paused"]:
            self.held_reason = "Paused - clear alarms, then Restart"
            self.em.set_state(EMState.HOLDING, self.held_reason)
            return False

        
        # ----------------------------Operator commands------------------------ 
        cmds = self.em.poll_commands()
        if cmds.get("hold"):
            self.em.ack_command("hold")
            self.cm.cmd_pause()
            self.em.set_state(EMState.HOLDING, "Operator hold received", False)
            self.held_reason = "Operator Hold"
            return False
        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.cm.cmd_cancel()
            self.em.set_state(EMState.STOPPING, "Operator stop received", False)
            return False

        # Ready to collect baselines
        if polled["ready_to_collect_baselines"]:
            if (modes.get("base_start") or "").lower().startswith("manual"):
                self.em.enter_prompt("Ready to collect baselines - press Confirm to proceed")
                if self.em.is_prompt_confirmed():
                    self._send_continue()
                    self.em.set_state(EMState.RUNNING,"Collecting baselines - waiting for instrument")
            else:
                self.em.set_state(EMState.RUNNING,"Preparing to collect baselines ({})".format(modes.get("base_start") or ""))
            return False

        # Collecting baselines
        if polled["collecting_baselines"]:
            end_mode = (modes.get("base_end") or "")
            if end_mode.lower().startswith("manual"):
                self.em.enter_prompt("Collecting baselines - press Confirm to stop")
                if self.em.is_prompt_confirmed():
                    self._send_continue()
                    self.em.set_state(EMState.RUNNING,"Baseline collection complete")
            elif end_mode.lower().startswith("fixed"):
                dur = modes.get("base_dur") or ""
                self.em.set_state(EMState.RUNNING,"Collecting baselines - ending automatically in {} min".format(dur))
            else:
                self.em.set_state(EMState.RUNNING,"Collecting baselines - ending by {}".format(end_mode or "Timing In"))
            return False

        # Baseline stage complete (transition moment)
        if polled["baseline_done"] and not polled["ready_to_start_triggers"]:
            self.em.set_state(EMState.RUNNING,"Baseline collection complete")
            return False

        # Ready to start triggers / data collection
        if polled["ready_to_start_triggers"]:
            if (modes.get("trig_start") or "").lower().startswith("manual"):
                self.em.enter_prompt("Ready to start data collection - press Confirm to proceed")
                if self.em.is_prompt_confirmed():
                    self._send_continue()
                    self.em.set_state(EMState.RUNNING,"Collecting data - waiting for instrument")
            else:
                self.em.set_state(EMState.RUNNING,"Preparing to start data collection ({})".format(modes.get("trig_start") or ""))
            return False

        # Collecting data
        if polled["collecting_data"]:
            end_mode = (modes.get("trig_end") or "")
            if end_mode.lower().startswith("manual"):
                self.em.enter_prompt("Collecting data - press Confirm to stop")
                if self.em.is_prompt_confirmed():
                    self._send_continue()
                    self.em.set_state(EMState.RUNNING,"Data collection complete")
            elif end_mode.lower().startswith("fixed"):
                dur = modes.get("trig_dur") or ""
                self.em.set_state(EMState.RUNNING,"Collecting data - ending automatically in {} min".format(dur))
            else:
                self.em.set_state(EMState.RUNNING,"Collecting data - ending by {}".format(end_mode or "Timing In"))
            return False

        # Data collection finished (triggers done)
        if polled["triggers_done"] and not polled["post_collection"]:
            self.em.set_state(EMState.RUNNING,"Data collection complete")
            return False

        # Post-collection cleaning
        if polled["post_collection"]:
            self.em.set_state(EMState.RUNNING,"Post-collection cleaning")
            return False

        # Done → proceed to store metadata
        if polled["done"]:
            self.latest_result_meta = polled["results"]
            self.em.set_state(EMState.STOPPING, "Workflow complete Stopping ...")
            return True

        # Otherwise, generic running
        self.em.set_state(EMState.RUNNING,"Monitoring instrument")
        return False

    # ---------------- Next sample -----------------------
    def _next_sample(self):
        """MALS is historian-first here; keep a single logical sample (1)."""
        return True  # no increment; remain at sample_no = 1

    # -------------- Store Result Metadata ---------------
    def _store_sample_data(self):
#        return True # disable extra storing for now
        udt_root = self.cm.tag_root.rsplit('/', 1)[0] + "/"
        payload = json.dumps({
            "workflow": self.workflow_name,
            "outcome":  (self.latest_result_meta or {}).get("outcome"),
            "error":    (self.latest_result_meta or {}).get("error_str"),
            "sample":   self.sample_no,  # fixed 1 by convention
        })

        params = {
            "data":                          payload,
            "step_counter":                  self.sample_no,
            "run_insert_id":                 self.db_run_insert_id,
            "sample_id":                     self.db_sample_insert_id,
            "data_type":                     "metadata",
            "pat_equipment_tag_path_prefix": udt_root,
            "pat_equipment_tag_name":        self.em.udt_instance_name,
            "run_name":                      self.run_params["run_name"],
            "model_name":                    self.run_params["model_name"],
            "sample_number":                 self.sample_no,
        }

        chart_id = system.sfc.startChart(
            system.project.getProjectName(),
            "PAT/Common/Database",
            params
        )
        self.em.set_state(EMState.STOPPING,"Storing metadata")
        return False #there is no "next sample" for MALS, we just stop

    # ---------------- Held / Stop Handling ---------------
    def held_poll(self):
        cmds = self.em.poll_commands()
        if cmds.get("restart"):
            self.em.ack_command("restart")
            self.cm.cmd_unpause()
            self.em.set_state(EMState.RESTARTING,"Restarted - monitoring")
        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.cm.cmd_cancel()
            self.em.set_state(EMState.STOPPING, "Stop requested")
        
    def hold(self):
        self.em.set_state(EMState.HOLDING, self.held_reason or "Holding")
        polled = self.cm.status_poll(self.workflow_name)
        if polled["paused"]:
            self.cm.status_poll(self.workflow_name) # to refresh cm message
        return polled["paused"]
        
    def held(self):
        """Indicate the SFC is now *HELD* and waiting for further commands."""
        due_to = ""
        if self.held_reason:
            due_to =  " - {}".format(self.held_reason)
        self.em.set_state(EMState.HELD, "Sequence held{}".format(due_to))
        
    def stop(self):
        self.em.set_state(EMState.STOPPING, "Stopping ...")
        try:
            polled = self.cm.status_poll(self.workflow_name)
            if polled["cancelled"] or polled["done"] or polled['error']:
                self.em.set_state(EMState.STOPPED, "tying to issue reset")
                self.cm.cmd_reset()
            elif polled["not_ready"] or polled["not_selected"] or polled["ready"]:
                self.em.set_state(EMState.STOPPED, "Sequence stopped")
                return True
            else:
                self.cm.cmd_cancel()
        except:
            return False

    def restart(self):
        """Clear *HELD* state and resume normal operation."""
        try:
            """Clear *HELD* state and resume normal operation."""
            self.em.set_state(EMState.RESTARTING, "Restarting from hold ...")
            self.held_reason = ""
            polled = self.cm.status_poll(self.workflow_name)
            if not polled["running"]:
                self.em.set_state(EMState.ERROR, "Unable to restart workflow")
                raise RuntimeError("Unable to restart workflow")
            if not polled["paused"]:
                self.em.set_state(EMState.RUNNING, "Restarting complete",False)
        except Exception as exc:
            self.em.post_error(exc,"Restarting failed")
        
    def _send_continue(self):
        """Tell the MALS workflow to advance via State/Continue."""
        self.cm.cmd_continue(self.workflow_name)