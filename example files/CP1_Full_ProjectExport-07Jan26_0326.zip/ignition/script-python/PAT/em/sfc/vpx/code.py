"""
SFC orchestrator for Flow VPX / ViPER.

This class glues together:
- BaseSFC (generic SFC step orchestration),
- VpxCM  (Flow VPX control module),
- VpxEM  (Flow VPX equipment module),

and provides a simple workflow:

1) Acquire CM/EM and check connectivity/interlocks.
2) Initialize a new PAT run (run metadata + DB run/sample entries).
3) Create a VPX DAQ instance via cm.create_daq_start().
4) Start collection via cm.start_collect().
5) Monitor collection, handling Hold / Restart / Stop commands.
6) Track a SCADA-side cycle count and persist:
       - LM/Results/CycleCount   (int)
       - LM/Results/StartedTime  (datetime)
       - LM/Results/CompletionTime (datetime)
       - LM/Results/Summary      (JSON with per-run stats)

Raw 1D data and “true” instrument cycle counters remain historian-first and
are exposed directly via the LM/Daq and LM/RawData tags. The SFC does not
store curves in the PAT DB.
"""

import json
from collections import OrderedDict

from PAT.em.sfc.base import BaseSFC
from PAT.em.base     import EMState
from PAT.cm.vpx      import VpxCM
from PAT.infra       import tagio, log
import PAT.db        as _db


__all__ = ["VpxSFC"]


class VpxSFC(BaseSFC):
    """
    SFC helper for Flow VPX.

    The chart should typically call, in order:

        vpx = VpxSFC(cm, em)

        # Acquire phase
        vpx.acquire(chart_id)
        vpx.initialize()

        # Start measurement
        vpx.sample()

        # In a loop step:
        vpx.monitor()     # returns True when DAQ is complete

        # After monitor → true:
        vpx.store_sample_data()
        vpx.release(chart_id)

    Hold / restart / stop are exposed via:

        vpx.hold()
        vpx.held()
        vpx.restart()
        vpx.stop()
    """

    # Read-only setup fields, mirroring the MALS pattern
    _P_TAGS = OrderedDict([
        ("run_name",      "/Parameters/Setup/1/Val_String"),
        ("batch_id",      "/Parameters/Setup/4/Val_String"),
        ("unit_op",       "/Parameters/Setup/5/Val_String"),
        ("model_name",    "/Parameters/Setup/2/Val_String"),
        ("model_version", "/Parameters/Setup/3/Val_Integer"),
    ])

    def __init__(self, cm, em):
        if not isinstance(cm, VpxCM):
            raise TypeError("cm must be VpxCM")

        super(VpxSFC, self).__init__(cm, em)
        self.log = log.get("PAT.EM.SFC.VPX")

        # Single logical sample per DAQ, historian-first
        self.sample_no = 1

        # Run / DB bookkeeping
        self.run_params          = {}
        self.db_run_insert_id    = None
        self.db_sample_insert_id = None

        # VPX-specific runtime fields
        self.active_daq_id       = None
        self.baseline_required   = False

        # SCADA-side cycle tracking (the “Results” cycle count)
        self.cycle_count         = 0    # SCADA view (LM/Results/CycleCount)
        self._last_raw_cycle_id  = None  # last LM/RawData/CycleCountId seen

        # High-level run statistics for the summary
        self.hold_count          = 0
        self.stop_count          = 0
        self.daq_mismatch_count  = 0
        self._had_error          = False
        self.held_reason         = ""

        self.is_restarting       = False

    # ------------------------------------------------------------------ #
    # BaseSFC hooks
    # ------------------------------------------------------------------ #

    def _initialize_after_acquire(self):
        """
        After CM is acquired:
        - Check interlocks.
        - Read run parameters.
        - Insert PAT DB run + sample rows.
        - Create a VPX DAQ instance via CM.
        - Stamp LM/Results/StartedTime.
        """
        ok, reason = self.cm.interlocks_met()
        if not ok:
            self.em.set_state(EMState.ERROR, reason)
            return False

        # Bulk-read operator/setup parameters
        paths  = [self.cm.tag_root + p for p in self._P_TAGS.values()]
        values = tagio.read_multi(paths)
        self.run_params = dict(zip(self._P_TAGS.keys(), values))

        # Normalise run name / ensure uniqueness (same pattern as MALS)
        run_name = self.run_params.get("run_name") or self.em.udt_instance_name
        equip    = self.em.udt_instance_name

        if _db.run_exists(run_name, equip):
            ts = system.date.format(system.date.now(), "___HH_mm_ss")
            run_name = "{}{}".format(run_name, ts)
            tagio.write_single(self.cm.tag_root + self._P_TAGS["run_name"], run_name)
            self.run_params["run_name"] = run_name

        # Insert the logical run into PAT DB
        self.db_run_insert_id = _db.run_insert(
            run_name       = run_name,
            equipment_name = equip,
            unit_name      = self.run_params.get("unit_op"),
            batch_id       = self.run_params.get("batch_id"),
            model_class    = self.run_params.get("model_name"),
            model_version  = self.run_params.get("model_version"),
        )
        if self.db_run_insert_id == -1:
            raise RuntimeError("DB run_insert failed for run {}".format(run_name))

        # One logical sample per Flow VPX DAQ
        self.db_sample_insert_id = _db.sample_insert(
            run_id        = self.db_run_insert_id,
            sample_number = self.sample_no,
            timestamp     = system.date.now(),
        )
        if self.db_sample_insert_id == -1:
            raise RuntimeError("DB sample_insert failed for run {}".format(run_name))

        # Stamp LM/Results/StartedTime
        self.start_time = system.date.now()
        tagio.write_single(
            self.cm.tag_root + self.cm.T_RES_STARTED_TIME,
            self.start_time,
        )

        # Fetch VPX config from LM tags and create DAQ
        cfg = self.cm.get_run_config()
        self.baseline_required = bool(cfg.get("baselineRequired"))
        daq_resp = self.cm.create_daq_start(cfg)
        self.active_daq_id = daq_resp.get("daqId")
        self.log.debug(
            "VpxSFC init complete for run '{}' (DAQ={})".format(
                run_name,
                self.active_daq_id,
            )
        )
        self.em.set_state(EMState.STARTING, "Method instance (daq) created for this run", False)
        return True

    def _sample_after_initialize(self):
        """
        Kick off data collection for the active DAQ.

        Returns
        -------
        bool
            *True* if the startCollect request was sent successfully, else *False*.
        """
        self.cm.start_collect(self.active_daq_id)
        self.em.set_state(
            EMState.RUNNING,
            "Intrument data collection started (DAQ {})".format(self.active_daq_id)
        )
        return True

    def _monitor_sample(self):
        """
        Monitor Flow VPX collection, track SCADA cycle count, and surface
        high-level EM state/messages for the SFC.

        Returns
        -------
        bool
            *True* when the DAQ is complete and the chart may advance to the
            “store / finalize” step; *False* while still monitoring.
        """
        if not self.cm.is_online():
            self.held_reason = "Device communication lost"
            self.em.set_state(EMState.HOLDING, self.held_reason)
            return False

        polled = self.cm.status_poll()

        # Update SCADA-side cycle count based on RawData/CycleCountId
        self._update_cycle_count_from_polled(polled)

        # Handle CM-level error / DAQ id mismatch
        if polled.get("daq_id_mismatch"):
            self.daq_mismatch_count += 1

        if polled.get("error"):
            msg = polled.get("status_msg") or "Flow VPX error"
            self._had_error = True
            self.em.set_state(EMState.ERROR, msg)
            raise RuntimeError(msg)

        # Operator commands (Hold / Stop)
        cmds = self.em.poll_commands()
        if cmds.get("hold"):
            self.em.ack_command("hold")
            self.hold_count += 1
            self.held_reason = "Operator hold"
            # VPX only supports start/stop; use stopMethod as a "hold" primitive.
            self.cm.cancel_active()
            self.em.set_state(EMState.HOLDING, "Operator hold received", False)
            return False

        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.stop_count += 1
            self.cm.cancel_active()
            self.em.set_state(
                EMState.STOPPING,
                "Operator stop requested",
                False,
            )
            return False

        # Normal state progression
        collecting = bool(polled.get("collecting"))
        complete   = bool(polled.get("complete"))

        if collecting:
            # Still collecting → keep running, update EM message
            self.em.set_state(EMState.RUNNING,"Collecting data - sample {}".format(polled.get("cycle_count")))
            return False

        if complete:
            self.em.set_state(EMState.STOPPING, "Data collection complete stopping ...")
            return True

        # Idle / waiting but not explicitly complete
        self.em.set_state(EMState.RUNNING,"Monitoring instrument")
        return False

    def _next_sample(self):
        """
        Flow VPX is historian-first in this design.

        We keep a single logical sample (1) per run, so this always returns
        True and does **not** increment sample_no.
        """
        return True

    def _store_sample_data(self):
        """
        Persist a run-level summary into LM/Results/Summary and keep
        LM/Results/CycleCount in sync with the SCADA-side value.

        The summary is JSON-encoded and meant for quick operator / historian
        visibility, not raw curve storage.
        """
        # Make sure CycleCount tag reflects our final SCADA cycle count.
        tagio.write_single(
            self.cm.tag_root + self.cm.T_RES_CYCLE_COUNT,
            self.cycle_count,
        )

        summary = {
            "runName":           self.run_params.get("run_name"),
            "equipment":         self.em.udt_instance_name,
            "daqId":             self.active_daq_id,
            "cycleCount":        self.cycle_count,
            "holdCount":         self.hold_count,
            "stopCount":         self.stop_count,
            "daqMismatchCount":  self.daq_mismatch_count,
            "baselineRequired":  bool(self.baseline_required),
            "hadError":          bool(self._had_error),
        }
        payload = json.dumps(summary)

        params = {
            "data":                          payload,
            "step_counter":                  self.sample_no,
            "run_insert_id":                 self.db_run_insert_id,
            "sample_id":                     self.db_sample_insert_id,
            "data_type":                     "metadata",
            "pat_equipment_tag_path_prefix": self.cm.tag_root,
            "pat_equipment_tag_name":        self.em.udt_instance_name,
            "run_name":                      self.run_params["run_name"],
            "model_name":                    self.run_params["model_name"],
            "sample_number":                 self.sample_no,
        }

        try:
            tagio.write_single(
                self.cm.tag_root + self.cm.T_RES_SUMMARY,
                payload,
            )
        except Exception as exc:
            self.log.debug(
                "Failed to write LM/Results/Summary: {}".format(str(exc))
            )
        chart_id = system.sfc.startChart(
            system.project.getProjectName(),
            "PAT/Common/Database",
            params
        )

        self.log.debug(
            "VpxSFC stored summary for run '{}' sample {}: {}".format(
                self.run_params.get("run_name"),
                self.sample_no,
                summary,
            )
        )
        # No extra “next sample” – Flow VPX is single sample per DAQ in this design.
        self.em.set_state(EMState.STOPPING,"Storing metadata")
        return False #there is no "next sample" for VPX, we just stop

    # ------------------------------------------------------------------ #
    # Hold / Restart / Stop helpers (for SFC chart steps)
    # ------------------------------------------------------------------ #

    def held_poll(self):
        cmds = self.em.poll_commands()
        if cmds.get("restart"):
            self.em.ack_command("restart")
            self.em.set_state(EMState.RESTARTING,"Restarted - monitoring")
        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.em.set_state(EMState.STOPPING, "Stop requested")

    def hold(self):
        """
        Called by the SFC 'Hold' step.

        We assume monitor() has already seen the operator hold command and
        issued the stopMethod via cm.cancel_active(). we only proceed when 
        instrument stops collecting (SFC step has a timeout)
        """
        polled = self.cm.status_poll()
        if not polled.get("collecting"):
            self.em.set_state(
                EMState.HOLDING,
                self.held_reason or "Holding",
                False,
            )
            return True
        return False

    def held(self):
        """
        Indicate the SFC is now *HELD* and waiting for further commands.
        """
        suffix = ""
        if self.held_reason:
            suffix = " - {}".format(self.held_reason)
        self.em.set_state(EMState.HELD, "Sequence held{}".format(suffix))

    def restart(self):
        """
        Clear HELD state and resume collection.

        Note on restart for VPX: even from the ViPER interface and internal db
        a restart should mean a new daq ID so the data in the VPX db stays separate
        we will keep the sample name the same and everytime we restart we will generate
        a new daq ID. When users browse in the ViPER db they will be able to view reports
        without duplicated data
        """
        try:
            self.em.set_state(EMState.RESTARTING, "Restarting from hold ...")
            self.held_reason = ""

            previous_id = self.active_daq_id
            # Fetch VPX config from LM tags and create DAQ
            if not self.is_restarting:
                cfg = self.cm.get_run_config()
                daq_resp = self.cm.create_daq_start(cfg)
                self.active_daq_id = daq_resp.get("daqId")
                self.cm.start_collect(self.active_daq_id)
                self.is_restarting = True

            polled = self.cm.status_poll()
            if polled.get("collecting"):
                self.is_restarting = False
                self.em.set_state(
                    EMState.RUNNING,
                    "DAQ {} restarted - (previous daq {})".format(self.active_daq_id,previous_id),
                    False,
                )
            elif polled.get("error"):
                self.em.set_state(EMState.ERROR, "Unable to restart")
                raise RuntimeError("Unable to restart")
        except Exception as exc:
            self._had_error = True
            self.em.post_error(exc, "Restart failed")

    def stop(self):
        """
        Called by the SFC 'Stop' step.

        We ensure the instrument is no longer collecting and move EM to
        STOPPED. If the workflow is already effectively idle, we simply
        mark STOPPED and return True.
        """
        self.em.set_state(EMState.STOPPING, "Stopping Flow VPX ...")

        try:
            polled = self.cm.status_poll()
            if not polled.get("collecting"):
                # Already stopped / idle
                self.em.set_state(EMState.STOPPED, "Sequence stopped")
                self.completion_time = system.date.now()
                tagio.write_single(
                    self.cm.tag_root + self.cm.T_RES_COMPLETION_TIME,
                    self.completion_time,
                )
                return True

            # Otherwise attempt a stop
            self.cm.cancel_active()
            return False
        except Exception as exc:
            self._had_error = True
            self.em.post_error(exc, "Stop failed")
            return False

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _update_cycle_count_from_polled(self, polled):
        """
        Update the SCADA-side cycle count using LM/RawData/CycleCountId.

        We treat CycleCountId as the instrument's current cycle index and keep
        LM/Results/CycleCount as the **maximum** value seen during the run.
        """
        raw_cycle = polled.get("raw_cycle_count_id")

        if raw_cycle in (None, "", 0):
            return

        try:
            raw_int = int(raw_cycle)
        except Exception:
            return

        # Monotonic max over the whole DAQ lifetime
        if raw_int > self.cycle_count:
            self.cycle_count = raw_int
            self._last_raw_cycle_id = raw_int

            tagio.write_single(
                self.cm.tag_root + self.cm.T_RES_CYCLE_COUNT,
                self.cycle_count,
            )