# PAT/em/sfc/base.py
"""PAT ‒ *Equipment‑Module* **SFC** orchestrator
=================================================
A **very** thin orchestrator that sits *above* one
:class:`PAT.cm.base.BaseCM` (the physical control module) **and** one
:class:`PAT.em.base.BaseEM` (the equipment‑module façade) and provides
only the boiler‑plate logic common to **all** PAT SFCs:

* **Arbitration & ownership** - Claim or refuse the CM if another chart
  has already taken it.
* **Interlock confirmation** - Optionally block until the CM reports all
  interlocks clear.
* **Lifecycle helpers**             - *acquire · release · stop · hold · …*
* Calls into *device‑specific* hooks so each implementation can focus on
  its own quirks (file I/O, REST calls, etc.).
* EM prompts (EMState.PROMPT / EM/Cmd_Confirm) are handled in instrument
  specific SFCs via BaseEM helpers and are not coupled to BaseSFC.
  
"""

import time

from PAT.infra  import tagio, log
from PAT.cm.base import BaseCM, CMState
from PAT.em.base import BaseEM, EMState

# ─────────────────────────────────────────────────────────────────────────────
# Base SFC
# ─────────────────────────────────────────────────────────────────────────────
class BaseSFC(object):
    """Common orchestrator for any *equipment‑type* (SIM, MIR, RAMAN…)."""

    # ms between two interlock polls while waiting for CM to become safe
    POLL_MS = 500
    # maximum time allowed during *acquire()* (ms)
    ACQUIRE_TIMEOUT_MS = 10000

    # ----------------------------ctor-------------------------------- 
    def __init__(self, cm, em):
        if not isinstance(cm, BaseCM):
            raise TypeError("cm must be a BaseCM instance")
        if not isinstance(em, BaseEM):
            raise TypeError("em must be a BaseEM instance")

        self.cm, self.em = cm, em
        self.log = log.get("PAT.EM.SFC.Base")

        # Orchestrator runtime flags/state
        self.is_acquired = False
        self.db_run_insert_id = None  # type: int | None
        self.db_sample_insert_id = None  # type: int | None
        self.held_reason = None  # explanatory text for *held* state

    # ────────────────────────life‑cycle helpers──────────────── 
    # --------------------------Acquire-----------------------------
    def acquire(self, chart_id):
        """Try to claim control of the CM.

        Parameters
        ----------
        chart_id : str
            The SFC *instanceId* so that the CM knows who owns it.

        Returns
        -------
        bool
            *True* on success, *False* if another chart already owns the CM
            or interlocks failed.
        """
        # 1) Arbitration ------------------------------------------------------
        owned = self.cm.is_owned()
        current_id = self.em.get_chart_id()
        if owned and current_id and current_id != chart_id:
            self.log.error(u"CM already owned by another EM (ChartID %s)" % current_id)
            return False

        # 2) Claim CM ---------------------------------------------------------
        self.em.set_state(EMState.STARTING, "Acquire request sent")
        self.cm.acquire()

        # 3) Mark success -----------------------------------------------------
        self.em.set_state(EMState.STARTING, "%s acquired" % self.em.udt_instance_name)
        self.em.set_chart_id(chart_id)
        self.is_acquired = True
        return True

    # -----------------------------Release---------------------------
    def release(self, chart_id=None):
        """Release the CM and reset both CM/EM to *STOPPED* → *IDLE*.

        The *chart_id* is optional - if omitted we’ll release regardless of
        ownership (useful for *finally* blocks).
        """
        owned = self.cm.is_owned()
        current_id = self.em.get_chart_id()

        if owned and chart_id and current_id != chart_id:
            self.log.warn(u"Skipping release - CM owned by another chart (%s)" % current_id)
            return False

        # Clear CM ownership and states
        self.em.set_state(EMState.STOPPED, "Releasing instrument")
        self.cm.release()
        self.em.set_state(EMState.STOPPED, "Instrument released")
        self.em.tear_down()
        self.is_acquired = False
        self.held_reason = ""
        return True

    #  -----------------------Stop / Hold----------------------------
    def stop(self):
        """Move EM to *STOPPING → STOPPED* - CM remains untouched."""
        self.em.set_state(EMState.STOPPING, "Stopping ...")
        self.em.set_state(EMState.STOPPED,  "Sequence stopped")

    def hold(self, reason="Operator request"):
        """Pause the run and flag the reason (displayed in the GUI)."""
        self.held_reason = unicode(reason)
        self.em.set_state(EMState.HOLDING, "Holding - %s" % self.held_reason)

    def held(self):
        """Indicate the SFC is now *HELD* and waiting for further commands."""
        self.em.set_state(EMState.HELD, "Sequence held - restart or stop")

    def restart(self):
        """Clear *HELD* state and resume normal operation."""
        self.em.set_state(EMState.RUNNING, "Restarting from hold ...")
        self.held_reason = ""

    # -------------------------Initialization-----------------------
    def initialize(self):
        """High‑level wrapper that calls the subclass specific init hook."""
        self.em.set_state(EMState.STARTING, u"Initializing ...")
        try:
            result = self._initialize_after_acquire()
        except Exception as exc:
            self.em.post_error(exc,"Initialization failed")
            self.cm.post_error(exc,"Initialization failed")
            return False
        if result:
        	self.em.set_state(EMState.RUNNING, "Initialization complete")
        return result

    # ---------------------Sample / monitor / store-----------------
    def sample(self):
        try:
            return self._sample_after_initialize()
        except Exception as exc:
            self.em.post_error(exc)
            return False

    def monitor(self):
        try:
            return self._monitor_sample()
        except Exception as exc:
            self.em.post_error(exc)
            return False

    def next_sample(self):
        try:
            return self._next_sample()
        except Exception as exc:
            self.em.post_error(exc)
            return False

    def store_sample_data(self):
        try:
            return self._store_sample_data()
        except Exception as exc:
            self.em.post_error(exc)
            return False

    # ────────────────────abstract hooks (override)──────────────── 
    def _initialize_after_acquire(self):
        """Subclass *must* implement - device/run specific initialization."""
        raise NotImplementedError

    def _sample_after_initialize(self):
        """Subclass *must* implement - trigger one sample/measurement."""
        raise NotImplementedError

    def _monitor_sample(self):
        """Subclass *must* implement - poll sample progress until done/err."""
        raise NotImplementedError

    def _next_sample(self):
        """Subclass *must* implement - prep orchestrator for the next sample."""
        raise NotImplementedError

    def _store_sample_data(self):
        """Subclass *must* implement - persist data (DB, file, …)."""
        raise NotImplementedError
        