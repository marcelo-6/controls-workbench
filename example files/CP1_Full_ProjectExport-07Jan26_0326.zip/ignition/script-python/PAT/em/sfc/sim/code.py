"""PAT › EM › SFC – Simulator orchestration
================================================

A *very* thin orchestration layer for the **SIM** instrument that plugs
into the generic :class:`PAT.em.sfc.base.BaseSFC` framework.
The class only provides the instrument‑specific hooks that the base SFC
expects – *all* state management, arbitration and error handling live in
``BaseSFC``.

Public API (called by the SFC engine)
-------------------------------------
``acquire  → BaseSFC``  | already implemented in the parent class
``initialize``          | delegates to :pymeth:`_initialize_after_acquire`
``sample``              | delegates to :pymeth:`_sample_after_initialize`
``monitor``             | delegates to :pymeth:`_monitor_sample`
``next_sample``         | delegates to :pymeth:`_next_sample`
``store_sample_data``   | delegates to :pymeth:`_store_sample_data`

Only the five *private* hooks below are implemented here.
"""


import json
from collections import OrderedDict

# Project imports -------------------------------------------------------------
from PAT.infra import log, tagio, retry
from PAT.cm.sim import SimCM
from PAT.em.base import BaseEM, EMState
from PAT.em.sfc.base import BaseSFC
import PAT.db as _db

# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------

#: Bulk‑read parameter map → *relative* tag paths under the UDT root.
_P_TAGS = OrderedDict([
    ("batch_id",      "/Parameters/Setup/4/Val_String"),
    ("unit_op",       "/Parameters/Setup/5/Val_String"),
    ("sim_delay",     "/Parameters/OP/0/Val_Integer"),
    ("run_name",      "/Parameters/Setup/1/Val_String"),
    ("model_name",    "/Parameters/Setup/2/Val_String"),
    ("model_version", "/Parameters/Setup/3/Val_Integer"),
    ("csv_path",      "/Parameters/OP/1/Val_String"),
])


# -----------------------------------------------------------------------------
# Class
# -----------------------------------------------------------------------------

class SimSFC(BaseSFC):
    """SFC orchestration layer specific to the *SIM* instrument."""

    # -----------------------------init------------------------------ 
    def __init__(self, cm, em):
        if not isinstance(cm, SimCM):
            raise TypeError("cm must be an instance of SimCM")
        super(SimSFC, self).__init__(cm, em)  # BaseSFC initialisation
        self.log = log.get("PAT.EM.SFC.SIM")

        # -----------------Runtime attributes---------------------------
        self.sample_no = 1               # Current sample number (1‑based)
        self.run_params = {}             # Dict with bulk‑read parameters

    # --------------------------hooks--------------------------------- 
    # These are invoked *indirectly* by BaseSFC public methods.

#    @retry.retry(attempts=3, delay_ms=400)
    def _initialize_after_acquire(self):
        """Initialization logic executed once the CM has been acquired."""

        # 1) Reset counters & write *SampleNo = 1* -------------------------------------------
        # TODO, isnt this responsability of the CM?
        self.sample_no = 1

        # 2) Bulk‑read operator / setup parameters -------------------------------------------
        paths = [self.cm.tag_root + rel for rel in _P_TAGS.values()]
        values = tagio.read_multi(paths)
        self.run_params = dict(zip(_P_TAGS.keys(), values))

        # 3) Insert *run* row ---------------------------------------------------------------
        run_name = self.run_params["run_name"]
        equip     = self.em.udt_instance_name
        if _db.run_exists(run_name, equip):
			# Ensure uniqueness by appending a timestamp	    
			import re
			# remove appended suffix if the run_name was appended by an SFC before
			pattern = re.compile(r'^(?P<prefix>.*)___\d{2}_\d{2}_\d{2}$')
			m = pattern.match(run_name)
			run_name = m.group('prefix') if m else run_name
			ts       = system.date.format(system.date.now(), "___HH_mm_ss")
			run_name = "{}{}".format(run_name, ts)
			tagio.write_single(self.cm.tag_root + _P_TAGS["run_name"], run_name)
			self.log.debug("Duplicate run name detected, renamed={}".format(run_name))
			self.run_params["run_name"] = run_name

        self.db_run_insert_id = _db.run_insert(
            run_name       = run_name,
            equipment_name = equip,
            unit_name      = self.run_params["unit_op"],
            batch_id       = self.run_params["batch_id"],
            model_class    = self.run_params["model_name"],
            model_version  = self.run_params["model_version"],
        )
        if self.db_run_insert_id == -1:
            raise RuntimeError("DB run_insert failed")

        # 4) Insert first *sample* row ------------------------------------------------------
        self.db_sample_insert_id = _db.sample_insert(
            run_id        = self.db_run_insert_id,
            sample_number = self.sample_no,
            timestamp     = system.date.now(),
        )
        if self.db_sample_insert_id == -1:
            raise RuntimeError("DB sample_insert failed")

        # 5) Cache CSV data inside the CM ---------------------------------------------------
        self.cm.csv_path = self.run_params["csv_path"]
        self.cm.load_data()  # raises if missing

        self.log.debug("Run={} Sample={} csv='{}'".format(self.db_run_insert_id,self.db_sample_insert_id, self.cm.csv_path)
        )
        return True

    # ---------------------------sample hooks------------------------------------
    def _sample_after_initialize(self):
        """No hardware call required – simply update EM state."""
        self.em.set_state(EMState.RUNNING, "Starting to read file")
        return True

    # --------------------------monitor hooks----------------------------------
    def _monitor_sample(self):
        """Advance the CM iterator and handle *end‑of‑file* gracefully."""
        self.em.set_state(EMState.RUNNING, "Monitoring sample")
        try:
            self.cm.next_sample()
        except StopIteration:
            self.em.set_state(EMState.STOPPING, "End of sample data reached")
            return False
        return True

    # ----------------------------next hooks--------------------------------------
    def _next_sample(self):
        """Prepare DB and EM for the *next* sample run."""        
        self.sample_no = tagio.read_single(self.cm.tag_root + self.cm._T_SAMPLE_NO)
        self.em.set_state(EMState.RUNNING, "Initializing next sample")

        self.db_sample_insert_id = _db.sample_insert(
            run_id        = self.db_run_insert_id,
            sample_number = self.sample_no,
            timestamp     = system.date.now(),
        )
        if self.db_sample_insert_id == -1:
            raise RuntimeError("DB sample_insert failed (next)")
        return True

    # ------------------------------store hooks-----------------------------------
    def _store_sample_data(self):
        """Push raw data to the DB‑insert SFC and to the prediction pipeline."""
        self.sample_no = tagio.read_single(self.cm.tag_root + self.cm._T_SAMPLE_NO)
        self.em.set_state(EMState.RUNNING, "Storing sample data")

        # --------------------------Raw spectral data---------------------------- 
        sample_data_tag = self.cm.tag_root + self.cm._T_SAMPLE_DATA
        spectral_data   = tagio.read_single(sample_data_tag)
        udt_root        = self.cm.tag_root.rsplit('/', 1)[0] + "/"

        # -------- DB insert SFC -------------------------------------------------------------
        db_params = {
            "data":                         spectral_data,
            "step_counter":                 self.sample_no,
            "run_insert_id":                self.db_run_insert_id,
            "sample_id":                    self.db_sample_insert_id,
            "data_type":                    "raw",
            "pat_equipment_tag_path_prefix": udt_root,
            "pat_equipment_tag_name":       self.em.udt_instance_name,
            "run_name":                     self.run_params["run_name"],
            "model_name":                   "",
            "sample_number":                self.sample_no,
        }
        db_chart = system.sfc.startChart(
            system.project.getProjectName(),
            "PAT/Common/Sub-DB",
            db_params,
        )
        self.em.set_state(EMState.RUNNING, "PAT/Common/Sub-DB chartId={}".format(db_chart), False)

        # -------- Prediction SFC ------------------------------------------------------------
        ml_params = {
            "In_RunName":              self.run_params["run_name"],
            "In_EquipmentTagPathPrefix": udt_root,
            "In_EquipmentName":        self.em.udt_instance_name,
            "In_ModelName":            self.run_params["model_name"],
            "In_ModelVersion":         self.run_params["model_version"],
            "In_RunId":                self.db_run_insert_id,
            "sample_id":               self.db_sample_insert_id,
            "In_SampleNumber":         self.sample_no,
            "In_Data":                 spectral_data,
        }
        ml_chart = system.sfc.startChart(
            system.project.getProjectName(),
            "PAT/Common/Sub-Model-Process",
            ml_params,
        )
        self.em.set_state(EMState.RUNNING, "PAT/Common/Sub-Model-Process chartId={}".format(ml_chart), False)

        # ----------------------------Operator commands------------------------ 
        cmds = self.em.poll_commands()
        if cmds.get("hold"):
            self.em.ack_command("hold")
            self.em.set_state(EMState.HOLDING, "Operator hold received", False)
        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.em.set_state(EMState.STOPPING, "Operator stop received", False)

        return True

    # -------------------------------utility-----------------------------------
    def held_poll(self):
        """Called from the *Held* state to look for *restart/stop* operator cmds."""
        cmds = self.em.poll_commands()
        if cmds.get("restart"):
            self.em.ack_command("restart")
            self.em.set_state(EMState.RUNNING, "Operator restart received", False)
        if cmds.get("stop"):
            self.em.ack_command("stop")
            self.em.set_state(EMState.STOPPING, "Operator stop received", False)
            