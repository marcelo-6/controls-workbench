# PAT.em.base.py
"""PAT ‒ *Equipment‑Module* helpers
===================================
Common code that every **Equipment‑Module (EM)** shares.
It takes care of

* keeping the *state‑code* and *state‑name* tags in sync;
* persisting human‑readable messages (`Val_Msg`);
* serialising exceptions to `Val_LastError`;
* reading / resetting command booleans (`Cmd_*` tags) in one call.
* allows for prompting while EM state is running

All subclasses should mutate *only through* the helpers exposed here - never
write directly to raw tag paths so that a single responsibility is maintained.

"""
import json, traceback

from PAT.infra import tagio, log

# ─────────────────────────────────────────────────────────────────────────────
# EM State abstraction
# ─────────────────────────────────────────────────────────────────────────────
class EMState(object):
    """Tiny value‑object holding an integer *code* and a human *name*.

    Instances are registered in :pyattr:`_MAP` for O(1) reverse lookup.
    """

    _MAP = {}  # code → EMState

    def __init__(self, code, name):
        self.code = int(code)
        self.name = unicode(name)
        EMState._MAP[self.code] = self

    # class‑level symbols (populated after class definition)
    IDLE       = None
    STARTING   = None
    RUNNING    = None
    HOLDING    = None
    HELD       = None
    STOPPING   = None
    STOPPED    = None
    ALARM      = None
    ERROR      = None
    PROMPT     = None
    RESTARTING = None

    # --------------------------class helpers---------------------------- 
    @classmethod
    def by_code(cls, code):
        """Return the *EMState* instance for *code*, defaulting to *ERROR*."""
        return cls._MAP.get(int(code), cls.ERROR)


# create the canonical objects
EMState.IDLE      = EMState(0,   "Idle")  
EMState.STARTING  = EMState(100, "Starting")  
EMState.RUNNING   = EMState(200, "Running")
EMState.PROMPT    = EMState(250, "Running") # prompt while running
EMState.HOLDING   = EMState(400, "Holding")  
EMState.HELD      = EMState(401, "Held")
EMState.RESTARTING= EMState(500, "Restarting") 
EMState.STOPPING  = EMState(600, "Stopping")  
EMState.STOPPED   = EMState(601, "Stopped")  
EMState.ALARM_W   = EMState(910, "Alarm") # Warning alarm that will not prevent sfc from running
EMState.ALARM_H   = EMState(920, "Alarm") # severe alarm that will put sfc into hold
EMState.ERROR     = EMState(999, "Error") # critical error that will abort sfc


# ─────────────────────────────────────────────────────────────────────────────
# Base Equipment‑Module
# ─────────────────────────────────────────────────────────────────────────────
class BaseEM(object):
    """Light‑weight façade around the EM tag‑folder of *one* instrument.

    Concrete sfc classes should keep **one** instance of *BaseEM* and
    interact exclusively through its methods - this guarantees that state
    codes / names and messages stay in sync and that exceptions are persisted
    in a uniform JSON schema.
    """

    # relative tag paths (under *tag_root*)
    _T_MSG       = "/EM/Val_Msg"
    _T_ERR       = "/EM/Val_LastError"
    _T_SC        = "/EM/Val_StateCode"
    _T_SN        = "/EM/Val_StateName"
    _T_CHART_ID  = "/EM/Val_ChartID"

    _CMD_TAGS = {
        "start":   "/EM/Cmd_Start",
        "stop":    "/EM/Cmd_Stop",
        "hold":    "/EM/Cmd_Hold",
        "restart": "/EM/Cmd_Restart",
        "reset":   "/EM/Cmd_Reset",
        "confirm": "/EM/Cmd_Confirm",
    }

    # ---------------------------------------------------------------------
    def __init__(self, tag_root, logger_name=None):
        self.tag_root = tag_root.rstrip("/")
        self.log = log.get(logger_name or "PAT.EM")
        self.udt_instance_name = self.tag_root.rsplit('/', 1)[1] or None
        self.stateNameTag = self._T_SN
        # TODO, no get_state needed?
        
        # Edge detector for EM/Cmd_Confirm to avoid double-handling
        self._confirm_seen = False

    # ------------------------state helpers--------------------------- 
    def set_state(self, state, msg=u"", persist_msg=True):
        """Atomically write state *(code & name)* and optionally a message.

        Parameters
        ----------
        state : :class:`EMState`
            The target state object.
        msg : unicode
            Human‑readable log / operator message.
        persist_msg : bool, default *True*
            *False* skips writing `Val_Msg` (but still logs).
        """
        paths = [self.tag_root + self._T_SC, self.tag_root + self._T_SN]
        values = [state.code, state.name]
        if persist_msg:
            paths.append(self.tag_root + self._T_MSG)
            values.append(msg)
        tagio.write_multi(paths, values)
        self.log.debug("[EM] %s - %s" % (state.name, msg))
        return state

    # ----------------------------error helper------------------------- 
    def post_error(self, exc, context=u""):
        """Persist *exc* details to `Val_LastError` & move EM to *ERROR* state."""
        info = {
            "type": exc.__class__.__name__,
            "msg":  unicode(exc),
            "trace": traceback.format_exc(limit=8),
            "timestamp": system.date.format(system.date.now(),"dd-MMM-YY HH:mm:ss"),
            "context": context,
        }
        tagio.write_single(self.tag_root + self._T_ERR, json.dumps(info))
        self.set_state(EMState.ERROR, "ERROR - see logs or Val_LastError")
        self.log.error("EM ERROR - %s" % info["msg"])
        return info
        
    def clear_error(self):
        tagio.write_single(self.tag_root + self._T_ERR, None)

    # ----------------------------prompt helpers------------------------- 
    def enter_prompt(self, msg):
        """
        Put the EM into *PROMPT* state and arm the Cmd_Confirm tag.

        Parameters
        ----------
        msg : unicode|str
            Operator-facing message shown while waiting for confirmation.
        """
        # StateCode = 250, StateName = "Prompt", Val_Msg = msg
        self.set_state(EMState.PROMPT, msg)
        
        # Reset edge detector and clear the tag
#        self._confirm_seen = False
#        path = self.tag_root + self._CMD_TAGS.get("confirm")
#        tagio.write_single(path, 0)

    def is_prompt_confirmed(self):
        """
        Return True exactly *once* per operator confirmation.

        This method implements a rising-edge detector on EM/Cmd_Confirm:

        * First scan where Cmd_Confirm == True and we have not yet
          consumed this 'high' -> return True, clear the tag, and
          remember that we've seen it.
        * Subsequent scans while Cmd_Confirm is still True -> return False.
        * Once Cmd_Confirm goes back to False -> re-arm for the next press.
        """
        path = self.tag_root + "/EM/Cmd_Confirm"
        raw = system.tag.readBlocking([path])[0].value

        if not raw:
            # Low level -> re-arm edge detector
            self._confirm_seen = False
            return False

        # raw is True
        if self._confirm_seen:
            # We already consumed this high - do NOT fire again
            return False

        # First rising edge
        self._confirm_seen = True
        system.tag.writeBlocking([path], [0])# clear the bit for cleanliness
        return True
    # ------------------------------ command helpers ------------------
    def poll_commands(self):
        """
        One-shot read of every ``Cmd_*`` tag.

        Returns
        -------
        dict
            e.g. ``{'start':0, 'stop':0, 'hold':1, ...}``
        """
        paths = [self.tag_root + p for p in self._CMD_TAGS.values()]
        bits  = tagio.read_multi(paths)
        return dict(zip(self._CMD_TAGS.keys(), bits))
        
    def clear_all_commands(self):
        """
        set all command tags to 0
        """
        paths = [self.tag_root + p for p in self._CMD_TAGS.values()]
        bits  = tagio.write_multi(paths, [0] * len(paths))

    def ack_command(self, key):
        """Reset a command boolean back to *0*."""
        tagio.write_single(self.tag_root + self._CMD_TAGS[key], 0)

    # --------------------------- chart binding helpers -----------------
    def set_chart_id(self, chart_id):
    	"""Persist the Chart UUID currently controlling this EM."""
        tagio.write_single(self.tag_root + self._T_CHART_ID, chart_id)

    def get_chart_id(self):
        return tagio.read_single(self.tag_root + self._T_CHART_ID)
        
    def tear_down(self):
    	"""used to wipe clean all tags of EM and put it back to idle"""    
#    	self.clear_error()
    	self.set_chart_id(None)
    	self.clear_all_commands()
    	self.set_state(EMState.IDLE,"Idle")