def getStatus(serverName):
	statusVal = system.opc.getServerState(serverName)
	if statusVal == "CONNECTED":
		return 1
	else:
		return 0
	