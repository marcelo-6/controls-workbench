/***************************************************************************************************
Procedure:          NQ_GetBatchDeviationDataByUniqueID
Create Date:       	31Mar22
Author:             Marcelo Amorim
Description:        This Named query returns Setpoint vs Actual from a single uniqueID.
Used By:            Report -> 020-Batch Detail
Parameter(s):       @UniqueID - UniqueID from a batch
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			31Mar22			MA			Created
***************************************************************************************************/

DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID

SELECT *
FROM BHStateCommand
WHERE BHStateCommand.uniqueid = @UniqueID