/***************************************************************************************************
Procedure:          NQ_GetBatchListByDateAndUnitName
Create Date:       	29Mar22
Author:             Marcelo Amorim
Description:        Based on spGetBatchListByDate stored procedure from Rockwell. 
					This Named query returns a list of batches within a specified time period.
					It also allows for optional BatchID /Recipe Name/ Unit Name/ Number of rows entry to filter results even further.
Used By:            Report -> 010-Batch Listing
Parameter(s):       @StartTime - start time of batch(s)
                    @EndTime - end time of batch(s)
                    @SearchWord - BatchID filter
                    @numrows - number of max rows to return
                    @unitName - name of a unit /list of units
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			29Mar22			MA			Created
***************************************************************************************************/
DECLARE @StartTime AS DateTime = NULL,
	@EndTime AS DateTime = NULL,
	@SearchWord AS VARCHAR(255) = NULL,
	@UnitName VARCHAR(Max)=NULL,
	@numrows AS INT = 0

SET @StartTime = :startTime
SET @EndTime = :endTime
SET @SearchWord = :searchWord
SET @numrows = :numRows
SET @UnitName = :unitName
SET NOCOUNT ON
SET ROWCOUNT @numrows
SET @SearchWord = REPLACE(ISNULL(@SearchWord, '%'), '*', '%')

IF @SearchWord = '' 
 SET @SearchWord = '%'

IF @StartTime IS NOT NULL and @EndTime IS NULL Begin

 SELECT  BHBatch.uniqueid, BHBatch.batchid, BHBatch.starttimeexecution, BHBatch.endtimeexecution, BHBatch.recipefilename, 
	BHBatch.productcode, BHBatch.productdescription, BHBatch.area, BHBatch.completionstate, 
	BHBatch.Recipe, BHUnit.unitname, 
	CASE WHEN DATEDIFF(minute, BHBatch.starttimeexecution, BHBatch.endtimeexecution) >= 0 THEN BHBatch.endtimeexecution-BHBatch.starttimeexecution ELSE '00:00:00' END AS elapsedtime
 FROM         BHBatch 
INNER JOIN   BHUnit ON BHBatch.uniqueid = BHUnit.uniqueid
 WHERE     (starttimeexecution >= @StartTime)
 AND   unitname IN (SELECT * FROM dbo.fnSPLIT(@Unitname, ','))
 AND   BatchID LIKE (@SearchWord)
 Order By CAST( BHBatch.uniqueid AS BIGINT)

End

IF @StartTime IS  NULL and @EndTime IS NOT NULL Begin

 SELECT  BHBatch.uniqueid, BHBatch.batchid, BHBatch.starttimeexecution, BHBatch.endtimeexecution, BHBatch.recipefilename, 
 	BHBatch.productcode, BHBatch.productdescription, BHBatch.area, BHBatch.completionstate, 
 	BHBatch.Recipe, BHUnit.unitname,
 	CASE WHEN DATEDIFF(minute, BHBatch.starttimeexecution, BHBatch.endtimeexecution) >= 0 THEN BHBatch.endtimeexecution-BHBatch.starttimeexecution ELSE '00:00:00' END AS elapsedtime
 FROM  BHBatch 
INNER JOIN  BHUnit ON BHBatch.uniqueid = BHUnit.uniqueid
 WHERE     (DATEADD(ms, -DATEPART(ms, endtimeexecution), endtimeexecution) <= @EndTime)
 AND   unitname IN (SELECT * FROM dbo.fnSPLIT(@Unitname, ','))
 AND   BatchID LIKE (@SearchWord)
 Order By CAST( BHBatch.uniqueid AS BIGINT) asc

End

IF @StartTime IS NOT NULL and @EndTime IS NOT NULL Begin

 SELECT   BHBatch.uniqueid, BHBatch.batchid, BHBatch.starttimeexecution, BHBatch.endtimeexecution, BHBatch.recipefilename, 
 	BHBatch.productcode, BHBatch.productdescription, BHBatch.area, BHBatch.completionstate, 
 	BHBatch.Recipe, BHUnit.unitname,
 	CASE WHEN DATEDIFF(minute, BHBatch.starttimeexecution, BHBatch.endtimeexecution) >= 0 THEN BHBatch.endtimeexecution-BHBatch.starttimeexecution ELSE '00:00:00' END AS elapsedtime
 FROM         BHBatch 
INNER JOIN  BHUnit ON BHBatch.uniqueid = BHUnit.uniqueid
 WHERE    (starttimeexecution >= @StartTime) AND (DATEADD(ms, -DATEPART(ms, endtimeexecution), endtimeexecution) <= @EndTime)
 AND   unitname IN (SELECT * FROM dbo.fnSPLIT(@Unitname, ','))
 AND   BatchID LIKE (@SearchWord)
 Order By CAST( BHBatch.uniqueid AS BIGINT)

End