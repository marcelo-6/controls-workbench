/***************************************************************************************************
Procedure:          NQ_GetBatchHeaderByUniqueID
Create Date:       	30Mar22
Author:             Marcelo Amorim
Description:        Based on spGetUniqueIDByDate stored procedure from Rockwell. 
					This Named query returns data that is used for the header of batch reports based on a single uniqueID.
Used By:            Report -> 020-Batch Detail
Parameter(s):       @uniqueID - UniqueID from a batch
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			30Mar22			MA			Created
***************************************************************************************************/

DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID


Select 
Distinct TOP (1)
	BHBatch.uniqueid, BHBatch.batchid, BHBatch.productcode, BHBatch.productdescription, BHBatch.starttimebatchlist, BHBatch.endtimebatchlist, 
	BHBatch.starttimeexecution, BHBatch.endtimeexecution, BHBatch.completionstate, BHBatch.area, BHBatch.eventfilename, BHBatch.author, 
	BHBatch.recipefilename, BHBatch.versionnumber, CONVERT(DATETIME, BHBatch.versiondate) as VersionDate, BHBatch.areamodelfilename, BHBatch.areamodeltime, 
	BHBatch.verificationtime, BHBatch.recipetype, BHBatch.classinstance, BHBatch.useridbatchlist, BHBatch.machineidbatchlist, 
	BHBatch.useridexecution, BHBatch.machineidexecution, BHBatch.reportstatus, BHUnit.processcell, formulationname, formulationdescription,
    BHBatch.recipefilename, recipe AS RecipeName, BHUnit.unitname as UnitName,
    CASE WHEN DATEDIFF(minute, BHBatch.starttimeexecution, BHBatch.endtimeexecution) >= 0 THEN BHBatch.endtimeexecution-BHBatch.starttimeexecution ELSE '00:00:00' END AS elapsedtime
FROM BHBatch
INNER JOIN  BHUnit ON BHBatch.uniqueid = BHUnit.uniqueid
WHERE BHBatch.uniqueid = @UniqueID
 AND BHBatch.starttimeexecution IS NOT NULL
ORDER BY BHBatch.starttimeexecution