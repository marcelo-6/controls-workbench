/***************************************************************************************************
Procedure:          NQ_GetAlarm&EventsByUniqueID
Create Date:       	31Mar22
Author:             Marcelo Amorim
Description:        Based on GetUniqueID_BatchIDForAlarms SQL reporting query from Rockwell. 
					This Named query returns alarm and events data from a single uniqueID based on 
					events recorded in the FactoryTalk Alarm and Events database. Given that both databases
					reside on the same database server (e.i. MSSQL server instance)
Used By:            Report -> 020-Batch Detail
Parameter(s):       @UniqueID - UniqueID from a batch
					@alarmDBName - FactoryTalk Alarm and events database name
					@alarmDBSchema - FactoryTalk Alarm and events database schema
Usage:              Call named query and pass appropriate parameters. HARDCODED to be used for EST
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			31Mar22			MA			Created
1.1			20Sep22			MA			Added severity from AlarmDB as a column to return
2.0			04Jun25			MA			Modified query for a system that uses FT Batch + Ignition Alarm DB
***************************************************************************************************/

DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID

--Need to check system time zone against GMT, the below comment was how Rockwell was doing. I dont seem to be able to run this from ignition
/**
declare @deltaGMT int

-- get difference between operating system time zone and GMT
exec master.dbo.xp_regread 'HKEY_LOCAL_MACHINE',
             'SYSTEM\CurrentControlSet\Control\TimeZoneInformation',
             'ActiveTimeBias', @deltaGMT output

-- It returns 
	--240 if in Eastern Time + DST
	--300 if in Eastern Time and no DST
-- However, we are able to query the sys.time_zone_info and get the DST status (true or false) and use that status + a hardocded deltaGMT value (300/240)
-- This would be different for systems that are not in EST zone
**/

--get alarms/events
/**
DECLARE @is_dst_rn TABLE(dst BIT)

Begin
INSERT @is_dst_rn
SELECT is_currently_dst 
FROM sys.time_zone_info
WHERE name = 'Eastern Standard Time'
End


-- Need to access a database in the same server but while using the same DB connection in Ignition
DECLARE @SQL_SCRIPT VARCHAR(MAX)
-- example path CMSAlarmDB.CMS_Alarm_User.ConditionEvent
SET @SQL_SCRIPT = 'SELECT * FROM ' + @AlarmDBName + '.' + @AlarmDBSchema +'.ConditionEvent'
EXECUTE (@SQL_SCRIPT)
**/
declare @deltaGMT int
Begin
-- get difference between operating system time zone and GMT
exec master.dbo.xp_regread 'HKEY_LOCAL_MACHINE',
             'SYSTEM\CurrentControlSet\Control\TimeZoneInformation',
             'ActiveTimeBias', @deltaGMT output
End


SELECT     BHUnit.uniqueid, BHBatch.batchid, BHUnit.unitname, BHUnit.processcell, BHUnit.area, BHUnit.starttime, BHUnit.endtime, 
                      BHUnit.completionstate, cast(CE.eventtime at time zone 'UTC' at time zone 'EASTERN STANDARD TIME' as datetime) EventTimeStamp,
                      CE.source as SourceName, CE.priority as Severity, CE.displaypath as Message, CE.displaypath as ConditionName, BHUnit.UnitName as AlarmClass,
                      CE.eventtype as Active
FROM         BHUnit INNER JOIN
                      BHBatch ON BHUnit.uniqueid = BHBatch.uniqueid
                  --INNER JOIN CMSAlarmDB.CMS_Alarm_User.ConditionEvent CE
                  ---INNER JOIN CMSAlarmDB.dbo.AllEvent CE
                  INNER JOIN ALARM_DB.dbo.alarm_events CE
                              ON CE.eventtime >= DateAdd(mi,@deltaGMT, BHUnit.starttime)
                              AND CE.eventtime <= DateAdd(mi, @deltaGMT, BHUnit.endtime)
                              AND displaypath like ('%'+BHUnit.UnitName+'%')
WHERE     (BHBatch.uniqueid = CAST(@UniqueID AS varchar(155)))
--AND ISNULL(CE.eventtype, 0) = 1