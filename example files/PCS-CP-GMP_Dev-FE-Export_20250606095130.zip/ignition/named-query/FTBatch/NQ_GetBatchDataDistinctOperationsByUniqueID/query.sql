/***************************************************************************************************
Procedure:          NQ_GetBatchDataDistinctPhasesByUniqueID
Create Date:       	30Mar22
Author:             Marcelo Amorim
Description:        Based on BHParam_BHPhase_BHMaterial SQL reporting query from Rockwell. 
					This Named query returns all operations from the bulk of Batch data from a single uniqueID.
					All operations returned are distinct
Used By:            Report -> 020-Batch Detail
Parameter(s):       @UniqueID - UniqueID from a batch
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			01Sep22			MA			Created
***************************************************************************************************/
DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID

SELECT DISTINCT 
	BHPhase.operation
FROM BHParameter INNER JOIN
	BHPhase ON BHParameter.recipe = BHPhase.recipe AND BHParameter.uniqueid = BHPhase.uniqueid INNER JOIN
	BHBatch ON BHParameter.uniqueid = BHBatch.uniqueid INNER JOIN
	BHUnit ON BHPhase.unitname = BHUnit.unitname AND BHPhase.uniqueid = BHUnit.uniqueid
WHERE     (BHBatch.uniqueid = CAST(@UniqueID AS varchar(155)))
/** or BHBatch.uniqueid IN
(SELECT PValue
FROM BHBatchHis
WHERE (BHBatchHis.uniqueid= CAST(@UniqueID AS varchar(155))) AND Descript='Operation Sequence Internal ID')
**/