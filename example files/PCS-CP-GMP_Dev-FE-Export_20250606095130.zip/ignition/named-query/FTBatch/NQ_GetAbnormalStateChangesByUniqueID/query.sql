/***************************************************************************************************
Procedure:          NQ_GetAbnormalStateChangesByUniqueID
Create Date:       	30Mar22
Author:             Marcelo Amorim
Description:        Based on AbnormalStateChanges SQL reporting query from Rockwell. 
					This Named query returns any abnormal batch state changes from a single uniqueID.
					Abnormal state changes are STOPPED, ABORTED, HELD, FAULTED.
Used By:            Report -> 020-Batch Detail
Parameter(s):       @UniqueID - UniqueID from a batch
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			30Mar22			MA			Created
***************************************************************************************************/

DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID

SELECT DISTINCT 
  BHChangeHistory.Lcltime,  BHChangeHistory.UniqueID, BHChangeHistory.BatchID, BHChangeHistory.PValue AS State, BHUnit.processcell, 
  BHUnit.unitname
FROM         BHChangeHistory INNER JOIN
  BHUnit ON BHChangeHistory.UniqueID = BHUnit.uniqueid
WHERE     ((BHChangeHistory.PValue = 'STOPPED') OR
  (BHChangeHistory.PValue = 'ABORTED') OR
  (BHChangeHistory.PValue = 'HELD') OR
  (BHChangeHistory.PValue = 'FAULTED') )AND ((BHChangeHistory.UniqueID = cast(@UniqueID as varchar(155))) or BHChangeHistory.uniqueid IN
(SELECT PValue
FROM BHBatchHis
WHERE (BHBatchHis.uniqueid= CAST(@UniqueID AS varchar(155))) AND Descript='Operation Sequence Internal ID'))