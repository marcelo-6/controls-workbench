/***************************************************************************************************
Procedure:          NQ_GetBatchListByDate
Create Date:        29Mar22
Author:             Marcelo Amorim
Description:        Based on spGetBatchListByDate stored procedure from Rockwell. 
					This Named query returns a list of batches within a specified time period.
					It also allows for optional BatchID /Recipe Name/ Unit Name/ Number of rows entry to filter results even further.
Used By:            Report -> 010-Batch Listing
Parameter(s):       @StartTime - start time of batch(s)
                    @EndTime - end time of batch(s)
                    @SearchWord - BatchID filter
                    @numrows - number of max rows to return
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			29Mar22			MA			Created
2.0			03Jun25			MA			Modified to return only one row per BHBatch.uniqueid
***************************************************************************************************/

DECLARE @StartTime AS DateTime = NULL,
	@EndTime AS DateTime = NULL,
	@SearchWord AS VARCHAR(255) = NULL,
	@numrows AS INT = 0

SET @StartTime = :startTime
SET @EndTime = :endTime
SET @SearchWord = :searchWord
SET @numrows = :numRows
SET NOCOUNT ON
SET ROWCOUNT @numrows
SET @SearchWord = REPLACE(ISNULL(@SearchWord, '%'), '*', '%')

IF @SearchWord = '' 
	SET @SearchWord = '%'

-- Case 1: StartTime only
IF @StartTime IS NOT NULL AND @EndTime IS NULL
BEGIN
	WITH RankedBatches AS (
		SELECT  
			BHBatch.uniqueid,
			BHBatch.batchid,
			BHBatch.starttimeexecution,
			BHBatch.endtimeexecution,
			BHBatch.recipefilename,
			BHBatch.productcode,
			BHBatch.productdescription,
			BHBatch.area,
			BHBatch.completionstate,
			BHBatch.Recipe,
			BHUnit.unitname,
			ROW_NUMBER() OVER (PARTITION BY BHBatch.uniqueid ORDER BY BHUnit.unitname ASC) AS rn,
			CASE 
				WHEN DATEDIFF(minute, BHBatch.starttimeexecution, BHBatch.endtimeexecution) >= 0 
					THEN BHBatch.endtimeexecution - BHBatch.starttimeexecution
					ELSE '00:00:00' 
			END AS elapsedtime
		FROM BHBatch 
		INNER JOIN BHUnit ON BHBatch.uniqueid = BHUnit.uniqueid
		WHERE starttimeexecution >= @StartTime
		  AND BatchID LIKE @SearchWord
	)
	SELECT 
		uniqueid, batchid, starttimeexecution, endtimeexecution, recipefilename,
		productcode, productdescription, area, completionstate,
		Recipe, unitname, elapsedtime
	FROM RankedBatches
	WHERE rn = 1
	ORDER BY CAST(uniqueid AS BIGINT)
END

-- Case 2: EndTime only
IF @StartTime IS NULL AND @EndTime IS NOT NULL
BEGIN
	WITH RankedBatches AS (
		SELECT  
			BHBatch.uniqueid,
			BHBatch.batchid,
			BHBatch.starttimeexecution,
			BHBatch.endtimeexecution,
			BHBatch.recipefilename,
			BHBatch.productcode,
			BHBatch.productdescription,
			BHBatch.area,
			BHBatch.completionstate,
			BHBatch.Recipe,
			BHUnit.unitname,
			ROW_NUMBER() OVER (PARTITION BY BHBatch.uniqueid ORDER BY BHUnit.unitname ASC) AS rn,
			CASE 
				WHEN DATEDIFF(minute, BHBatch.starttimeexecution, BHBatch.endtimeexecution) >= 0 
					THEN BHBatch.endtimeexecution - BHBatch.starttimeexecution
					ELSE '00:00:00' 
			END AS elapsedtime
		FROM BHBatch 
		INNER JOIN BHUnit ON BHBatch.uniqueid = BHUnit.uniqueid
		WHERE DATEADD(ms, -DATEPART(ms, endtimeexecution), endtimeexecution) <= @EndTime
		  AND BatchID LIKE @SearchWord
	)
	SELECT 
		uniqueid, batchid, starttimeexecution, endtimeexecution, recipefilename,
		productcode, productdescription, area, completionstate,
		Recipe, unitname, elapsedtime
	FROM RankedBatches
	WHERE rn = 1
	ORDER BY CAST(uniqueid AS BIGINT)
END

-- Case 3: Both StartTime and EndTime
IF @StartTime IS NOT NULL AND @EndTime IS NOT NULL
BEGIN
	WITH RankedBatches AS (
		SELECT  
			BHBatch.uniqueid,
			BHBatch.batchid,
			BHBatch.starttimeexecution,
			BHBatch.endtimeexecution,
			BHBatch.recipefilename,
			BHBatch.productcode,
			BHBatch.productdescription,
			BHBatch.area,
			BHBatch.completionstate,
			BHBatch.Recipe,
			BHUnit.unitname,
			ROW_NUMBER() OVER (PARTITION BY BHBatch.uniqueid ORDER BY BHUnit.unitname ASC) AS rn,
			CASE 
				WHEN DATEDIFF(minute, BHBatch.starttimeexecution, BHBatch.endtimeexecution) >= 0 
					THEN BHBatch.endtimeexecution - BHBatch.starttimeexecution
					ELSE '00:00:00' 
			END AS elapsedtime
		FROM BHBatch 
		INNER JOIN BHUnit ON BHBatch.uniqueid = BHUnit.uniqueid
		WHERE starttimeexecution >= @StartTime
		  AND DATEADD(ms, -DATEPART(ms, endtimeexecution), endtimeexecution) <= @EndTime
		  AND BatchID LIKE @SearchWord
	)
	SELECT 
		uniqueid, batchid, starttimeexecution, endtimeexecution, recipefilename,
		productcode, productdescription, area, completionstate,
		Recipe, unitname, elapsedtime
	FROM RankedBatches
	WHERE rn = 1
	ORDER BY CAST(uniqueid AS BIGINT)
END
