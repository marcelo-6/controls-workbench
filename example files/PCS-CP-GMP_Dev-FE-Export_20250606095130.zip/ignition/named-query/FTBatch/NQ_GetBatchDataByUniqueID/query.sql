/***************************************************************************************************
Procedure:          NQ_GetBatchDataByUniqueID
Create Date:       	30Mar22
Author:             Marcelo Amorim
Description:        Based on BHParam_BHPhase_BHMaterial SQL reporting query from Rockwell. 
					This Named query returns the bulk of Batch data from a single uniqueID.
					Batch data includes, Unit Procedure, Operations, and Phases start/end time
					as well as the values of recipe/report parameters
Used By:            Report -> 020-Batch Detail
Parameter(s):       @UniqueID - UniqueID from a batch
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			30Mar22			MA			Created
1.1			01Sep22			MA			Removed nested select statement to improve performance. 
										1hr long batch data query used to take 1-5min to run, now it takes < 1sec
***************************************************************************************************/
DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID

SELECT DISTINCT 
	BHParameter.uniqueid, BHPhase.unitname, BHPhase.unitprocedure, BHPhase.operation, BHPhase.equipmentphase, BHPhase.phaseinstance, 
	BHPhase.recipephase, BHPhase.starttime, BHPhase.endtime, BHParameter.eventtime, BHPhase.completionstate, BHParameter.paramname, 
	BHParameter.paramvalue, BHParameter.paramtype, BHParameter.recipe, BHParameter.eu, BHBatch.recipefilename, BHUnit.processcell,
	CASE WHEN DATEDIFF(minute, BHPhase.starttime, BHPhase.endtime) >= 0 THEN BHPhase.endtime-BHPhase.starttime ELSE '00:00:00' END AS duration
FROM BHParameter INNER JOIN
	BHPhase ON BHParameter.recipe = BHPhase.recipe AND BHParameter.uniqueid = BHPhase.uniqueid INNER JOIN
	BHBatch ON BHParameter.uniqueid = BHBatch.uniqueid INNER JOIN
	BHUnit ON BHPhase.unitname = BHUnit.unitname AND BHPhase.uniqueid = BHUnit.uniqueid
WHERE     (BHBatch.uniqueid = CAST(@UniqueID AS varchar(155)))
/** or BHBatch.uniqueid IN
(SELECT PValue
FROM BHBatchHis
WHERE (BHBatchHis.uniqueid= CAST(@UniqueID AS varchar(155))) AND Descript='Operation Sequence Internal ID')
**/
ORDER BY BHPhase.starttime, BHPhase.endtime, BHParameter.paramtype