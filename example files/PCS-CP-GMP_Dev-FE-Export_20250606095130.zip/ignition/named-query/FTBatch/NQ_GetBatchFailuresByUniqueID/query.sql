/***************************************************************************************************
Procedure:          NQ_GetBatchFailuresByUniqueID
Create Date:       	31Mar22
Author:             Marcelo Amorim
Description:        Based on GetBatchFailures SQL reporting query from Rockwell. 
					This Named query returns any batch failures from a single uniqueID.
					Batch failures are recorded in the BHFailure table.
Used By:            Report -> 020-Batch Detail
Parameter(s):       @UniqueID - UniqueID from a batch
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			31Mar22			MA			Created
***************************************************************************************************/

DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID

SELECT DISTINCT BHFailure.uniqueid, BHFailure.area, BHFailure.equipmentphase, BHFailure.unitname, BHFailure.recipe, 
BHFailure.failurevalue, BHFailure.eventtime, BHBatch.batchid, BHBatch.recipefilename, BHOperation.unitprocedure, BHUnit.processcell 
FROM   BHFailure 
	INNER JOIN BHBatch ON BHFailure.uniqueid = BHBatch.uniqueid 
	INNER JOIN BHUnit ON ((BHFailure.uniqueid = BHUnit.uniqueid) AND (BHFailure.unitname = BHUnit.unitname))
	INNER JOIN BHOperation ON BHFailure.uniqueid = BHOperation.uniqueid
WHERE     (BHFailure.uniqueid = @UniqueID)
or BHBatch.uniqueid IN
(SELECT PValue
FROM BHBatchHis
WHERE (BHBatchHis.uniqueid= @UniqueID) AND Descript='Operation Sequence Internal ID')