/***************************************************************************************************
Procedure:          NQ_GetUnitNamesByUniqueID
Create Date:       	05Jun25
Author:             Marcelo Amorim
Description:        Based on BHParam_BHPhase_BHMaterial SQL reporting query from Rockwell. 
					This Named query returns all unit module names from the bulk of Batch 
					data from a single uniqueID
					All units returned are distinct
Used By:            report scripting for dynamic unit referece
Parameter(s):       @UniqueID - UniqueID from a batch
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			05Jun25			MA			Created
***************************************************************************************************/
DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID

SELECT DISTINCT 
	BHPhase.unitname
FROM BHParameter INNER JOIN
	BHPhase ON BHParameter.recipe = BHPhase.recipe AND BHParameter.uniqueid = BHPhase.uniqueid INNER JOIN
	BHBatch ON BHParameter.uniqueid = BHBatch.uniqueid INNER JOIN
	BHUnit ON BHPhase.unitname = BHUnit.unitname AND BHPhase.uniqueid = BHUnit.uniqueid
WHERE     (BHBatch.uniqueid = CAST(@UniqueID AS varchar(155)))