/***************************************************************************************************
Procedure:          NQ_GetBatchDataRecipeNameByUniqueID
Create Date:       	10Oct22
Author:             Marcelo Amorim
Description:        This Named query returns recipe name from a single uniqueID.
Used By:            Phase/Operation Filtering
Parameter(s):       @UniqueID - UniqueID from a batch
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			10Oct22			MA			Created
***************************************************************************************************/
DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID

SELECT
	BHBatch.recipe As RecipeName
FROM BHBatch 
WHERE     (BHBatch.uniqueid = CAST(@UniqueID AS varchar(155)))