/***************************************************************************************************
Procedure:          NQ_GetAbnormalCommandByUniqueID
Create Date:       	31Mar22
Author:             Marcelo Amorim
Description:        This Named query returns batch Command changes from a single uniqueID.
					Batch command changes include ABORT, HOLD, STOP, CLEAR_FAILURES, RESTART.
					it also includes the event time and well as the user who issued the command along
					with the machineid used by the user.
Used By:            Report -> 020-Batch Detail
Parameter(s):       @UniqueID - UniqueID from a batch
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			31Mar22			MA			Created
***************************************************************************************************/

DECLARE @UniqueID AS varchar(155)
	
SET @UniqueID = :uniqueID

SELECT *
FROM BHStateCommand
WHERE BHStateCommand.uniqueid = @UniqueID