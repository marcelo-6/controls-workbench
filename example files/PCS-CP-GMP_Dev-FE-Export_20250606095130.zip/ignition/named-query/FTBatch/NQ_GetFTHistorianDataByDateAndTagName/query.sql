/***************************************************************************************************
Procedure:          NQ_GetFTHistorianDataByDateAndTagName
Create Date:       	21Apr22
Author:             Marcelo Amorim
Description:        This Named query returns OSI PI data from a given time range AND tag name 
					Can include wildcards for tag names such as
					'%PT_02%' 	-> it will return all tags that match time range criteria + it contains PT_02 anywhere in its name
					'%PT_02'	-> it will return all tags that match time range criteria + it ENDS with PT_02
					'PT_02%'	-> it will return all tags that match time range criteria + it STARTS with PT_02
Used By:            Report -> 020-Batch Detail
Parameter(s):       @StartDate - start date
					@EndDate - end date
					@TagName - Tag Name / substring
					@Interval - interval (Integer) to divide the batch duration into even intervals (it will be converted to seconds)
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			21Apr22			MA			Created
***************************************************************************************************/

DECLARE @StartTime AS DateTime = NULL,
	@EndTime AS DateTime = NULL,
	@TagName AS VARCHAR(255) = NULL,
	@Interval AS INT = 1000,
	@TimeStep_InSec AS INT = 0,
	@InitialQuery As VARCHAR(2000) = NULL,
	@LinkedServer As VARCHAR(20) = NULL,
	@FinalQuery As VARCHAR(2000) = NULL,
	@TmpTimeStep As INT = 5

SET @StartTime = :startDate
SET @EndTime = :endDate
SET @TagName = :tagName
SET @Interval = :trendResolutionInterval
SET @TmpTimeStep = FLOOR(DATEDIFF(SECOND, @StartTime,@EndTime)/@Interval)

IF @TmpTimeStep <=1
	SET @TimeStep_InSec = 1
ELSE
	SET @TimeStep_InSec = @TmpTimeStep;
SET @LinkedServer = '[CMS_HISTORIAN]'

--builds initial query with tagname, start and end times. Time step for the interpolated data returned uses X seconds where X is the 
-- duration of the batch (endtime - starttime)/interval in seconds

SET @InitialQuery = '
SELECT d.tag, p.descriptor, d.time, DIGSTRING(CAST(d.value AS Int32)) svalue, d.value value, DIGSTRING(d.status) status 
FROM pipoint.classic p
INNER JOIN piarchive.piinterp2 d ON d.tag = p.tag
WHERE p.tag LIKE ''''' + @TagName +'''''
	AND d.time BETWEEN ''''' + CONVERT(Varchar(20), @StartTime, 113) + ''''' AND ''''' + CONVERT(Varchar(20), @EndTime, 113) + '''''
	AND p.pointsource = ''''FTLD''''
	AND d.timestep = ''''' + CONVERT(Varchar(20), @TimeStep_InSec) + 's''''
ORDER BY d.time, p.tag DESC
OPTION (FORCE ORDER)
'
--OPENQUERY call since using Linked MSSQL server
SET @FinalQuery = 'SELECT * FROM OPENQUERY('+ @LinkedServer + ',''' + @InitialQuery + ''')'

EXEC (@FinalQuery) 