/***************************************************************************************************
Procedure:          NQ_GetBatchUniqueIDMultipleByDate
Create Date:       	29Mar22
Author:             Marcelo Amorim
Description:        Based on spGetUniqueIDByDate stored procedure from Rockwell. 
					This Named query returns MULTIPLE uniqueID Batch that match input parameters.
Used By:            Report -> 020-Batch Detail
Parameter(s):       @StartTime - Time range to search for start of batches,
					@EndTime - Time range to search for end of batches,
					@SearchWord - BatchID Filter (accepts wildcards, e.g. "%BatchID_X%
					@UnitName - Unit name 
					@RecipeName - Recipe Name
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Date(ddMMMyy)    Author              Comments
------------------- ------------------- ------------------------------------------------------------

***************************************************************************************************/

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

DECLARE @StartTime AS DateTime = NULL,
	@EndTime AS DateTime =NULL,
	@SearchWord VARCHAR(8000)=NULL,
	@UnitName VARCHAR(Max)=NULL,
	@RecipeName VARCHAR(Max)=NULL
--	@ProcessCell VARCHAR(Max)=NULL
	
SET @StartTime = :startTime
SET @EndTime =:endTime
SET @SearchWord =:searchWord
SET @UnitName =:unitName
SET @RecipeName =:recipeName

-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON

SET @SearchWord = REPLACE(ISNULL(@SearchWord, '%'), '*', '%')

IF @SearchWord = '' 
 SET @SearchWord = '%'


DECLARE @batches TABLE(UniqueID varchar(155))

IF @StartTime IS NOT NULL and @EndTime IS NULL Begin
INSERT @batches
SELECT top 1000 UniqueID FROM dbo.BHBatch 
 WHERE     (starttimeexecution >= @StartTime)
 ORDER BY starttimeexecution

End

IF @StartTime IS  NULL and @EndTime IS NOT NULL Begin
INSERT @batches
SELECT TOP 1000 UniqueID FROM dbo.BHBatch 
 WHERE     (DATEADD(ms, -DATEPART(ms, endtimeexecution), endtimeexecution) <= @EndTime)
 ORDER BY starttimeexecution

End

IF @StartTime IS NOT NULL and @EndTime IS NOT NULL Begin

INSERT @batches
SELECT TOP 1000 UniqueID FROM dbo.BHBatch 
 WHERE     (starttimeexecution >= @StartTime) AND (DATEADD(ms, -DATEPART(ms, endtimeexecution), endtimeexecution) <= @EndTime)
 ORDER BY starttimeexecution

End

Select 
Distinct BHBatch.uniqueid, BHBatch.batchid, BHBatch.recipefilename, recipe AS RecipeName, BHBatch.starttimeexecution
FROM BHBatch
INNER JOIN @batches As myBatches ON myBatches.UniqueID = BHBatch.UniqueID
INNER JOIN  BHUnit ON BHBatch.uniqueid = BHUnit.uniqueid
WHERE (unitname IN (SELECT * FROM dbo.fnSPLIT(@Unitname, ','))
 AND recipe IN (SELECT * FROM dbo.fnSPLIT(@RecipeName, ',')))
 AND BatchID LIKE (@SearchWord) 
 AND BHBatch.starttimeexecution IS NOT NULL
ORDER BY BHBatch.starttimeexecution