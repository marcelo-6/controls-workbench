/***************************************************************************************************
Procedure:          NQ_GetAuditTrailByDateAndUnitName
Create Date:       	16May22
Author:             Marcelo Amorim
Description:        This Named query returns audit trail entries logged in AssetCentre database
					that match the Location (FT Client where the source of the audit trail entries came from)
					as well as within a specified time period.
Used By:            Report -> 020-Batch Details
Parameter(s):       @StartTime - start time of batch(s)
                    @EndTime - end time of batch(s)
                    @unitName - name of a unit /list of units
Usage:              Call named query and pass appropriate parameters
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			16May22			MA			Created
***************************************************************************************************/
DECLARE @StartTime AS DateTime = NULL,
	@EndTime AS DateTime = NULL,
	@UnitName VARCHAR(Max)=NULL

SET @StartTime = :startTime
SET @EndTime = :endTime
SET @UnitName = :unitName

-- System time is EST but values recorded in AssetCentre DB are in UTC, 
--so we need to convert the input parameters of this query to UTC

declare @deltaGMT int
Begin
-- get difference between operating system time zone and GMT
exec master.dbo.xp_regread 'HKEY_LOCAL_MACHINE',
             'SYSTEM\CurrentControlSet\Control\TimeZoneInformation',
             'ActiveTimeBias', @deltaGMT output
End

SELECT  cast(DateTimeOccurred at time zone 'UTC' at time zone 'EASTERN STANDARD TIME' as datetime) eventtime , Message as manualoperation, UserName as userid
FROM    dbo.log_AuditEventLog
WHERE  (DateTimeOccurred BETWEEN DateAdd(mi,@deltaGMT, @StartTime) AND DateAdd(mi, @deltaGMT, @EndTime)) AND
location LIKE ('%' + @UnitName)
order by DateTimeOccurred