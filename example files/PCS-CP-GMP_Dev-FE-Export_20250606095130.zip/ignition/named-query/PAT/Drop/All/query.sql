/*
  drop_all_tables.sql

  Description:
    Drops tables [sample_data], [sample], and [run] in order, handling foreign
    key dependencies. Useful for testing a clean bootstrap.

  Usage:
    1. Run this script last when you want to remove all tables.
    2. Uses TRY/CATCH to handle any errors.
*/
BEGIN TRY
    /* Must drop sample_data first because it depends on sample */
    IF OBJECT_ID(N'dbo.sample_data', N'U') IS NOT NULL
        DROP TABLE dbo.sample_data;

    /* Then drop sample because it depends on run */
    IF OBJECT_ID(N'dbo.[sample]', N'U') IS NOT NULL
        DROP TABLE dbo.[sample];

    /* Finally drop run */
    IF OBJECT_ID(N'dbo.[run]', N'U') IS NOT NULL
        DROP TABLE dbo.[run];

    PRINT 'All tables dropped successfully.';
END TRY
BEGIN CATCH
    PRINT 'Error dropping tables: ' + ERROR_MESSAGE();
END CATCH;