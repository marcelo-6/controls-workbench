/*
  create_sample_table.sql

  Description:
    Creates the [sample] table, which references the [run] table via a foreign key.
    Each row in [sample] represents a single sample collected as part of a run.
    - sample_id (INT IDENTITY) is the internal PK.
    - sample_uuid (UNIQUEIDENTIFIER) can be used for referencing sample_data
      without needing the sample_id back from the DB.
    - run_uuid (FK) references run.run_uuid, leveraging the UNIQUE constraint.
  Usage:
    1. Run this script after create_run_table.sql.
    2. Extended properties provide column descriptions.
*/

BEGIN TRY
    CREATE TABLE dbo.[sample] (
        sample_id         INT                IDENTITY(1,1) NOT NULL PRIMARY KEY,
        sample_uuid       UNIQUEIDENTIFIER   NOT NULL,
        run_uuid          UNIQUEIDENTIFIER   NOT NULL,
        sample_number     INT                NOT NULL,
        server_timestamp  DATETIME2          NOT NULL
            CONSTRAINT DF_sample_server_timestamp DEFAULT (SYSUTCDATETIME()),
        client_timestamp  DATETIME2          NULL,
        CONSTRAINT UQ_sample_uuid UNIQUE (sample_uuid),

        -- Foreign Key referencing run_uuid (which has a UNIQUE constraint)
        CONSTRAINT FK_sample_run_uuid
            FOREIGN KEY (run_uuid)
            REFERENCES dbo.[run](run_uuid)
            ON DELETE CASCADE
    );

    ----------------------------------------------------------------------------
    -- Extended Properties
    ----------------------------------------------------------------------------
    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Unique ID for each sample (PK, auto-increment).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample',
        @level2type = N'COLUMN', @level2name = N'sample_id';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Client-supplied UUID for referencing the sample.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample',
        @level2type = N'COLUMN', @level2name = N'sample_uuid';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Foreign key to run.run_uuid (store-and-forward).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample',
        @level2type = N'COLUMN', @level2name = N'run_uuid';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Server timestamp set on INSERT (UTC).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample',
        @level2type = N'COLUMN', @level2name = N'server_timestamp';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Client-supplied timestamp from SCADA.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample',
        @level2type = N'COLUMN', @level2name = N'client_timestamp';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Sample number for ordering within the run (e.g. 1, 2, 3...).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample',
        @level2type = N'COLUMN', @level2name = N'sample_number';

    ----------------------------------------------------------------------------
    -- Index to quickly query samples within a run in order by sample_number
    ----------------------------------------------------------------------------
    CREATE INDEX IX_sample_runid_samplenumber
        ON dbo.[sample] (run_id, sample_number);

END TRY
BEGIN CATCH
    PRINT 'Error creating [sample] table: ' + ERROR_MESSAGE();
END CATCH;
