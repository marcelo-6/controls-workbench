/*
  create_sample_data_table.sql

  Description:
    Creates the [sample_data] table, which stores JSON data for each sample.
    Each row has a data_type (e.g. 'raw', 'transformed', 'prediction'), an
    optional model_name, and a JSON field. This allows partial inserts for 
    different data types or different models without overwriting a single JSON blob.
    - sample_data_id (INT IDENTITY) is the internal PK.
    - sample_uuid references sample.sample_uuid (which is UNIQUE).
    - Timestamps:
        server_timestamp (DB inserts), client_timestamp (SCADA).
    - failure_reason is included for any data-specific failure or invalid result.
  Usage:
    1. Run this script after create_sample_table.sql.
    2. Extended properties provide column descriptions.
*/

BEGIN TRY
    CREATE TABLE dbo.[sample_data] (
        sample_data_id   INT                IDENTITY(1,1) NOT NULL PRIMARY KEY,
        sample_uuid      UNIQUEIDENTIFIER   NOT NULL,
        data_type        VARCHAR(50)        NOT NULL,  -- e.g. 'raw', 'prediction'
        model_name       VARCHAR(100)       NULL,
        data_json        NVARCHAR(MAX)      NULL,
        server_timestamp DATETIME2          NOT NULL
            CONSTRAINT DF_sample_data_server_timestamp DEFAULT (SYSUTCDATETIME()),
        client_timestamp DATETIME2          NULL,
        failure_reason   VARCHAR(1000)      NULL,

        -- Foreign Key to sample.sample_uuid (which has a UNIQUE constraint)
        CONSTRAINT FK_sample_data_sample_uuid
            FOREIGN KEY (sample_uuid)
            REFERENCES dbo.[sample](sample_uuid)
            ON DELETE CASCADE
    );

    ----------------------------------------------------------------------------
    -- Extended Properties
    ----------------------------------------------------------------------------
    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Unique ID for each data row (PK, auto-increment).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample_data',
        @level2type = N'COLUMN', @level2name = N'sample_data_id';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'References sample.sample_uuid for store-and-forward.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample_data',
        @level2type = N'COLUMN', @level2name = N'sample_uuid';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Server timestamp set on INSERT (UTC).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample_data',
        @level2type = N'COLUMN', @level2name = N'server_timestamp';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Client-supplied timestamp from SCADA.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample_data',
        @level2type = N'COLUMN', @level2name = N'client_timestamp';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Reason for data entry failure or invalid result, if applicable.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample_data',
        @level2type = N'COLUMN', @level2name = N'failure_reason';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Type of data stored in JSON (e.g. raw, prediction, metadata).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample_data',
        @level2type = N'COLUMN', @level2name = N'data_type';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Name of the model if this data is a prediction or model-specific (e.g. mRNA).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample_data',
        @level2type = N'COLUMN', @level2name = N'model_name';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'JSON field storing large data (2D arrays, dictionary of predictions, etc.).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'sample_data',
        @level2type = N'COLUMN', @level2name = N'data_json';

    ----------------------------------------------------------------------------
    -- Index to speed up queries on (sample_id, data_type)
    ----------------------------------------------------------------------------
    CREATE INDEX IX_sample_data_sampleid_datatype
        ON dbo.sample_data (sample_id, data_type);

END TRY
BEGIN CATCH
    PRINT 'Error creating [sample_data] table: ' + ERROR_MESSAGE();
END CATCH;
