/*
  create_run_table.sql

  Description:
    Creates the [run] table which stores run-level metadata: equipment info,
    batch info, model class/version, and a timestamp for when the run started.
    - Uses run_id (INT IDENTITY) as internal PK for performance.
    - Uses run_uuid (UNIQUEIDENTIFIER) for external references (store-and-forward).
    - run_uuid is UNIQUE so that child tables can reference it directly.
    - server_timestamp is DB-generated (UTC).
    - client_timestamp is SCADA-supplied to reflect actual start times.
    
  Usage:
    1. Run this script first to create the [run] table.
    2. Extended properties are used to add column descriptions.
*/

BEGIN TRY
    CREATE TABLE dbo.[run] (
        run_id            INT                IDENTITY(1,1) NOT NULL PRIMARY KEY,
        run_uuid          UNIQUEIDENTIFIER   NOT NULL,
        equipment_name    VARCHAR(255)       NOT NULL
            CONSTRAINT DF_run_equipment_name DEFAULT ('Unknown'),
        run_name          VARCHAR(255)       NULL,
        batch_id          VARCHAR(255)       NULL,
        unit_name         VARCHAR(255)       NULL,
        model_class       VARCHAR(255)       NULL,
        model_version     VARCHAR(255)       NULL,
        server_timestamp  DATETIME2          NOT NULL
            CONSTRAINT DF_run_server_timestamp DEFAULT (SYSUTCDATETIME()),
        client_timestamp  DATETIME2          NULL,

        -- Ensure run_uuid is unique so we can FK-reference it in [sample]
        CONSTRAINT UQ_run_uuid UNIQUE (run_uuid)
    );

    ----------------------------------------------------------------------------
    -- Extended Properties:
    ----------------------------------------------------------------------------
    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Unique ID for each run (PK, auto-increment).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'run_id';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Name of the equipment used in this run.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'equipment_name';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Optional human-readable name of the run.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'run_name';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Client-supplied UUID for store-and-forward referencing.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'run_uuid';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Server timestamp set on INSERT (UTC).',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'server_timestamp';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Client-supplied timestamp from SCADA.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'client_timestamp';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Batch ID associated with this run.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'batch_id';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Unit name (e.g. IVT) associated with this run.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'unit_name';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'The class of model used for this run (e.g., "mRNA").',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'model_class';

    EXEC sys.sp_addextendedproperty
        @name = N'MS_Description',
        @value = N'Version of the model used for this run.',
        @level0type = N'SCHEMA', @level0name = N'dbo',
        @level1type = N'TABLE',  @level1name = N'run',
        @level2type = N'COLUMN', @level2name = N'model_version';

END TRY
BEGIN CATCH
    PRINT 'Error creating [run] table: ' + ERROR_MESSAGE();
END CATCH;
