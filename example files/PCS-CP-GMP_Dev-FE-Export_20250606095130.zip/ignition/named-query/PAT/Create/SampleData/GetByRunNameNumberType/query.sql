/*
  Named Query: SampleData/GetByRunNameNumberType

  Retrieves all rows from sample_data that match:
    1) A run with run_name = run_name
    2) A sample with sample_number = sample_number
    3) A sample_data row with data_type = data_type
*/

SELECT 
    sd.model_name,
    sd.data_json,
    sd.created_at
FROM dbo.[run] AS r
JOIN dbo.[sample] AS s 
    ON s.run_id = r.run_id
JOIN dbo.sample_data AS sd
    ON sd.sample_id = s.sample_id
WHERE r.run_name = :run_name
  AND s.sample_number = :sample_number
  AND sd.data_type = :data_type
ORDER BY sd.created_at;
