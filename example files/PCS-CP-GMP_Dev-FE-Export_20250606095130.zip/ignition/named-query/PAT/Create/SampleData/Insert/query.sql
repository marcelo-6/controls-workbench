/*
  Named Query: SampleData/Insert

  Description:
    Inserts a row into [sample_data], referencing the sample_id that matches
    the given (run_id, sample_number). Returns the new sample_data_id.

  Parameters:
    run_id         INT
    sample_number  INT
    data_type      VARCHAR(50)    -- e.g. 'raw', 'transformed', 'prediction'
    model_name     VARCHAR(100)   -- optional, can be NULL
    data_json      NVARCHAR(MAX)  -- JSON data

  Note:
    - If no sample matches (run_id, sample_number), no row is inserted.
    - If multiple samples match (rare case), the TOP 1 ensures only one insert.
    - We use the OUTPUT clause to return the newly created sample_data_id.
*/

BEGIN TRY

    INSERT INTO dbo.sample_data (
        sample_id,
        data_type,
        model_name,
        data_json
    )
    VALUES (
        :sample_id,
        :data_type,
        :model_name,
        :data_json
    );

    -- On success, return 1
    SELECT 1 AS result;

END TRY
BEGIN CATCH

    -- On any SQL error, return -1
    SELECT -1 AS result;

END CATCH;
