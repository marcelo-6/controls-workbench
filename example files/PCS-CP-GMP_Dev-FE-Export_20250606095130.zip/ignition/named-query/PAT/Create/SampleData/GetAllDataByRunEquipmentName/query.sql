/*
  Named Query SampleData/GetAllDataByRunEquipmentName

  Description
    Retrieves ALL rows from sample_data for the specified run name, 
    across all samples (sample_number) and all data types ('raw', 'prediction', etc.)
*/

SELECT TOP 20
	r.run_name,
	r.equipment_name,
	r.model_class,
	r.model_version,
	r.batch_id,
	r.unit_name as unit_name,
	r.[timestamp] as run_start_timestamp,
    s.sample_number,
    s.[timestamp] as sample_start_timestamp,
    sd.data_type,
    sd.model_name,
    sd.data_json,
    sd.created_at as sample_data_timestamp
FROM dbo.[run] AS r
JOIN dbo.[sample] AS s
    ON s.run_id = r.run_id
JOIN dbo.[sample_data] AS sd
    ON sd.sample_id = s.sample_id
WHERE r.run_name = :run_name
AND r.equipment_name = :equipment_name
AND sd.data_type = 'raw'
ORDER BY s.sample_number DESC, sd.created_at DESC 
