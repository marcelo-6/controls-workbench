/*
  Named Query: SampleData/GetAllPredictionsByRunName

  Description:
    Returns all rows in [sample_data] with data_type = 'prediction' 
    for samples in the specified run (identified by run_name).
*/

SELECT 
    s.sample_number,
    sd.model_name,
    sd.data_json,
    sd.created_at
FROM dbo.[run] AS r
JOIN dbo.[sample] AS s 
    ON s.run_id = r.run_id
JOIN dbo.sample_data AS sd
    ON sd.sample_id = s.sample_id
WHERE r.run_name = :run_name
  AND sd.data_type = 'prediction'
ORDER BY s.sample_number, sd.created_at;
