/*
  Named Query: Sample/Insert

  Description:
    Inserts a single row into [sample], referencing a run by run_uuid,
    and assigning a new sample_uuid for store-and-forward.

  Parameters:
    sample_uuid
    run_uuid
    sample_number
    client_timestamp
*/

BEGIN TRY

    INSERT INTO dbo.[sample] (
        sample_uuid,
        run_uuid,
        sample_number,
        client_timestamp
        -- server_timestamp is defaulted by the DB (e.g. SYSUTCDATETIME())
    )
    VALUES (
        :sample_uuid,
        :run_uuid,
        :sample_number,
        :client_timestamp
    );

    SELECT 1 AS insert_success;

END TRY
BEGIN CATCH
    SELECT -1 AS insert_fail;
END CATCH;
