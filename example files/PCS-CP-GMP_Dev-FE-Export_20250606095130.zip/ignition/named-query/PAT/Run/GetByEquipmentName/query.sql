/*
  Named Query: Run/GetByEquipmentName

  Returns all runs whose [equip_name] is a match.
*/

SELECT TOP (50) r.run_name
FROM dbo.[run] AS r
WHERE r.[equipment_name] = :equip_name  
ORDER BY r.[client_timestamp] DESC;

