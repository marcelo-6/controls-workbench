/*
  Named Query: Run/GetByTimeRange

  Returns all runs whose [timestamp] is between start_time and end_time.
  Also returns how many samples belong to each run (sample_count).
  Note: requires a time zone for the timestamp (assumed EST otherwise)
*/

SELECT
    r.equipment_name,
    r.run_name,
    CAST(r.client_timestamp AT TIME ZONE 'UTC' AT TIME ZONE COALESCE(:timezone, 'Eastern Standard Time') AS DATETIME2) AS timestamp,
    -- r.[timestamp],
    r.batch_id,
    r.unit_name,
    -- DISTINCT ensures we count each sample only once
    COUNT(DISTINCT s.sample_number) AS sample_count,
    r.model_class,
    r.model_version

FROM dbo.[run] AS r
LEFT JOIN dbo.[sample] AS s
       ON s.run_uuid = r.run_uuid
WHERE r.client_timestamp >= CAST(:start_time AT TIME ZONE COALESCE(:timezone, 'Eastern Standard Time') AT TIME ZONE 'UTC' AS DATETIME2)
  AND r.client_timestamp <  CAST(:end_time AT TIME ZONE COALESCE(:timezone, 'Eastern Standard Time') AT TIME ZONE 'UTC' AS DATETIME2)
GROUP BY
    r.run_id,
    r.equipment_name,
    r.run_name,
    r.client_timestamp,
    r.batch_id,
    r.unit_name,
    r.model_class,
    r.model_version
ORDER BY
    r.client_timestamp;

 