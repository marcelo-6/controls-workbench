/*
  Named Query: Run/InsertRun

  Description:
    Inserts a new row into [run], leveraging a UUID for store-and-forward.
    We don't return run_id, only do a placeholder select on success.
*/

BEGIN TRY

    INSERT INTO dbo.[run] (
        run_uuid,
        equipment_name,
        run_name,
        batch_id,
        unit_name,
        model_class,
        model_version,
        -- server_timestamp is auto-populated by DEFAULT
        client_timestamp
    )
    VALUES (
        :run_uuid,
        :equipment_name,
        :run_name,
        :batch_id,
        :unit_name,
        :model_class,
        :model_version,
        :client_timestamp
    );

    SELECT 1 AS insert_success;  -- Arbitrary success indicator

END TRY
BEGIN CATCH
    SELECT -1 AS insert_fail;    -- Return -1 if there's an error
END CATCH;
