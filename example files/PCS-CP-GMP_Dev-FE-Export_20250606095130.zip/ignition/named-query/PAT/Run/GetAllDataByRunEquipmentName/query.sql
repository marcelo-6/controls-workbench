/*
  Named Query SampleData/GetAllDataByRunEquipmentNameTransposed

  Description
    Retrieves ALL rows from sample_data for the specified run name, 
    across all samples (sample_number) and all data types ('raw', 'prediction', etc.)
*/

SELECT
	r.run_name,
	r.equipment_name,
	r.model_class,
	r.model_version,
	r.batch_id,
	r.unit_name,
	r.client_timestamp as run_start_timestamp,
    s.sample_number,
    s.client_timestamp as sample_start_timestamp,
    sd.data_type,
    sd.model_name,
    sd.data_json,
    sd.client_timestamp as sample_data_timestamp,
    sd.failure_reason,
    r.client_timestamp as run_start_server_timestamp,
    s.client_timestamp as sample_start_server_timestamp,
    sd.client_timestamp as sample_data_server_timestamp
FROM dbo.[run] AS r
JOIN dbo.[sample] AS s
    ON s.run_uuid = r.run_uuid
JOIN dbo.[sample_data] AS sd
    ON sd.sample_uuid = s.sample_uuid
WHERE r.run_name = :run_name
AND r.equipment_name = :equipment_name
ORDER BY s.sample_number, sd.client_timestamp