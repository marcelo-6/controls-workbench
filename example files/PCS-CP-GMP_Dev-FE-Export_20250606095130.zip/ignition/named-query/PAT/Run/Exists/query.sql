/*
Description:
This query calculates the number of runs associated with a specific run name and equipment name.

Parameters:
- run_name: The name of the run for which the count is being retrieved.
- equipment_name: The name of the equipment associated with the runs.

Returns:
- run_count: The total count of runs matching the given run name and equipment name.
*/

SELECT COUNT(run_name) AS 'run_count'
FROM run
WHERE (run_name = :run_name
AND equipment_name = :equipment_name);