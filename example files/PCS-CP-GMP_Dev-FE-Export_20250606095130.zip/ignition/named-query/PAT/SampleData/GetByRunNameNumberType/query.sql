/*
  Named Query: SampleData/GetByRunNameNumberType

  Retrieves all rows from sample_data that match:
    1) A run with run_name = run_name
    2) A sample with sample_number = sample_number
    3) A sample_data row with data_type = data_type
*/

SELECT 
    sd.model_name,
    sd.data_json,
    sd.client_timestamp
FROM dbo.[run] AS r
JOIN dbo.[sample] AS s 
    ON s.run_uuid = r.run_uuid
JOIN dbo.sample_data AS sd
    ON sd.sample_uuid = s.sample_uuid
WHERE r.run_name = :run_name
  AND s.sample_number = :sample_number
  AND sd.data_type = :data_type
ORDER BY sd.client_timestamp;
