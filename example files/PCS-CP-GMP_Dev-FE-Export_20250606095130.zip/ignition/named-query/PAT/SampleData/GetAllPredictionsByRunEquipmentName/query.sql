/*
  Named Query: SampleData/GetAllPredictionsByRunName

  Description:
    Returns all rows in [sample_data] with data_type = 'prediction' 
    for samples in the specified run (identified by run_name).
*/

SELECT
    s.sample_number,
    sd.model_name,
    sd.data_json,
    sd.client_timestamp
FROM dbo.[run] AS r
JOIN dbo.[sample] AS s 
    ON s.run_uuid = r.run_uuid
JOIN dbo.sample_data AS sd
    ON sd.sample_uuid = s.sample_uuid
WHERE r.run_name = :run_name
  AND sd.data_type = 'prediction'
  AND r.equipment_name = :equipment_name
  --AND sd.data_json IS NOT NULL
ORDER BY sd.client_timestamp, s.sample_number;
