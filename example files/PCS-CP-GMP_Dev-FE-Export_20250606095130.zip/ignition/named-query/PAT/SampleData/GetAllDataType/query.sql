/*
  Named Query SampleData/GetAllDataByRunEquipmentName

  Description
    Retrieves ALL rows from sample_data for the specified run name, 
    across all samples (sample_number) and all data types ('raw', 'prediction', etc.)
*/

SELECT s.sample_number
FROM dbo.[run] AS r
JOIN dbo.[sample] AS s
    ON s.run_uuid = r.run_uuid
JOIN dbo.[sample_data] AS sd
    ON sd.sample_uuid = s.sample_uuid
WHERE r.run_name = :run_name
AND r.equipment_name = :equipment_name
AND sd.data_type = :data_type
