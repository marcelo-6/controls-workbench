/*
  Named Query SampleData/GetAllModelNames

  Description
    Retrieves ALL model names in first sample of given run
*/

SELECT DISTINCT sd.model_name
FROM dbo.[run] AS r
JOIN dbo.[sample] AS s
    ON s.run_uuid = r.run_uuid
JOIN dbo.[sample_data] AS sd
    ON sd.sample_uuid = s.sample_uuid
WHERE r.run_name = :run_name
AND r.equipment_name = :equipment_name
AND sd.data_type = 'prediction'
