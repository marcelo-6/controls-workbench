/*
  Named Query: SampleData/Insert

  Description:
    Inserts a new row into [sample_data], referencing a sample by sample_uuid.
    We don't generate a separate UUID for sample_data, so we just store
    the sample_uuid plus data_type, JSON, etc.

  Parameters:
    sample_uuid      UNIQUEIDENTIFIER
    data_type        VARCHAR(50)
    model_name       VARCHAR(100)   (NULL allowed)
    data_json        NVARCHAR(MAX)  (NULL allowed)
    client_timestamp string      (NULL allowed)
    failure_reason

  On success, we SELECT 1. On any error, we SELECT -1.
*/

BEGIN TRY

    INSERT INTO dbo.[sample_data] (
        sample_uuid,
        data_type,
        model_name,
        data_json,
        client_timestamp,
        failure_reason
        -- server_timestamp is auto-defaulted in the DB
    )
    VALUES (
        :sample_uuid,
        :data_type,
        :model_name,
        :data_json,
        :client_timestamp,
        :failure_reason
    );

    -- Return a simple 1 to signal success
    SELECT 1 AS result;

END TRY
BEGIN CATCH

    -- On any SQL error, return -1
    SELECT -1 AS result;

END CATCH;
