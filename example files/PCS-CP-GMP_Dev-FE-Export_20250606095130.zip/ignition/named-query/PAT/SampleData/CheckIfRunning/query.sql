/*
  Named Query: SampleData/GetAllPredictionsByRunName

  Description:
    Returns all rows in [sample_data] with data_type = 'prediction' 
    for samples in the specified run (identified by run_name).
*/

SELECT TOP 1 *
FROM dbo.[run] AS r
--JOIN dbo.[sample] AS s 
--    ON s.run_id = r.run_id
--JOIN dbo.sample_data AS sd
--    ON sd.sample_id = s.sample_id
WHERE r.run_name = :run_name
--  AND sd.data_type = 'prediction'
  AND r.equipment_name = :equipment_name
--ORDER BY sd.created_at, s.sample_number;
