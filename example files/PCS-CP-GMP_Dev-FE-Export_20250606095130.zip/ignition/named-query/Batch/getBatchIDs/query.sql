/*****************************************************************************************************
Procedure:          getBatchIDs
Create Date:       	28Aug23
Author:             Marcelo Amorim
Description:        This queries Sepasoft MES DB for all batch IDs and/or recipes that match a given parameters
					It support wild cards "*", it is used to replace the Analysis Queries from Sepasoft  
					
					Tested on Sepasoft Modules:
					Batch Procedure Module Version 3.81.8 SP-3
					Production Module Version 3.81.8 SP-3
					
					Input Parameters:
					Parameter Name		Data Type	Usage
					recipeName			String		filter query results by recipe name
					batchID				String		filter query results by batchID
					startDate			String		filter query results by between start and end date
					endDate				String		filter query results by between start and end date
					
Used By:            Reports Display dropdown
******************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			28Aug23			MA			Created
*******************************************************************************************************/
SELECT MESBatchControlRecipe.RecipeBatchID,
  MESBatchControlRecipe.RecipeName,
  MESBatchControlRecipe.TimeStamp
FROM MESBatchControlRecipe
WHERE MESBatchControlRecipe.RecipeBatchID LIKE REPLACE(:batchID, '*', '%') AND
MESBatchControlRecipe.RecipeName LIKE REPLACE(:recipeName, '*', '%') AND
MESBatchControlRecipe.TimeStamp BETWEEN :startDate AND :endDate
ORDER BY MESBatchControlRecipe.TimeStamp DESC