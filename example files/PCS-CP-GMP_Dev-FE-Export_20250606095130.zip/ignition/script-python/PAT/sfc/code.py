class BaseChart:
    """
    A helper class to encapsulate common operations for handling tags, logging, and messages
    in the Ignition SCADA chart workflow.

    Attributes:
        chart (object): The chart object from the SFC engine.
        logger (Logger): Logger instance for logging messages.
        em_message_tag_path (str): Path for the equipment message tag.
        em_status_tag_path (str): Path for the equipment status tag.
        sample_no_tag (str): Path for the sample number tag.
    """

    def __init__(self, chart):
        """
        Initializes the BaseChartHelper with the chart object and sets up commonly used tag paths.

        Args:
            chart (object): The chart object from the SFC engine.
        """
        self.chart = chart
        # Use the logger_name from the chart object if it exists, otherwise use the default logger
        logger_name = getattr(chart, "logger_name", "PAT SFC Class")
        self.logger = system.util.getLogger(logger_name)
        self.init_paths()
        
    def init_paths(self):
        """
        Initializes commonly used tag paths for the equipment.
        """
        chart = self.chart
        self.em_message_tag_path = "{0}{1}/EM/Val_Msg".format(chart.pat_equipment_tag_path_prefix, chart.pat_equipment_tag_name)
        self.em_status_tag_path = "{0}{1}/Val_EM_Status".format(chart.pat_equipment_tag_path_prefix, chart.pat_equipment_tag_name)
#        self.sample_no_tag = "{0}{1}/EM/Val_SampleNo".format(chart.In_EquipmentTagPathPrefix, chart.In_EquipmentName) # need to expand this class to only RAMAN functiuonality for this

    def log_debug(self, message):
        """
        Logs a debug message if debug mode is enabled.

        Args:
            message (str): The message to log.
        """
        if self.logger.isDebugEnabled():
            self.logger.debug(message)

    def log_error(self, message):
        """
        Logs an error message.

        Args:
            message (str): The error message to log.
        """
        self.logger.error(message)

    def update_message(self, message, write_to_tag=True):
        """
        Updates the equipment message tag and logs the message.

        Args:
            message (str): The message to write and log.
        """
        self.chart.message = message
        if write_to_tag: system.tag.writeBlocking([self.em_message_tag_path], [message])
        self.log_debug(message)
        
    def update_status_code(self, code):
        """
        Updates the equipment message tag and logs the message.

        Args:
            code (int): The message to write and log.
        """
        system.tag.writeBlocking([self.em_status_tag_path], [code])
        
    def construct_message(self, step_number, description, sample_number=None):
        """
        Constructs a formatted step message.

        Args:
            step_number (int): The step number.
            description (str): Description of the step.
            sample_number (int, optional): The sample number, if applicable.

        Returns:
            str: The formatted step message.
        """
        if sample_number is not None:
            return "Step: {:02d} Sample {}: {}".format(step_number, sample_number, description)
        return "Step: {:02d} {}".format(step_number, description)
        
    def check_arbitration_logic(self, chart):
        """
        Checks if the CM is already acquired by another EM or if it can be acquired.
        
        Args:
            chart (object): The chart object containing necessary attributes like instanceId,
                            pat_equipment_tag_path_prefix, and pat_equipment_tag_name.
        
        Returns:
            bool: True if the arbitration was successful (CM acquired), False otherwise.
        """       
        # Construct tag paths for arbitration logic
        tag_paths = [
            "{0}{1}/CM/Val_Owned".format(chart.pat_equipment_tag_path_prefix, chart.pat_equipment_tag_name),
            "{0}{1}/EM/Val_ChartID".format(chart.pat_equipment_tag_path_prefix, chart.pat_equipment_tag_name),
        ]

        # Read the tag values
        val_owned, val_chartID = [tag.value for tag in system.tag.readBlocking(tag_paths)]

        # Check if the CM is already acquired by another EM
        if val_owned and val_chartID != chart.instanceId:
            # CM is already acquired by another EM
            chart.cm_acquired_external = True
            error_message = "CM is already acquired by another EM (ChartID: {0})".format(val_chartID)
            self.log_error(error_message)
            self.update_message(error_message, False)
        else:
            # If CM is not acquired, read device IP and port
            device_ip_path = "{0}{1}/Parameters/EP/0/Val_String".format(chart.pat_equipment_tag_path_prefix, chart.pat_equipment_tag_name)
            device_port_path = "{0}{1}/Parameters/EP/1/Val_String".format(chart.pat_equipment_tag_path_prefix, chart.pat_equipment_tag_name)
            chart.ip, chart.port = [tag.value for tag in system.tag.readBlocking([device_ip_path, device_port_path])]

            # Update the message to indicate status
            message = self.construct_message(chart.step_counter, "Acquiring {}".format(chart.pat_equipment_tag_name))
            self.update_message(message)

    def acquire_cm(self, chart):
        """
        Attempts to acquire the CM (Control Module) by writing to the relevant tags.
        Also checks if interlocks are met to confirm acquisition success.

        Args:
            chart (object): The chart object containing necessary attributes.

        Returns:
            bool: True if CM is successfully acquired (interlocks met), False otherwise.
        """
        # If CM is already acquired externally, skip the acquisition process
        if not chart.cm_acquired_external:
	        # Construct tag paths for acquisition
	        tag_paths = [
	            "{0}{1}/CM/Val_Owned".format(chart.pat_equipment_tag_path_prefix, chart.pat_equipment_tag_name),
	            "{0}{1}/EM/Val_ChartID".format(chart.pat_equipment_tag_path_prefix, chart.pat_equipment_tag_name),
	        ]
	
	        # Write to tags to acquire CM
	        system.tag.writeBlocking(tag_paths, [1, chart.instanceId])
	
	        # Check if interlocks are met
	        interlock_tag = "{0}{1}/CM/Sts_InterlocksMet".format(chart.pat_equipment_tag_path_prefix, chart.pat_equipment_tag_name)
	        interlocks_met = system.tag.readBlocking([interlock_tag])[0].value
	
	        # Update the chart's acquisition success flag
	        chart.aquired_success = interlocks_met  # Assuming "1" indicates success
	        
    def acquire_on_stop(self, chart):
        """
        Handles the onStop logic for any step, including updating the message tag,
        logging success or failure, and incrementing the step counter.

        Args:
            chart (object): The chart object containing necessary attributes.
            action_name (str): A description of the action being handled (e.g., "Acquired").

        Raises:
            Exception: If an error occurs during the process.
        """
        try:
            # Check if CM was acquired externally
            if not chart.cm_acquired_external:
                # Successful acquisition
                message = self.construct_message(chart.step_counter, "Acquired {}".format(chart.pat_equipment_tag_name))
                self.update_message(message)
                chart.step_counter += 1  # Increment the step counter
            else:
                # Failed acquisition
                error_message = self.construct_message(chart.step_counter, "Failed to Acquire {}".format(chart.pat_equipment_tag_name))
                self.log_error(error_message)
                system.tag.writeBlocking([self.em_status_tag_path], [999])  # Set status to error
        except Exception:
            # Log exception using a centralized logging mechanism
            PAT.sfc.log_chart_exception(chart, "An error occurred during 'Acquire' step.")
            
import sys
import traceback
import inspect

def log_chart_exception(chart, message="An error occurred"):
    """
    Logs the full stack trace of an exception within an Ignition chart context.

    Args:
        chart (object): The chart object containing `chartPath` and `step_name`.
        message (str): Additional context message for the log.
    """
    try:
        # Get the current script name
        script_name = inspect.currentframe().f_back.f_code.co_name  # Get the caller function name

        # Get the logger based on the chart path
        logger = system.util.getLogger(chart.chartPath)

        # Get exception details
        ex_type, ex, tb = sys.exc_info()

        # Format the full stack trace
        full_stack_trace = "".join(traceback.format_exception(ex_type, ex, tb))
        if chart.get('step_name') is not None and chart.get('message') is not None:
	        # Log the full stack trace
	        logger.error("ERROR in chart '{}' step '{}' script '{}':\n{}\n{}\n------ chart.message:'{}'".format(
	            chart.chartPath, chart.step_name, script_name, message, full_stack_trace, chart.message
	        ))
        else:
	        # Log the full stack trace
	        logger.error("ERROR in chart '{}' script '{}':\n{}\n{}\n------ chart.message:'{}'".format(
	            chart.chartPath, script_name, message, full_stack_trace, message
	        ))
    except Exception as logging_error:
        # Handle unexpected issues in the error logging itself
        fallback_logger = system.util.getLogger("PAT-SFC-FallbackLogger")
        fallback_logger.error("Failed to log exception: {}".format(logging_error))

## SIM
import csv
import json
from collections import OrderedDict

def read_csv_to_list(file_path="C:\WME_Files\SIM\SIM-CP1-Covid-012.csv"):
    """
    Reads a CSV file from disk and converts it into an ordered dictionary.

    The dictionary structure follows:
    - Keys are taken from the first column starting from the second row (sample number).
    - Values are ordered dictionaries where:
        - The key is the x-axis value (column header from row 1, starting from the second column).
        - The value is the y-axis value (cell value from row 2 onward, excluding the first column).

    Parameters
    ----------
    file_path : str
        The path to the CSV file.

    Returns
    -------
    list
        where:
        - The first column values (sample numbers) are the order in the list (starting from 0).
        - The values are ordered dictionaries mapping x-axis values to y-axis values.in a json string
    """
    #data_dict = OrderedDict()
    data_list = []

    with open(file_path, mode='r') as file:
        reader = csv.reader(file)
        rows = list(reader)

        if len(rows) < 2:
            raise ValueError("CSV file does not have enough rows to process.")

        headers = rows[0][1:]  # Extract column headers (X-axis values) from the first row, skipping the first column

        for row in rows[1:]:  # Skip the first row (headers)
            sample_number = row[0]  # First column becomes the key
            sample_data = OrderedDict()

            for i in range(len(headers)):
                sample_data[round(float(headers[i]),4)] = float(row[i + 1])   # Store (x-axis, y-axis) as string keys

            #data_dict[sample_number] = sample_data
            data_list.append(format_sample_as_string(sample_data))

    return data_list

def format_sample_as_string(sample_data):
    """
    Formats a single sample's data as a newline-separated string, preserving order.
    THIS IS MADE TO FEED INTO WebApp FORMAT for predictions!!! not for sql database

    Parameters
    ----------
    sample_data : OrderedDict
        Ordered dictionary containing x-axis and y-axis values.

    Returns
    -------
    str
        A newline-separated string in the format "x-axis value,y-axis value".
    """
    return '\n'.join(['{},{}'.format(k, v) for k, v in sample_data.items()])
    
def parse_sample_from_string(sample_string):
    """
    Parses a newline-separated JSON string into an OrderedDict.

    Parameters
    ----------
    sample_string : str
        A newline-separated string where each line follows the format:
        "x-axis value,y-axis value".

    Returns
    -------
    OrderedDict
        An ordered dictionary where:
        - Keys are x-axis values.
        - Values are y-axis values.
    """
    sample_data = OrderedDict()
    
    for line in sample_string.strip().split('\n'):
    	
        parts = line.split(',')
        if len(parts) == 2:
            x_value, y_value = parts[0], parts[1]
            sample_data[x_value] = y_value  # Maintain order

    return sample_data