'''***************************************************************************************************
Procedure:          PAT.raman.marqmetrix.util
Create Date:       	23Sep24
Author:             Marcelo Amorim
Description:        See documentation for more info on this script.
Used By:			PAT SFC

Module for processing data from spectrometers.

This module provides functionality to compute X-axis values for instrument calibration,
extract Y-axis values from a Base64 buffer, and combine the results into a structured format.

Steps:
1. Retrieve X-axis values based on the provided calibration data.
2. Extract Y-axis (counts) values from a Base64 buffer and convert them into a double array.
3. Gather metadata from the JSON response that accompanies the Y-axis data.
4. Combine the X-axis and Y-axis values into a single JSON structure in the format:
   { "x-axis value 1": "y-axis value 1", "x-axis value 2": "y-axis value 2", ... }

****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			23Sep24			MA			Created
***************************************************************************************************
'''
import json
import base64
import struct
from collections import OrderedDict
class Calibration:
	"""
	A class to handle instrument calibration data.

	Attributes:
		laser_wavelength (float): The wavelength of the laser used in the calibration.
		arguments (list): Coefficients for calculating the Raman shift.

	Methods:
		get_x_axis_values(sample_data_length=2048): Computes the X-axis values based on the calibration data.
		wavelengths(raman_shift, laser_wavelength): Converts Raman shift values to wavelengths.
		raman_shift(size, reference_wavelength, arguments): Calculates the Raman shift based on the polynomial coefficients.
	"""
	class XAxisValues:
		"""
		A class to represent X-axis values.

		Attributes:
			shift (list): The computed Raman shift values.
			wavelength (list): The computed wavelength values.
		"""
		def __init__(self, shift, wavelength):
			self.shift = shift
			self.wavelength = wavelength

	def __init__(self, laser_wavelength, arguments):
		"""
		Initializes the Calibration instance with laser wavelength and arguments.

		Parameters:
			laser_wavelength (float): The wavelength of the laser used.
			arguments (list): Coefficients for calculating Raman shift.
		"""
		self.laser_wavelength = laser_wavelength
		self.arguments = arguments

	def get_x_axis_values(self, sample_data_length=2048):
		"""
		Computes the X-axis values for the calibration.

		Parameters:
			sample_data_length (int): The length of the sample data (default is 2048).

		Returns:
			XAxisValues: An instance containing the calculated shift and wavelength.
		"""
		shift = self.raman_shift(sample_data_length, self.laser_wavelength, self.arguments)
		wavelength = self.wavelengths(shift, self.laser_wavelength)
		return self.XAxisValues(shift, wavelength)

	def wavelengths(self, raman_shift, laser_wavelength):
		"""
		Converts Raman shift values to wavelengths.

		Parameters:
			raman_shift (list): List of Raman shift values.
			laser_wavelength (float): The wavelength of the laser used.

		Returns:
			list: List of calculated wavelength values.
		"""
		result = []
		laser_wavelength_centimeters = 1e-7 * laser_wavelength
		for shift in raman_shift:
			result.append(laser_wavelength / (1 - shift * laser_wavelength_centimeters))
		return result

	def raman_shift(self, size, reference_wavelength, arguments):
		"""
		Calculates the Raman shift values based on polynomial coefficients.

		Parameters:
			size (int): The number of Raman shift values to calculate.
			reference_wavelength (float): The reference wavelength for calculations.
			arguments (list): Coefficients for calculating the wavelength.

		Returns:
			list: List of calculated Raman shift values. rounded to the nearest 4th decimal
		"""
		result = []
		for i in range(size):
			wavelength = sum(arguments[j] * (i ** j) for j in range(len(arguments)))
			result.append((1 / reference_wavelength - 1 / wavelength) * 10000000)
			#result.append(round((1 / reference_wavelength - 1 / wavelength) * 10000000,4))
		return result

def decode_base64_buffer(buffer):
	"""
	Decodes a Base64 buffer into a list of double values.

	Parameters:
		buffer (str): A Base64 encoded string representing the double values.

	Returns:
		list: A list of decoded double values.
	"""
	# Decode the Base64 string and convert it into a list of doubles
	raw_data = base64.b64decode(buffer)
	# Assuming the data is in a format where doubles are represented as 8-byte values
	double_array = []
	for i in range(0, len(raw_data), 8):
		double_value = struct.unpack('<d', raw_data[i:i + 8])[0]
		double_array.append(double_value)
		#print(double_value)
	return double_array

def process_calibration_and_data(calibration_json, response_json):
	"""
	Processes calibration data and raw data to return combined results.

	Parameters:
		calibration_json (dict): JSON object containing calibration data.
		response_json (dict): JSON object containing response data with raw counts.

	Returns:
		dict: A dictionary containing combined X-axis and Y-axis data along with metadata.
	"""
	# Create Calibration instance
	calibration = Calibration(
		laser_wavelength=calibration_json['laserWavelength'],
		arguments=calibration_json['arguments']
	)

	# Step 1: Get X Axis values
	x_axis_values = calibration.get_x_axis_values()

	# Step 2: Get Y-axis values from the Base64 buffer
	y_axis_values = decode_base64_buffer(response_json['data']['buffer'])
	
	# Step 3: Extract metadata
	parsed_metadata = response_json['metadata']

	# Step 4: Combine X-axis and Y-axis into a single JSON structure (ordered dict to maintain order since jython default dicts dont!)
	combined_data = OrderedDict()
	for x, y in zip(x_axis_values.shift, y_axis_values):
		combined_data[x] = y

	# Include metadata in the final output
	combined_output = OrderedDict()
	combined_output = {
		"combinedData": combined_data,
		"metadata": parsed_metadata
	}

	return combined_output

# Example usage:
# Load your calibration and response data here
# calibration_data = { ... }
# response_data = { ... }
# result = process_calibration_and_data(calibration_data, response_data)
# print(json.dumps(result, indent=2))