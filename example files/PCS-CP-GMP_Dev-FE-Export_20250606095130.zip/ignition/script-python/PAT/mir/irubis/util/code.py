'''
***************************************************************************************************
Procedure:          PAT.mir.irubis.util
Create Date:        23Dec24
Author:             Marcelo Amorim
Description:        Utility functions for processing data from Irubis MIR spectrometers.
Used By:            PAT SFC

Module for processing spectral data from IRubis MIR spectrometers.

This module provides functionality to:
1. Combine X-axis values (wavenumbers in cm-1) and Y-axis values (absorbance in mAu) into a structured format.
2. Ensure the combined data maintains the original order of the input values using `OrderedDict`.
3. Prepare a JSON-like structure including combined data and associated metadata.

Steps:
------
1. Retrieve X-axis values.
2. Retrieve Y-axis values.
3. Gather metadata (TBD).
4. Combine the X-axis and Y-axis values into a JSON-like structure:
   {
       "combinedData": { "x1": "y1", "x2": "y2", ... },
       "metadata": <metadata>
   }

****************************************************************************************************
SUMMARY OF CHANGES
Version     Date(ddMMMyy)    Author      Comments
----------------------------------------------------------------------------------------------------
1.0         23Dec24          MA          Created
***************************************************************************************************
'''

import json
from collections import OrderedDict

def process_data(wavenumbers_array, absorbance_array):
	"""
	Processes wavenumber and absorbance data into a structured format for MIR spectrometers.
	
	Parameters
	----------
	wavenumbers_array : list[float]
	    Array containing X-axis values (wavenumbers in cm-1).
	
	absorbance_array : list[float]
	    Array containing Y-axis values (absorbance in mAu).
	
	Returns
	-------
	dict
	    A dictionary containing:
	        - combinedData: OrderedDict with X-axis values as keys and Y-axis values as values.
	        - metadata: Metadata associated with the data (placeholder as of now).
	
	Raises
	------
	ValueError
	    If the lengths of `wavenumbers_array` and `absorbance_array` do not match.
	
	Example
	-------
	>>> wavenumbers = [1000.0, 1001.0, 1002.0]
	>>> absorbance = [0.5, 0.6, 0.7]
	>>> result = process_data(wavenumbers, absorbance)
	>>> print(result)
	{
	    "combinedData": OrderedDict([("1000.0", "0.5"), ("1001.0", "0.6"), ("1002.0", "0.7")]),
	    "metadata": ""
	}
	"""
	# Step 1: Validate input lengths
	if len(wavenumbers_array) != len(absorbance_array):
	    raise ValueError("The lengths of X-axis (wavenumbers) and Y-axis (absorbance) arrays must match.")
	
	# Step 2: Combine X-axis and Y-axis into an ordered dictionary
	combined_data = OrderedDict()
	for x, y in zip(wavenumbers_array, absorbance_array):
	    combined_data[str(x)] = str(y)  # Convert to strings to ensure JSON compatibility
	
	# Step 3: Placeholder for metadata (to be implemented)
	parsed_metadata = ""  # Metadata handling to be added in the future
	
	# Step 4: Prepare the final combined output
	combined_output = {
	    "combinedData": combined_data,
	    "metadata": parsed_metadata
	}
	
	return combined_output