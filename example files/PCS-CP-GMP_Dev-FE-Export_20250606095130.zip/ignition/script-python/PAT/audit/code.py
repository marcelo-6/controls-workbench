def entry(audit_action, audit_target, action_value):
	'''
	Function to make it a requirement for audit_action, audit_target, action_value values before audit trail entries
	'''
	system.util.audit(action=audit_action, actionTarget=audit_target, actionValue=action_value)