import glob
import os
import json

## Dynamically select networkfolder based on system
try:
	root_folder = 'C:\\WME_Files\\ML Models'
	if 'DEV' in system.tag.readBlocking(tagPaths=["[System]Gateway/SystemName"])[0].value:
		pass
	else:
		root_folder = 'E:\\SCADA_Imports\\ML Models'
except:
	pass

logging = system.util.getLogger("PAT." + __name__)

def get_list_of_all_models(order_by = 'name ASC'):
	try:
		response = WM_API.WebApp.get_models(model_filter="tags.stage = 'production'",order_by=order_by)
		if response != None and response.statusCode == 200:
			return response.json['data']['models']
		else:
			return None
	except:
		return None

def get_list_of_all_archived_models(order_by = 'name ASC'):
	try:
		response = WM_API.WebApp.get_models(model_filter="tags.stage = 'archived'",order_by=order_by)
		if response != None and response.statusCode == 200:
			return response.json['data']['models']
		else:
			return None
	except:
		return None
		
def get_all_models_history():
	try:
		response = WM_API.WebApp.get_all_models(model_filter="tags.stage LIKE '%'")
		if response != None and response.statusCode == 200:
#			response.json['data']['models']['Creation_timestamp'] = 
			return response.json['data']['models']
		else:
			return None
	except:
		return None
		
def register_model(bytes = None, name = None, description = None,change = None, tags = None, file_name = None):
	try:
		if name == None or bytes == None:
			return 0
			
		model_metadata = {
		    "ml_model_name": name,
		    "ml_model_description": description,
		    "ml_model_change_description": change,
		    "ml_model_tags": tags,
		    "model_file_name": file_name # only used by Ignition to build the request body, no needed for rest API
		}
		model_bytes = bytes
		response = WM_API.WebApp.post_register_model(model_metadata, model_bytes)
		
		# Check if a string
		if isinstance(response, str):
			return False, response
		if response == None:
			return False, "An error occurred, Web App check logs for details"
			
		# Check if a valid response object
		try:
			if response.getcode() == 202:
				response_json = json.loads(response.read())
				
				# if response contains 'message' field, return it
				if 'message' in response_json:
					return True, response_json['message']
				else:
					return True, response.read()
			else:
				return False, response.read()
		except Exception as e:
			PAT.utils.log_exception()
			if logging.isDebugEnabled(): logging.debug(str(e))
			# return False, str(e)
			raise e
	except Exception as e:
		PAT.utils.log_exception()
		if logging.isDebugEnabled(): logging.debug(str(e))
		raise e
		#return False, str(e)
		
def archive_model(name = None, change = None):
	try:
			
		model_metadata =  {
			"latest_version": False,
			"description": change,
			"tags": {"stage": "archived"}
		}

		response = WM_API.WebApp.put_archive_model(model_name=name, model_metadata=model_metadata)
		if isinstance(response, str):
			return False, response
		if response != None and response.statusCode == 200:
			return True, response.json['message']
		else:
			return False, response
	except Exception as e:
		if logging.isDebugEnabled(): logging.debug(str(e))
		return False, str(e)
		
def browse_and_list_pkl_files():
    try:
        dataset_data = []
        
        # Use glob to find all .pkl files in the specified folder
        print root_folder
        for pkl_file in glob.glob(os.path.join(root_folder, '*.pkl')):
            dataset_data.append({
                "label": os.path.basename(pkl_file),  # File name
                "value": pkl_file                    # Full file path
            })
        
        # Return the list of pkl files in the required format
        return dataset_data

    except Exception as e:
    	if logging.isDebugEnabled(): logging.debug(str(e))
        return str(e)  # Return the error if something goes wrong

def download_model(model_name, model_version):
	"""
	Downloads a production model (.pkl file) using the WebApp API wrapper.

	Parameters
	----------
	model_name : str
	    Name of the registered model in MLflow.
	model_version : str
	    Version number of the model to download.
	save_path : str
	    Local path to save the downloaded .pkl file.

	Returns
	-------
	str or None
	    File path if download is successful, None otherwise.
	"""
	try:
		response = WM_API.WebApp.download_model_from_registry(
			model_name=model_name,
			model_version=model_version
		)
		return response

	except:
		return None