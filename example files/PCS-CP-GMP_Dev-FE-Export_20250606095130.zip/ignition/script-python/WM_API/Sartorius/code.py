# WME - CB 21Nov2023
# See documentation for more info on this script. Intended for use with WM_Sartorius_UDT
# Main function called from Gateway Timer Scripts
# Ver. 1.0 - Released for QA
# Ver. 2.0 - Added main function

def getReq(ip_address, client):
	try:
	    # Send a GET request
	    response = client.get('https://' + ip_address + '/rest/modules/weighing/data/value',timeout=500)
	    # Verify the sign and return the response
	    if response.json['sign'] == '-':
	        return [(response.json['sign'] + response.json['number'])][0]
	    else:
	        return [response.json['number']][0]
	except:
		return -99999

def postReq(ip_address, endpoint):
	# Create the JythonHttpClient
	client = system.net.httpClient(bypass_cert_validation=True)
	# Send a POST request
	client.post('https://' + ip_address + endpoint)

def main():
	# Create the JythonHttpClient
	client = system.net.httpClient(bypass_cert_validation=True)
	# Scale number and IP address
	scales = [['01','10.118.92.90'], ['02','10.118.92.91'], ['03','10.118.92.92'], 
				['04','10.118.92.93'], ['05','10.118.92.94'], ['06','10.118.92.95'], 
				['07','10.118.92.96'], ['08','10.118.92.97'], ['09','10.118.92.98']]
	
	for s in scales:
		tagpath = '[default]RBP/IO/CubisScale' + s[0]
		api_response = getReq(s[1],client)
		# Set response from scale
		system.tag.writeBlocking(tagpath + '/Source_Weight', api_response)
		# Set communication status
		if api_response == -99999:
			system.tag.writeBlocking(tagpath + '/Source_CommsOK', False)
		else:
			system.tag.writeBlocking(tagpath + '/Source_CommsOK', True)
