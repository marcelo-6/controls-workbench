'''***************************************************************************************************
	Procedure:          WM_API.Irubis
	Create Date:       	11Jun24
	Author:             Caroline Houston
	Description:        See documentation for more info on this script. Intended for use with WM_IrubisMIR_UDT
	Used By:			WM_IrubisMIR_UDT
	****************************************************************************************************
	SUMMARY OF CHANGES
	Version		Date(ddMMMyy)	Author		Comments
	----------------------------------------------------------------------------------------------------
	1.0			03Jun24			CH			Created, Released for QA
	1.1			11Jun24			MA			Updated to conform with FIRE LIB
***************************************************************************************************'''
########################################################################################################
##### Single httpClient object instance for connection to API
##### Global variables
########################################################################################################
# Create the JythonHttpClient.
import json
global logging
#logging = system.util.getLogger("PAT." + __name__)
logging = system.util.getLogger("PAT Logger - CM Tags")

client = system.net.httpClient(bypass_cert_validation=True, timeout=2000)
api_port_num = "5555" # seems to be a constant between different MIR
api_root_meas = "/api/"
api_csv_root_path = "E:\\SCADA_Exports\\IRUBIS_Mid_IR_Data\\"#"C:\\WME_Files\\archive\\Dump\\Irubis\\"

def is_faulted(response):
	if (response is not None and 
        response.statusCode == 200 and 
        'status' in response.json and 
        response.json['status'] == "200" and
        'result' in response.json):
		for alarm, status in response.json['result'].iteritems():
			if status: 
				return True
		return False
	else:
		return True
				

def get_csv_root_path():
	"""Function used to get the path that the CSV files are saved
	"""
	return api_csv_root_path


def heartbeat(ip,port):
    """
    Checks the health of the API.
    
    Returns
    -------
    bool
        True if the web app is running/healthy, False otherwise.
    """
    try:
        base_url = "http://{0}:{1}".format(ip, port)
        url = "{0}/{1}".format(base_url, "api/general/check_device")
        
        response = client.get(url, timeout=1000)
		
        if (response is not None and 
            response.statusCode == 200 and 
            'status' in response.json and 
            response.json['status'] == "200"):
            return 1
        else:
            return 0
			
    except (Exception, IOError) as e:
        logging.debug("Heartbeat failed for {0}: {1}".format(base_url, str(e)))
        return 0



def get_alarms(ip,port):
	"""
	Checks the alarms
	
	Returns
	-------
		dict alarm status false if error
		{
			'IR_emitter_temperature_controller': False, 
		 	'IR_emitter_temperature': False, 
		 	'battery': False, 
		 	'laser_temperature': False, 
		 	'scanner_drive': False, 
		 	'IR_emitter_open_circuit': False, 
		 	'detector_2_temperature': False, 
		 	'IR_emitter_over_voltage': False, 
		 	'detector_temperature': False, 
		 	'initialisation_mode': False
		}
	"""
	try:
		base_url = "http://{0}:{1}".format(ip, port)
		url = "{0}/{1}".format(base_url,"api/spectrometer/alarm")
		response = client.get(url, timeout=1000)
		
		if is_faulted(response):
			return 0
		else:
			return 1
			
	except (Exception, IOError) as e:
		logging.debug("get_spectrometer_alarm failed for {0}: {1}".format(base_url, str(e)))
        print "get_spectrometer_alarm failed for {0}: {1}".format(base_url, str(e))
        return False


def get_n_samples(ip,port,run_name):
	"""
	Retrieves the number of samples, i.e., the number of datapoints of a stored or currently running measurement given its name.
	
	Returns
	-------
	Number of samples False otherwise.
	"""
	try:
		base_url = "http://{0}:{1}".format(ip, port)
		url = "{0}/{1}{2}{3}".format(base_url,"api/storage/",run_name,"/n_samples")
		response = client.get(url, timeout=1000)
		
		if response != None and response.statusCode == 200 and response.json['status'] == "200":
			return response.json['result']
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("get_n_samples failed for {0}: {1}".format(base_url, str(e)))
        return False


def get_current(ip, port):
	"""
	Retrieves the currently running measurement name.
	
	Returns a list containing the name of the currently running measurement, or false if no measurement or failure
	"""
	try:
		base_url = "http://{0}:{1}".format(ip, port)
		url = "{0}/api/continuous_measurement/running_measurements".format(base_url)
		response = client.get(url, timeout=1000)
		if response != None and response.json['result']!= [None] and response.statusCode == 200 and response.json['status'] == "200":
			return response.json['result']
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("get_current failed for {0}: {1}".format(base_url, str(e)))
        return False	


def get_data(ip,port,run_name, from_idx, to_idx):
	"""
	Retrieves the spectral data of a stored or currently running measurement given its name.

	There are three possible data sets that can be retrieved:

    the actual energy spectrum A (source = internal and attribute = cell)

    the internal reference energy spectrum B (source = internal and attribute = reference).

    For the evaluation light mode (see the endpoint /api/storage/{name}/light_mode), this is just a plain copy of A.

    the absorbance spectrum C (source = processed and attribute = measurements)

    (the corresponding wavenumbers can be retrieved via the wavenumbers-parameter returned by the endpoint /api/storage/{name}/params)
	 
	Returns
	-------
	data False otherwise.
	"""
	try:
		base_url = "http://{0}:{1}".format(ip, port)
		url = "{0}/{1}{2}{3}{4}{5}{6}".format(base_url,"api/storage/",run_name,"/data/processed/measurements?index_from=",from_idx,"&index_to=",to_idx)
		response = client.get(url, timeout=1000)
		
		if response != None and response.statusCode == 200 and response.json['status'] == "200":
			return response.json['result']
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("get_data run_name:{0}, from:{1} to:{2} failed for {3}: {4}".format(run_name, from_idx, to_idx,  base_url, str(e)))
        return False


def get_last_measurament(ip,port):
	"""
	Retrieves the spectral data of a stored or currently running measurement given its name.

	There are three possible data sets that can be retrieved:

    the actual energy spectrum A (source = internal and attribute = cell)

    the internal reference energy spectrum B (source = internal and attribute = reference).

    For the evaluation light mode (see the endpoint /api/storage/{name}/light_mode), this is just a plain copy of A.

    the absorbance spectrum C (source = processed and attribute = measurements)

    (the corresponding wavenumbers can be retrieved via the wavenumbers-parameter returned by the endpoint /api/storage/{name}/params)
	 
	Returns
	-------
	data False otherwise.
	"""
	try:
		run_name = get_current(ip, port)
		if isinstance(run_name, list) and len(run_name) > 0:
			print run_name
			run_name  = str(run_name[0])
			idx = get_n_samples(ip, port, run_name)
			print idx
			if isinstance(idx, (long)):
				if idx > 0:
					data = get_data(ip,port,run_name, idx-1, idx-1) 
					if isinstance(data, list):
						return data
					else:
						if logging.isDebugEnabled():
							logging.debug("get_last_measurament get_data({0},{1},{2},{3},{4}) did not return a list".format(ip,port,run_name, idx-1, idx-1))
						return False
				else:
					if logging.isDebugEnabled():
						logging.debug("get_last_measurament get_n_samples({0},{1},{2}) = 0 ".format(ip,port,run_name))
					return False
			else:
				if logging.isDebugEnabled():
					logging.debug("get_last_measurament get_n_samples({0},{1},{2}) is not a number ".format(ip,port,run_name))
				return False
		else:
			if logging.isDebugEnabled():
				logging.debug("get_last_measurament get_current({0},{1}) did not return a list".format(ip,port))
			return False
			
	except (Exception, IOError) as e:
		logging.debug("get_last_measurament failed: {0}".format(str(e)))
        return False


def get_params(ip,port,run_name):
	"""
	Retrieves the measurement parameters of a stored or currently running measurement given its name, i.e., 
	all the settings and states of the measurement at the time of calling this endpoint.
	 
	Returns
	-------
	list params False otherwise.
	"""
	try:
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/{1}{2}{3}'.format(base_url,"api/storage/",run_name,"/params")
		response = client.get(url, timeout=1000)
		
		if response != None and response.statusCode == 200 and response.json['status'] == "200":
			return response.json['result']
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("get_params run_name:{0} failed for {1}: {2}".format(run_name, base_url, str(e)))
        return False
		

def get_details(ip,port,run_name):
	"""
	Retrieves the run-specific data of a stored or currently running measurement given its name, 
	e.g., the start, stop, and runtime..
	 
	Returns
	-------
	return details list  False otherwise.
	"""
	try:
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/{1}{2}{3}'.format(base_url,"api/storage/",run_name,"/details")
		response = client.get(url, timeout=1000)
		
		if response != None and response.statusCode == 200 and response.json['status'] == "200":
			return response.json['result']
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("get_details run_name:{0} failed for {1}: {2}".format(run_name, base_url, str(e)))
        return False


def get_cell_availability(ip,port):
	"""Retrieves the availability status of the flow cell.
		Returns a list containing one value that indicates the current status. Possible values are:
		
		True: the flow cell is available for a new measurement
		False: the flow cell is currently in use
		"pending": the flow cell is currently in use, but the measurement is stopping
    """
	try:
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/{1}'.format(base_url,"api/continuous_measurement/cells_availability")
		response = client.get(url)
	
		if [response.json['result']][0] == [True] :
			return "Ready"
		if [response.json['result']][0] == ["pending"] :
			return "Pending"
		if [response.json['result']][0] == [False] :
			return "Measuring"
	except (Exception, IOError) as e:
		logging.debug("get_cell_availability failed for {0}: {1}".format(base_url, str(e)))
        return False


def start_measurement(ip, port, run_name):
    """
    Start a new measurement based on the current configuration and provided parameters.
    
    Args:
        ip (str): IP address of the server
        port (str): Port number of the server
        run_name (str): Name of the measurement run (e.g., "my_measurement")
        components (list): List of components to measure (e.g., ["glucose", "lactate", "protein"])
    
    Returns:
        result (bool/dict): Result of the measurement start or False if failed
    """
    try:
        base_url = 'http://{0}:{1}'.format(ip, port)
        url = '{0}/api/continuous_measurement?name={1}'.format(base_url,run_name)
        response = client.post(url, data=['glucose', 'lactate', 'protein'])
        logging.debug("start_measurement run_name response:{0}".format(response))
        print "start_measurement run_name response:{0}".format(response.json)
        if response.statusCode == 200: # response.json['status'] == "200": # and response.json['message'] == "OK":
            return True
        else:
            return False
            
    except (Exception, IOError) as e:
        logging.debug("start_measurement run_name:{0} failed for {1}: {2}".format(run_name, base_url, str(e)))
        print "start_measurement run_name:{0} failed for {1}: {2}".format(run_name, base_url, str(e))
        return False


def pause_current_measurement(ip,port):
	"""
	Pauses the currentl measurement session
	
	Returns
	-------
	bool
	    True if the xxxx False otherwise.
	"""
	try:
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/api/continuous_measurement/pause_control?value=true'.format(base_url)

		response = client.put(url)
		
		if response.json['message'] == 'OK':
			return True
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("pause_current_measuremen failed for {0}: {1}".format(base_url, str(e)))
        return False
	

def pause_current_measurement_ext(ip,port, tag_paths):
	"""
	Pauses the currentl measurement session
	
	Returns
	-------
	bool
	    True if the xxxx False otherwise.
	"""
	try:
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/api/continuous_measurement/pause_control?value=true'.format(base_url)

		response = client.put(url)
		
		if response.json['message'] == 'OK':
			system.tag.writeBlocking(tag_paths, [31,"Measurement Paused"])
			return True
		else:
			system.tag.writeBlocking(tag_paths, [33,"No Active Measurement"])
			return False
	except (Exception, IOError) as e:
		system.tag.writeBlocking(tag_paths, [32,"pause_current_measurement_ext failed"])
		logging.debug("pause_current_measuremen failed for {0}: {1}".format(base_url, str(e)))
        return False
        

def resume_current_measurement(ip,port):
	"""
	unpauses (resumes) the currentl measurement session
	
	Returns
	-------
	bool
	    True if the xxxx False otherwise.
	"""
	try:
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/api/continuous_measurement/pause_control?value=false'.format(base_url)

		response = client.put(url)
		
		if response.json['message'] == 'OK':
			return True
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("resume_current_measuremen failed for {0}: {1}".format(base_url, str(e)))
        return False


def cancel_current_measurement(ip,port):
	"""
	delete the current measurement session
	
	Returns
	-------
	bool
	    True if the xxxx False otherwise.
	"""
	try:
		logging.debug("cancel_current_measurement called with IP:{0}, PORT:{1}".format(ip, port))
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/api/continuous_measurement'.format(base_url)

		response = client.delete(url)
		logging.debug("Here 3 response={0}".format(response))	
		if response.json['message'] == 'OK':
			return True
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("cancel_current_measurement failed for {0}: {1}".format(base_url, str(e)))
        return False

def cancel_current_measurement_ext(ip,port, tag_paths):
	"""
	delete the current measurement session
	
	Returns
	-------
	bool
	    True if the xxxx False otherwise.
	"""
	try:
		logging.debug("cancel_current_measurement_ext called with IP:{0}, PORT:{1} PATHS:{2}".format(ip, port, tag_paths))
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/api/continuous_measurement/pause_control?value=true'.format(base_url)
		response = client.put(url)		
		url = '{0}/api/continuous_measurement'.format(base_url)
		response = client.delete(url)
		if response.json['message'] == 'OK':
			system.tag.writeBlocking(tag_paths, [31,"Measurement Canceled"])
			logging.debug("cancel_current_measurementext: Measurement Canceled Done")
			return True
		else:
			system.tag.writeBlocking(tag_paths, [33,"No Active Measurement"])
			logging.debug("cancel_current_measurementext: No Active Measurament")
			return False
	except (Exception, IOError) as e:
		system.tag.writeBlocking(tag_paths, [32,"cancel_current_measurement failed"])
		logging.debug("cancel_current_measurement failed for {0}: {1}".format(base_url, str(e)))
        return False

def delete_measurement(ip,port,run_name):
	"""
	Remove a measurement from the file manager
	-------
	bool
		True if deleted 
	"""
	try:
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/{1}{2}'.format(base_url,"api/file_manager/delete_measurements?measurements_list=",run_name)
		response = client.delete(url)
		
		if response != None and response.statusCode == 200 and response.json['status'] == "200":
			return True
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("get_params run_name:{0} failed for {1}: {2}".format(run_name, base_url, str(e)))
        return False



def get_list(ip,port):
	"""GET to retreive all measurements
	    
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
		    
	    Returns
	    -------
	    result: `list`
	    	list of all measurments stored on MIR device
    """
	try:
		base_url = 'http://{0}:{1}'.format(ip, port)
		url = '{0}/api/storage'.format(base_url)
		response = client.get(url)
		
		if response.json['message'] == "OK":
			return response.json['result']
		else:
			return False
	except (Exception, IOError) as e:
		logging.debug("get_list failed for {0}: {1}".format(base_url, str(e)))
        return False


def dev_get_download(ip, file_name, file_extension):
	"""GET to retrive the absorbance spectra with the given measurement 
		in the given file format
	    
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    file_name : `str`
	    	file name of the measurment to retrieve
	    file_extension : `str`
	    	file type to retrieve
	    Returns
	    -------
	    result : `csv`/etc
	        
    """
	# A GET request is made to the storage endpoint to retrieve the {.type} file for the specified run.
	response = client.get('http://{0}:{1}{2}storage/get_{3}_measurements?measurements_list={4}'.format(ip, api_port_num,api_root_meas,file_extension,file_name))
	import java.lang.Exception
	try:
		# Specify the filename for saving the CSV content locally.
		date = system.date.now()
		data_format = system.date.format(date, "_ddMMMyy_HHmmss")
		filename = (api_csv_root_path + file_name + data_format + '.' + file_extension)
		
		if response.statusCode == 200:
			with open(filename, 'wb') as file:
				file.write(response.body)
			
	except (Exception, IOError) as e:
		logging.debug("dev_get_download failed :{0}".format(str(e)))
		