'''***************************************************************************************************
	Procedure:          WM_API.Avantes
	Create Date:       	31May24
	Author:             Marcelo Amorim
	Description:        See documentation for more info on this script. Intended for use with WM_AvantesNIR_UDT
	Used By:			WM_AvantesNIR_UDT
	****************************************************************************************************
	SUMMARY OF CHANGES
	Version		Date(ddMMMyy)	Author		Comments
	----------------------------------------------------------------------------------------------------
	1.0			03Jun24			MA			Created
	1.1			17Jun24			MA			Added try catch for heartbeat  call
	***************************************************************************************************'''
########################################################################################################
##### Single httpClient object instance for connection to API
##### Global variables
########################################################################################################
client = system.net.httpClient()
api_root_comms = "/api/v1/comms"
api_root_meas = "/api/v1/meas"
api_csv_root_path = "E:\\SCADA_Exports\\Avantes_NIR_Data\\"##"C:\\WME_Files\\archive\\Dump\\"

def get_csv_root_path():
	"""Function used to get the path that the CSV files are saved
	"""
	return api_csv_root_path

def dev_get_available(ip,port):
	"""GET to browse for available Avantes NIR devices
	    
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        List of serial number of devices and their statuses
	    response status code: `int`
	        Rest API response code.
	    """
	response = client.get('http://{0}:{1}{2}'.format(ip, port,api_root_comms))
	return response

def dev_get_heartbeat(ip,port,sn):
	"""GET to browse for available Avantes NIR device (used as heartbeat)
	    
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    sn : `str`
	        The serial number of device.
	
	    Returns
	    -------
	    result : `int`
	        1=device status is available, 0= not available or error.
	    """
	#payload = {'loggerName':'WM_AvantesNIR_UDT','level':'error','message':ip + "," + port+ "," +sn}
	#system.util.sendMessage(project=system.util.getProjectName(), messageHandler='logger',payload=payload) 
	try:
		response = client.get('http://{0}:{1}{2}/{3}'.format(ip, port,api_root_comms,sn))
		
		result = False
		if response != "" and response.statusCode == 200:
			if response.json['data'] == "Available":
				result = True
		
		return result
	except:
		return False

def meas_get_status(ip,port,sn):
	"""GET to measurement status of given device serial number
	    
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    sn : `str`
	        The serial number of device.
	
	    Returns
	    -------
	    result : `str`
	        device measurment status (ready, not ready, measuring)
	    """
	#payload = {'loggerName':'WM_AvantesNIR_UDT','level':'error','message':ip + "," + port+ "," +sn}
	#system.util.sendMessage(project=system.util.getProjectName(), messageHandler='logger',payload=payload) 
	try:
		response = client.get('http://{0}:{1}{2}/status_{3}'.format(ip, port,api_root_meas,sn))
		
		result = "Not Ready"
		if response != "" and response.statusCode == 200:
			result = response.json['data']
		
		return result
	except:
		return "Not Ready"

def dev_put_activate(ip,port,sn):
	"""PUT to activate device by given serial number
		activated devices listen to measurement start/stop commands
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    sn : `str`
	        The serial number of device.
	
	    Returns
	    -------
	    response data : `json`
	        Serial number of device and their statuses
	    response status code: `int`
	        Rest API response code.
	    """
	response = client.put('http://{0}:{1}{2}/{3}'.format(ip, port,api_root_comms,sn))
	return response

def dev_del_deactivate(ip,port,sn):
	"""DELETE to deactivate device by given serial number
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    sn : `str`
	        The serial number of device.
	
	    Returns
	    -------
	    response data : `json`
	        Serial number of device and their statuses
	    response status code: `int`
	        Rest API response code.
	    """
	response = client.delete('http://{0}:{1}{2}/{3}'.format(ip, port,api_root_comms,sn))
	return response

def meas_post_start(ip,port,sn):
	"""POST to start measurement on device by given serial number
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    sn : `str`
	        The serial number of device.
	
	    Returns
	    -------
	    response data : `json`
	        Serial number of device and their statuses
	    response status code: `int`
	        Rest API response code.
	    """
	response = client.post('http://{0}:{1}{2}/{3}'.format(ip, port,api_root_meas,sn))
	return response

def meas_put_config(ip,port,sn,cfg):
	"""PUT to configure measurement settings on device by given serial number
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    sn : `str`
	        The serial number of device.
	    cfg : 'json'
	    	The configuration of mesurement in the following format:
	    	        'number_of_measurements': {'type': 'integer',"minimum":-1},
	    	        'integration_time': {'type': 'number',"minimum":1},
	    	        'number_of_averages': {'type': 'integer',"minimum":1}
	
	    Returns
	    -------
	    response data : `json`
	        Serial number of device and their statuses
	    response status code: `int`
	        Rest API response code.
	    """
	response = client.put('http://{0}:{1}{2}/{3}'.format(ip, port,api_root_meas,sn),data=cfg)
	return response

def meas_del_stop(ip,port,sn):
	"""DELETE to stop measurement on device by given serial number
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    sn : `str`
	        The serial number of device.
	
	    Returns
	    -------
	    response data : `json`
	        Serial number of device and their statuses
	    response status code: `int`
	        Rest API response code.
	    """
	response = client.delete('http://{0}:{1}{2}/{3}'.format(ip, port,api_root_meas,sn))
	return response
	
def meas_get_data(ip,port,sn,csv):
	"""GET to get measurement on device by given serial number
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    sn : `str`
	        The serial number of device.
	    csv: `str`
	        file name to save (date will be appended)
	        
	    Returns
	    -------
	    response data : `json`
	        Serial number of device and their statuses
	    response status code: `int`
	        Rest API response code.
	    """
	response = client.get('http://{0}:{1}{2}/{3}?csv={4}'.format(ip, port,api_root_meas,sn,1))
	import java.lang.Exception
	try:
		# Specify the filename for saving the CSV content locally.
		date = system.date.now()
		date_format = system.date.format(date, "_ddMMMyy_HHmmss")
	
		filename = api_csv_root_path + csv + date_format + '.csv'

		if response.statusCode == 200:
			import csv
			with open(filename, 'w') as csvfile:
				csvwriter = csv.writer(csvfile)
				ret = csvwriter.writerows(response.json['data'])
	except Exception as e:
		template = "Exception trying to get measurement data, An exception of type {0} occurred. Arguments:\n{1!r}"
		message = template.format(type(e).__name__, e.args)
		print(message)
		raise e
	except java.lang.Exception as e:
		raise e
	finally:
		return response