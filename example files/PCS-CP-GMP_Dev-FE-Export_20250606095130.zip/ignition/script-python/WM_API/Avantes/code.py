'''***************************************************************************************************
	Procedure:          WM_API.Avantes
	Create Date:       	31May24
	Author:             Marcelo Amorim
	Description:        See documentation for more info on this script. Intended for use with WM_AvantesNIR_UDT
	Used By:			WM_AvantesNIR_UDT
	****************************************************************************************************
	SUMMARY OF CHANGES
	Version		Date(ddMMMyy)	Author		Comments
	----------------------------------------------------------------------------------------------------
	1.0			03Jun24			MA			Created
	1.1			17Jun24			MA			Added try catch for heartbeat  call
	1.2			28Jan25			MA			Updated endpoints per Flask to FastAPI migration
	***************************************************************************************************'''
########################################################################################################
##### Single httpClient object instance for connection to API
##### Global variables
########################################################################################################
client = system.net.httpClient(version="HTTP_1_1", timeout=60000)
api_root_comms = "/comms"
api_root_meas = "/meas"
api_csv_root_path = "C:\\WME_Files\\archive\\Dump\\"##"C:\\WME_Files\\archive\\Dump\\"


def get_communication(ip, port):
    """
    Retrieve the list of available Avantes NIR devices.

    Parameters
    ----------
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.

    Returns
    -------
    response : dict or None
        The response from the server or None if an error occurs.
    """
    try:
        url = "http://{}:{}{}".format(ip, port,api_root_comms)
        response = client.get(url)
        return response
    except Exception as e:
        template = "Exception occurred. An exception of type {0} occurred. Arguments:\n{1!r}"
        message = template.format(type(e).__name__, e.args)
        print(message)
        return None

def get_single_communication(ip, port, sn):
    """
    Check if a specific device is available and activate it if necessary.

    Parameters
    ----------
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.
    sn : str
        The serial number of the device.

    Returns
    -------
    response : dict or None
        The response from the server or None if an error occurs.
    """
    try:
        url = "http://{}:{}{}/{}".format(ip, port,api_root_comms, sn)
        response = client.get(url)
        return response
    except Exception as e:
        template = "Exception occurred. An exception of type {0} occurred. Arguments:\n{1!r}"
        message = template.format(type(e).__name__, e.args)
        print(message)
        return None

def put_communication(ip, port, sn):
    """
    Activate a device by its serial number.

    Parameters
    ----------
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.
    sn : str
        The serial number of the device.

    Returns
    -------
    response : dict or None
        The response from the server or None if an error occurs.
    """
    try:
        url = "http://{}:{}/{}".format(ip, port,api_root_comms, sn)
        response = client.put(url)
        return response
    except Exception as e:
        template = "Exception occurred. An exception of type {0} occurred. Arguments:\n{1!r}"
        message = template.format(type(e).__name__, e.args)
        print(message)
        return None

def del_communication(ip, port, sn):
    """
    Deactivate a device by its serial number.

    Parameters
    ----------
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.
    sn : str
        The serial number of the device.

    Returns
    -------
    response : dict or None
        The response from the server or None if an error occurs.
    """
    try:
        url = "http://{}:{}{}/{}".format(ip, port,api_root_comms, sn)
        response = client.delete(url)
        return response
    except Exception as e:
        template = "Exception occurred. An exception of type {0} occurred. Arguments:\n{1!r}"
        message = template.format(type(e).__name__, e.args)
        print(message)
        return None

def browse_devices(ip, port):
    """
    Retrieve the list of all connected devices.

    Parameters
    ----------
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.

    Returns
    -------
    response : dict or None
        The response from the server or None if an error occurs.
    """
    try:
        url = "http://{}:{}{}".format(ip, port,api_root_comms)
        response = client.get(url)
        return response
    except Exception as e:
        template = "Exception occurred. An exception of type {0} occurred. Arguments:\n{1!r}"
        message = template.format(type(e).__name__, e.args)
        print(message)
        return None

def meas_post_start(sn, ip, port, client):
    """
    Sends a POST request to start a measurement on a device by its serial number.

    Parameters
    ----------
    sn : str
        The serial number of the device.
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.
    client : JythonHttpClient
        The HTTP client object to make the request.

    Returns
    -------
    response : Response object
        The response from the API.
    """
    try:
        base_url = "http://{}:{}".format(ip, port)
        url = "{}{}/{}".format(base_url,api_root_meas, sn)
        
        headers = {"accept": "application/json"}
        response = client.post(url, headers=headers)

        return response
    except Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Arguments:\n{}"
        message = template.format(base_url, type(e).__name__, e.args)
        print(message)
        raise e
    except java.lang.Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Exception:\n{}"
        message = template.format(base_url, type(e).__name__, str(e))
        print(message)
        raise e

def meas_put_configure(sn, meas_settings, ip, port, client):
    """
    Sends a PUT request to configure measurement settings for a device by its serial number.

    Parameters
    ----------
    sn : str
        The serial number of the device.
    meas_settings : dict
        Measurement settings as a dictionary.
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.
    client : JythonHttpClient
        The HTTP client object to make the request.

    Returns
    -------
    response : Response object
        The response from the API.
    """
    try:
        base_url = "http://{}:{}".format(ip, port)
        url = "{}{}/{}".format(base_url,api_root_meas, sn)
        
        headers = {"Content-Type": "application/json", "accept": "application/json"}
        response = client.put(url, headers=headers, data=meas_settings)

        return response
    except Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Arguments:\n{}"
        message = template.format(base_url, type(e).__name__, e.args)
        print(message)
        raise e
    except java.lang.Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Exception:\n{}"
        message = template.format(base_url, type(e).__name__, str(e))
        print(message)
        raise e

def meas_delete_stop(sn, ip, port, client):
    """
    Sends a DELETE request to stop a measurement on a device by its serial number.

    Parameters
    ----------
    sn : str
        The serial number of the device.
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.
    client : JythonHttpClient
        The HTTP client object to make the request.

    Returns
    -------
    response : Response object
        The response from the API.
    """
    try:
        base_url = "http://{}:{}".format(ip, port)
        url = "{}{}/{}".format(base_url,api_root_meas, sn)
        
        headers = {"accept": "application/json"}
        response = client.delete(url, headers=headers)

        return response
    except Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Arguments:\n{}"
        message = template.format(base_url, type(e).__name__, e.args)
        print(message)
        raise e
    except java.lang.Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Exception:\n{}"
        message = template.format(base_url, type(e).__name__, str(e))
        print(message)
        raise e

def meas_get_data(sn, ip, port, client, data_scope="all"):
    """
    Sends a GET request to retrieve measurement data for a device by its serial number.

    Parameters
    ----------
    sn : str
        The serial number of the device.
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.
    client : JythonHttpClient
        The HTTP client object to make the request.
    data_scope : str, optional
        Scope of the data to retrieve (default is "all").

    Returns
    -------
    response : Response object
        The response from the API.
    """
    try:
        base_url = "http://{}:{}".format(ip, port)
        url = "{}{}/{}?data_scope={}".format(base_url,api_root_meas, sn, data_scope)
        
        headers = {"accept": "application/json"}
        response = client.get(url, headers=headers)

        return response
    except Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Arguments:\n{}"
        message = template.format(base_url, type(e).__name__, e.args)
        print(message)
        raise e
    except java.lang.Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Exception:\n{}"
        message = template.format(base_url, type(e).__name__, str(e))
        print(message)
        raise e

def meas_get_status(sn, ip, port, client):
    """
    Sends a GET request to retrieve the measurement status for a device by its serial number.

    Parameters
    ----------
    sn : str
        The serial number of the device.
    ip : str
        The IP address of the FastAPI server.
    port : str
        The port of the FastAPI server.
    client : JythonHttpClient
        The HTTP client object to make the request.

    Returns
    -------
    response : Response object
        The response from the API.
    """
    try:
        base_url = "http://{}:{}".format(ip, port)
        url = "{}{}}/{}/status".format(base_url,api_root_meas, sn)
        
        headers = {"accept": "application/json"}
        response = client.get(url, headers=headers)

        return response
    except Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Arguments:\n{}"
        message = template.format(base_url, type(e).__name__, e.args)
        print(message)
        raise e
    except java.lang.Exception as e:
        template = "Exception trying {}, An exception of type {} occurred. Exception:\n{}"
        message = template.format(base_url, type(e).__name__, str(e))
        print(message)
        raise e