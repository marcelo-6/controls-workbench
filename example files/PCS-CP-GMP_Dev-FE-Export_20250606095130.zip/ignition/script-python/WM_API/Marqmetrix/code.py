'''***************************************************************************************************
	Procedure:          WM_API.Marqmetrix
	Create Date:       	16SEP24
	Author:             Caroline Houston
	Description:        See documentation for more info on this script. Intended for use with WM_MarqmetricRAMAN_UDT
	Used By:			WM_MarqmetrixRAMAN_UDT
	****************************************************************************************************
	SUMMARY OF CHANGES
	Version		Date(ddMMMyy)	Author		Comments
	----------------------------------------------------------------------------------------------------
	1.0			16SEP24			CH			Created
	***************************************************************************************************'''
########################################################################################################
##### Single httpClient object instance for connection to API
##### Global variables
########################################################################################################
import hmac
import hashlib
import base64
import urllib
import urllib2
from datetime import datetime

client = system.net.httpClient(timeout=4000)
### pass headers
api_root_comms = "api/"
api_root_instrument = "api/Instrument"

global api_key
global content_type
#api_key = 'pm/aiIsEui7DFx3JbaM0EtWPjupF9X33jBCzGlTmx22yPFSmHjk7WhnO3UJxi+23kcjTkxQG5LHx4vx6UKDZ3Q=='
content_type = 'application/json'
    
def generate_auth_key(method, url_path, content_type, api_key):
	
	# Current date in RFC 1123 format
	request_date = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
	
	# Create string to hash
	string_to_hash = "\n".join([method,url_path,content_type,request_date])
	print "Authorization String:", string_to_hash
	
	# Generate HMAC SHA256 hash
	signature = hmac.new(
		msg = string_to_hash.encode('utf-8'), # string to bytes
		key = base64.b64decode(api_key.encode('utf-8')),  # Decode the API key
		digestmod = hashlib.sha256).digest()
	
	auth_token = base64.b64encode(signature).decode('utf-8')  # Decode to string
	# print "Authorization Token:", auth_token
	
	return auth_token, request_date

def format_duration(milliseconds):
    # Calculate total seconds, minutes, and hours from milliseconds
    total_seconds = milliseconds // 1000
    milliseconds_remaining = milliseconds % 1000
    
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    
    # Format the string
    formatted_time = "{:02}:{:02}:{:02}.{:04}".format(hours, minutes, seconds, milliseconds_remaining)
    return formatted_time


def security_get_short_code(ip,port):
	"""GET to connect to IM (Instrument Manager) on instrument 
	    
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        GenerationId
	    response status code: `int`
	        Rest API response code.
	    """
	response = client.get('http://{0}:{1}/{2}Security/GenerateShortCode'.format(ip, port, api_root_comms))
	return response

def security_post_access_key(ip,port,cfg):
	"""POST to send access key to device by short code
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    sn : `str`
	        The short code from the device
	
	    Returns
	    -------
	    response data : `json`
	        Primary api key of the device
	    response status code: `int`
	        Rest API response code.
	    """
	response = client.post('http://{0}:{1}/{2}Security/AccessKey'.format(ip, port, api_root_comms),data=cfg)
	return response


def instrument_get_instrument(ip,port,api_key):
	"""GET to obtain information about device
	    
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        List of information about the device
	    response status code: `int`
	        Rest API response code.
	    """
	method = 'GET'  # HTTP method
	url_path = '{0}'.format(api_root_instrument) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	
	response = client.get('http://{0}:{1}/{2}'.format(ip,port,api_root_instrument),headers=headers)
	return response

def instrument_get_instrument_interlcoks(ip,port,api_key,timeout=5000):
	"""GET to obtain information about device
	    
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        List of information about the device
	    response status code: `int`
	        Rest API response code.
	    """
	method = 'GET'  # HTTP method
	url_path = '{0}'.format(api_root_instrument) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	
	try:
		response = client.get('http://{0}:{1}/{2}'.format(ip,port,api_root_instrument),headers=headers,timeout=timeout)
		
		result = False
		if (response.json['isLaserEnabled'] and 
		response.json['isLaserEnabled'] and 
		response.json['metadata']['DoorInterlock1'] and 
		response.json['metadata']['DoorInterlock2'] and 
		response.json['metadata']['RemoteInterlock'] and 
		response.json['metadata']['ProbeInterlock'] and 
		response.json['metadata']['KeyInterlock']):
			result = True
		
		return result
	except:
		return False

	return result

def instrument_put_laser_enabled(ip,port,api_key):
	"""PUT to enable laser on device
	
		Parameters
		----------
		ip : `str`
			IP of API connection
		port : `str`
			port of API connection
		cfg : 'json'
			The configuration of mesurement in the following format:
			        'isLaserEnabled': {'type': 'integer'},
		
		Returns
		-------
		response data : `json`
		    isLaserEnabled and status
		response status code: `int`
		    Rest API response code.
		"""
	method = 'PUT'  # HTTP method
	url_path = '{0}'.format(api_root_instrument) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	
	cfg = {
	"isLaserEnabled": 1
	}
	response = client.put('http://{0}:{1}/{2}'.format(ip, port,api_root_instrument),data=cfg,headers=headers)
	return response

def instrument_put_laser_disabled(ip,port,api_key):
	"""PUT to disable laser on device
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	    cfg : 'json'
			The configuration of mesurement in the following format:
			        'isLaserEnabled': {'type': 'integer'},
	
	    Returns
	    -------
	    response data : `json`
	        isLaserDisabled and status
	    response status code: `int`
	        Rest API response code.
	    """
	method = 'PUT'  # HTTP method
	url_path = '{0}'.format(api_root_instrument) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	
	cfg = {
	"isLaserEnabled": 0
	}
	response = client.put('http://{0}:{1}/{2}'.format(ip, port,api_root_instrument),data=cfg,headers=headers)
	return response

def instrument_get_calibration_list(ip,port,api_key):
	"""GET caliration list
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        Calibration information.  Passing only id, status, and created to the UDT.
	    response status code: `int`
	        Rest API response code.
	    """
	method = 'GET'  # HTTP method
	url_path = '{0}/Calibration'.format(api_root_instrument) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	response = client.get('http://{0}:{1}/{2}/Calibration'.format(ip,port,api_root_instrument),headers=headers)
	
	json = response.json
	items = json["items"]
	
	headers = ["id", "createdBy", "created"]
	dataset = []
	for i in items :
		dataset.append([i["id"], i["createdBy"], i["created"]])
	ids = system.dataset.toDataSet(headers, dataset)
	
	return response, ids

def instrument_get_calibration_data(ip,port,api_key,cfg):
	"""GET calibration data
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        Calibration data.
	    response status code: `int`
	        Rest API response code.
	    """
	
	method = 'GET'  # HTTP method
	url_path = '{0}/Calibration/{1}'.format(api_root_instrument, cfg) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	response = client.get('http://{0}:{1}/{2}/Calibration/{3}'.format(ip,port,api_root_instrument,cfg),headers=headers)
	
	return response


def meas_post_sample_list(ip,port,api_key):
	"""POST sample list
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        Calibration information.  Passing only completed samples.
	    response status code: `int`
	        Rest API response code.
	    """
	method = 'POST'  # HTTP method
	url_path = '{0}/Samples'.format(api_root_instrument) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	cfg = {"maximumResults": 100,
	}
	response = client.post('http://{0}:{1}/{2}/Samples'.format(ip,port,api_root_instrument),data=cfg,headers=headers)
	
	json = response.json
	items = json["items"]
	
	headers = ["id", "status", "created"]
	dataset = []
	for i in items :
		dataset.append([i["id"], i["status"], i["created"]])
	ids = system.dataset.toDataSet(headers, dataset)
	
	return response,ids

def meas_post_sample_start(ip,port,api_key,values):
	"""POST to start measurement on device
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        
	    response status code: `int`
	        Rest API response code.
	    """
	method = 'POST'  # HTTP method
	url_path = '{0}/AcquireSample'.format(api_root_instrument) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	
	formatted_time = format_duration(values[0])
	
	if values[3] == 0:
		outputAxisAlignment = "Wavelength"
	elif values[3] == 1:
		outputAxisAlignment = "RamanShift"
		
	if values[4] == 0:
		outputProcessingType = "Raw"
	elif values[4] == 1:
		outputProcessingType = "DarkSubtraction"
	elif values[4] == 2:
		outputProcessingType = "IntensityCorrection"
	
	if values[6] == 0:
		outputFileFormat = "SPC"
		fileExtension = ".spc"
	elif values[6] == 1:
		outputFileFormat = "Text"
		fileExtension = ".txt"
	
	
	if values[2] == 0: #laserPower is '0' so dark sample
		cfg = {
		    'integrationTime': formatted_time,
		    'sampleAverageCount': values[1],
		    'laserPower': values[2],
		    "failureRetryCount": 2,
			'metadata': {
			},
			'pushSettings': {
				'outputAxisAlignment': outputAxisAlignment,
				'outputProcessingType': outputProcessingType,
				'outputFileFormat': outputFileFormat,
				"pushType": "File",
			    'directoryName': values[7],
			    "filenameScheme": "Data_"+values[5]+fileExtension,
			    'skipDarkSamples': int(values[8]),
			    'faultOnFailure': int(values[9]),
			    'standardizedXAxis': int(values[10])
			}
		}
	else:
	
		darkSample = values[11]
		dark_sample_format = darkSample.replace('"', '')
	
		cfg = {
		    'integrationTime': formatted_time,
		    'sampleAverageCount': values[1],
		    'laserPower': values[2],
		    "failureRetryCount": 2,
			'metadata': {
			    "DarkSampleId": dark_sample_format
			},
			'pushSettings': {
				'outputAxisAlignment': outputAxisAlignment,
				'outputProcessingType': outputProcessingType,
				'outputFileFormat': outputFileFormat,
				"pushType": "File",
			    'directoryName': values[7],
			    "filenameScheme": "Data_"+values[5]+fileExtension,
			    'skipDarkSamples': int(values[8]),
			    'faultOnFailure': int(values[9]),
			    'standardizedXAxis': int(values[10])
			}
		}
	
	response = client.post('http://{0}:{1}/{2}/AcquireSample'.format(ip,port,api_root_instrument),data=cfg,headers=headers)
	
	return response

def meas_get_sample_status(ip,port,api_key,cfg):
	"""GET for sample status
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        Sample status
	    response status code: `int`
	        Rest API response code.
	    """
#	response, ids_info, ids = meas_post_sample_list(ip,port)
#	
#	cfg = ids_info.getValueAt(0,0)
	
	method = 'GET'  # HTTP method
	url_path = '{0}/Samples/{1}'.format(api_root_instrument, cfg) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	
	response = client.get('http://{0}:{1}/{2}/Samples/{3}'.format(ip,port,api_root_instrument,cfg),headers=headers)
	
	return response

def meas_get_status(ip,port,api_key):
	"""GET for sample status
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        Sample status
	    response status code: `int`
	        Rest API response code.
	    """
	response, ids_info, ids = meas_post_sample_list(ip,port)
	
	cfg = ids_info.getValueAt(0,0)
	
	method = 'GET'  # HTTP method
	url_path = '{0}/Samples/{1}'.format(api_root_instrument, cfg) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	
	response = client.get('http://{0}:{1}/{2}/Samples/{3}'.format(ip,port,api_root_instrument,cfg),headers=headers)
	status = str(response.json["status"])
	
	return status

def meas_get_sample_data(ip,port,api_key,cfg):
	"""GET calibration data
	
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    response data : `json`
	        Calibration data.
	    response status code: `int`
	        Rest API response code.
	    """
#	response, ids = meas_post_sample_list(ip,port)
#	cfg = ids.getValueAt(0,0)
	
	method = 'GET'  # HTTP method
	url_path = '{0}/Samples/{1}/Data'.format(api_root_instrument, cfg) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	
	response = client.get('http://{0}:{1}/{2}/Samples/{3}/Data'.format(ip,port,api_root_instrument,cfg),headers=headers)
	
	return response

def dev_get_heartbeat(ip,port,api_key,timeout=5000):
	"""GET to browse for available RAMAN device (used as heartbeat)
	    
	    Parameters
	    ----------
	    ip : `str`
	    	IP of API connection
	    port : `str`
	    	port of API connection
	
	    Returns
	    -------
	    result : `int`
	        1=device status is available, 0= not available or error.
	    """
	method = 'GET'  # HTTP method
	url_path = '{0}'.format(api_root_instrument) # API endpoint
	auth_key, request_date = generate_auth_key(method, url_path, content_type, api_key)
	
	headers = {
	    "Date": request_date,
	    "Authorization": ('SharedKey {}'.format(auth_key)),
	    "Content-Type": content_type
	}
	try:
		response = client.get('http://{0}:{1}/{2}Instrument'.format(ip, port,api_root_comms),headers=headers,timeout=timeout)
		
		result = False
		if response != "" and response.statusCode == 200:
			result = True
		
		return result
	except:
		return False
