# WME - 
# See documentation for more info on this script. Intended for use with WM_Irubis_UDT
# Ver. 1.0 - Released for QA
client = system.net.httpClient(bypass_cert_validation=True)
# --- Obtaining Device Status ---
def getAvailableReq(ip):
	# Create the JythonHttpClient.
	# client = system.net.httpClient(bypass_cert_validation=True)

	# A get request is made to the cell availability endpoint
	response = client.get('http://' + ip + ':5555/api/continuous_measurement/cells_availability')
	
	if [response.json['result']][0] == [True] :
		return "Ready"
	if [response.json['result']][0] == ["pending"] :
		return "pending"
	if [response.json['result']][0] == [False] :
		return "Measuring"

# --- Starting a Measurement ---
def postReq(ip,run_name, data1):
	# Create the JythonHttpClient.
	# client = system.net.httpClient(bypass_cert_validation=True)

	# A POST request is made to the continuous measurement endpoint
	response = client.post('http://' + ip + ':5555/api/continuous_measurement?name=' + run_name, data=[data1])

# --- Stopping a Measurement ---
def deleteReq(ip):
	# Create the JythonHttpClient.
	# client = system.net.httpClient(bypass_cert_validation=True)

	# A DELETE request is made to the continuous measurement endpoint
	client.delete('http://' + ip + ':5555/api/continuous_measurement')

# --- Setting Resolution ---
def putRes(ip, res_value):
	# Create the JythonHttpClient.
	# client = system.net.httpClient(bypass_cert_validation=True)

	# A PUT request is made to the reolustion endpoint
	response = client.put('http://' + ip + ':5555/api/spectrometer/resolution?value=' + res_value)

# --- Setting General Settings ---
def putSettings(ip, measurement_time):
	# Create the JythonHttpClient.
	# client = system.net.httpClient(bypass_cert_validation=True)

	# A PUT request is made to the reolustion endpoint
	response = client.put('http://' + ip + ':5555/api/general/settings?spectrometer_measurement_time=' + measurement_time)

# --- Downloading Measurement Data ---
def downloadReq(ip, file_name, file_extension):
	# Create the JythonHttpClient.
	# client = system.net.httpClient(bypass_cert_validation=True)

	# A GET request is made to the storage endpoint to retrieve the {.type} file for the specified run.
	response = client.get('http://' + ip + ':5555/api/storage/get_' + file_extension + '_measurements?measurements_list=' + file_name)

	# Specify the filename for saving the CSV content locally.
	date = system.date.now()
	data_format = system.date.format(date, "_yyMMdd")
	print data_format
	filename = ('E:\SCADA_Exports\IRUBIS_Mid_IR_Data\IRUBIS_' + file_name + data_format + '.' + file_extension)
	
	if response.statusCode == 200:
		with open(filename, 'wb') as file:
			file.write(response.body)
		print ("File saved as: " + filename)
	else:
	    print ("Failed to download data. Status code: " + response.statusCode)