# WME - CB 21Nov2023
# See documentation for more info on this script. Intended for use with WM_Sartorius_UDT
# Ver. 1.0 - Released for QA
client = system.net.httpClient(bypass_cert_validation=True)
def getReq(ip_address, endpoint):
    try:
        # Create the JythonHttpClient.
        # client = system.net.httpClient(bypass_cert_validation=True)
        # Send a GET request.
        response = client.get('https://' + ip_address + endpoint)
        # Verify the sign and return the response
        if response.json['sign'] == '-':
            return [(response.json['sign'] + response.json['number'])][0]
        else:
            return [response.json['number']][0]
    except:
        return -9999

def postReq(ip_address, endpoint):
	# Create the JythonHttpClient.
	# client = system.net.httpClient(bypass_cert_validation=True)
	
	# Send a POST request
	client.post('https://' + ip_address + endpoint)