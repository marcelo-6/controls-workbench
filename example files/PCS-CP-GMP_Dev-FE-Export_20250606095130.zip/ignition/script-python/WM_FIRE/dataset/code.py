'''***************************************************************************************************
Script:				WM_FIRE.dataset
Create Date:		17Nov22
Author:				Marcelo Amorim
Description:		This WM_FIRE script contains user defined functions related to dataset access/view/modify
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			17Nov22			MA			Created
1.1			06Jun24			MA			Added insert to DB from a py dataset function
1.2			08Jul24			MA			Added alarm journal parser for alarm reporting
***************************************************************************************************'''
def excelToDataSet(filePath, headerRow = None, sheetNumber = 0, firstRow = None, lastRow = None, firstColumn = None, lastColumn = None):
	"""
		Snipped from: https://forum.inductiveautomation.com/t/copying-a-excel-file-to-a-tables-dataset/34942/13
		Better version at: https://github.com/IgnitionModuleDevelopmentCommunity/ignition-extensions
		Modified by MA17Nov22 to add error checks
		
	   Function to create a dataset from an Excel spreadsheet. It will try to automatically detect the boundaries of the data,
	   but helper parameters are available:
	   params:
	   		filePath	- The Excel document to read - the path to the file on disk.
	   		headerRow	- The row number to use for the column names in the output dataset.
	   		sheetNumber	- The sheet number (zero-indexed) in the Excel document to extract data from. If not supplied, defaults to the first sheet.
	   		firstRow	- The first row (zero-indexed) in the Excel document to retrieve data from. If not supplied, the first non-empty row will be used.
	   		lastRow		- The last row (zero-indexed) in the Excel document to retrieve data from. If not supplied, the last non-empty row will be used.
	   		firstColumn	- The first column (zero-indexed) in the Excel document to retrieve data from. If not supplied, the first non-empty column will be used
	   		lastColumn	- The last column (zero-indexed) in the Excel document to retrieve data from. If not supplied, the last non-empty column will be used.
		
		Returns:	A Dataset created from the Excel document. Types are assumed based on the first row of input data.
	"""
	import org.apache.poi.ss.usermodel.WorkbookFactory as WorkbookFactory
	import org.apache.poi.ss.usermodel.DateUtil as DateUtil
	from java.io import ByteArrayInputStream
	from java.io import FileInputStream
	from java.util import Date
	
	# Get File and do some error checking (only takes string(file path))
	if not isinstance(filePath, (str, unicode)):
		#try:
		fileObj = ByteArrayInputStream(filePath)
		workbook = WorkbookFactory.create(fileObj)
		#except Exception as e:
			#raise TypeError('Unable to create Workbook from input; should be string or binary data. Got %(inputType)s instead.\n%(error)s' % {"inputType":type(filePath), 'error':e})
		#raise TypeError('Unable to create Workbook from input; should be string. Got %(inputType)s instead.' % {"inputType":type(filePath)})
	elif not system.file.fileExists(filePath):
		raise ValueError('Unable to create Workbook from input; file in given path does not exist.')
	else:
		fileObj = FileInputStream(filePath)
		workbook = WorkbookFactory.create(fileObj)
	
	# Initialize variables
	sheet = workbook.getSheetAt(sheetNumber)
	headerRow = headerRow if isinstance(headerRow, int) else -1
	firstRow =  firstRow if isinstance(firstRow, int) else max(sheet.firstRowNum, headerRow + 1)
	lastRow = lastRow if isinstance(lastRow, int) else sheet.lastRowNum
	
	validRange = range(headerRow, lastRow+1)
	dataRange = range(firstRow, lastRow + 1)
	if firstRow > lastRow: raise ValueError('firstRow %(firstRow)s must be less than lastRow %(lastRow)s.' % {"firstRow":firstRow, "lastRow":lastRow})
	if headerRow >= 0 and headerRow in range(firstRow, lastRow): raise ValueError('headerRow %(headerRow)s must not be in firstRow..lastRow %(dataRange)s.' % {"headerRow":headerRow, "dataRange":dataRange})
	columnRow = sheet.getRow(headerRow if (headerRow >= 0) else firstRow)

	
	firstColumn = firstColumn if isinstance(firstColumn, int) else columnRow.firstCellNum
	lastColumn = lastColumn + 1 if isinstance(lastColumn, int) else columnRow.lastCellNum
	if firstColumn >= lastColumn: raise ValueError('firstColumn %(firstColumn)s must be less than lastColumn %(lastColumn)s.' % {"firstColumn":firstColumn, "lastColumn":lastColumn})
	columnCount = lastColumn - firstColumn
	columnRange = range(firstColumn, lastColumn)
	
	#print '\nheaderRow=%(headerRow)s\nfirstRow=%(firstRow)s\nlastRow=%(lastRow)s\ndataRange=%(dataRange)s\nvalidRange=%(validRange)s\ncolumnRange=%(columnRange)s\nfirstColumn=%(firstColumn)s\nlastColumn=%(lastColumn)s\n' % {"headerRow":headerRow, "firstRow":firstRow,"lastRow":lastRow, "dataRange":dataRange,"validRange":validRange,"columnRange":columnRange, "lastColumn":lastColumn,"firstColumn":firstColumn, "lastColumn":lastColumn}
	data = []
	headers = []
	for i in validRange:
		row = sheet.getRow(i)
		#print str(i).zfill(3), list(row)
		if i == firstRow:
			if firstColumn is None:
				firstColumn = row.getFirstCellNum()

			if lastColumn is None:
				lastColumn  = row.getLastCellNum()
			else:
				# if lastCol is specified add 1 to it.
				lastColumn += 1
		if headerRow != -1 and i == headerRow:
			headers = list(row)[firstColumn:lastColumn]
		elif len(headers) == 0:
			headers = ['Col'+str(i) for i in columnRange]
		#print headers
		rowOut = []
		
		for j in columnRange:
			if i == headerRow:
				pass
			else:
				cell = row.getCell(j)
				cellType = cell.getCellType().toString()
				if cellType == 'NUMERIC':
					if DateUtil.isCellDateFormatted(cell):
						value = cell.dateCellValue
					else:
						value = cell.getNumericCellValue()
						#if value == int(value):
						#	value = int(value)
						value = str(value)
						#print 'Row=%(row)s ---- Column=%(col)s ---- Value=%(value)s ---- Type=%(type)s' % {"row":str(i), "col":str(j), "value":str(value), "type":str(type(value))}
				elif cellType == 'STRING':
					value = cell.getStringCellValue()
				elif cellType == 'BOOLEAN':
					value = cell.getBooleanCellValue()
				elif cellType == 'BLANK':
					value = None	
				elif cellType == 'FORMULA':
					formulatype=str(cell.getCachedFormulaResultType())
					if formulatype == 'NUMERIC':
						if DateUtil.isCellDateFormatted(cell):
							value =  cell.dateCellValue
						else:
							value = cell.getNumericCellValue()
							#if value == int(value):
							#	value = int(value)
							value = str(value)
					elif formulatype == 'STRING':
						value = cell.getStringCellValue()
					elif formulatype == 'BOOLEAN':
						value = cell.getBooleanCellValue()
					elif formulatype == 'BLANK':
						value = None
				else:
					value = None	
				rowOut.append(value)
		if len(rowOut) > 0:
			data.append(rowOut)
		

	fileObj.close()
	
	return system.dataset.toDataSet(headers, data)

def alarmJournalResultsToDatasetByEventID(journal_results,active_only=False):
	"""
	   Function to create a dataset from a list of alarm events returned by system.alarm.queryJournal. 
	   It will parse the list and return a dataset where each row is an eventID. This is used to make it easier to display alarm
	   for reporting purposes. It will calculate the duration and response time of alarms as well
	   params:
	   		journal_results	`list`: The data to parse `list` of alarm events
	   		active_only 	'bool`: if True, data returned will only include alarms that became active from journal_results
		
		Returns:	A Dataset of parsed alarm data
	"""
	from com.inductiveautomation.ignition.common.alarming import AlarmStateTransition
	
	alarm_data = {}
	alarm_data_rows = []
	alarm_headers = ['EventId', 'TimeActive','TimeCleared','TimeAcked','AlarmDesc','Priority','Duration','ResponseTime']
	
	# Iterates through the journal results to determine the eventid, source, tag, label, priority, active, ack, and clear data 
	# Groups multiple alarm by their event ID. 
	for alarm_event in journal_results:
		alarm_data_getters = {
			AlarmStateTransition.Ack: lambda e: e.ackData.getTimestamp(),
			AlarmStateTransition.Active: lambda e: e.activeData.getTimestamp(),
			AlarmStateTransition.Clear: lambda e: e.clearedData.getTimestamp(),
		}
		alarm_event_id = alarm_event.getId()
		alarm_event_state = alarm_event.getState()
		alarm_event_priority = alarm_event.getPriority()
		alarm_event_display_path = alarm_event.getDisplayPath()
		#print "id=\t",alarm_event.getId()
		#print "name=\t",alarm_event.getDisplayPath()
		#print "state=\t",alarm_event.getState()
		event_time = alarm_data_getters[alarm_event.lastEventState](alarm_event)
		#event_time = system.date.format(system.date.fromMillis(event_time),"dd-MMM-yy HH:mm:ss")
		event_time = system.date.fromMillis(event_time)
		
		# Init alarm data dict keys if new alarm event
		if alarm_event_id not in alarm_data:
			alarm_data[alarm_event_id] = {'TimeActive':None,'TimeCleared':None,'TimeAcked':None,
										  'Duration':None,'ResponseTime':None,'Priority':None,
										  'AlarmDesc':None}
										  
		# Always collect info of alarm
		alarm_data[alarm_event_id]['Priority'] = alarm_event_priority
		alarm_data[alarm_event_id]['AlarmDesc'] = alarm_event_display_path
		
		# Get Active timestamp
		if str(alarm_event_state) == "Active, Unacknowledged":
			alarm_data[alarm_event_id]['TimeActive'] = event_time
			
		# Get earliest Acked timestamp and measure reponse time (acked time - active time)
		if ", Ack" in str(alarm_event_state):
			if alarm_event_id in alarm_data and alarm_data[alarm_event_id]['TimeAcked'] != None:
				if system.date.isBefore(event_time, alarm_data[alarm_event_id]['TimeAcked']):
					alarm_data[alarm_event_id]['TimeAcked'] = event_time
			else:
				alarm_data[alarm_event_id]['TimeAcked'] = event_time
			alarm_data[alarm_event_id]['ResponseTime'] = WM_FIRE.util.durationConvert(system.date.millisBetween(alarm_data[alarm_event_id]['TimeActive'], alarm_data[alarm_event_id]['TimeAcked']) if alarm_data[alarm_event_id]['TimeActive'] != None else 0,None)
				
		# Get earliest clear timestamp and measure duration (cleared time - active time)
		if "Clear" in str(alarm_event_state):
			if alarm_event_id in alarm_data and alarm_data[alarm_event_id]['TimeCleared'] != None:
				if system.date.isBefore(event_time, alarm_data[alarm_event_id]['TimeCleared']):
					alarm_data[alarm_event_id]['TimeCleared'] = event_time
			else:
				alarm_data[alarm_event_id]['TimeCleared'] = event_time
			alarm_data[alarm_event_id]['Duration'] = WM_FIRE.util.durationConvert(system.date.millisBetween(alarm_data[alarm_event_id]['TimeActive'], alarm_data[alarm_event_id]['TimeCleared']) if alarm_data[alarm_event_id]['TimeActive'] != None else 0,None)
				
	#from pprint import pprint
	#pprint(alarm_data)
	
	# Create dataset from alarm events data dict (if active_only, check if active time is within start/end time aka not None)
	if not active_only:
		for alarm_event in alarm_data:
			alarm_data_rows.append([alarm_event,alarm_data[alarm_event]['TimeActive'],alarm_data[alarm_event]['TimeCleared'],alarm_data[alarm_event]['TimeAcked'],
			alarm_data[alarm_event]['AlarmDesc'],alarm_data[alarm_event]['Priority'],alarm_data[alarm_event]['Duration'],alarm_data[alarm_event]['ResponseTime']])
	else:
		for alarm_event in alarm_data:
			if alarm_data[alarm_event]['TimeActive'] != None:
				alarm_data_rows.append([alarm_event,alarm_data[alarm_event]['TimeActive'],alarm_data[alarm_event]['TimeCleared'],alarm_data[alarm_event]['TimeAcked'],
				alarm_data[alarm_event]['AlarmDesc'],alarm_data[alarm_event]['Priority'],alarm_data[alarm_event]['Duration'],alarm_data[alarm_event]['ResponseTime']])
	return system.dataset.toDataSet(alarm_headers, alarm_data_rows)
			
def populate_dbtable_from_pydataset(pds,colNamesList,dbTable,dbConn,maxRecs):
	"""
	   Function to populate a given DB table with a given py dataset in batches of up to maxRecs
	   params:
	   		pds		- Pydataset to use for data (use system functions to convert normal dataset to pydataset if neeeded)
	   		colNamesList - List of column names in order that match database column names (col1, col2, etc should exist in the DB and be in the same order in py dataset)
	   		dbTable	- table name to write to
	   		dbConn	- DB connection name
	   		maxRecs	- Max number of records to write to DB at a time (can be smaller than the number of the py dataset rows)

		
		Returns:	?
	"""

	cols = pds.getColumnCount()
	rows = pds.getRowCount()
	
	# no inserts if no data
	if rows > 0:
		# set up insert query string
		placeHolders = "({:s})".format(",".join("?"*cols))
		columnPlaceHolders = "({:s})".format(",".join(pds.getColumnNames()))
			
		queryStr = "INSERT INTO {:s} {:s} VALUES {:s}".format(dbTable,columnPlaceHolders,"{placeHolders}")
		
		# indices for first N records
		minIdx = 0
		maxIdx = maxRecs
		
		# DB inserts in batchs of N
		while (maxIdx < rows):
			queryArgs = []
			queryData = []
			for row in pds[minIdx:maxIdx]:
				queryData.extend(row)
				queryArgs.append(placeHolders)
			
			queryStr1 = queryStr.format(placeHolders=",".join(queryArgs))
			
			# insert N rows into DB
			system.db.runPrepUpdate(queryStr1, queryData, dbConn)
			
			# advance indicies for next N records
			minIdx = maxIdx
			maxIdx += maxRecs
		
		# handle any leftover records
		maxIdx = rows
		queryArgs = []
		queryData = []
		for row in pds[minIdx:maxIdx]:
			queryData.extend(row)
			queryArgs.append(placeHolders)
		
		queryStr2 = queryStr.format(placeHolders=",".join(queryArgs))
		
		# insert remaining rows into DB
		system.db.runPrepUpdate(queryStr2, queryData, dbConn)