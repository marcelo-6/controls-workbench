'''***************************************************************************************************
Script:				WM_FIRE.util
Create Date:		17Nov22
Author:				Marcelo Amorim
Description:		This WM_FIRE script contains user defined functions for tools/utilities
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
0.1			17Nov22			MA			Created
0.2			31Jan23			MA			Added shutdown gateway script to issue shutdown to windows OS
0.3			16Feb23			MA			Added restart gateway script to issue restart to windows OS
0.4			24Jun24			MA			Added milisecond to duration conversion (days:hours:minutes:seconds format)
***************************************************************************************************'''
def tryEvalStringToNumbers(val):
	# This function try to evaluate a given unicode string into a number
	import ast
	try:
		val = ast.literal_eval(val)
	except ValueError:
		pass
	#print val
	return val

def removeZerosFromFloats(num):
	# This function removes leading zeros from floating decimals (it returns the integer equivalent)
	if num % 1 == 0:
		return int(num)
	else:
		return num

def tryEvalAndRemoveZeros(val):
	# Combine both into one
	return removeZerosFromFloats(tryEvalStringToNumbers(val))
	
def durationConvert(millisIn,zeroReturn=0):
	# Convert miliseconds to duration in the days:hours:minuts:seconds format
	if millisIn > 0:
		seconds, ms = divmod(millisIn, 1000)
		minutes, seconds = divmod(seconds, 60)
		hours, minutes = divmod(minutes, 60)
		if hours > 24:
			days,hours = divmod(hours, 24)
			return '{:d}:{:02d}:{:02d}:{:02d}'.format(days,hours,minutes,seconds)
		else:
			return '{:d}:{:02d}:{:02d}'.format(hours,minutes,seconds)
	else:
		return zeroReturn

def progressLog(num=0, increment=0, indent=0, msg=None, obj=None, separator=' | ', end=';', loggerObj='', fullLog='',logLevel=0):
	'''
		This Function is to be used as default logging for the library
		
		Example log progress message: 
		<Log Line Number> <Separator> <how many tabs to indent> <actual message> <end char>
		
		001 | Indentation 1	Started doing something;
		002 |		Indentation 2	Started doing something;
		003 |			Indentation 3	Started doing something;
		
		and so on
		
		It takes a few arguments
	'''
	if indent <= logLevel:
		num += increment
		indentation = ''
		if indent > 0:
			for number in range(indent):
				indentation +='\t'
		msg = '%(num)s%(separator)s%(indent)s%(msg)s%(end)s' % {"num":str(num).zfill(3),"msg":msg,"separator":separator,"end":end, 'indent':indentation}
		print msg
		if loggerObj != '':
			loggerObj.debug(msg)
		else:
			fullLog = fullLog + '\n' + msg
	return num, fullLog
	
def debugPrint(firstVal, second, third, forth, fifth, sixth):
	msg = 's%(first)\ts%(second)\ts%(third)\ts%(msg)\ts%(end)s' % {"first":str(first),"second":str(first),"third":str(third),"end":str(first), 'indent':str(first)}
	print msg
	
def shutdownGatewayComputer():
	# Function to issue shutdown command to Windows OS from a vision client / perspective client
	
	# To call this function use a message handler in a gateway event script (this ensures that the script only runs in the gateway scope)
	# Then make sure to use system.util.sendMessage(project=system.project.getProjectName(),messageHandler="ShutdownGatewayComputer")
	# WARNING IF CALLED FROM Designer session IT WILL SHUTDOWN COMPUTER
	import os 
  
	os.system("shutdown /s /t 2")

def restartGatewayComputer():
	# Function to issue Restart command to Windows OS from a vision client / perspective client
	
	# To call this function use a message handler in a gateway event script (this ensures that the script only runs in the gateway scope)
	# Then make sure to use system.util.sendMessage(project=system.project.getProjectName(),messageHandler="RestartGatewayComputer")
	# WARNING IF CALLED FROM Designer session IT WILL Restart COMPUTER
	import os 
  
	os.system("shutdown /r /t 2")