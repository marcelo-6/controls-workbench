'''***************************************************************************************************
Procedure:          WM_FIRE.report
Create Date:       	15Nov22
Author:             Marcelo Amorim
Description:        These scripts are used by multiple views and graphical objects within F.I.R.E library
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			15Nov22			MA			Created
***************************************************************************************************'''
########################################################################################################
##### Global Variables used for contants
########################################################################################################
# Reports and their titles are to be first defined here (this is used since we dont want to hardcode 
# report names and report titles since it can change from project to project and this defines a single
# place to make those changes )
# NOTE that index matters: for report display we use 10, 20, 30 etc for visibility behind the scenes 
# BATCH REPORT INDEXES ARE RESERVED TO BE between 30-50 (for some scripting in displays dropdown for reporting)

# To create a new report no built'in from FIRE lib do the following:

report_P_10 = {'Inp_StartDate':'','Inp_EndDate':'','Inp_ReportTitle':'Active Alarm Report', 'Inp_Filter':''}
report_10 = {'name':'10_Alarm_Report','title':'Active Alarm Report', 'index':10, 'params':report_P_10, 'isBatchReport':False}

report_P_11 = {'Inp_StartDate':'','Inp_EndDate':'','Inp_ReportTitle':'Alarm Summary Report', 'Inp_Filter':''}
report_11 = {'name':'11_Alarm_Summary_Report','title':'Alarm Summary Report', 'index':11, 'params':report_P_11, 'isBatchReport':False}

report_P_20 = {'Inp_StartDate':'','Inp_EndDate':'','Inp_ReportTitle':'Audit Report', 'Inp_Filter':''}
report_20 = {'name':'20_Audit_Report','title':'Audit Report', 'index':20, 'params':report_P_20, 'isBatchReport':False}

report_P_30 = {'Inp_BatchID':'','Inp_UnitName':'','Inp_UnitName_Long':''}
report_30 = {'name':'30_Batch_Report','title':'Batch Report', 'index':30, 'params':report_P_30, 'isBatchReport':True}

report_P_35 = {'Inp_BatchID':'','Inp_UnitName':'','Inp_UnitName_Long':''}
report_35 = {'name':'35_Batch_Exceptions','title':'Batch Exception Report', 'index':35, 'params':report_P_35, 'isBatchReport':True}

arrayReports = [report_10,report_11, report_20, report_30, report_35]

########################################################################################################
##### Functions that should be called from graphics/views
########################################################################################################
def getArrayReports():
	return arrayReports

# to make it easier for dropdown options
def getReportNamesWithIndexesAsValueLabelPair():
	finalReturn = []
	for item in arrayReports:
		finalReturn.append({
					"value": item['index'],
					"label": item['name'],
				})
	return finalReturn
	
# put in package app.chartUtils
# https://forum.inductiveautomation.com/t/range-axis-tick-density-in-status-chart/5170/4
import WM_FIRE
global WM_FIRE

def setDateTickUnits(chart, label):
	from java.text import SimpleDateFormat
	from org.jfree.chart.axis import TickUnits
	from org.jfree.chart.axis import DateTickUnit
	
	# Create a new org.jfree.chart.axis.TickUnits
	units = TickUnits()
	
	# Format definitions
	# Formats are created with default timezone and default locale
	# format.setTimezone might be used to override the timezone
	# Additional space is added to the format to prevent ticks from being
	# displayed without space (happens sometimes when using anchored layout).
	formatMSec = SimpleDateFormat(" HH:mm:ss SS")
	formatSec = SimpleDateFormat(" HH:mm:ss")
	formatMin = SimpleDateFormat(" HH:mm")
	formatHour = SimpleDateFormat(" HH:mm")
	formatDay = SimpleDateFormat(" dd-MM HH:mm")
	formatMonth = SimpleDateFormat(" dd-MMM-yy")
	formatYear = SimpleDateFormat(" MMM yyyy")
	
	# Add the units
	units.add(DateTickUnit(DateTickUnit.MILLISECOND, 5, formatMSec))
	units.add(DateTickUnit(DateTickUnit.MILLISECOND, 50, DateTickUnit.MILLISECOND, 5, formatMSec))
	units.add(DateTickUnit(DateTickUnit.MILLISECOND, 250, DateTickUnit.MILLISECOND, 50, formatMSec))
	units.add(DateTickUnit(DateTickUnit.MILLISECOND, 500, DateTickUnit.MILLISECOND, 50, formatMSec))
	units.add(DateTickUnit(DateTickUnit.SECOND, 1, DateTickUnit.MILLISECOND, 50, formatSec))
	units.add(DateTickUnit(DateTickUnit.SECOND, 2, DateTickUnit.MILLISECOND, 250, formatSec))
	units.add(DateTickUnit(DateTickUnit.SECOND, 5, DateTickUnit.MILLISECOND, 250, formatSec))
	units.add(DateTickUnit(DateTickUnit.SECOND, 10, DateTickUnit.MILLISECOND, 500, formatSec))
	units.add(DateTickUnit(DateTickUnit.SECOND, 30, DateTickUnit.SECOND, 2, formatSec))
	units.add(DateTickUnit(DateTickUnit.MINUTE, 1, DateTickUnit.SECOND, 5, formatSec))
	units.add(DateTickUnit(DateTickUnit.MINUTE, 2, DateTickUnit.SECOND, 10, formatMin))
	units.add(DateTickUnit(DateTickUnit.MINUTE, 5, DateTickUnit.SECOND, 30, formatMin))
	units.add(DateTickUnit(DateTickUnit.MINUTE, 10, DateTickUnit.MINUTE, 1, formatMin))
	units.add(DateTickUnit(DateTickUnit.MINUTE, 20, DateTickUnit.MINUTE, 5, formatMin))
	units.add(DateTickUnit(DateTickUnit.MINUTE, 30, DateTickUnit.MINUTE, 5, formatMin))
	units.add(DateTickUnit(DateTickUnit.HOUR, 1, DateTickUnit.MINUTE, 5, formatHour))
	units.add(DateTickUnit(DateTickUnit.HOUR, 2, DateTickUnit.MINUTE, 10, formatHour))
	units.add(DateTickUnit(DateTickUnit.HOUR, 4, DateTickUnit.MINUTE, 30, formatHour))
	units.add(DateTickUnit(DateTickUnit.HOUR, 6, DateTickUnit.HOUR, 1, formatHour))
	units.add(DateTickUnit(DateTickUnit.HOUR, 12, DateTickUnit.HOUR, 2, formatHour))
	units.add(DateTickUnit(DateTickUnit.DAY, 1, DateTickUnit.HOUR, 1, formatDay))
	units.add(DateTickUnit(DateTickUnit.DAY, 2, DateTickUnit.HOUR, 4, formatDay))
	units.add(DateTickUnit(DateTickUnit.DAY, 7, DateTickUnit.DAY, 1, formatDay))
	units.add(DateTickUnit(DateTickUnit.DAY, 14, DateTickUnit.DAY, 1, formatDay))
	units.add(DateTickUnit(DateTickUnit.MONTH, 1, DateTickUnit.DAY, 1, formatDay))
	units.add(DateTickUnit(DateTickUnit.MONTH, 2, DateTickUnit.DAY, 7, formatMonth))
	units.add(DateTickUnit(DateTickUnit.MONTH, 3, DateTickUnit.DAY, 14, formatMonth))
	units.add(DateTickUnit(DateTickUnit.MONTH, 6, DateTickUnit.MONTH, 1, formatMonth))
	units.add(DateTickUnit(DateTickUnit.YEAR, 1, DateTickUnit.MONTH, 1, formatYear))
	units.add(DateTickUnit(DateTickUnit.YEAR, 2, DateTickUnit.MONTH, 3, formatYear))
	
	# Apply the new tick units to the chart
	plot = chart.getPlot()
	axis = plot.getDomainAxis()
	customAxis = WM_FIRE.report.CustomDateAxis(label)
	customAxis.setConfigFromAxis(axis)
	customAxis.setStandardTickUnits(units)
	plot.setDomainAxis(customAxis)

# This class is used to set DateTickUnits asynchronous by invokeLater
# Usage in propertyChange script of the chart:
# if event.propertyName == 'propertiesLoading':
#	newUnits = app.chartUtils.DateTickUnits(event.source)
#	system.util.invokeLater(newUnits.setDateTickUnits)  
#
# The chart will be created with the default DateTickUnits. The invokeLater sets the new units
# immediately, but there WILL be a flicker everytime the chart reloads.
class DateTickUnits:
	# Param chart: Reference to the chart
	# Param label: The custom label (see CustomDateAxis) %s will be replaced with start/end date
	def __init__(self, chart, label="%s - %s"):
	   self.chart = chart
	   self.label = label
	   
	def setDateTickUnits(self):
		import WM_FIRE
	 	WM_FIRE.report.setDateTickUnits(self.chart, self.label)
	 	
# Override DateAxis#getLabel to return min & max date in custom format
from org.jfree.chart.axis import DateAxis
class CustomDateAxis(DateAxis):
	def __init__(self, label):
		self.custom_label = label
	
	def getLabel(self):
		from java.text import SimpleDateFormat
		minDate = self.getMinimumDate()
		maxDate = self.getMaximumDate()
		# Modify the format given here, ore add additional logic to change according to the range
		format = SimpleDateFormat("dd-MMM-yy HH:mm:ss")
		# a custom label might be added to the return string
		return self.custom_label % (format.format(minDate), format.format(maxDate))
	# Copy the config from another axis
	def setConfigFromAxis(self, other):
		from org.jfree.chart.axis import DateAxis

		self.setLabelAngle(other.labelAngle)
		self.setLabelFont(other.labelFont)
		self.setLabelPaint(other.labelPaint)

		self.setTickLabelFont(other.tickLabelFont)
		self.setTickLabelPaint(other.tickLabelPaint)
		self.setTickLabelsVisible(other.tickLabelsVisible)
		self.setVerticalTickLabels(other.verticalTickLabels)
		
		self.setTickMarkInsideLength(other.tickMarkInsideLength)
		self.setTickMarkOutsideLength(other.tickMarkOutsideLength)
		self.setTickMarkPaint(other.tickMarkPaint)
		self.setTickMarksVisible(other.tickMarksVisible)
			
		self.setNegativeArrowVisible(other.negativeArrowVisible)
		self.setPositiveArrowVisible(other.positiveArrowVisible)
		self.setLowerMargin(other.lowerMargin)
		self.setUpperMargin(other.upperMargin)