'''***************************************************************************************************
Script:				WM_FIRE.batch.util
Create Date:		16Nov22
Author:				Marcelo Amorim
Description:		This script is used by the deferral tool views and graphical objects within F.I.R.E library
Used By:			Deferral Tools Views
****************************************************************************************************
SUMMARY OF CHANGES
Version		Date(ddMMMyy)	Author		Comments
----------------------------------------------------------------------------------------------------
1.0			16Nov22			MA			Created
***************************************************************************************************'''
stageProgress = 0
debugLogEnabled = False
runningLog = ''

def removeAllUserDefinedParamsFromBatchPhaseObj(obj):
	# This function removes all user defined parameters for BatchPhase objects
	# Returns count removed params, list of their names, and any errors
	global debugLogEnabled
	global stageProgress
	global runningLog
	try:
		removedCount = 0
		removedParamNameList = []
		objParamsList = obj.getParameterList()
		
		for paramObj in objParamsList:
			paramName = paramObj.getName()
			if (paramObj.getParamTagTypeName() == 'OPC'
				and paramName != 'Command_Number'
				and	paramName != 'State_Number'
				and paramName != 'Handshake_Ack'
				and paramName != 'Handshake_Value'):
					if debugLogEnabled: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 3, 'Removed Parameter= %(name)s\tTagType= %(tagType)s\tKind= %(kind)s\tValue= %(value)s\tValue Source= %(valueSource)s' % ({'name':paramObj.getFriendlyName(), 'tagType':paramObj.getParamTagTypeName(), 'kind':paramObj.getParamKindName(), 'value':paramObj.getParamValue(), 'valueSource':paramObj.getParamValueSourceName()}))
					obj.removeParameter(paramObj)
					removedParamNameList.append('\t' + paramName + '\n')
					removedCount += 1
	except Exception as e:
		return removedCount, removedParamNameList, e
	else:
		return removedCount, removedParamNameList, ''

def removeAllUserDefinedParamsFromBatchMasterLogicObj(obj):
	# This function removes all user defined parameters for BatchMasterLogic objects
	# Returns count removed params, list of their names, and any errors
	global debugLogEnabled
	global stageProgress
	global runningLog
	try:
		removedCount = 0
		removedParamNameList = []
		objParamsList = obj.getAllParameters()
		
		for paramObj in objParamsList:
			paramName = paramObj.getFriendlyName()
			#if debugLogEnabled: print 'Parameter Name= %(name)s\tTagType= %(tagType)s\tKind= %(kind)s\tValue= %(value)s\tValue Source= %(valueSource)s' % ({'name':paramObj.getFriendlyName(), 'tagType':paramObj.getParamTagTypeName(), 'kind':paramObj.getParamKindName(), 'value':paramObj.getParamValue(), 'valueSource':paramObj.getParamValueSourceName()})
			#if (paramObj.getParamKindName() != 'Built-in' and paramObj.getParamKindName() != 'Built-in Hidden'):
			if paramObj.getParamKindName() == 'User Logic':
				#obj.removeParameter(paramObj)
				if debugLogEnabled: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 3, 'Removed Parameter= %(name)s\tTagType= %(tagType)s\tKind= %(kind)s\tValue= %(value)s\tValue Source= %(valueSource)s' % ({'name':paramObj.getFriendlyName(), 'tagType':paramObj.getParamTagTypeName(), 'kind':paramObj.getParamKindName(), 'value':paramObj.getParamValue(), 'valueSource':paramObj.getParamValueSourceName()}))
				obj.removeParameter(paramName)
				removedParamNameList.append('\t' + paramName + '\n')
				removedCount += 1
	except Exception as e:
		return removedCount, removedParamNameList, e
	else:
		return removedCount, removedParamNameList, ''

def setOrCreateParameterInBatchMasterLogicObj(obj, paramName, paramRecordingTypeName, paramValueSourceName, paramDataTypeName, paramValue, paramMinValue, paramMaxValue, paramCalculation=''):
	# This function checks if parameter exists, if it does it modifies it. otherwise it tries to create it. Default value for calculation property is blank (deferral property)
	global debugLogEnabled
	global stageProgress
	global runningLog
	created = False
	try:
		paramObj = obj.findParameterByFriendlyName(paramName)
		if paramObj == None:
			param = obj.addParameter(paramName)
			param.setParamKindName('User Logic')
			param.setParamRecordingTypeName(paramRecordingTypeName)
			param.setParamValueSourceName(paramValueSourceName)
			param.setParamDataTypeName(paramDataTypeName)
			param.setParamCalculation(paramCalculation)
			param.setParamValue(paramValue)
			param.setParamMinValue(paramMinValue)
			param.setParamMaxValue(paramMaxValue)
			if debugLogEnabled: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 3, 'Created Parameter= %(name)s\tTagType= %(tagType)s\tKind= %(kind)s\tValue= %(value)s\tValue Source= %(valueSource)s' % ({'name':param.getFriendlyName(), 'tagType':param.getParamTagTypeName(), 'kind':param.getParamKindName(), 'value':param.getParamValue(), 'valueSource':param.getParamValueSourceName()}))
			created = True
		else:
			param = paramObj
			param.setParamRecordingTypeName(paramRecordingTypeName)
			param.setParamValueSourceName(paramValueSourceName)
			param.setParamDataTypeName(paramDataTypeName)
			param.setParamCalculation(paramCalculation)
			param.setParamValue(paramValue)
			param.setParamMinValue(paramMinValue)
			param.setParamMaxValue(paramMaxValue)
			if debugLogEnabled: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 3, 'Modified Parameter= %(name)s\tTagType= %(tagType)s\tKind= %(kind)s\tValue= %(value)s\tValue Source= %(valueSource)s' % ({'name':param.getFriendlyName(), 'tagType':param.getParamTagTypeName(), 'kind':param.getParamKindName(), 'value':param.getParamValue(), 'valueSource':param.getParamValueSourceName()}))
	except Exception as e:
		return False, created, e
	else:
		return True, created, ''

def getAllUserDefinedParametersList(obj):
	global debugLogEnabled
	global stageProgress
	global runningLog
	objParamsList = obj.getParameters()
	paramList = []
	paramListObj = []
	for paramObj in objParamsList:
		if paramObj.getParamKindName() != 'Built-in':
			paramList.append(paramObj.getFriendlyName())
			paramListObj.append(paramObj)
			if debugLogEnabled: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 3, 'User Defined Parameter Found Name= %(name)s\tTagType= %(tagType)s\tKind= %(kind)s\tValue= %(value)s\tValue Source= %(valueSource)s' % ({'name':paramObj.getFriendlyName(), 'tagType':paramObj.getParamTagTypeName(), 'kind':paramObj.getParamKindName(), 'value':paramObj.getParamValue(), 'valueSource':paramObj.getParamValueSourceName()}))
	return paramList, paramListObj

def setParameterCalculationInBatchMasterLogicObj(obj,paramName, paramCalculation):
	global debugLogEnabled
	global stageProgress
	global runningLog
	try:
		#param = obj.getParameter(paramName)
		param = obj.findParameterByFriendlyName(paramName)
		prevCalc = param.getParamCalculation()
		param.setParamCalculation(paramCalculation)
		calc = param.getParamCalculation()
		if debugLogEnabled: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 3, 'Modified Calculation Property for Parameter= %(name)s\tPrevious= %(prevCalc)s\tNew= %(calc)s' % ({'name':param.getFriendlyName(), 'prevCalc':prevCalc, 'calc':calc}))
	except Exception as e:
		return False, e
	else:
		return True, ''

def setParameterDeferralInBatchMasterLogicObject(objList, stepsDict, stepsType):
	global debugLogEnabled
	global stageProgress
	global runningLog
	deferredCount = 0
	for stepName, nestedDict in stepsDict.items():			
		# Go tru list of MES Objects to find OP steps by name, once found mod parameters within it
		for procedureMESObject in objList:
			if stepsType != 'phase':
				if procedureMESObject.getName() == nestedDict['name']:
					stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, '%(name)s\tUpdating Parameters' % ({'name':nestedDict['name']}))
					for paramName, paramDict in nestedDict[stepsType]['params'].items():
						good, error = setParameterCalculationInBatchMasterLogicObj(procedureMESObject,paramDict['name'], paramDict['defer'])
						if debugLogEnabled and not good: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 3, '%(name)s\tDeferral Update Error=%(error)s' % ({'name':paramName, 'error':error}))
						if good and len(paramDict['defer']) > 0: deferredCount += 1
			else:
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, '%(name)s\tUpdating Parameters' % ({'name':nestedDict['name']}))
				for paramName, paramDict in nestedDict[stepsType]['params'].items():
					good, error = setParameterCalculationInBatchMasterLogicObj(procedureMESObject,paramDict['name'], paramDict['defer'])
					if debugLogEnabled and not good: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 3, '%(name)s\tDeferral Update Error=%(error)s' % ({'name':paramName, 'error':error}))
					if good and len(paramDict['defer']) > 0: deferredCount += 1
	return deferredCount

def deferImport(scope='', fileData='', skipPhase=False, skipOP=False, skipUP=False, skipPP=False, debug=False):
	"""		
	   Function uses an excel file to create deferral parameters for Phases, Operations, Unit Procedures, Procedures
	   params:
	   		scope				- scope that this script will be running from							(default = '')
	   							(for logging and the source of how function obtains excel file
   								if scope = 'gateway' 	Prompt User to open Excel file from local computer and create a logger and log any status to that logger
   								if scope = '' (default) Prompt User to open Excel file from local computer and log every line into a string that gets returned at the end
   								if scope = 'designer' 	it will behave like the default setting
   								if scope = 'perspective' Needs a binaryArray that represents the excel file (comes from FileUpload component in perspective) and log every line into a string that gets returned at the end
	   							)
	   		fileData			- binaryArray that represents the excel file							(default = '')
	   		skipPhase			- if true skips creating any phase parameters							(default = False)
	   		skipOP				- if true skips creating any operation parameters						(default = False)
	   		skipUP				- if true skips creating any unit Procedure parameters					(default = False)
	   		skipPP				- if true skips creating any procedure parameters						(default = False)
	   		debug				- if true the log will be much more detailed for troubleshooting only	(default = False)
		
		Returns:				- Full log string that can be saved to a txt file if needed
	"""
	global debugLogEnabled
	global stageProgress
	global runningLog
	import shutil
	from java.io import FileInputStream
	#from java.lang import IllegalArgumentException
	from java.util import NoSuchElementException
	from pprint import pprint
	#if debugLog: debugLogEnabled = True
	##########################################################################################################################################################
	#### Convert Excel file to a dataset
	##########################################################################################################################################################
	
	stageProgress = 0
	debugLogEnabled = debug
	runningLog = ''
	if scope == '':
		myLogger = ''
	elif scope == 'designer':
		myLogger = ''
	elif scope == 'gateway':
		myLogger == system.util.getLogger('Defferal_Script_Logger')
	elif scope == 'perspective':
		myLogger = ''
	# Create Temp file so user can still have their original excel file open
	if scope != 'perspective':
		filePath = system.file.openFile('.xlsx')
		if filePath != None:
			if WM_FIRE.file.isFileBeingUsed(filePath):
				raise IOError('File %(filePath)s \n is currently open, close it and try again (a temp copy will be made and no change to original file will be made).' % {"filePath":filePath})
			else:
				#tempFilePath = system.file.getTempFile("xlsx")
				#stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress, 1, 'Temporary File created %(tempFilePath)s' % {"tempFilePath":tempFilePath})
				
				#shutil.copy2(filePath, tempFilePath)
				#stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 'Temporary File copied from source file')
				
				dataset = WM_FIRE.dataset.excelToDataSet(filePath, headerRow=1, firstRow=2)
				#dataset = WM_FIRE_Tools.excelToDataSet(tempFilePath, headerRow=1, firstRow=2)
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Dataset created from Excel file', loggerObj=myLogger, fullLog=runningLog)
		else:
			sys.exit()
	else:
		dataset = WM_FIRE.dataset.excelToDataSet(fileData, headerRow=1, firstRow=2)
		#dataset = WM_FIRE_Tools.excelToDataSet(tempFilePath, headerRow=1, firstRow=2)
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Dataset created from Excel file', loggerObj=myLogger, fullLog=runningLog)
	##########################################################################################################################################################
	#### Constants
	##########################################################################################################################################################
	
	validParameterDatatypes = ["Byte"
		,"Short"
		,"Integer"
		,"Long"
		,"Float"
		,"Double"]
	
	validParameterDatatypesPython = {"Byte":int
		,"Short":int
		,"Integer":int
		,"Long":int
		,"Float":float
		,"Double":int}
	
	## If column names ever change in excel sheet, they should only need to be updated here:
	columnNamesPhaseName = 'Phase Name'
	columnNamesPhasePathName = 'Phase Class Name'
	columnNamesUnitClassName = 'Unit Class Name'
	columnNamesPhaseParameterName = 'Phase Parameter Name'
	columnNamesPhaseParameterDatatype = 'Phase Parameter Datatype'
	columnNamesPhaseParameterType = 'Phase Parameter Type'
	columnNamesPhaseParameterDefaultValue = 'Phase Parameter Default Value'
	columnNamesPhaseParameterMinValue = 'Phase Parameter Min Value'
	columnNamesPhaseParameterMaxValue = 'Phase Parameter Max Value'
	
	columnNamesOperationName = 'Operation Name'
	columnNamesOperationPathName = 'Operation Path'
	columnNamesOperationStepName = 'Operation Step Name'
	columnNamesOperationDeferName = 'Defer To Operation'
	columnNamesOperationParameterName = 'Operation Parameter Name'
	columnNamesOperationParameterName = 'Operation Parameter Name'
	columnNamesOperationParameterDefaultValue = 'Operation Parameter Default Value'
	columnNamesOperationParameterMinValue = 'Operation Parameter Min Value'
	columnNamesOperationParameterMaxValue = 'Operation Parameter Max Value'
	
	columnNamesUnitProcedureName = 'Unit Procedure Name'
	columnNamesUnitProcedurePathName = 'Unit Procedure Path'
	columnNamesUnitProcedureStepName = 'Unit Procedure Step Name'
	columnNamesUnitProcedureDeferName = 'Defer To Unit Procedure'
	columnNamesUnitProcedureParameterName = 'Unit Procedure Parameter Name'
	columnNamesUnitProcedureParameterDefaultValue = 'Unit Procedure Parameter Default Value'
	columnNamesUnitProcedureParameterMinValue = 'Unit Procedure Parameter Min Value'
	columnNamesUnitProcedureParameterMaxValue = 'Unit Procedure Parameter Max Value'
	
	columnNamesProcedureName = 'Procedure Name'
	columnNamesProcedurePathName = 'Procedure Path'
	columnNamesProcedureStepName = 'Procedure Step Name'
	columnNamesProcedureDeferName = 'Defer To Procedure'
	columnNamesProcedureParameterName = 'Procedure Parameter Name'
	columnNamesProcedureParameterDefaultValue = 'Procedure Parameter Default Value'
	columnNamesProcedureParameterMinValue = 'Procedure Parameter Min Value'
	columnNamesProcedureParameterMaxValue = 'Procedure Parameter Max Value'
	
	listOfColumnParameterNames = [columnNamesPhaseParameterName, columnNamesOperationParameterName, columnNamesUnitProcedureParameterName, columnNamesProcedureParameterName]
	listOfColumnDefaultParameterValues = [columnNamesPhaseParameterDefaultValue, columnNamesOperationParameterDefaultValue, columnNamesUnitProcedureParameterDefaultValue, columnNamesProcedureParameterDefaultValue]
	listOfColumnParameterMinValues = [columnNamesPhaseParameterMinValue, columnNamesOperationParameterMinValue, columnNamesUnitProcedureParameterMinValue, columnNamesProcedureParameterMinValue]
	listOfColumnParameterMaxValues = [columnNamesPhaseParameterMaxValue, columnNamesOperationParameterMaxValue, columnNamesUnitProcedureParameterMaxValue, columnNamesProcedureParameterMaxValue]
	
	## Param constants
	paramDefaultRecordingTypeName = 'All to Object and History'
	paramDefaultValueSourceRecipe = 'Recipe and Execution'
	paramDefaultValueSourceReport = 'Monitor'
	
	
	##########################################################################################################################################################
	#### Prechecks
	##########################################################################################################################################################
	
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Started Pre Checks.', loggerObj=myLogger, fullLog=runningLog)
	
	
	listOfNonValidDataTypes = []
	listOfNonValidMinMax = []
	listOfNonValidRanges = []
	listOfNonValidParamDataTypes = []
	listOfDuplicateParamPhases = []
	listOfDuplicateParamOperations = []
	listOfDuplicateParamUnitProcedures = []
	listOfDuplicateParamProcedures = []
	
	for row in range(dataset.getRowCount()):
	
		cellDataTypeValue = dataset.getValueAt(row, columnNamesPhaseParameterDatatype)
		###################################################################################
		#### Check if data type of all parameters is supported
		###################################################################################
		if cellDataTypeValue not in validParameterDatatypes: listOfNonValidDataTypes.append(dataset.getValueAt(row, columnNamesPhaseParameterName) + "\tDatatype= " + str(cellDataTypeValue) + '\n')
		
		###################################################################################
		#### Check if min max are correct (min < max)
		###################################################################################
		for col in listOfColumnParameterMinValues:
			indexParamName = listOfColumnParameterMinValues.index(col)
			
			minValueCheck = dataset.getValueAt(row, listOfColumnParameterMinValues[indexParamName])
			maxValueCheck = dataset.getValueAt(row, listOfColumnParameterMaxValues[indexParamName])
			
		if minValueCheck > maxValueCheck: listOfNonValidMinMax.append(dataset.getValueAt(row, listOfColumnParameterNames[indexParamName]) + "\t Min= " + str(minValueCheck) + "\t Max= " + str(maxValueCheck) + '\n')
	
	
		###################################################################################
		## Check if default value is correct based on datatype
		## Check if deferable parameters have the same datatype as its original (R_ same as OP_ same as UP_ etc)
		###################################################################################
		for paramName in listOfColumnParameterNames:
			indexParamName = listOfColumnParameterNames.index(paramName)
			parameterName = dataset.getValueAt(row, paramName)
			cellDefaultValue = dataset.getValueAt(row, listOfColumnDefaultParameterValues[indexParamName])
			cellMinValue = dataset.getValueAt(row, listOfColumnParameterMinValues[indexParamName])
			cellMaxValue = dataset.getValueAt(row, listOfColumnParameterMaxValues[indexParamName])
			
			if not isinstance(WM_FIRE.util.tryEvalStringToNumbers(cellDefaultValue), (str,unicode)):
				cellDefaultValueConverted = WM_FIRE.util.tryEvalAndRemoveZeros(cellDefaultValue)
			cellMinValueConverted = WM_FIRE.util.tryEvalAndRemoveZeros(cellMinValue)
			cellMaxValueConverted = WM_FIRE.util.tryEvalAndRemoveZeros(cellMaxValue)
			
			# if parameter value is not a valid datatype
			if not isinstance(cellDefaultValueConverted, validParameterDatatypesPython[cellDataTypeValue]): 
				listOfNonValidParamDataTypes.append(listOfColumnDefaultParameterValues[indexParamName] + '\tParameter= ' + parameterName + '\tValue=' + str(cellDefaultValueConverted) + '\tExpected=' + str(validParameterDatatypesPython[cellDataTypeValue]) + '\n')
			
			# If parameter is outside of valid range raise flag
			if not isinstance(WM_FIRE.util.tryEvalStringToNumbers(cellDefaultValue), (str,unicode)) and (cellDefaultValueConverted > cellMaxValueConverted or cellDefaultValueConverted < cellMinValueConverted):
				listOfNonValidRanges.append(listOfColumnDefaultParameterValues[indexParamName] + '\tParameter= ' + parameterName + '\tValue=' + str(cellDefaultValueConverted) + '\tExpected Range= '+  str(cellMinValueConverted)+ '-'+  str(cellMaxValueConverted) + '\n')

	###################################################################################
	## Check if duplicate procedure parameters within same phase, operation, unit procedure, procedure???? no time
	###################################################################################
	
	if len(listOfNonValidDataTypes) > 0: raise ValueError('Non Supported Datatypes in the Following Rows: \n%(listOfNonValidDataTypes)s\nSupported Datatypes: %(validParameterDatatypes)s' % {"listOfNonValidDataTypes":''.join(listOfNonValidDataTypes), "validParameterDatatypes":validParameterDatatypes})
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Check: Datatypes Check Passed', loggerObj=myLogger, fullLog=runningLog)
	
	if len(listOfNonValidMinMax) > 0: raise ValueError('Min > Max for Following Rows: \n%(listOfNonValidMinMax)s\nNot Valid' % {"listOfNonValidMinMax":''.join(listOfNonValidMinMax)})
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Check: Min/Max Check Passed', loggerObj=myLogger, fullLog=runningLog)

	if len(listOfNonValidRanges) > 0: raise ValueError('Values Out of Range in the Following Rows: \n%(listOfNonValidRanges)s' % {"listOfNonValidRanges":''.join(listOfNonValidRanges)})
	if len(listOfNonValidParamDataTypes) > 0: raise ValueError('Non Supported Datatypes in the Following Rows: \n%(listOfNonValidParamDataTypes)s' % {"listOfNonValidParamDataTypes":''.join(listOfNonValidParamDataTypes)})
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Check: Default Value Datatypes and Ranges Check Passed', loggerObj=myLogger, fullLog=runningLog)
	
	#### Check if Yes to defer is missing its param???? no time
	#### check if things are blank? no time
	#### check if operation is assigned to Unit Class??? no time
	'''
	###################################################################################
	# Get list of objects from dataset
	# Count number or parameters for each, count number of steps, get UUID for unit class, get paths etc
	
	# Build Objects to be easier to loop tru
	# WM_FIRE Phase Object format:
	# Phase = {'name':None, 'class':None, 'params':[], 'step':None}
	
	# Param object format
	# Param = {'name':'example', 'type':'Recipe', 'value':0, 'dataType':'Integer', 'valueMin':0, 'valueMax':1, 'defer':False, 'calculation':''}
	
	# Generic object for Procedure, Unit Procedure, Operation
	# step needs step name and phase/OP/UP object
	# procedure doesnt have a class param value
	# Obj = {'name':'example', 'path':'','class':None,'unitClass':None, 'params':[], 'paramsCount':0,'steps':['name':'', 'child':[]], 'stepsCount':0}
	###################################################################################
	'''
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Check: Building Objects', loggerObj=myLogger, fullLog=runningLog)
	uniquePhaseList = []
	uniqueOperationList = []
	uniqueUnitProcedureList = []
	uniqueProcedureList = []
	uniqueUnitClassList = []
	uniqueOperationPathList = []
	uniqueUnitProcedurePathList = []
	uniqueProcedurePathList = []
	uniqueTupleOperationPathList = [] # List of tuples for (<PathToOperation>, <Operation>) (used to check if operation exists later
	uniqueTupleUnitProcedurePathList = [] # List of tuples for (<PathToUnitProcedure>, <Unit Procedure>) (used to check if Unit Procedure exists later
	uniqueTupleProcedurePathList = [] # List of tuples for (<PathToProcedure>, <Procedure>) (used to check if Procedure exists later
	
	dictOfPhases = {}
	
	dictOfOperations = {}
	dictOfPhasesPerOperation = {}
	
	dictOfUnitProcedures = {}
	dictOfOperationsPerUnitProcedure = {}
	
	dictOfProcedures = {}
	dictOfUnitProceduresPerProcedure = {}
	
	for row in range(dataset.getRowCount()):
		currentPhase = dataset.getValueAt(row, columnNamesPhaseName)
		currentPhaseParameterName = dataset.getValueAt(row, columnNamesPhaseParameterName)
		
		currentOperation = dataset.getValueAt(row, columnNamesOperationName)
		currentOperationPath = dataset.getValueAt(row, columnNamesOperationPathName)
		currentOperationParameterName = dataset.getValueAt(row, columnNamesOperationParameterName)
		
		currentUnitProcedure = dataset.getValueAt(row, columnNamesUnitProcedureName)
		currentUnitProcedurePath = dataset.getValueAt(row, columnNamesUnitProcedurePathName)
		currentUnitProcedureParameterName = dataset.getValueAt(row, columnNamesUnitProcedureParameterName)
		
		currentProcedure = dataset.getValueAt(row, columnNamesProcedureName)
		currentProcedurePath = dataset.getValueAt(row, columnNamesProcedurePathName)
		currentProcedureParameterName = dataset.getValueAt(row, columnNamesProcedureParameterName)
		
		currentUnitClass = dataset.getValueAt(row, columnNamesUnitClassName)
	
		# Get unique Unit Class to check if it exists later
		if currentUnitClass not in uniqueUnitClassList:
			uniqueUnitClassList.append(currentUnitClass)
		
		# Get unique paths to check if it exists later	
		if currentOperationPath not in uniqueOperationPathList:
			uniqueOperationPathList.append(currentOperationPath)
		if currentUnitProcedurePath not in uniqueUnitProcedurePathList:
			uniqueUnitProcedurePathList.append(currentUnitProcedurePath)
		if currentProcedurePath not in uniqueProcedurePathList:
			uniqueProcedurePathList.append(currentProcedurePath)
		
		uniqueTupleOperationPathList.append((currentOperationPath,currentOperation))
		uniqueTupleUnitProcedurePathList.append((currentUnitProcedurePath,currentUnitProcedure))
		uniqueTupleProcedurePathList.append((currentProcedurePath,currentProcedure))
		
		# DeferralCheck	
		# Phase to Operation
		sepasoft_deferral_prefix_phToOP = 'param("/{}/{}/{}.'
		sepasoft_deferral_sufix_phToOP = '")'
		if dataset.getValueAt(row, columnNamesOperationDeferName) == 'Yes':
			phToOP_Final_DeferralExpression = sepasoft_deferral_prefix_phToOP + currentOperationParameterName + sepasoft_deferral_sufix_phToOP
		else:
			phToOP_Final_DeferralExpression = ''
	
		# Operation to Unit Procedure
		sepasoft_deferral_prefix_opToUP = 'param("/{}/{}.'
		sepasoft_deferral_sufix_opToUP = '")'
		if dataset.getValueAt(row, columnNamesUnitProcedureDeferName) == 'Yes':
			opToUP_Final_DeferralExpression = sepasoft_deferral_prefix_opToUP + currentUnitProcedureParameterName + sepasoft_deferral_sufix_opToUP
		else:
			opToUP_Final_DeferralExpression = ''
	
		# Unit Procedure to Procedure
		sepasoft_deferral_prefix_upToP = 'param("/{}.'
		sepasoft_deferral_sufix_upToP = '")'
		if dataset.getValueAt(row, columnNamesProcedureDeferName) == 'Yes':
			upToP_Final_DeferralExpression = sepasoft_deferral_prefix_upToP + currentProcedureParameterName + sepasoft_deferral_sufix_upToP
		else:
			upToP_Final_DeferralExpression = ''
		#print upToP_Final_DeferralExpression
		################################################################
		# Create phase param obj		
		################################################################

		phaseParam = {
				'name':currentPhaseParameterName,
				'type':paramDefaultValueSourceRecipe if dataset.getValueAt(row, columnNamesPhaseParameterType) == 'Recipe' else paramDefaultValueSourceReport,
				'value':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesPhaseParameterDefaultValue)),
				'dataType':dataset.getValueAt(row, columnNamesPhaseParameterDatatype),
				'valueMin':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesPhaseParameterMinValue)),
				'valueMax':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesPhaseParameterMaxValue)),
				'defer':phToOP_Final_DeferralExpression}	
	
		if currentPhase not in uniquePhaseList:
			uniquePhaseList.append(currentPhase)
	
			# Create a phase obj
			phase = {
					'name':dataset.getValueAt(row, columnNamesPhaseName),
					'path':dataset.getValueAt(row, columnNamesPhasePathName),
					'type':'phase',
					'paramCount':0,
					'deferralCount':0,
					#'params':[]}
					'params':{}}
			#phase['params'].append(phaseParam)
			phase['params'][currentPhaseParameterName] = phaseParam
			phase['paramCount'] = 1
			phase['deferralCount'] = 1 if len(phToOP_Final_DeferralExpression) > 0 else 0
			
			dictOfPhases[currentPhase] = phase
			
		else:
			# add param to phase obj
			#dictOfPhases[currentPhase]['params'].append(phaseParam)
			dictOfPhases[currentPhase]['params'][currentPhaseParameterName] = phaseParam
			dictOfPhases[currentPhase]['paramCount'] += 1
			dictOfPhases[currentPhase]['deferralCount'] += 1 if len(phToOP_Final_DeferralExpression) > 0 else 0
		
		################################################################
		# Create operation param obj	
		################################################################
		operationParam = {
				'name':currentOperationParameterName,
				'type':paramDefaultValueSourceRecipe if dataset.getValueAt(row, columnNamesPhaseParameterType) == 'Recipe' else paramDefaultValueSourceReport,
				'value':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesOperationParameterDefaultValue)),
				'dataType':dataset.getValueAt(row, columnNamesPhaseParameterDatatype),
				'valueMin':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesOperationParameterMinValue)),
				'valueMax':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesOperationParameterMaxValue)),
				'defer':opToUP_Final_DeferralExpression}
		
		stepNameOP = dataset.getValueAt(row, columnNamesOperationStepName)
		steps = {
				'name':stepNameOP,
				'phaseName':currentPhase,
				'phase':dictOfPhases[currentPhase]}
				
		if currentOperation not in uniqueOperationList:
			uniqueOperationList.append(currentOperation)
			
			# Create a operation obj		
			operation = {
					'name':currentOperation,
					'path':dataset.getValueAt(row, columnNamesOperationPathName),
					'type':'operation',
					'paramCount':0,
					#'params':[],
					'params':{},
					'deferralCount':0,
					'stepsCount':0,
					'steps':{}}
					
			#operation['params'].append(operationParam)
			operation['params'][currentOperationParameterName] = operationParam
			operation['paramCount'] = 1
			operation['deferralCount'] = 1 if len(opToUP_Final_DeferralExpression) > 0 else 0
			operation['stepsCount'] = 1
			operation['steps'][stepNameOP] = steps
			
			dictOfOperations[currentOperation] = operation
		else:
			# add param to operation obj
			#dictOfOperations[currentOperation]['params'].append(operationParam)
			dictOfOperations[currentOperation]['params'][currentOperationParameterName] = operationParam
			dictOfOperations[currentOperation]['paramCount'] += 1
			dictOfOperations[currentOperation]['deferralCount'] += 1 if len(opToUP_Final_DeferralExpression) > 0 else 0
			dictOfOperations[currentOperation]['stepsCount'] += 1
			dictOfOperations[currentOperation]['steps'][stepNameOP] = steps
		
		################################################################
		# Create unit procedure param obj	
		################################################################
		unitProcedureParam = {
				'name':currentUnitProcedureParameterName,
				'type':paramDefaultValueSourceRecipe if dataset.getValueAt(row, columnNamesPhaseParameterType) == 'Recipe' else paramDefaultValueSourceReport,
				'value':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesUnitProcedureParameterDefaultValue)),
				'dataType':dataset.getValueAt(row, columnNamesPhaseParameterDatatype),
				'valueMin':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesUnitProcedureParameterMinValue)),
				'valueMax':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesUnitProcedureParameterMaxValue)),
				'defer':upToP_Final_DeferralExpression}
		
		stepNameUP = dataset.getValueAt(row, columnNamesUnitProcedureStepName)
		steps = {
				'name':stepNameUP,
				'operationName':currentOperation,
				'operation':dictOfOperations[currentOperation]}
	
		if currentUnitProcedure not in uniqueUnitProcedureList:
			uniqueUnitProcedureList.append(currentUnitProcedure)
			
			# Create a unit procedure obj		
			unitProcedure = {
					'name':currentUnitProcedure,
					'path':dataset.getValueAt(row, columnNamesUnitProcedurePathName),
					'type':'unit procedure',
					'paramCount':0,
					#'params':[],
					'params':{},
					'deferralCount':0,
					'stepsCount':0,
					'steps':{}}
					
			#unitProcedure['params'].append(unitProcedureParam)
			unitProcedure['params'][currentUnitProcedureParameterName] = unitProcedureParam
			unitProcedure['paramCount'] = 1
			unitProcedure['deferralCount'] = 1 if len(upToP_Final_DeferralExpression) > 0 else 0
			unitProcedure['stepsCount'] = 1
			unitProcedure['steps'][stepNameUP] = steps
			
			dictOfUnitProcedures[currentUnitProcedure] = unitProcedure
		else:
			# add param to unit procedure obj
			#dictOfUnitProcedures[currentUnitProcedure]['params'].append(unitProcedureParam)
			dictOfUnitProcedures[currentUnitProcedure]['params'][currentUnitProcedureParameterName] = unitProcedureParam
			dictOfUnitProcedures[currentUnitProcedure]['paramCount'] += 1
			dictOfUnitProcedures[currentUnitProcedure]['deferralCount'] += 1 if len(upToP_Final_DeferralExpression) > 0 else 0
			dictOfUnitProcedures[currentUnitProcedure]['stepsCount'] += 1
			dictOfUnitProcedures[currentUnitProcedure]['steps'][stepNameUP] = steps
		
		################################################################
		# Create procedure param obj	
		################################################################
	
		procedureParam = {
				'name':currentProcedureParameterName,
				'type':paramDefaultValueSourceRecipe if dataset.getValueAt(row, columnNamesPhaseParameterType) == 'Recipe' else paramDefaultValueSourceReport,
				'value':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesProcedureParameterDefaultValue)),
				'dataType':dataset.getValueAt(row, columnNamesPhaseParameterDatatype),
				'valueMin':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesProcedureParameterMinValue)),
				'valueMax':WM_FIRE.util.tryEvalAndRemoveZeros(dataset.getValueAt(row, columnNamesProcedureParameterMaxValue)),
				}
		
		stepNameP = dataset.getValueAt(row, columnNamesProcedureStepName)
		steps = {
				'name':stepNameP,
				'unitProcedureName':currentUnitProcedure,
				'unitProcedure':dictOfUnitProcedures[currentUnitProcedure]}
	
		if currentProcedure not in uniqueProcedureList:
			uniqueProcedureList.append(currentProcedure)
			
			# Create a unit procedure obj		
			procedure = {
					'name':currentProcedure,
					'path':dataset.getValueAt(row, columnNamesProcedurePathName),
					'type':'procedure',
					'paramCount':0,
					#'params':[],
					'params':{},
					'stepsCount':0,
					'steps':{}}
					
			procedure['params'][currentProcedureParameterName] = procedureParam
			procedure['paramCount'] = 1
			procedure['stepsCount'] = 1
			procedure['steps'][stepNameP] = steps
			
			dictOfProcedures[currentProcedure] = procedure
		else:
			# add param to unit procedure obj
			#dictOfProcedures[currentProcedure]['params'].append(procedureParam)
			dictOfProcedures[currentProcedure]['params'][currentProcedureParameterName] = procedureParam
			dictOfProcedures[currentProcedure]['paramCount'] += 1
			dictOfProcedures[currentProcedure]['stepsCount'] += 1
			dictOfProcedures[currentProcedure]['steps'][stepNameP] = steps
			
	# Make lists of tuples actually unique by removing duplicates
	uniqueTupleOperationPathList = list(set(uniqueTupleOperationPathList))
	uniqueTupleUnitProcedurePathList = list(set(uniqueTupleUnitProcedurePathList))
	uniqueTupleProcedurePathList = list(set(uniqueTupleProcedurePathList))
	#pprint(dictOfProcedures)
	###################################################################################
	# Check if Phases, Operations, Unit Procedures, Procedures exist in system
	###################################################################################
	
	listOfNonValidObjects = []
	listOfNonValidUnitClassAssigments = []
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Check: Checking if Unit Classes are Valid', loggerObj=myLogger, fullLog=runningLog)
	if len(uniqueUnitClassList) > 0:
		for unitClass in uniqueUnitClassList:
			try:
				temp = system.mes.batch.unitclass.getLink(unitClass)
			except:
				listOfNonValidObjects.append('\t' + unitClass + '\n')
			else:
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2,'Unit Class:' + '\t' + unitClass, loggerObj=myLogger, fullLog=runningLog)
	if len(listOfNonValidObjects) > 0: raise ValueError('Unit Classes Not Found in System: \n%(listOfNonValidObjects)s' % {"listOfNonValidObjects":''.join(listOfNonValidObjects)})
	
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Check: Checking if Phases are Valid', loggerObj=myLogger, fullLog=runningLog)
	if len(uniquePhaseList) > 0:
		for phase in uniquePhaseList:
			try:
				temp = system.mes.batch.phase.getPhaseLink(phase)
			except:
				listOfNonValidObjects.append('\t' + phase + '\n')
			else:
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2,'Phase:' + '\t' + phase, loggerObj=myLogger, fullLog=runningLog)
	if len(listOfNonValidObjects) > 0: raise ValueError('Phases Not Found in System: \n%(listOfNonValidObjects)s' % {"listOfNonValidObjects":''.join(listOfNonValidObjects)})
	
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Check: Checking if Operations are Valid', loggerObj=myLogger, fullLog=runningLog)
	if len(uniqueOperationList) > 0:
		for operationPath,operation in uniqueTupleOperationPathList:
			try:
				operationsTemplateClassObj = system.mes.batch.recipe.loadTemplateClass(operationPath, None)
				operationsTemplateClassLink = operationsTemplateClassObj.asLink()
				temp = system.mes.batch.recipe.getTemplateLink(operation, operationsTemplateClassLink)
			except:
				listOfNonValidObjects.append('\t' + operation + '\n')
			else:
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2,operationPath + ':\t' + operation, loggerObj=myLogger, fullLog=runningLog)
	if len(listOfNonValidObjects) > 0: raise ValueError('Operations Not Found in System: \n%(listOfNonValidObjects)s' % {"listOfNonValidObjects":''.join(listOfNonValidObjects)})
	
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Check: Checking if Unit Procedures are Valid', loggerObj=myLogger, fullLog=runningLog)
	if len(uniqueUnitProcedureList) > 0:
		for unitProcedurePath,unitProcedure in uniqueTupleUnitProcedurePathList:
			try:
				unitProceduresTemplateClassObj = system.mes.batch.recipe.loadTemplateClass(unitProcedurePath, None)
				unitProceduresTemplateClassLink = unitProceduresTemplateClassObj.asLink()
				temp = system.mes.batch.recipe.getTemplateLink(unitProcedure, unitProceduresTemplateClassLink)
			except:
				listOfNonValidObjects.append('\t' + unitProcedure + '\n')
			else:
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2,unitProcedurePath + ':\t' + unitProcedure, loggerObj=myLogger, fullLog=runningLog)
	if len(listOfNonValidObjects) > 0: raise ValueError('Unit Procedures Not Found in System: \n%(listOfNonValidObjects)s' % {"listOfNonValidObjects":''.join(listOfNonValidObjects)})
	
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Check: Checking if Procedures are Valid', loggerObj=myLogger, fullLog=runningLog)
	if len(uniqueProcedureList) > 0:
		for procedurePath,procedure in uniqueTupleProcedurePathList:
			try:
				proceduresClassObj = system.mes.batch.recipe.loadRecipeClass(procedurePath, None)
				proceduresClassLink = proceduresClassObj.asLink()
				temp = system.mes.batch.recipe.getRecipeLink(procedure, proceduresClassLink)
			except:
				listOfNonValidObjects.append('\t' + procedure + '\n')
			else:
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, procedurePath + ':\t' + procedure, loggerObj=myLogger, fullLog=runningLog)
	if len(listOfNonValidObjects) > 0: raise ValueError('Procedures Not Found in System: \n%(listOfNonValidObjects)s' % {"listOfNonValidObjects":''.join(listOfNonValidObjects)})
	
	stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, 'Pre Checks Completed', loggerObj=myLogger, fullLog=runningLog)
	'''
	##########################################################################################################################################################
	#### Modify Existing MES Objects (Phases, Operations, Unit Procedures, Procedures)
	#### This is the main code, it does phases first using the dataset since its the simpler way (but ineficient) then it uses the nested dictionaries to
	#### first update parameters for each object from top level down Procedures, Unit Procedures, then Operations
	#### Finally, it updates the parameters in the logic (e.g. Procedure with step UP_001 (Unit Procedure) is then updated will any deferral parameters)
	#### In sepasoft class based objects should not have their parameters filled with deferrals. You could, but that would lock down that class and not be dynamic enough.
	#### The deferrals should be done in the steps within the object's logic
	#### Because of how sepasoft deals with things behind the scenes, it looks like updating class parameters first and saving their respective MES objects first
	#### IN THE FOLLOWING ORDER OP, UP, P
	#### THEN update deferral values in a separate loop
	##########################################################################################################################################################
	'''
	# Mod Phases Objects
	modCount = 0
	createdCount = 0
	removedCount = 0
	
	# __Super Ineficient loop__, but keeps one phase at a time order (better way would be to sort dataset by phase name to guarantee order... maybe next time)
	if not skipPhase:
		for phase in uniquePhaseList:
			stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, phase + '\tStarted Updating/Creating Phase Parameter(s)', loggerObj=myLogger, fullLog=runningLog)
			currentPhaseMESObject = system.mes.batch.phase.getPhaseLink(currentPhase).getMESObject()
			#currentPhaseMESObject.setExposed(True)
			
			## Remove all OPC params first (to guarantee that OPC parameters that are not in the excel sheet dont remain in phase)
			removedCount, listOfRemovedParams, removedError = removeAllUserDefinedParamsFromBatchPhaseObj(currentPhaseMESObject)
			if debugLogEnabled and removedError != '': raise  ValueError('Error While Removing Params from Unit Procedure. Error: \n%(removedError)s' % {"removedError":removedError})
			if debugLogEnabled and len(listOfRemovedParams) > 0: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 1, 'Parameters Removed: \n%(listOfRemovedParams)s' % {"listOfRemovedParams":''.join(listOfRemovedParams)}, loggerObj=myLogger, fullLog=runningLog)
			
			# for each param for current phase:
			for row in range(dataset.getRowCount()):
				currentPhase = dataset.getValueAt(row, columnNamesPhaseName)
				if phase == currentPhase:
					currentParameter = dataset.getValueAt(row, columnNamesPhaseParameterName)
					currentParameterDatatype = dataset.getValueAt(row, columnNamesPhaseParameterDatatype)
					currentParameterDefaultValue = dataset.getValueAt(row, columnNamesPhaseParameterDefaultValue)
					currentParameterMinValue = dataset.getValueAt(row, columnNamesPhaseParameterMinValue)
					currentParameterMaxValue = dataset.getValueAt(row, columnNamesPhaseParameterMaxValue)
					
					currentParameterDefaultValue = WM_FIRE.util.tryEvalAndRemoveZeros(currentParameterDefaultValue)
					currentParameterMinValue = WM_FIRE.util.tryEvalAndRemoveZeros(currentParameterMinValue)
					currentParameterMaxValue = WM_FIRE.util.tryEvalAndRemoveZeros(currentParameterMaxValue)
							
					# Change default built-in params
					currentPhaseMESObject.getParameter('Command_Number').setParamTagTypeName('OPC')
					currentPhaseMESObject.getParameter('State_Number').setParamTagTypeName('OPC')
					currentPhaseMESObject.getParameter('Handshake_Ack').setParamTagTypeName('OPC')
					currentPhaseMESObject.getParameter('Handshake_Value').setParamTagTypeName('OPC')
					
					# Add/Modify params as needed
					try:
						param = currentPhaseMESObject.getParameter(currentParameter)
					except NoSuchElementException:
						# 'Param doesnt exists'
						#print 'Param doesnt exist'
						param = currentPhaseMESObject.addParameter(currentParameter)
						param.setParamRecordingTypeName(paramDefaultRecordingTypeName)
						param.setParamValueSourceName(paramDefaultValueSourceRecipe if dataset.getValueAt(row, columnNamesPhaseParameterType) == 'Recipe' else paramDefaultValueSourceReport)
						param.setParamTagTypeName('OPC')
						param.setParamDataTypeName(currentParameterDatatype)
						param.setParamCalculation('')
						param.setParamValue(currentParameterDefaultValue)
						param.setParamMinValue(currentParameterMinValue)
						param.setParamMaxValue(currentParameterMaxValue)
						if debugLogEnabled: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 1,  'Created Parameter: ' + currentParameter, loggerObj=myLogger, fullLog=runningLog)
						createdCount += 1
					except Error as e:
						print 'Its Bad'
						print e
					else: # All Good
						# 'Param exists'
						param.setParamRecordingTypeName(paramDefaultRecordingTypeName)
						param.setParamValueSourceName(paramDefaultValueSourceRecipe if dataset.getValueAt(row, columnNamesPhaseParameterType) == 'Recipe' else paramDefaultValueSourceReport)
						param.setParamTagTypeName('OPC')
						param.setParamDataTypeName(currentParameterDatatype)
						param.setParamCalculation('')
						param.setParamValue(currentParameterDefaultValue)
						param.setParamMinValue(currentParameterMinValue)
						param.setParamMaxValue(currentParameterMaxValue)
						if debugLogEnabled: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 1, 'Modified Parameter: ' + currentParameter, loggerObj=myLogger, fullLog=runningLog)
						modCount += 1
	
			system.mes.batch.phase.savePhase(currentPhaseMESObject)
			stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, 'Completed Phase Updates' + '\tParameters Modified: ' + str(modCount) + '\tParameters Created: ' + str(createdCount)+ '\t Parameters Removed: ' + str(removedCount), loggerObj=myLogger, fullLog=runningLog)
		
	modCount = 0
	createdCount = 0
	removedCount = 0
	deferralCount = 0
	#pprint(dictOfProcedures, depth=2)
	
	### CLASS PARAMS
	for procedureName, procedureDict in dictOfProcedures.items():
		currentProcedureName = procedureDict['name']
		currentProcedureObjList = system.mes.batch.recipe.loadRecipe(system.mes.batch.recipe.getRecipeLink(currentProcedureName, system.mes.batch.recipe.loadRecipeClass(procedureDict['path'], None).asLink()))
		
		###########################################################################
		## List contains class parameters and steps with instance parameters
		## Loop tru Procedure Parameters to mod/add/remove based on excel sheet
		###########################################################################
		stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, currentProcedureName + '\tStarted Updating/Creating Procedure Parameter(s)', loggerObj=myLogger, fullLog=runningLog)
		
		if not skipPP:
			for procedureObjLogic in currentProcedureObjList:
				if procedureObjLogic.getName() == currentProcedureName and currentProcedureObjList.index(procedureObjLogic) > 0:
					currentProcedureLogicObjParamsListClean = [] # list of non bult-in user defined parameters Objects
					currentProcedureLogicParamsListCleaned = [] # list of non bult-in user defined parameters (string name only) that will be removed one by one as we mod those params, the remaining params in this list will be removed from MESObject
							
					currentProcedureLogicObjParamsList = procedureObjLogic.getParameters()
					
					# Loop tru all Procedure Logic MESObject Parameters get user defined ones
					currentProcedureLogicParamsListCleaned, currentProcedureLogicObjParamsListClean = getAllUserDefinedParametersList(procedureObjLogic)
					currentProcedureLogicObjParamsListCleaned = currentProcedureLogicObjParamsListClean
					
					modCount = 0
					createdCount = 0
					for procedureParamName, procedureParam in procedureDict['params'].items():
						for paramObj in currentProcedureLogicObjParamsListClean:
							good, created, error = setOrCreateParameterInBatchMasterLogicObj(procedureObjLogic, procedureParam['name'], paramDefaultRecordingTypeName, procedureParam['type'], procedureParam['dataType'], procedureParam['value'], procedureParam['valueMin'], procedureParam['valueMax'], paramCalculation='')
							if good and not created: # already exists
								modCount += 1
								currentProcedureLogicParamsListCleaned.remove(procedureParamName)
							elif good:
								createdCount += 1
							elif not good and debugLogEnabled:
								stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 1,'Error Removing Parameter:\t%(param)s\tError%(error)s' % {"param":procedureParam['name'],"error":error}, loggerObj=myLogger, fullLog=runningLog)
							
					removedCount = 0
					if len(currentProcedureLogicParamsListCleaned) > 0:
						for paramtoDelete in currentProcedureLogicParamsListCleaned:
							stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, 'Parameter Name= %(name)s exists in system but not in excel sheet, will be deleted' % ({'name':currentProcedureParamName}), loggerObj=myLogger, fullLog=runningLog)
							procedureObjLogic.removeParameter(paramtoDelete)
							removedCount += 1
			system.mes.batch.recipe.saveRecipe(currentProcedureObjList)
			stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, 'Completed'  + '\tParameters Modified: ' + str(modCount) + '\tParameters Created: ' + str(createdCount)+ '\t Parameters Removed: ' + str(removedCount), loggerObj=myLogger, fullLog=runningLog)
	
		
		###########################################################################
		## Loop tru Procedure Logic UnitProcedure
		###########################################################################
		### Only go tru ONE unique UNIT procedure (template) to update its params,
		### then go tru ALL unit procedures that are steps in Procedure
		for procedureStepName, procedureStepDict in procedureDict['steps'].items():
			currentUnitProcedureName = procedureStepDict['unitProcedure']['name']
			currentUnitProcedureObjList = system.mes.batch.recipe.loadTemplate(system.mes.batch.recipe.getTemplateLink(currentUnitProcedureName, system.mes.batch.recipe.loadTemplateClass(procedureStepDict['unitProcedure']['path'], None).asLink()))
			if not skipUP:
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, currentUnitProcedureName + '\tStarted Creating Unit Procedure Parameter(s)', loggerObj=myLogger, fullLog=runningLog)
				for unitProcedureObjLogic in currentUnitProcedureObjList:
					if unitProcedureObjLogic.getName() == currentUnitProcedureName:
						## Remove all existing user defined parameters to guarantee excel sheet new params will be correct
						removedCount, listOfRemovedParams, removedError = removeAllUserDefinedParamsFromBatchMasterLogicObj(unitProcedureObjLogic)
						if debugLogEnabled and removedError != '': raise  ValueError('Error While Removing Params from Unit Procedure. Error: \n%(removedError)s' % {"removedError":removedError})
						if debugLogEnabled and len(listOfRemovedParams) > 0: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 1,'Parameters Removed: \n%(listOfRemovedParams)s' % {"listOfRemovedParams":''.join(listOfRemovedParams)}, loggerObj=myLogger, fullLog=runningLog)
						
						## Add params
						createdCount = 0
						for paramName, paramDict in procedureStepDict['unitProcedure']['params'].items():
							good, created, error = setOrCreateParameterInBatchMasterLogicObj(unitProcedureObjLogic, paramDict['name'], paramDefaultRecordingTypeName, paramDict['type'], paramDict['dataType'], paramDict['value'], paramDict['valueMin'], paramDict['valueMax'], paramCalculation='')
							if good and created: 
								createdCount += 1
							elif not good and debugLogEnabled:
								stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 1,'Error Removing Parameter:\t%(param)s\tError%(error)s' % {"param":paramDict['name'],"error":error}, loggerObj=myLogger, fullLog=runningLog)
						
				if createdCount > 0 or removedCount > 0:
					system.mes.batch.recipe.saveTemplate(currentUnitProcedureObjList)
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, 'Completed'  + '\tParameters Created: ' + str(createdCount)+ '\t Parameters Removed: ' + str(removedCount), loggerObj=myLogger, fullLog=runningLog)
			
			###########################################################################
			## Loop tru Operation Logic Operation
			###########################################################################
			### Only go tru ONE unique Operation (template) to update its params,
			### then go tru ALL Operations that are steps in ALL unit Procedures that are steps in Procedure...
			for unitProcedureStepName, unitProcedureStepDict in procedureStepDict['unitProcedure']['steps'].items():
				currentOperationName = unitProcedureStepDict['operation']['name']
				currentOperationObjList = system.mes.batch.recipe.loadTemplate(system.mes.batch.recipe.getTemplateLink(currentOperationName, system.mes.batch.recipe.loadTemplateClass(unitProcedureStepDict['operation']['path'], None).asLink()))
				if not skipOP:
					stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, currentOperationName + '\tStarted Creating Operation Parameter(s)', loggerObj=myLogger, fullLog=runningLog)
					for currentOperationObj in currentOperationObjList:
						if currentOperationObj.getName() == currentOperationName:
							## Remove all existing user defined parameters to guarantee excel sheet new params will be correct
							removedCount, listOfRemovedParams, removedError = removeAllUserDefinedParamsFromBatchMasterLogicObj(currentOperationObj)
							if debugLogEnabled and removedError != '': raise  ValueError('Error While Removing Params from Operation. Error: \n%(removedError)s' % {"removedError":removedError})
							if debugLogEnabled and len(listOfRemovedParams) > 0: stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 2,'Parameters Removed: \n%(listOfRemovedParams)s' % {"listOfRemovedParams":''.join(listOfRemovedParams)}, loggerObj=myLogger, fullLog=runningLog)
							
							## Add params
							createdCount = 0
							for paramName, paramDict in unitProcedureStepDict['operation']['params'].items():
								good, created, error = setOrCreateParameterInBatchMasterLogicObj(currentOperationObj, paramDict['name'], paramDefaultRecordingTypeName, paramDict['type'], paramDict['dataType'], paramDict['value'], paramDict['valueMin'], paramDict['valueMax'], paramCalculation='')
								if good and created: 
									createdCount += 1
								elif not good and debugLogEnabled:
									stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 1,'Error Removing Parameter:\t%(param)s\tError%(error)s' % {"param":paramDict['name'],"error":error}, loggerObj=myLogger, fullLog=runningLog)
							
					if createdCount > 0 or removedCount > 0:
						system.mes.batch.recipe.saveTemplate(currentOperationObjList)
					stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, 'Completed'  + '\tParameters Created: ' + str(createdCount)+ '\t Parameters Removed: ' + str(removedCount), loggerObj=myLogger, fullLog=runningLog)
	
	### INSTANCE PARAMS
	
	###########################################################################
	## Loop tru Procedure Step Parameters to add deferral (Unit Procedure 'Instance' parameters)
	###########################################################################
	for procedureName, procedureDict in dictOfProcedures.items():
		currentProcedureName = procedureDict['name']
		currentProcedureObjList = system.mes.batch.recipe.loadRecipe(system.mes.batch.recipe.getRecipeLink(currentProcedureName, system.mes.batch.recipe.loadRecipeClass(procedureDict['path'], None).asLink()))
		
		if not skipPP: 
			stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, '%(name)s\tStarted Updating Procedure Step(s) Parameter(s) Deferral(s)' % ({'name':currentProcedureName}), loggerObj=myLogger, fullLog=runningLog)
			deferralCount = setParameterDeferralInBatchMasterLogicObject(currentProcedureObjList, procedureDict['steps'], 'unitProcedure')
			stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, 'Completed \tParameters Deferred: %(count)s' % ({'count':deferralCount}), loggerObj=myLogger, fullLog=runningLog)
			currentProcedureObjList[0].setUserVersion(currentProcedureObjList[0].getUserVersion() + 1)	
			system.mes.batch.recipe.saveRecipe(currentProcedureObjList)
		###########################################################################
		## Loop tru Unit Procedure Step Parameters to add deferral (Operation 'Instance' parameters)
		###########################################################################
		for procedureStepName, procedureStepDict in procedureDict['steps'].items():
			currentUnitProcedureName = procedureStepDict['unitProcedure']['name']
			currentUnitProcedureObjList = system.mes.batch.recipe.loadTemplate(system.mes.batch.recipe.getTemplateLink(currentUnitProcedureName, system.mes.batch.recipe.loadTemplateClass(procedureStepDict['unitProcedure']['path'], None).asLink()))
			
			if not skipUP: 
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, '%(name)s\tStarted Updating Unit Procedure Step(s) Parameter(s) Deferral(s)' % ({'name':currentUnitProcedureName}), loggerObj=myLogger, fullLog=runningLog)
				deferralCount = setParameterDeferralInBatchMasterLogicObject(currentUnitProcedureObjList, procedureStepDict['unitProcedure']['steps'], 'operation')
				stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, 'Completed \tParameters Deferred: %(count)s' % ({'count':deferralCount}), loggerObj=myLogger, fullLog=runningLog)
				system.mes.batch.recipe.saveTemplate(currentUnitProcedureObjList)
			###########################################################################
			## Loop tru Unit Procedure Step Parameters to add deferral (Phase 'Instance' parameters)
			###########################################################################
			for unitProcedureStepName, unitProcedureStepDict in procedureStepDict['unitProcedure']['steps'].items():
				currentOperationName = unitProcedureStepDict['operation']['name']
				currentOperationObjList = system.mes.batch.recipe.loadTemplate(system.mes.batch.recipe.getTemplateLink(currentOperationName, system.mes.batch.recipe.loadTemplateClass(unitProcedureStepDict['operation']['path'], None).asLink()))
				
				if not skipOP:
					stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,1, 0, '%(name)s\tStarted Updating Operation Step(s) Parameter(s) Deferral(s)' % ({'name':currentOperationName}), loggerObj=myLogger, fullLog=runningLog)
					deferralCount = setParameterDeferralInBatchMasterLogicObject(currentOperationObjList, unitProcedureStepDict['operation']['steps'], 'phase')
					stageProgress, runningLog = WM_FIRE.util.progressLog(stageProgress,0, 2, 'Completed \tParameters Deferred: %(count)s' % ({'count':deferralCount}), loggerObj=myLogger, fullLog=runningLog)
					system.mes.batch.recipe.saveTemplate(currentOperationObjList)
	return runningLog