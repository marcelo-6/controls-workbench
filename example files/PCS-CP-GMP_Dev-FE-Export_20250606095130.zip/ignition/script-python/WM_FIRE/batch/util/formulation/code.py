'''***************************************************************************************************
	Procedure:          WM_FIRE.batch.util.formulation
	Create Date:       	03Nov22
	Author:             Marcelo Amorim
	Description:        These scripts are used by fomulation views and graphical objects within F.I.R.E library
	Used By:			Formulas View
	****************************************************************************************************
	SUMMARY OF CHANGES
	Version		Date(ddMMMyy)	Author		Comments
	----------------------------------------------------------------------------------------------------
	1.0			03Nov22			MA			Created
	***************************************************************************************************'''
########################################################################################################
##### Global Variables used for multiple/any function defined here
########################################################################################################
# Some procedure parameters returned by the MESObjects are irelevant for us, this is a running list to filter them out
listOfProcedureLevelParametersTofilterOut = ["Command_Number"
,"Step_Active"
,"Propagate_Hold_To_Parent"
,"End_Date_Time"
,"Begin_Date_Time"
,"Duration"
,"Execute_Count"
,"Transition_Expression"
,"Unit_Path"
,"Command"
,"Step_Name"
,"Mode"
,"Step_Sequence"
,"Phase_Exception"
,"State_Number"
,"Manually_Executed"
,"State"
,"Complete"
,"Unit_Procedure_Ref_UUID"
,"Batch_Quantity"
,"Recipe_Name"
,"Batch_Name"
,"Batch_ID"
,"Batch_Scale"
,"Recipe_Version"]

### NamedQuery Paths (so it is not hardcoded anywhere but here)
NQ_getAllFormulasUUIDPath = 'Batch/getAllFormulasUUID'


## How query Recipe Classes (folders)
## defined here are the UUIDs for the Procedures Folder (master recipes used) and the Formulas folders (copies of master recipes since sepasoft currently doesnt have formulation functional)

'''
system.mes.getMESObjectLinkByName('BatchMasterRecipeClass', 'Procedures')
system.mes.getMESObjectLinkByName('BatchMasterRecipeClass', 'Formulas')
'''

########################################################################################################
#### Functions
########################################################################################################

def getAllProcedureParameterValuesList(masterRecipeUUID):
	# This function returns all values for complex properties that are relevant to us for Master Recipes / Procedures
	# name, value, valueMin, valueMax, dataType, uniqueID
	# each in a "row" of data that can be then made to a dataset
	# Arguments are:
		#	masterRecipeUUID	= Master Recipe's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	
	'''
	To filter values out of the list returned use something like the following:
	coulmnsToSkip = [0, 2, 3, 4] # where numbers the order of values returned by this function
	for i in range(len(data)):
		for j in range(len(data[i])):
			if j not in coulmnsToSkip:
				print(data[i][j])
	'''
	
	# Get MES Object that holds procedure core properties
	obj = system.mes.loadMESObject(masterRecipeUUID)
	
	# Get MES Object that holds procedure main logic
	objMainLogicUUID = obj.getPropertyValue('RecipeLogicRefUUID')
	objMainLogic = system.mes.loadMESObject(objMainLogicUUID)
	
	data = []
	
	# Get MES Object that holds procedure main logic
	for item in objMainLogic.getComplexPropertyItemNames('BatchMasterParameters'):
		name = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamFriendlyName')
		value = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamValue')
		valueMin = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamMinimumValue')
		valueMax = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamMaximumValue')
		dataType = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamDataType')
		uniqueID = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamUUID')
		if name not in listOfProcedureLevelParametersTofilterOut:
			data.append([name, value, valueMin, valueMax, dataType, uniqueID])
	return data

def getProcedureParameterNamesValuesList(masterRecipeUUID):
	# This function returns only parameter values and UUID for complex properties that are relevant to us for Master Recipes / Procedures
	# uniqueID, name, value
	# each in a "row" of data that can be then made to a dataset
	# Arguments are:
	#	masterRecipeUUID	= Master Recipe's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	
	# Get MES Object that holds procedure core properties
	obj = system.mes.loadMESObject(masterRecipeUUID)
	
	# Get MES Object that holds procedure main logic
	objMainLogicUUID = obj.getPropertyValue('RecipeLogicRefUUID')
	objMainLogic = system.mes.loadMESObject(objMainLogicUUID)
	
	data = []
	
	# Get MES Object that holds procedure main logic
	for item in objMainLogic.getComplexPropertyItemNames('BatchMasterParameters'):
		name = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamFriendlyName')
		value = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamValue')
		valueMin = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamMinimumValue')
		valueMax = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamMaximumValue')
		uniqueID = objMainLogic.getPropertyValue('BatchMasterParameters.' + item + '.ParamUUID')
		if name not in listOfProcedureLevelParametersTofilterOut:
			data.append([uniqueID, name, value, valueMin, valueMax])
	return data
	
def getProcedureParametersDataset(masterRecipeUUID):
	# This function returns dataset of relevant parameters from procedures
	# uniqueID, name, value
	# Arguments are:
	#	masterRecipeUUID	= Master Recipe's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	
	headers = ["UUID", "Parameter Name", "Default Value", "Minimum", "Maximum"]
	data = getProcedureParameterNamesValuesList(masterRecipeUUID)
	
	finalDataset = system.dataset.toDataSet(headers, data)
	return finalDataset

def getFormulaParametersDataset(masterRecipeUUID, formulaUUID):
	# This function returns dataset of relevant parameters from a procedure and a formula
	# uniqueID, name, default procedure value, value from formula
	# It accounts for parameters being at different orders in MES Objects (all parameter values orders needs to match procedure)
	# Arguments are:
	#	masterRecipeUUID	= Master Recipe's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	#	formulaUUID			= Formula's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	
	# Get Parameter datasets for each UUID
	procedureOnlyDataset = getProcedureParametersDataset(masterRecipeUUID)
	formulaOnlyParameterDataset = getProcedureParametersDataset(formulaUUID)
	
	# Get Formula Name from UUID
	formulaLink = system.mes.getMESObjectLink(formulaUUID)
	formulaName = formulaLink.getName()
	
	# Get list of UUIDs in order ( to match indexs later)
	formulaOnlyUUIDList = formulaOnlyParameterDataset.getColumnAsList(0) #UUID column is 0
	procedureOnlyUUIDList = procedureOnlyDataset.getColumnAsList(0) #UUID column is 0
	tempColumnList = []
	messageMe = []
	
	# Format dataset into a list
	for uuid in procedureOnlyUUIDList:
		# Get correct index of UUID based on master recipe /procedure
		
		formulaIndex = formulaOnlyUUIDList.index(uuid)
		procedureIndex = procedureOnlyUUIDList.index(uuid)
		# 2 is the value column
		# Make sure order is correct (match UUIDs)

		parameterValue = formulaOnlyParameterDataset.getValueAt(formulaIndex, 2)
		tempColumnList.append(parameterValue)
		#messageMe.append('Formula = formulaIndex= %(formulaIndex)s: parameterName= %(parameterName)s parameterUUID= %(parameterUUID)s  parameterValue= %(parameterValue)s uuid=%(uuid)s' % {"formulaIndex":formulaIndex, "parameterName":parameterName,"parameterUUID":parameterUUID, "parameterValue":parameterValue, "uuid":uuid})

	# Remove everything except value column 
	# (add formula values list (sorted to match procedure UUIDs order) to procedure dataset as a new column)	
	finalDataset = system.dataset.addColumn(procedureOnlyDataset, tempColumnList, formulaName, str)
	
	return finalDataset, messageMe


def getAllFormulaParametersDataset(masterRecipeUUID):
	# This function returns a dataset of relevant parameters from all existing formulas in the system for a given procedure
	# it uses the masterRecipe UUID to query MES DB for it using the prefix of the name of MasterRecipe's
	# Arguments are:
	#	masterRecipeUUID	= Master Recipe's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	
	# Get Parameter datasets for each UUID
	procedureOnlyDataset = getProcedureParametersDataset(masterRecipeUUID)

	# Get list of all formulas given a master recipe name
	recipeName = system.mes.getMESObjectLink(masterRecipeUUID).getName()
	
	# Create a Python dictionary of parameters to pass.
	params = {"preFixRecipeName":recipeName + "_"}
	listOfFormulasUUID = []
	
	# Run the Named Query and populate list
	# if named query in a different project, need to pass project name to runNamedQuery function
	resultDataset = system.db.runNamedQuery("Batch/getAllFormulasUUID", params)
	
	finalDataset = procedureOnlyDataset
	
	if resultDataset.getRowCount() > 0:
		# Grab UUIDs from dataset and make into a list
		for row in range(resultDataset.getRowCount()):
			listOfFormulasUUID.append(resultDataset.getValueAt(row, 0))
		
		# for each item in list, create a new column in dataset
		for singleFormulaUUID in listOfFormulasUUID:
			# Get Formula Name from UUID
			formulaLink = system.mes.getMESObjectLink(singleFormulaUUID)
			formulaName = formulaLink.getName()
			
			# Get Parameter datasets for each UUID
			formulaOnlyParameterDataset = getProcedureParametersDataset(singleFormulaUUID)
			
			# Get list of UUIDs in order ( to match indexs later)
			formulaOnlyUUIDList = formulaOnlyParameterDataset.getColumnAsList(0) #UUID column is 0
			procedureOnlyUUIDList = procedureOnlyDataset.getColumnAsList(0) #UUID column is 0
			
			tempColumnList = []
			
			# Format dataset into a list
			for uuid in procedureOnlyUUIDList:
				# Get correct index of UUID based on master recipe /procedure
				
				formulaIndex = formulaOnlyUUIDList.index(uuid)
				# 2 is the value column
				# Make sure order is correct (match UUIDs)
		
				parameterValue = formulaOnlyParameterDataset.getValueAt(formulaIndex, 2)
				tempColumnList.append(parameterValue)
		
			# Remove everything except value column
			
			finalDataset = system.dataset.addColumn(finalDataset, tempColumnList, formulaName, str)
	
	return finalDataset

def createFormula(masterRecipeUUID, formulaName):
	# This function creates a copy of a master recipe using given master recipe UUID
	# Copy will have the following format <Master Recipe / Procedure Name>_<Formula Name>
	# It will return true on success and false on failure
	# Arguments are:
	#	masterRecipeUUID	= Master Recipe's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	#	formulaName			= Formula Name to be created (currently as of 03Nov22 it is not easy to create copies of recipes in a different folder... all sepasoft's fault)
	
	# Get MESObjectLink from UUID
	recipeLink = system.mes.getMESObjectLink(masterRecipeUUID)
	recipeName = recipeLink.getName()
	formulaFullName = recipeName + "_" + formulaName
	
	# Try to copy recipe and create new one with format <Master Recipe / Procedure Name>_<Formula Name>
	try:
		newObj = system.mes.batch.recipe.copyRecipe(recipeLink, formulaFullName)
		newObj[0].setUserVersion(1) # copy recipe return a MESObjectList and the first item on that list [0] is the BatchMasterRecipe object, since it is a new formula. its version should be 1
		system.mes.batch.recipe.saveRecipe(newObj)
		return True
	except:
		return False
		
def checkNewProcedureParameterValueWithinRange(masterRecipeUUID, parameterUUID, newValue):
	# This function returns true if new value is within parameter's defined range
	# The main use for this is when a user makes a change in formula's table to check the entered value's range
	# The table logic should in turn NOT update the dataset if the value is not within range. That makes it easier to
	# make the updates to the MES formula object later since all values in the table dataset will have the proper values
	#NOTE #we dont support strings/enum as of now
	
	# Simplifies the logic to update MES objects
	# Arguments are
	#	masterRecipeUUID	= Master Recipe's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	#	parameterUUID		= Parameter UUID
	#	newValue 			= new value 
	
	# Get MES Object that holds procedure core properties
	obj = system.mes.loadMESObject(masterRecipeUUID)
	
	# Get MES Object that holds procedure main logic
	objMainLogicUUID = obj.getPropertyValue('RecipeLogicRefUUID')
	objMainLogic = system.mes.loadMESObject(objMainLogicUUID)
	
	data = []
	valueMin = 0
	valueMax = 0
	hasValidDataType = False
	newValueCasted = 0
	result = False
	dataType = "error"
	#masterRecipeParameterValue = objMainLogic.getParameterValue(parameterUUID)
	# uniqueID = objMainLogic.getPropertyValue('BatchMasterParameters.' + parameterUUID + '.ParamUUID')
	try:
		newValueCasted = float(newValue)
		# Get min and max and data type
		dataType = objMainLogic.getPropertyValue('BatchMasterParameters.' + parameterUUID + '.ParamDataType')
		if dataType != "String" and dataType != "Date"and dataType != "Boolean" and dataType != "Enum":
			hasValidDataType = True
			valueMin = objMainLogic.getPropertyValue('BatchMasterParameters.' + parameterUUID + '.ParamMinimumValue')
			valueMax = objMainLogic.getPropertyValue('BatchMasterParameters.' + parameterUUID + '.ParamMaximumValue')
		
		# If parameter does have min and max cast as the correct datatype and check agaist NewValue
		if hasValidDataType:
			if dataType == "Float":
				result = True if float(newValue) >= float(valueMin) and float(newValue) <= float(valueMax) else False
				newValueCasted = float(newValue)
			elif dataType == "Integer":
				result = True if int(newValue) >= int(valueMin) and int(newValue) <= int(valueMax) else False
				newValueCasted = int(newValue)
			elif dataType == "Double":
				result = True if double(newValue) >= double(valueMin) and double(newValue) <= double(valueMax) else False
				newValueCasted = double(newValue)
			elif dataType == "Long":
				result = True if long(newValue) >= long(valueMin) and long(newValue) <= long(valueMax) else False
				newValueCasted = long(newValue)
			elif dataType == "Byte":
				result = True if int(newValue) >= int(valueMin) and int(newValue) <= int(valueMax) else False
				newValueCasted = int(newValue)
		return result, valueMin, valueMax, newValue, dataType
	except:
		return result, valueMin, valueMax, newValue, dataType

def updateFormulaFromDataset(formulaUUID, dataset, columnWithParameterValues, columnWithParameterUUIDs):
	# This function updates a formula based on a dataset that contains formula parameter UUIDs and values and its formulaUUID (MES Object)
	# It will return true on success and false on failure. If sucess it will return how many parameter values were changed
	# its purpose it is to be used with a table where users update parameter values in a single column
	# Arguments are:
	#	formulaUUID					= Formula's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	#	dataset						= Dataset that contains the formula parameters values and their UUIDs
	#	columnWithParameterValues	= Column of given dataset that contains the formula parameters values
	#	columnWithParameterUUIDs	= Column of given dataset that contains the formula parameters UUIDs
	
	# Get MESObjectLink from UUID
	formulaLink = system.mes.getMESObjectLink(formulaUUID)
	
	
	# Get MES Object that holds procedure core properties
	#obj = system.mes.loadMESObject(masterRecipeUUID)
	obj = system.mes.batch.recipe.loadRecipe(formulaLink) # this returns a list of MES Objects
	# 0 is BatchMasterRecipe Object, 1 is the Procedure Logic Object (BatchMasterRecipeLogic object), all other objects are UPs and below
	
	data = []
	updateCount = 0
	messageMe = []
	# Try to update values
	try:
		# Loop thru dataset of parameter values and UUIDs and for each UUID update its value on the main MES Object logic
		for row in range(dataset.getRowCount()):
			currentDatasetParameterUUID = dataset.getValueAt(row, columnWithParameterUUIDs)
			currentDatasetParameterValue = dataset.getValueAt(row, columnWithParameterValues)
			currentFormulaParameterValue = obj[1].getParameterValue(currentDatasetParameterUUID) #better way to get param value since it comes with datatype
			
			# check if they are the same, if not, update
			if str(currentDatasetParameterValue) != str(currentFormulaParameterValue): # this assumes value ranges have been checked to be within already
				#messageMe.append('Started updating a Parameter(count= %(updateCount)s: currentDatasetParameterUUID= %(currentDatasetParameterUUID)s currentDatasetParameterValue= %(currentDatasetParameterValue)s  currentFormulaParameterValue= %(currentFormulaParameterValue)s' % {"currentDatasetParameterUUID":currentDatasetParameterUUID, "currentDatasetParameterValue":currentDatasetParameterValue,"currentFormulaParameterValue":currentFormulaParameterValue, "updateCount":updateCount})
				obj[1].setParameterValue(currentDatasetParameterUUID, currentDatasetParameterValue)
				currentFormulaParameterValue = obj[1].getParameterValue(currentDatasetParameterUUID)
				# keep count of how many were actually updated
				updateCount += 1
				#messageMe.append('Updated a Parameter(count= %(updateCount)s: currentDatasetParameterUUID= %(currentDatasetParameterUUID)s currentDatasetParameterValue= %(currentDatasetParameterValue)s  currentFormulaParameterValue= %(currentFormulaParameterValue)s' % {"currentDatasetParameterUUID":currentDatasetParameterUUID, "currentDatasetParameterValue":currentDatasetParameterValue,"currentFormulaParameterValue":currentFormulaParameterValue, "updateCount":updateCount})
				#print messageMe
		if updateCount > 0:
			# Increment recipe version since there is a change
			#currentVersion = obj[0].getUserVersion()
			obj[0].setUserVersion(obj[0].getUserVersion() + 1)
			system.mes.batch.recipe.saveRecipe(obj)
		return True, updateCount, messageMe
	except Exception as e:
		return False, updateCount, e
		
def updateFormulaFromProcedureUUID(masterRecipeUUID, formulaUUID):
	# This function updates a formula based on a procedure (MESObject masterRecipe)
	# It will copy new recipe, update copi'ed recipe values with existing formula (as possible ussing matching parameter UUIDs)
	# then delete old formula and save new formula (while restarting the version of that formula back to 1)
	# It will return true on success and false on failure it also returns the formulaName that was updated
	# its purpose it is to be used for when a recipe change is made (parameter name changed, parameter added, parameter removed, and or logic changed)
	# Arguments are:
	#	formulaUUID					= Formula's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	#	masterRecipeUUID			= Master Recipe's MESObject UUID (obtained from MESObjectSelector perspective object for example)
	
	import random
	updateCount = 0
	oldFormulaName = ''
	try:
		# Load old formula MES Object and Get name of old formula and load it
		oldFormulaLink = system.mes.getMESObjectLink(formulaUUID)
		oldFormulaName = oldFormulaLink.getName()
		oldFormulaObjectList = system.mes.batch.recipe.loadRecipe(oldFormulaLink)
		oldFormulaVersion = oldFormulaObjectList[0].getUserVersion()
		
		# Create copy of master recipe (procedure)
		updatedRecipeLink = system.mes.getMESObjectLink(masterRecipeUUID)
		system.mes.batch.recipe.removeRecipe(oldFormulaLink)
		
		# remove any lingering "{}" in formula name (hapends when formula was already "disabled" or "removed" from MES DB
		
		#newFormulaName = oldFormulaName + "_" + str(random.randint(0,99999))
		newFormulaMESObjectList = system.mes.batch.recipe.copyRecipe(updatedRecipeLink, oldFormulaName)
		
		# Try to update values as possible (needs to match UUID, and it will ignore and not update any other matches)

		# list of UUID params
		listOfparamUUIDsFromOldFormula = oldFormulaObjectList[1].getComplexPropertyItemNames('BatchMasterParameters')
		cleanedUpListOfparamUUIDsFromOldFormula = []
		for item in listOfparamUUIDsFromOldFormula:
			name = oldFormulaObjectList[1].getPropertyValue('BatchMasterParameters.' + item + '.ParamFriendlyName')
			
			if name not in listOfProcedureLevelParametersTofilterOut:
				cleanedUpListOfparamUUIDsFromOldFormula.append(item)
		
		# Loop thru dataset of parameter values and UUIDs and for each UUID update its value on the main MES Object logic
		for parameterUUID in cleanedUpListOfparamUUIDsFromOldFormula:
			
			# Only Try to add if new formula has that parameter (UUID match)
			#if newFormulaMESObjectList[1].getParameterByUUI(parameterUUID):
			currentFormulaParameterValue = oldFormulaObjectList[1].getParameterValue(parameterUUID)
			valuee = oldFormulaObjectList[1].getPropertyValue('BatchMasterParameters.' + parameterUUID + '.ParamValue')
			paramName = oldFormulaObjectList[1].getPropertyValue('BatchMasterParameters.' + parameterUUID + '.ParamFriendlyName')
			#messageMe = 'currentFormulaParameterValue= %(currentFormulaParameterValue)s paramName= %(paramName)s  parameterUUID= %(parameterUUID)s' % {"currentFormulaParameterValue":currentFormulaParameterValue, "paramName":paramName,"parameterUUID":parameterUUID}
			#print messageMe
			#Check if within range (only update if it is)
			if currentFormulaParameterValue != None:
				resultRangeCheckPass, valueMin, valueMax, newValueCasted, dataType = checkNewProcedureParameterValueWithinRange(masterRecipeUUID, parameterUUID, currentFormulaParameterValue)
				
				if resultRangeCheckPass:
					newFormulaMESObjectList[1].setParameterValue(parameterUUID, currentFormulaParameterValue)
					
					# keep count of how many were actually updated
					updateCount += 1
		
		# Increment recipe version since there is a change
		newFormulaMESObjectList[0].setUserVersion(oldFormulaVersion + 1)
		system.mes.batch.recipe.saveRecipe(newFormulaMESObjectList)
		
		return True, updateCount, "" , oldFormulaName
	except Exception as e:
		return False, updateCount, e, oldFormulaName