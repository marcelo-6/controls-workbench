def doGet(request, session):
	html = """
	    <html>
	    <head>
	      <script src='https://cdn.plot.ly/plotly-3.0.1.min.js'></script>
	    </head>
	    <body>
	        <div id='tester'><!-- Plotly chart will be drawn inside this DIV --></div>
	        <script>
	            TESTER = document.getElementById('tester');
	            Plotly.newPlot( TESTER, [{
	            x: [1, 2, 3, 4, 5],
	            y: [1, 2, 4, 8, 16] }], {
	            margin: { t: 0 } } );
	       </script>
	    </body>
	    </html>
		"""
	return {'html': html}