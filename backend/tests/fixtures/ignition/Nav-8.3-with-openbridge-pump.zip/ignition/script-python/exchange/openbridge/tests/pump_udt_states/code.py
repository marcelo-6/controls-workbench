# openbridge.tests.pump_udt_states
"""
Pump UDT UI test cycle (Ignition Jython 2.7)

Writes known combinations of pump states into a Pump UDT instance so you can
visually confirm your Perspective graphics (badges, alarm border, labels, etc).

Pump UDT naming conventions (base_path points to folder):
  - Speed     (float)
  - Setpoint  (float)
  - Status    (int bitmask)
  - Alarm     (int/bool; non-zero/True means alarm)
  - _Metadata (document)

This test uses the SINGLE SOURCE OF TRUTH spec:
  project.openbridge.pump

Usage (Script Console):
  from project.openbridge.tests import pump_udt_states
  pump_udt_states.run("[default]Site 1/.../Pump", delay_ms=500)
"""

import time
from exchange.openbridge import pump as pump_spec


def _build_status_word(
    running=False,
    faulted=False,
    interlocked=False,
    local_mode=False,
    auto=False,
    manual=False,
    cmd_source=0  # 0=Operator, 1=Program, 2=Remote, 3=Other
):
    """
    Build Status using openbridge.pump bit definitions so UI/test cannot drift.
    """
    w = 0

    def set_bit(bit, enabled):
        return (1 << bit) if enabled else 0

    # Basic
    w |= set_bit(pump_spec.BITS["RUNNING"], running)
    w |= set_bit(pump_spec.BITS["FAULTED"], faulted)
    w |= set_bit(pump_spec.BITS["INTERLOCKED"], interlocked)

    # Modes
    w |= set_bit(pump_spec.BITS["LOCAL"], local_mode)
    w |= set_bit(pump_spec.BITS["AUTO"], auto)
    w |= set_bit(pump_spec.BITS["MANUAL"], manual)

    # Cmd source packed into bits 11..12
    cmd_source = int(cmd_source) & 0x3
    w |= (cmd_source << pump_spec.CMD_SOURCE_BITS[0])

    return int(w)


def _write(paths, values):
    """Write tags using writeBlocking when available, else fallback."""
    try:
        system.tag.writeBlocking(paths, values)
    except:
        # fallback (older contexts)
        for p, v in zip(paths, values):
            system.tag.write(p, v)


def run(base_path, delay_ms=800):
    """
    Run a single test cycle against a Pump UDT instance.

    Args:
        base_path (str): Tag folder path to the pump instance.
        delay_ms (int): Delay between states (milliseconds).
        write_metadata (bool): If True, writes _Metadata so you can validate popups.
    """
    log = system.util.getLogger("OB.PumpTest")

    speed_tag = base_path + "/Speed"
    sp_tag = base_path + "/Setpoint"
    status_tag = base_path + "/Status"
    alarm_tag = base_path + "/Alarm"
    meta_tag = base_path + "/_Metadata"

    tests = [
        # name, status_kwargs, alarm_value
        ("STOPPED / Operator", dict(running=False, auto=False, manual=False, local_mode=False, cmd_source=0), 0),

        ("RUNNING / Auto / Operator", dict(running=True, auto=True, manual=False, local_mode=False, cmd_source=0), 0),
        ("RUNNING / Auto / Program",  dict(running=True, auto=True, manual=False, local_mode=False, cmd_source=1), 0),
        ("RUNNING / Auto / Remote",   dict(running=True, auto=True, manual=False, local_mode=False, cmd_source=2), 0),

        ("RUNNING / Manual / Operator", dict(running=True, auto=False, manual=True, local_mode=False, cmd_source=0), 0),
        ("LOCAL MODE",                  dict(running=False, auto=False, manual=False, local_mode=True, cmd_source=0), 0),

        ("INTERLOCKED", dict(running=False, interlocked=True, auto=False, manual=False, local_mode=False, cmd_source=0), 0),

        # Alarm border checks (your decode() uses Alarm>0 OR Faulted bit)
        ("FAULTED (bit)",        dict(running=False, faulted=True, cmd_source=0), 0),
        ("ALARM (Alarm tag)",    dict(running=False, faulted=False, cmd_source=0), 1),

        ("STOPPED / Other source", dict(running=False, cmd_source=3), 0),
    ]

    log.info("Starting pump UDT test cycle at: %s" % base_path)

    speed = 100.5
    sp = 50.5

    for (name, kwargs, alarm_val) in tests:
        speed += 5.5
        sp += 1.5

        status_val = _build_status_word(**kwargs)

        log.info("TEST: %s | Speed=%.2f SP=%.2f Status=%d Alarm=%d" %
                 (name, speed, sp, status_val, alarm_val))

        _write(
            [speed_tag, sp_tag, status_tag, alarm_tag],
            [speed, sp, status_val, int(alarm_val)]
        )

        time.sleep(float(delay_ms) / 1000.0)

    # Reset safe at end
    log.info("Pump UDT test complete. Resetting STOPPED / no alarm.")
    reset_status = _build_status_word(running=False, cmd_source=0)
    _write(
        [speed_tag, sp_tag, status_tag, alarm_tag],
        [100.0, 50.0, reset_status, 0]
    )