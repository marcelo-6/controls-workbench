# openbridge.pump
"""
Pump status decoding helpers (Ignition / Perspective).

This module is the **single source of truth** for how a Pump UDT encodes UI-relevant
information into a packed integer `Status` word (bitmask), and how the Perspective
UI should interpret it.

Why this exists
---------------
When you have hundreds of pumps, it’s easy to end up with duplicated/fragmented logic:
multiple bindings all doing their own `getBit(...)` math, drifting enums, and hard-to-review
changes. This module centralizes:

- Bit positions for `Status` (running/fault/interlock/modes)
- Command Source encoding (2 bits packed into Status)
- UI badge decisions (mode/alarm/interlock/cmd source)
- A single `decode(...)` output object that the UI binds to everywhere

Expected Pump UDT tag naming (your conventions)
-----------------------------------------------
- Status    : Int (bitmask)
- Alarm     : Int/Bool (non-zero/True means alarm condition present)
- Command   : Int (bitmask; not decoded here)
- Setpoint  : Float
- Speed     : Float
- _Metadata : Document (instance configuration)

_Metadata document schema (example)
-----------------------------------
{
  "label": "Pump-01",
  "description": "Pump 01",
  "step": { "small": 10, "large": 100 }
}

UI usage pattern (recommended)
------------------------------
1) Bind Status / Alarm / _Metadata into a single Script Transform that calls:
      openbridge.pump.decode(Status, Alarm, _Metadata)
2) Store the returned dict into a view custom property (Document), e.g.:
      view.custom.pumpUi
3) Bind all icon badges / labels / classes to view.custom.pumpUi.* (no duplicated bit logic)

Notes
-----
- This code is **Jython 2.7 compatible** (no Python 3-only syntax).
- Command source is packed into Status bits 11..12 (2-bit value 0..3).
"""

# Single source of truth for Pump Status bit layout + UI badge mapping

BITS = {
    # Basic
    "RUNNING": 0,
    "FAULTED": 1,
    "INTERLOCKED": 2,

    # Modes
    "LOCAL": 4,
    "REMOTE": 5,   # optional, not used for badge unless you want it
    "AUTO": 6,
    "MANUAL": 7,
}

# Command Source packed into Status word bits 11..12 (LSB, MSB)
CMD_SOURCE_BITS = (11, 12)

CMD_SOURCES = {
    0: {"label": "Operator", "icon": "material/person",           "tooltip": "Command Source: Operator"},
    1: {"label": "Program",  "icon": "material/memory",           "tooltip": "Command Source: Program"},
    2: {"label": "Remote",   "icon": "material/desktop_windows",  "tooltip": "Command Source: Remote"},
    3: {"label": "Other",    "icon": "material/help_outline",     "tooltip": "Command Source: Other"},
}

MODE_BADGES = {
    "AUTO":   {"label": "Auto",   "icon": "material/brightness_auto", "tooltip": "Mode: Auto"},
    "MANUAL": {"label": "Manual", "icon": "material/touch_app", "tooltip": "Mode: Manual"},
    "LOCAL":  {"label": "Local",  "icon": "material/handyman",  "tooltip": "Mode: Local"},
}


def _get_bit(word, bit):
    """
    Return True if a given bit index is set in `word`.

    Args:
        word (int): Packed integer bitmask (e.g., Pump/Status).
        bit (int): Bit position to read (0 = LSB).

    Returns:
        bool: True if (word >> bit) & 1 == 1, else False.
    """
    return ((int(word) >> int(bit)) & 1) == 1


def decode_cmd_source(status_word):
    """
    Decode the 2-bit Command Source value from the Status word.

    Encoding
    --------
    Uses two bits (CMD_SOURCE_BITS) inside Status:
        value = (LSB ? 1 : 0) + (MSB ? 2 : 0)

    Values
    ------
        0 -> Operator
        1 -> Program
        2 -> Remote
        3 -> Other

    Args:
        status_word (int): Packed Pump Status word.

    Returns:
        tuple:
            - (int) cmd_source_value in range 0..3
            - (dict) metadata dict: {"label": <str>, "icon": <str>}
    """
    lsb, msb = CMD_SOURCE_BITS
    value = (1 if _get_bit(status_word, lsb) else 0) + (2 if _get_bit(status_word, msb) else 0)
    return value, CMD_SOURCES.get(value, CMD_SOURCES[3])


def decode_basic_state(status_word):
    """
    Derive a single "basic state" label from the Status word.

    Priority
    --------
    Faulted > Running > Stopped

    Notes
    -----
    Interlock is handled separately as its own badge, because it often overlays
    other states without being the "primary" state text.

    Args:
        status_word (int): Packed Pump Status word.

    Returns:
        dict: {"key": <str>, "label": <str>}
              key is one of: FAULTED, RUNNING, STOPPED
    """
    if _get_bit(status_word, BITS["FAULTED"]):
        return {"key": "FAULTED", "label": "Faulted"}
    if _get_bit(status_word, BITS["RUNNING"]):
        return {"key": "RUNNING", "label": "Running"}
    return {"key": "STOPPED", "label": "Stopped"}


def decode_mode_badge(status_word):
    """
    Return UI badge metadata for the pump mode (Auto/Manual/Local).

    Priority
    --------
    Local > Auto > Manual > None

    Args:
        status_word (int): Packed Pump Status word.

    Returns:
        dict: {"key": <str>, "label": <str>, "icon": <str>, "visible": <bool>}
              key is one of: LOCAL, AUTO, MANUAL, NONE
    """
    if _get_bit(status_word, BITS["LOCAL"]):
        d = dict(MODE_BADGES["LOCAL"])
        d.update({"key": "LOCAL", "visible": True})
        return d

    if _get_bit(status_word, BITS["AUTO"]):
        d = dict(MODE_BADGES["AUTO"])
        d.update({"key": "AUTO", "visible": True})
        return d

    if _get_bit(status_word, BITS["MANUAL"]):
        d = dict(MODE_BADGES["MANUAL"])
        d.update({"key": "MANUAL", "visible": True})
        return d

    return {"key": "NONE", "label": "", "icon": "material/help_outline", "visible": False}


def decode(status_word, alarm_word):
    """
    Decode the Pump UDT runtime values into a single JSON-friendly object for UI bindings.

    Intended usage
    --------------
    Call this from a Perspective Script Transform and store the return value into
    a view custom Document property (e.g. view.custom.pumpUi). Bind your icon badges,
    alarm border class, and status labels to fields in the returned object.

    Alarm logic
    -----------
    `hasAlarm` becomes True when:
      - alarm_word > 0  OR
      - the FAULTED bit is set in Status

    Args:
        status_word (int|None): Pump Status bitmask.
        alarm_word (int|bool|None): Alarm indicator; non-zero/True means alarm present.

    Returns:
        dict: A JSON-friendly dictionary with stable keys:

              "status": {
                "word": int,
                "basicState": {"key": str, "label": str},
                "interlocked": bool,
                "faulted": bool,
                "hasAlarm": bool
              },
              "badges": {
                "mode": {"key": str, "label": str, "icon": str, "visible": bool},
                "alarm": {"visible": bool, "icon": str, "label": str},
                "interlock": {"visible": bool, "icon": str, "label": str},
                "cmdSource": {"visible": bool, "value": int, "label": str, "icon": str}
              }
            }
    """
    try:
        status_word = int(status_word)
    except:
        status_word = 0

    try:
        alarm_word = int(alarm_word)
    except:
        alarm_word = 0

    basic = decode_basic_state(status_word)
    mode = decode_mode_badge(status_word)

    cmd_src_val, cmd_src = decode_cmd_source(status_word)

    interlocked = _get_bit(status_word, BITS["INTERLOCKED"])
    faulted = _get_bit(status_word, BITS["FAULTED"])

    has_alarm = (alarm_word > 0) or faulted

    return {
        "status": {
            "word": status_word,
            "basicState": basic,
            "interlocked": interlocked,
            "faulted": faulted,
            "hasAlarm": has_alarm,
        },
        "badges": {
            "mode": mode,  # now includes tooltip
            "alarm": {
                "visible": has_alarm,
                "icon": "material/error",
                "label": "Alarm",
                "tooltip": "Alarm Active" if has_alarm else "No Alarm"
            },
            "interlock": {
                "visible": True,
                "icon": "material/lock" if interlocked else "material/lock_open",
                "label": "Interlock",
                "tooltip": "Interlock Active" if interlocked else "No Interlock"
            },
            "cmdSource": {
                "visible": True,
                "value": cmd_src_val,
                "label": cmd_src["label"],
                "icon": cmd_src["icon"],
                "tooltip": cmd_src.get("tooltip", "Command Source")
            }
        }
    }